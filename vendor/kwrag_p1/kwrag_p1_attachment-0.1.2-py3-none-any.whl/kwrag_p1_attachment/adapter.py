"""Streaming admission and KWRAG ABI adapter for the selected FTS factory."""

from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import stat
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping
from urllib.parse import quote

from kwrag_p1_attachment.factory import (
    BACKEND_ID,
    ContractError,
    FtsAttachmentPipeline,
)


_SHA256 = re.compile(r"^sha256:[0-9a-f]{64}$")
_RESOURCE_KEYS = set(
    "schema status observationDigest observedAt ttlSeconds targetInstanceId "
    "containerIdentityDigest cgroupIdentityDigest profileDigest "
    "requiredCpuMillicores requiredMemoryBytes requiredPids "
    "containerCpuUsedMillicores containerMemoryUsedBytes containerPidsUsed "
    "hostCpuAvailableMillicores hostMemoryAvailableBytes hostPidsAvailable".split()
)
_BINDING_KEYS = set(
    "schema proofMode enabled family instanceId runtimeProfileDigest containerNasRoot "
    "transport hostPortCount mountReadOnly componentDigest contractDigest "
    "resourceProfileDigest p1Identity attachmentData".split()
)
_DATA_KEYS = set(
    "databaseSha256 indexManifestDigest sourceSnapshotDigest "
    "readOnlyAuthorityReceiptDigest slotRuntimeBindingDigest".split()
)
_CONSUMPTION_KEYS = set(
    "schema_version consumer_family attachment_status consumption_status "
    "provider_dispatch_attempted instance_id binding_digest resource_observation_digest "
    "component_digest p1_identity_digest attachment_data_digest request_id operation_id "
    "run_id attempt result_status result_count result_digest operation_receipt_digest "
    "result_receipt_digest".split()
)


def _digest(value: object) -> str:
    text = str(value or "")
    if not _SHA256.fullmatch(text):
        raise ContractError("digest is invalid")
    return text


def _read_stable_file(path: Path, label: str, maximum_bytes: int) -> bytes:
    source = Path(path)
    if not source.is_absolute() or source.is_symlink():
        raise ContractError(f"{label} is unavailable")
    flags = (
        os.O_RDONLY
        | getattr(os, "O_BINARY", 0)
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
    )
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise ContractError(f"{label} is unavailable") from exc
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or not 0 < before.st_size <= maximum_bytes
        ):
            raise ContractError(f"{label} file identity is invalid")
        chunks: list[bytes] = []
        total = 0
        while chunk := os.read(descriptor, 64 * 1024):
            total += len(chunk)
            if total > maximum_bytes:
                raise ContractError(f"{label} is too large")
            chunks.append(chunk)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
            before.st_ctime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ):
            raise ContractError(f"{label} changed while loading")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def load_canonical_mapping(path: Path, label: str) -> tuple[dict[str, Any], str]:
    """Load one bounded canonical JSON mapping from a stable descriptor."""

    raw = _read_stable_file(path, label, 256 * 1024)
    value = json.loads(raw)
    if (
        not isinstance(value, dict)
        or raw
        != json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode()
    ):
        raise ContractError(f"{label} is not canonical JSON")
    return value, "sha256:" + hashlib.sha256(raw).hexdigest()


def load_receipt(path: Path, digest: str | None, label: str) -> dict[str, Any]:
    """Resolve exactly one canonical receipt from a stable bounded ledger."""

    matches = []
    for line in _read_stable_file(path, label, 8 * 1024 * 1024).splitlines():
        value = json.loads(line)
        if (
            isinstance(value, dict)
            and line
            == json.dumps(
                value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ).encode()
            and (
                digest is None or "sha256:" + hashlib.sha256(line).hexdigest() == digest
            )
        ):
            matches.append(value)
    if len(matches) != 1:
        raise ContractError(f"{label} receipt linkage is invalid")
    return matches[0]


def validate_attachment_binding(
    value: Mapping[str, Any],
    *,
    digest: str,
    expected_digest: str,
    component_digest: str,
    contract_digest: str,
    resource_profile_digest: str,
    p1_identity: Mapping[str, Any],
) -> None:
    """Validate the exact Hermes private binding-v2 profile."""

    if set(value) != _BINDING_KEYS or digest != expected_digest:
        raise ContractError("attachment binding fields or digest are invalid")
    if (
        value["schema"] != "agent-runtime-retrieval-binding/v2"
        or value["proofMode"] != "attachment_only"
        or value["family"] != "hermes"
        or value["containerNasRoot"] != "/workspace/nas_docs"
        or value["transport"] != "in_process"
        or isinstance(value["hostPortCount"], bool)
        or not isinstance(value["hostPortCount"], int)
        or value["hostPortCount"] != 0
        or value["mountReadOnly"] is not True
        or value["componentDigest"] != component_digest
        or value["contractDigest"] != contract_digest
        or value["resourceProfileDigest"] != resource_profile_digest
        or value["p1Identity"] != p1_identity
    ):
        raise ContractError("attachment binding is not the approved Hermes P1 profile")
    _digest(value["runtimeProfileDigest"])
    if not isinstance(value["instanceId"], str) or not re.fullmatch(
        r"[A-Za-z0-9][A-Za-z0-9._:-]{0,191}", value["instanceId"]
    ):
        raise ContractError("attachment target identity is invalid")
    if value["enabled"] is True:
        data = value["attachmentData"]
        if not isinstance(data, Mapping) or set(data) != _DATA_KEYS:
            raise ContractError("enabled attachment data fields are invalid")
        for field in _DATA_KEYS:
            _digest(data[field])
    elif value["enabled"] is not False or value["attachmentData"] is not None:
        raise ContractError("disabled attachment binding retains live data")


def validate_receipt_linkage(
    consumption: Mapping[str, Any],
    operation: Mapping[str, Any],
    result: Mapping[str, Any],
    *,
    binding: Mapping[str, Any],
    observation_digest: str,
    component_digest: str,
    runtime_binding_digest: str,
    index_manifest_digest: str,
    binding_digest: str,
    p1_identity_digest: str,
    attachment_data_digest: str,
) -> None:
    """Validate operation-to-result-to-not-consumed attachment linkage."""

    common = (
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "result_status",
        "result_count",
        "result_digest",
    )
    if (
        set(consumption) != _CONSUMPTION_KEYS
        or consumption["schema_version"]
        != "hermes-kwrag-p1-attachment-consumption-receipt-v1"
        or consumption["consumer_family"] != "hermes"
        or consumption["attachment_status"] != "verified"
        or consumption["consumption_status"] != "not_consumed"
        or consumption["provider_dispatch_attempted"] is not False
        or consumption["instance_id"] != binding["instanceId"]
        or consumption["binding_digest"] != binding_digest
        or consumption["resource_observation_digest"] != observation_digest
        or consumption["component_digest"] != component_digest
        or consumption["p1_identity_digest"] != p1_identity_digest
        or consumption["attachment_data_digest"] != attachment_data_digest
        or any(
            result.get(key) != consumption[key]
            or operation.get(key) != consumption[key]
            for key in common
        )
        or result.get("operation_receipt_digest")
        != consumption["operation_receipt_digest"]
        or result.get("schema_version") != "hermes-kwrag-result-receipt-v1"
        or result.get("consumer_family") != "hermes"
        or result.get("adapter_status") != "verified_by_product_adapter"
        or result.get("component_digest") != component_digest
        or result.get("runtime_binding_digest") != runtime_binding_digest
        or result.get("index_manifest") != index_manifest_digest
        or result.get("pipeline_fingerprint")
        != binding["p1Identity"]["pipelineFingerprint"]
        or operation.get("schema_version") != "kwrag-slot-search-operation-receipt-v1"
        or operation.get("authorization_basis") != "slot_mounted_storage"
        or operation.get("execution_status") != "completed"
        or operation.get("index_manifest") != index_manifest_digest
        or operation.get("pipeline_fingerprint")
        != binding["p1Identity"]["pipelineFingerprint"]
        or operation.get("pipeline_evidence", {}).get("schema_version")
        != "kwrag-slot-pipeline-evidence-v1"
        or operation.get("pipeline_evidence", {}).get("backend_id")
        != binding["p1Identity"]["backendId"]
        or operation
        .get("pipeline_evidence", {})
        .get("data_boundary", {})
        .get("bytes_sent_outside_slot")
        != 0
        or operation
        .get("pipeline_evidence", {})
        .get("data_boundary", {})
        .get("external_persistence")
        != "not_applicable"
    ):
        raise ContractError("attachment receipt linkage is invalid")


def validate_resource_observation(
    value: Mapping[str, Any],
    *,
    profile_digest: str,
    instance_id: str,
    container_identity_digest: str,
    cgroup_identity_digest: str,
    cpu_reservation: int,
    memory_reservation: int,
    pids_reservation: int,
) -> int:
    """Validate a fresh call-scoped measurement and return memory headroom."""

    if set(value) != _RESOURCE_KEYS:
        raise ContractError("resource observation fields are invalid")
    body = dict(value)
    observed_digest = _digest(body.pop("observationDigest"))
    raw = json.dumps(
        body, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != observed_digest:
        raise ContractError("resource observation digest is invalid")
    try:
        observed = datetime.fromisoformat(str(value["observedAt"]))
    except (TypeError, ValueError) as exc:
        raise ContractError("resource observation time is invalid") from exc
    ttl = value["ttlSeconds"]
    if observed.tzinfo is None or isinstance(ttl, bool) or not isinstance(ttl, int):
        raise ContractError("resource observation time is invalid")
    age = (
        datetime.now(timezone.utc) - observed.astimezone(timezone.utc)
    ).total_seconds()
    expected = {
        "requiredCpuMillicores": cpu_reservation,
        "requiredMemoryBytes": memory_reservation,
        "requiredPids": pids_reservation,
    }
    if (
        value["schema"] != "agent-runtime-retrieval-headroom/v1"
        or value["status"] != "within_required_headroom"
        or value["profileDigest"] != profile_digest
        or value["targetInstanceId"] != instance_id
        or value["containerIdentityDigest"] != container_identity_digest
        or value["cgroupIdentityDigest"] != cgroup_identity_digest
        or not 1 <= ttl <= 3600
        or not -5 <= age <= ttl
        or any(value[key] != expected_value for key, expected_value in expected.items())
    ):
        raise ContractError("resource observation is stale, foreign, or mismatched")
    measured = [
        value[key]
        for key in (
            "requiredCpuMillicores",
            "requiredMemoryBytes",
            "requiredPids",
            "containerCpuUsedMillicores",
            "containerMemoryUsedBytes",
            "containerPidsUsed",
            "hostCpuAvailableMillicores",
            "hostMemoryAvailableBytes",
            "hostPidsAvailable",
        )
    ]
    if any(
        isinstance(item, bool) or not isinstance(item, int) or item < 0
        for item in measured
    ):
        raise ContractError("resource measurements are invalid")
    if (
        value["containerCpuUsedMillicores"] > cpu_reservation
        or value["containerMemoryUsedBytes"] >= memory_reservation
        or value["containerPidsUsed"] > pids_reservation
        or value["hostCpuAvailableMillicores"] < cpu_reservation
        or value["hostMemoryAvailableBytes"] < memory_reservation
        or value["hostPidsAvailable"] < pids_reservation
    ):
        raise ContractError("resource observation exceeds the declared reservation")
    return memory_reservation - value["containerMemoryUsedBytes"]


def _open_verified(
    database_path: Path, binding: dict[str, object], maximum_bytes: int
) -> FtsAttachmentPipeline:
    required = {
        "databaseSha256",
        "readOnlyAuthorityReceiptDigest",
        "sourceSnapshotDigest",
    }
    if set(binding) != required or any(
        not _SHA256.fullmatch(str(binding[key])) for key in required
    ):
        raise ContractError("attachment data fields are invalid")
    path = Path(database_path)
    if path.is_symlink() or not path.is_file():
        raise ContractError("database must be a regular non-symlink file")
    resolved = path.resolve(strict=True)
    descriptor = os.open(
        resolved,
        os.O_RDONLY
        | getattr(os, "O_BINARY", 0)
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0),
    )
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_size <= 0
            or before.st_size > maximum_bytes
        ):
            raise ContractError("database exceeds measured memory headroom")
        digest = hashlib.sha256()
        while chunk := os.read(descriptor, 1024 * 1024):
            digest.update(chunk)
        after = os.fstat(descriptor)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise ContractError("database changed while hashing")
        if "sha256:" + digest.hexdigest() != binding["databaseSha256"]:
            raise ContractError("database digest mismatch")
    finally:
        os.close(descriptor)
    connection = sqlite3.connect(
        "file:" + quote(str(resolved)) + "?mode=ro&immutable=1", uri=True
    )
    tables = {
        str(row[0])
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        )
    }
    if not {"turns", "turn_mids", "turns_fts"}.issubset(tables):
        connection.close()
        raise ContractError("required FTS schema is absent")
    pipeline = FtsAttachmentPipeline.__new__(FtsAttachmentPipeline)
    pipeline._connection = connection
    pipeline.binding = {
        "databaseSha256": binding["databaseSha256"],
        "authority": {
            "mode": "slot_local_read_only_nas",
            "readOnlyObserved": True,
            "receiptDigest": binding["readOnlyAuthorityReceiptDigest"],
        },
        "sourceSnapshotDigest": binding["sourceSnapshotDigest"],
    }
    return pipeline


def build_p1_runtime(
    runtime: Mapping[str, Any],
    runtime_digest: str,
    binding: Mapping[str, Any],
    mount: Path,
    receipt_path: Path,
    room: str,
    maximum_bytes: int,
    pipeline_fingerprint: str,
):
    """Bind the selected P1 pipeline to the public KWRAG runtime ABI."""

    from kwrag.slot_runtime import SlotRuntimeSpec, build_slot_runtime

    data = binding["attachmentData"]
    if runtime_digest != data["slotRuntimeBindingDigest"]:
        raise ContractError("slot runtime binding digest is not attached")
    spec = SlotRuntimeSpec.from_mapping(runtime)
    if (
        spec.mount_root != mount
        or spec.index_manifest_digest != data["indexManifestDigest"]
        or spec.pipeline_fingerprint != pipeline_fingerprint
        or spec.receipt_path != receipt_path
        or spec.max_concurrent != 1
    ):
        raise ContractError("slot runtime binding is invalid")
    holder: list[KwragFtsPipeline] = []
    runtime_object = build_slot_runtime(
        spec,
        pipeline_factory=lambda scope: (
            holder.append(KwragFtsPipeline(scope, data, room, maximum_bytes))
            or holder[0]
        ),
    )
    return spec, runtime_object, holder[0]


class KwragFtsPipeline:
    """The selected factory projected into KWRAG's backend-neutral ABI."""

    def __init__(
        self,
        scope: Any,
        attachment_data: Mapping[str, Any],
        room: str,
        maximum_bytes: int,
    ):
        from kwrag.slot_mount import resolve_mounted_path

        if scope.manifest.corpus_snapshot != attachment_data["sourceSnapshotDigest"]:
            raise ContractError("source snapshot is not bound")
        files = scope.manifest.raw.get("rooms", {}).get(room, {}).get("files", [])
        matches = [
            item
            for item in files
            if isinstance(item, Mapping)
            and item.get("sha256") == attachment_data["databaseSha256"]
        ]
        if len(matches) != 1:
            raise ContractError("FTS database is not uniquely bound")
        relative = PurePosixPath(
            scope.index_root.relative_to(scope.mount_root).as_posix()
        ) / PurePosixPath(str(matches[0]["path"]))
        database = resolve_mounted_path(scope.mount_root, relative, kind="file")
        self.database_size = database.stat().st_size
        self.room = room
        self.pipeline = _open_verified(
            database,
            {
                key: attachment_data[key]
                for key in (
                    "databaseSha256",
                    "readOnlyAuthorityReceiptDigest",
                    "sourceSnapshotDigest",
                )
            },
            maximum_bytes,
        )

    def close(self) -> None:
        self.pipeline.close()

    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]:
        if rooms != [self.room]:
            raise ContractError("P1 search escaped its bound room")
        raw = self.pipeline.search(query)
        hits = [
            {
                "room": self.room,
                "level": "turn",
                "seg_id": item["unitId"],
                "text": item["text"],
                "score": item["score"],
                "message_ids": item["sourceIds"],
            }
            for item in raw[:k]
        ]
        return {
            "hits": hits,
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": BACKEND_ID,
                "stages": [
                    {
                        "stage_id": "slot_local_fts5",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": len(hits),
                        "model": None,
                        "revision": "sha256:0dbe54f5a8bc56a6c821e181a0dc6cfda85d25be8cea6a01235cb5e347782f0e",
                    }
                ],
                "candidate_count": len(raw),
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }
