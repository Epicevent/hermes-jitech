"""Streaming admission and KWRAG ABI adapter for the selected FTS factory."""

from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import stat
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping
from urllib.parse import quote

from kwrag_p1_attachment.factory import (
    BACKEND_ID,
    ContractError,
    FtsAttachmentPipeline,
)


_SHA256 = re.compile(r"^sha256:[0-9a-f]{64}$")
_RESOURCE_KEYS = set(
    "schema status observationDigest observedAt ttlSeconds targetInstanceId "
    "containerIdentityDigest cgroupIdentityDigest profileDigest "
    "requiredCpuMillicores requiredMemoryBytes requiredPids "
    "containerCpuUsedMillicores containerMemoryUsedBytes containerPidsUsed "
    "hostCpuAvailableMillicores hostMemoryAvailableBytes hostPidsAvailable".split()
)
_BINDING_KEYS = set(
    "schema proofMode enabled family instanceId runtimeProfileDigest containerNasRoot "
    "transport hostPortCount mountReadOnly componentDigest contractDigest "
    "resourceProfileDigest p1Identity attachmentData".split()
)
_DATA_KEYS = set(
    "databaseSha256 indexManifestDigest sourceSnapshotDigest "
    "readOnlyAuthorityReceiptDigest slotRuntimeBindingDigest".split()
)
_CONSUMPTION_KEYS = set(
    "schema_version consumer_family attachment_status consumption_status "
    "provider_dispatch_attempted instance_id binding_digest resource_observation_digest "
    "component_digest p1_identity_digest attachment_data_digest request_id operation_id "
    "run_id attempt result_status result_count result_digest operation_receipt_digest "
    "result_receipt_digest".split()
)
_RESULT_RECEIPT_KEYS = set(
    "schema_version consumer_family adapter_status component_digest "
    "runtime_binding_digest request_id operation_id run_id attempt index_manifest "
    "pipeline_fingerprint result_status result_digest operation_receipt_digest "
    "result_count result_characters".split()
)
_OPERATION_RECEIPT_KEYS = set(
    "schema_version recorded_at operation_id operation_id_source request_id run_id "
    "attempt authorization_basis corpora query_chars requested_max_results "
    "index_manifest pipeline_fingerprint execution_status result_status duration_ms "
    "result_count result_digest pipeline_evidence provider_billing full_economic_cost "
    "error_code".split()
)
_PIPELINE_EVIDENCE_KEYS = set(
    "status schema_version backend_id stages candidate_count returned_count "
    "corpus_count data_boundary".split()
)
_PIPELINE_STAGE_KEYS = set(
    "stage_id execution_scope call_count input_count output_count model revision".split()
)
_DATA_BOUNDARY_KEYS = {
    "bytes_sent_outside_slot",
    "external_persistence",
    "persistence_receipt_digest",
}
_COST_KEYS = {"status", "amount", "currency", "reason"}
_SOURCE_GENERATION_KEYS = {"source_generation"}


def _receipt_generation(
    *receipts: Mapping[str, Any],
) -> tuple[str | None, bool]:
    """Return one optional source-generation identity shared by all receipts."""

    present = [
        receipt.get("source_generation")
        for receipt in receipts
        if "source_generation" in receipt
    ]
    if not present:
        return None, False
    if (
        len(present) != len(receipts)
        or any(
            not isinstance(value, str)
            or not 1 <= len(value) <= 256
            or value.lower() in {"unknown", "latest", "current"}
            for value in present
        )
        or len(set(present)) != 1
    ):
        raise ContractError("receipt source generation is invalid")
    return present[0], True


def _digest(value: object) -> str:
    text = str(value or "")
    if not _SHA256.fullmatch(text):
        raise ContractError("digest is invalid")
    return text


def _exact_integer(
    value: object, *, minimum: int = 0, maximum: int | None = None
) -> bool:
    return (
        isinstance(value, int)
        and not isinstance(value, bool)
        and value >= minimum
        and (maximum is None or value <= maximum)
    )


def _bounded_text(value: object, *, maximum: int, nullable: bool = False) -> bool:
    return (nullable and value is None) or (
        isinstance(value, str) and 1 <= len(value) <= maximum
    )


def _read_stable_file(
    path: Path,
    label: str,
    maximum_bytes: int,
    *,
    required_owner_uid: int | None = None,
) -> bytes:
    source = Path(path)
    if not source.is_absolute() or source.is_symlink():
        raise ContractError(f"{label} is unavailable")
    flags = (
        os.O_RDONLY
        | getattr(os, "O_BINARY", 0)
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
    )
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise ContractError(f"{label} is unavailable") from exc
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or not 0 < before.st_size <= maximum_bytes
            or (
                required_owner_uid is not None
                and (
                    before.st_uid != required_owner_uid
                    or stat.S_IMODE(before.st_mode) & 0o022
                )
            )
        ):
            raise ContractError(f"{label} file identity is invalid")
        chunks: list[bytes] = []
        total = 0
        while chunk := os.read(descriptor, 64 * 1024):
            total += len(chunk)
            if total > maximum_bytes:
                raise ContractError(f"{label} is too large")
            chunks.append(chunk)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
            before.st_ctime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ):
            raise ContractError(f"{label} changed while loading")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def load_canonical_mapping(path: Path, label: str) -> tuple[dict[str, Any], str]:
    """Load one bounded canonical JSON mapping from a stable descriptor."""

    raw = _read_stable_file(path, label, 256 * 1024)
    value = json.loads(raw)
    if (
        not isinstance(value, dict)
        or raw
        != json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode()
    ):
        raise ContractError(f"{label} is not canonical JSON")
    return value, "sha256:" + hashlib.sha256(raw).hexdigest()


def load_authoritative_canonical_mapping(
    path: Path, label: str, *, required_owner_uid: int
) -> tuple[dict[str, Any], str]:
    """Load a canonical mapping owned by the external OPS authority."""

    if (
        isinstance(required_owner_uid, bool)
        or not isinstance(required_owner_uid, int)
        or required_owner_uid < 0
    ):
        raise ContractError(f"{label} owner identity is invalid")
    raw = _read_stable_file(
        path,
        label,
        256 * 1024,
        required_owner_uid=required_owner_uid,
    )
    value = json.loads(raw)
    if (
        not isinstance(value, dict)
        or raw
        != json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode()
    ):
        raise ContractError(f"{label} is not canonical JSON")
    return value, "sha256:" + hashlib.sha256(raw).hexdigest()


def load_receipt(path: Path, digest: str | None, label: str) -> dict[str, Any]:
    """Resolve exactly one canonical receipt from a stable bounded ledger."""

    receipts: list[tuple[str, dict[str, Any]]] = []
    for line in _read_stable_file(path, label, 8 * 1024 * 1024).splitlines():
        value = json.loads(line)
        if (
            not isinstance(value, dict)
            or line
            != json.dumps(
                value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ).encode()
        ):
            raise ContractError(f"{label} receipt ledger is invalid")
        receipts.append(("sha256:" + hashlib.sha256(line).hexdigest(), value))
    if digest is None:
        if receipts:
            return receipts[-1][1]
        raise ContractError(f"{label} receipt linkage is invalid")
    matches = [value for receipt_digest, value in receipts if receipt_digest == digest]
    if not matches or any(value != matches[0] for value in matches[1:]):
        raise ContractError(f"{label} receipt linkage is invalid")
    return matches[-1]


def validate_attachment_binding(
    value: Mapping[str, Any],
    *,
    digest: str,
    expected_digest: str,
    component_digest: str,
    contract_digest: str,
    resource_profile_digest: str,
    p1_identity: Mapping[str, Any],
) -> None:
    """Validate the exact Hermes private binding-v2 profile."""

    if set(value) != _BINDING_KEYS or digest != expected_digest:
        raise ContractError("attachment binding fields or digest are invalid")
    if (
        value["schema"] != "agent-runtime-retrieval-binding/v2"
        or value["proofMode"] != "attachment_only"
        or value["family"] != "hermes"
        or value["containerNasRoot"] != "/workspace/nas_docs"
        or value["transport"] != "in_process"
        or isinstance(value["hostPortCount"], bool)
        or not isinstance(value["hostPortCount"], int)
        or value["hostPortCount"] != 0
        or value["mountReadOnly"] is not True
        or value["componentDigest"] != component_digest
        or value["contractDigest"] != contract_digest
        or value["resourceProfileDigest"] != resource_profile_digest
        or value["p1Identity"] != p1_identity
    ):
        raise ContractError("attachment binding is not the approved Hermes P1 profile")
    _digest(value["runtimeProfileDigest"])
    if not isinstance(value["instanceId"], str) or not re.fullmatch(
        r"[A-Za-z0-9][A-Za-z0-9._:-]{0,191}", value["instanceId"]
    ):
        raise ContractError("attachment target identity is invalid")
    if value["enabled"] is True:
        data = value["attachmentData"]
        if not isinstance(data, Mapping) or set(data) != _DATA_KEYS:
            raise ContractError("enabled attachment data fields are invalid")
        for field in _DATA_KEYS:
            _digest(data[field])
    elif value["enabled"] is not False or value["attachmentData"] is not None:
        raise ContractError("disabled attachment binding retains live data")


def _has_valid_result_semantics(receipt: Mapping[str, Any]) -> bool:
    result_status = receipt.get("result_status")
    result_count = receipt.get("result_count")
    result_digest = receipt.get("result_digest")
    return (
        result_status in {"hits", "zero_hits"}
        and _exact_integer(result_count, maximum=10)
        and (result_count == 0) == (result_status == "zero_hits")
        and isinstance(result_digest, str)
        and _SHA256.fullmatch(result_digest) is not None
    )


def _has_valid_result_characters(receipt: Mapping[str, Any]) -> bool:
    characters = receipt.get("result_characters")
    return _exact_integer(characters, minimum=2, maximum=20_000) and (
        characters == 2
        if receipt.get("result_status") == "zero_hits"
        else characters >= 112
    )


def _has_valid_recorded_at(value: object) -> bool:
    if not isinstance(value, str) or len(value) != 20:
        return False
    try:
        datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return False
    return True


def _has_valid_common_receipt_identity(receipt: Mapping[str, Any]) -> bool:
    return (
        _bounded_text(receipt.get("request_id"), maximum=128)
        and _bounded_text(receipt.get("operation_id"), maximum=128)
        and _bounded_text(receipt.get("run_id"), maximum=128, nullable=True)
        and _exact_integer(receipt.get("attempt"), minimum=1, maximum=16)
        and _has_valid_result_semantics(receipt)
    )


def _has_valid_cost(value: object, *, expected_status: str) -> bool:
    return (
        isinstance(value, Mapping)
        and set(value) == _COST_KEYS
        and value.get("status") == expected_status
        and value.get("amount") is None
        and value.get("currency") is None
        and _bounded_text(value.get("reason"), maximum=512)
    )


def _has_valid_slot_local_pipeline(
    value: object,
    *,
    backend_id: str,
    expected_revision: str,
    result_count: int,
    corpus_count: int,
) -> bool:
    if (
        not isinstance(value, Mapping)
        or set(value) != _PIPELINE_EVIDENCE_KEYS
        or value.get("status") != "available"
        or value.get("schema_version") != "kwrag-slot-pipeline-evidence-v1"
        or value.get("backend_id") != backend_id
        or not _exact_integer(
            value.get("candidate_count"), minimum=result_count, maximum=10
        )
        or value.get("returned_count") != result_count
        or not _exact_integer(value.get("returned_count"))
        or value.get("corpus_count") != corpus_count
        or not _exact_integer(value.get("corpus_count"), minimum=1)
    ):
        return False
    stages = value.get("stages")
    if not isinstance(stages, list) or len(stages) != 1:
        return False
    stage = stages[0]
    if (
        not isinstance(stage, Mapping)
        or set(stage) != _PIPELINE_STAGE_KEYS
        or stage.get("stage_id") != "slot_local_fts5"
        or stage.get("execution_scope") != "slot_local"
        or stage.get("call_count") != 1
        or not _exact_integer(stage.get("call_count"), minimum=1, maximum=1)
        or stage.get("input_count") != 1
        or not _exact_integer(stage.get("input_count"), minimum=1, maximum=1)
        or stage.get("output_count") != result_count
        or not _exact_integer(stage.get("output_count"))
        or stage.get("model") is not None
        or stage.get("revision") != expected_revision
    ):
        return False
    boundary = value.get("data_boundary")
    return (
        isinstance(boundary, Mapping)
        and set(boundary) == _DATA_BOUNDARY_KEYS
        and _exact_integer(boundary.get("bytes_sent_outside_slot"))
        and boundary.get("bytes_sent_outside_slot") == 0
        and boundary.get("external_persistence") == "not_applicable"
        and boundary.get("persistence_receipt_digest") is None
    )


def _has_valid_operation_receipt(
    operation: Mapping[str, Any],
    *,
    binding: Mapping[str, Any],
    index_manifest_digest: str,
    result_count: int,
    source_generation: str | None = None,
) -> bool:
    corpora = operation.get("corpora")
    expected_keys = _OPERATION_RECEIPT_KEYS | (
        _SOURCE_GENERATION_KEYS if source_generation is not None else set()
    )
    generation_valid = (
        source_generation is None
        or operation.get("source_generation") == source_generation
    )
    return (
        set(operation) == expected_keys
        and _has_valid_common_receipt_identity(operation)
        and operation.get("schema_version") == "kwrag-slot-search-operation-receipt-v1"
        and _has_valid_recorded_at(operation.get("recorded_at"))
        and operation.get("operation_id_source") == "client"
        and operation.get("authorization_basis") == "slot_mounted_storage"
        and isinstance(corpora, list)
        and len(corpora) == 1
        and _bounded_text(corpora[0], maximum=256)
        and _exact_integer(operation.get("query_chars"), minimum=1, maximum=4_000)
        and _exact_integer(
            operation.get("requested_max_results"), minimum=1, maximum=10
        )
        and operation.get("requested_max_results") >= result_count
        and operation.get("index_manifest") == index_manifest_digest
        and operation.get("pipeline_fingerprint")
        == binding["p1Identity"]["pipelineFingerprint"]
        and operation.get("execution_status") == "completed"
        and _exact_integer(operation.get("duration_ms"))
        and operation.get("error_code") is None
        and generation_valid
        and _has_valid_slot_local_pipeline(
            operation.get("pipeline_evidence"),
            backend_id=binding["p1Identity"]["backendId"],
            expected_revision=binding["p1Identity"]["pipelineFactoryDigest"],
            result_count=result_count,
            corpus_count=1,
        )
        and _has_valid_cost(
            operation.get("provider_billing"), expected_status="not_applicable"
        )
        and _has_valid_cost(
            operation.get("full_economic_cost"), expected_status="unavailable"
        )
    )


def validate_receipt_linkage(
    consumption: Mapping[str, Any],
    operation: Mapping[str, Any],
    result: Mapping[str, Any],
    *,
    binding: Mapping[str, Any],
    observation_digest: str,
    component_digest: str,
    runtime_binding_digest: str,
    index_manifest_digest: str,
    binding_digest: str,
    p1_identity_digest: str,
    attachment_data_digest: str,
) -> None:
    """Validate operation-to-result-to-not-consumed attachment linkage."""

    common = (
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "result_status",
        "result_count",
        "result_digest",
    )
    source_generation, has_generation = _receipt_generation(
        consumption, operation, result
    )
    expected_consumption_keys = _CONSUMPTION_KEYS | (
        _SOURCE_GENERATION_KEYS if has_generation else set()
    )
    expected_result_keys = _RESULT_RECEIPT_KEYS | (
        _SOURCE_GENERATION_KEYS if has_generation else set()
    )
    if (
        set(consumption) != expected_consumption_keys
        or not all(
            _has_valid_common_receipt_identity(receipt)
            for receipt in (consumption, operation, result)
        )
        or set(result) != expected_result_keys
        or not _has_valid_result_characters(result)
        or not _has_valid_operation_receipt(
            operation,
            binding=binding,
            index_manifest_digest=index_manifest_digest,
            result_count=consumption["result_count"],
            source_generation=source_generation,
        )
        or consumption["schema_version"]
        != "hermes-kwrag-p1-attachment-consumption-receipt-v1"
        or consumption["consumer_family"] != "hermes"
        or consumption["attachment_status"] != "verified"
        or consumption["consumption_status"] != "not_consumed"
        or consumption["provider_dispatch_attempted"] is not False
        or consumption["instance_id"] != binding["instanceId"]
        or consumption["binding_digest"] != binding_digest
        or consumption["resource_observation_digest"] != observation_digest
        or consumption["component_digest"] != component_digest
        or consumption["p1_identity_digest"] != p1_identity_digest
        or consumption["attachment_data_digest"] != attachment_data_digest
        or any(
            result.get(key) != consumption[key]
            or operation.get(key) != consumption[key]
            for key in common
        )
        or result.get("operation_receipt_digest")
        != consumption["operation_receipt_digest"]
        or result.get("schema_version") != "hermes-kwrag-result-receipt-v1"
        or result.get("consumer_family") != "hermes"
        or result.get("adapter_status") != "verified_by_product_adapter"
        or result.get("component_digest") != component_digest
        or result.get("runtime_binding_digest") != runtime_binding_digest
        or result.get("index_manifest") != index_manifest_digest
        or result.get("pipeline_fingerprint")
        != binding["p1Identity"]["pipelineFingerprint"]
        or operation.get("schema_version") != "kwrag-slot-search-operation-receipt-v1"
        or operation.get("authorization_basis") != "slot_mounted_storage"
        or operation.get("execution_status") != "completed"
        or operation.get("index_manifest") != index_manifest_digest
        or operation.get("pipeline_fingerprint")
        != binding["p1Identity"]["pipelineFingerprint"]
        or operation.get("pipeline_evidence", {}).get("schema_version")
        != "kwrag-slot-pipeline-evidence-v1"
        or operation.get("pipeline_evidence", {}).get("backend_id")
        != binding["p1Identity"]["backendId"]
        or operation.get("pipeline_evidence", {})
        .get("data_boundary", {})
        .get("bytes_sent_outside_slot")
        != 0
        or operation.get("pipeline_evidence", {})
        .get("data_boundary", {})
        .get("external_persistence")
        != "not_applicable"
        or (
            has_generation
            and (
                consumption.get("source_generation") != source_generation
                or result.get("source_generation") != source_generation
                or operation.get("source_generation") != source_generation
            )
        )
    ):
        raise ContractError("attachment receipt linkage is invalid")


def validate_resource_observation(
    value: Mapping[str, Any],
    *,
    profile_digest: str,
    instance_id: str,
    container_identity_digest: str,
    cgroup_identity_digest: str,
    cpu_reservation: int,
    memory_reservation: int,
    pids_reservation: int,
) -> int:
    """Validate a fresh call-scoped measurement and return memory headroom."""

    if set(value) != _RESOURCE_KEYS:
        raise ContractError("resource observation fields are invalid")
    body = dict(value)
    observed_digest = _digest(body.pop("observationDigest"))
    raw = json.dumps(
        body, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode()
    if "sha256:" + hashlib.sha256(raw).hexdigest() != observed_digest:
        raise ContractError("resource observation digest is invalid")
    try:
        observed = datetime.fromisoformat(str(value["observedAt"]))
    except (TypeError, ValueError) as exc:
        raise ContractError("resource observation time is invalid") from exc
    ttl = value["ttlSeconds"]
    if observed.tzinfo is None or isinstance(ttl, bool) or not isinstance(ttl, int):
        raise ContractError("resource observation time is invalid")
    age = (
        datetime.now(timezone.utc) - observed.astimezone(timezone.utc)
    ).total_seconds()
    expected = {
        "requiredCpuMillicores": cpu_reservation,
        "requiredMemoryBytes": memory_reservation,
        "requiredPids": pids_reservation,
    }
    if (
        value["schema"] != "agent-runtime-retrieval-headroom/v1"
        or value["status"] != "within_required_headroom"
        or value["profileDigest"] != profile_digest
        or value["targetInstanceId"] != instance_id
        or value["containerIdentityDigest"] != container_identity_digest
        or value["cgroupIdentityDigest"] != cgroup_identity_digest
        or not 1 <= ttl <= 3600
        or not -5 <= age <= ttl
        or any(value[key] != expected_value for key, expected_value in expected.items())
    ):
        raise ContractError("resource observation is stale, foreign, or mismatched")
    measured = [
        value[key]
        for key in (
            "requiredCpuMillicores",
            "requiredMemoryBytes",
            "requiredPids",
            "containerCpuUsedMillicores",
            "containerMemoryUsedBytes",
            "containerPidsUsed",
            "hostCpuAvailableMillicores",
            "hostMemoryAvailableBytes",
            "hostPidsAvailable",
        )
    ]
    if any(
        isinstance(item, bool) or not isinstance(item, int) or item < 0
        for item in measured
    ):
        raise ContractError("resource measurements are invalid")
    if (
        value["containerCpuUsedMillicores"] > cpu_reservation
        or value["containerMemoryUsedBytes"] >= memory_reservation
        or value["containerPidsUsed"] > pids_reservation
        or value["hostCpuAvailableMillicores"] < cpu_reservation
        or value["hostMemoryAvailableBytes"] < memory_reservation
        or value["hostPidsAvailable"] < pids_reservation
    ):
        raise ContractError("resource observation exceeds the declared reservation")
    return memory_reservation - value["containerMemoryUsedBytes"]


def _open_verified(
    database_path: Path, binding: dict[str, object], maximum_bytes: int
) -> FtsAttachmentPipeline:
    required = {
        "databaseSha256",
        "readOnlyAuthorityReceiptDigest",
        "sourceSnapshotDigest",
    }
    if set(binding) != required or any(
        not _SHA256.fullmatch(str(binding[key])) for key in required
    ):
        raise ContractError("attachment data fields are invalid")
    path = Path(database_path)
    if path.is_symlink() or not path.is_file():
        raise ContractError("database must be a regular non-symlink file")
    resolved = path.resolve(strict=True)
    descriptor = os.open(
        resolved,
        os.O_RDONLY
        | getattr(os, "O_BINARY", 0)
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0),
    )
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_size <= 0
            or before.st_size > maximum_bytes
        ):
            raise ContractError("database exceeds measured memory headroom")
        digest = hashlib.sha256()
        while chunk := os.read(descriptor, 1024 * 1024):
            digest.update(chunk)
        after = os.fstat(descriptor)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise ContractError("database changed while hashing")
        if "sha256:" + digest.hexdigest() != binding["databaseSha256"]:
            raise ContractError("database digest mismatch")
    finally:
        os.close(descriptor)
    connection = sqlite3.connect(
        "file:" + quote(str(resolved)) + "?mode=ro&immutable=1", uri=True
    )
    tables = {
        str(row[0])
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        )
    }
    if not {"turns", "turn_mids", "turns_fts"}.issubset(tables):
        connection.close()
        raise ContractError("required FTS schema is absent")
    pipeline = FtsAttachmentPipeline.__new__(FtsAttachmentPipeline)
    pipeline._connection = connection
    pipeline.binding = {
        "databaseSha256": binding["databaseSha256"],
        "authority": {
            "mode": "slot_local_read_only_nas",
            "readOnlyObserved": True,
            "receiptDigest": binding["readOnlyAuthorityReceiptDigest"],
        },
        "sourceSnapshotDigest": binding["sourceSnapshotDigest"],
    }
    return pipeline


def build_p1_runtime(
    runtime: Mapping[str, Any],
    runtime_digest: str,
    binding: Mapping[str, Any],
    mount: Path,
    receipt_path: Path,
    room: str,
    maximum_bytes: int,
    pipeline_fingerprint: str,
):
    """Bind the selected P1 pipeline to the public KWRAG runtime ABI."""

    from kwrag.slot_runtime import SlotRuntimeSpec, build_slot_runtime

    data = binding["attachmentData"]
    if runtime_digest != data["slotRuntimeBindingDigest"]:
        raise ContractError("slot runtime binding digest is not attached")
    spec = SlotRuntimeSpec.from_mapping(runtime)
    if (
        spec.mount_root != mount
        or spec.index_manifest_digest != data["indexManifestDigest"]
        or spec.pipeline_fingerprint != pipeline_fingerprint
        or spec.receipt_path != receipt_path
        or spec.max_concurrent != 1
    ):
        raise ContractError("slot runtime binding is invalid")
    holder: list[KwragFtsPipeline] = []
    runtime_object = build_slot_runtime(
        spec,
        pipeline_factory=lambda scope: (
            holder.append(KwragFtsPipeline(scope, data, room, maximum_bytes))
            or holder[0]
        ),
    )
    return spec, runtime_object, holder[0]


class KwragFtsPipeline:
    """The selected factory projected into KWRAG's backend-neutral ABI."""

    def __init__(
        self,
        scope: Any,
        attachment_data: Mapping[str, Any],
        room: str,
        maximum_bytes: int,
    ):
        from kwrag.slot_mount import resolve_mounted_path

        if scope.manifest.corpus_snapshot != attachment_data["sourceSnapshotDigest"]:
            raise ContractError("source snapshot is not bound")
        files = scope.manifest.raw.get("rooms", {}).get(room, {}).get("files", [])
        matches = [
            item
            for item in files
            if isinstance(item, Mapping)
            and item.get("sha256") == attachment_data["databaseSha256"]
        ]
        if len(matches) != 1:
            raise ContractError("FTS database is not uniquely bound")
        relative = PurePosixPath(
            scope.index_root.relative_to(scope.mount_root).as_posix()
        ) / PurePosixPath(str(matches[0]["path"]))
        database = resolve_mounted_path(scope.mount_root, relative, kind="file")
        self.database_size = database.stat().st_size
        self.room = room
        self.pipeline = _open_verified(
            database,
            {
                key: attachment_data[key]
                for key in (
                    "databaseSha256",
                    "readOnlyAuthorityReceiptDigest",
                    "sourceSnapshotDigest",
                )
            },
            maximum_bytes,
        )

    def close(self) -> None:
        self.pipeline.close()

    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]:
        from kwrag.jsonutil import canonical_json_bytes
        from kwrag.operation import map_results

        if rooms != [self.room]:
            raise ContractError("P1 search escaped its bound room")
        raw = self.pipeline.search(query)
        hits: list[dict[str, Any]] = []
        for item in raw:
            candidate = {
                "room": self.room,
                "level": "turn",
                "seg_id": item["unitId"],
                "text": item["text"],
                "score": item["score"],
                "message_ids": item["sourceIds"],
            }
            projected = map_results(hits + [candidate], k, {self.room})
            if len(canonical_json_bytes(projected).decode("utf-8")) <= 20_000:
                hits.append(candidate)
            if len(hits) >= k:
                break
        return {
            "hits": hits,
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": BACKEND_ID,
                "stages": [
                    {
                        "stage_id": "slot_local_fts5",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": len(hits),
                        "model": None,
                        "revision": "sha256:0dbe54f5a8bc56a6c821e181a0dc6cfda85d25be8cea6a01235cb5e347782f0e",
                    }
                ],
                "candidate_count": len(raw),
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }
