"""Immutable P1 attachment component."""

from kwrag_p1_attachment.adapter import (
    KwragFtsPipeline,
    build_p1_runtime,
    load_canonical_mapping,
    load_receipt,
    validate_attachment_binding,
    validate_receipt_linkage,
    validate_resource_observation,
)
from kwrag_p1_attachment.factory import BACKEND_ID, TEXT_CHARACTER_MAXIMUM

__all__ = [
    "BACKEND_ID",
    "KwragFtsPipeline",
    "TEXT_CHARACTER_MAXIMUM",
    "build_p1_runtime",
    "load_canonical_mapping",
    "load_receipt",
    "validate_attachment_binding",
    "validate_receipt_linkage",
    "validate_resource_observation",
]
