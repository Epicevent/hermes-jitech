"""Immutable index-release manifest verification."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from .jsonutil import is_sha256, load_strict_json


class ManifestError(ValueError):
    pass


@dataclass(frozen=True)
class IndexManifest:
    digest: str
    release_id: str
    corpus_snapshot: str
    embedding_fingerprint: str
    rooms: Mapping[str, str]
    raw: Mapping[str, Any]


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def _canonical_digest(raw: Mapping[str, Any]) -> str:
    payload = json.dumps(raw, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def load_and_verify_manifest(
    path: Path,
    index_dir: Path,
    *,
    resolve_file: Callable[[str], Path] | None = None,
    verify_file: Callable[[str, str], None] | None = None,
    raw_manifest: Any | None = None,
) -> IndexManifest:
    if resolve_file is not None and verify_file is not None:
        raise ManifestError("manifest file resolver and verifier are mutually exclusive")
    raw = load_strict_json(Path(path)) if raw_manifest is None else raw_manifest
    if not isinstance(raw, dict) or raw.get("version") != 1:
        raise ManifestError("index manifest version must be 1")
    release_id = str(raw.get("release_id") or "").strip()
    corpus_snapshot = str(raw.get("corpus_snapshot") or "").strip()
    embedding_fingerprint = str(raw.get("embedding_fingerprint") or "").strip()
    room_entries = raw.get("rooms")
    if (
        not release_id
        or not corpus_snapshot
        or not is_sha256(embedding_fingerprint)
        or not isinstance(room_entries, dict)
        or not room_entries
    ):
        raise ManifestError("index manifest is missing release metadata or rooms")

    rooms: dict[str, str] = {}
    root = Path(index_dir).resolve()
    for room, entry in room_entries.items():
        if not isinstance(room, str) or not isinstance(entry, dict):
            raise ManifestError("index room entry is invalid")
        room = room.strip()
        cid = str(entry.get("conversation_id") or "").strip()
        files = entry.get("files")
        if not cid or not isinstance(files, list) or not files:
            raise ManifestError("index room entry is missing conversation_id or files")
        for file_entry in files:
            if not isinstance(file_entry, dict):
                raise ManifestError("index file entry is invalid")
            raw_relative = file_entry.get("path")
            if not isinstance(raw_relative, str) or not raw_relative:
                raise ManifestError("index file path is invalid")
            relative = Path(raw_relative)
            expected_digest = str(file_entry.get("sha256") or "")
            if not is_sha256(expected_digest):
                raise ManifestError("index manifest contains an invalid file digest")
            if verify_file is not None:
                verify_file(raw_relative, expected_digest)
                continue
            if resolve_file is None:
                target = (root / relative).resolve()
                if root not in target.parents or not target.is_file():
                    raise ManifestError(
                        "index manifest references a missing or escaping file"
                    )
            else:
                target = Path(resolve_file(raw_relative))
            if _file_sha256(target) != expected_digest:
                raise ManifestError(f"index digest mismatch: {relative.as_posix()}")
        if not room or room in rooms:
            raise ManifestError("index manifest contains an empty or duplicate room")
        rooms[room] = cid

    return IndexManifest(
        digest=_canonical_digest(raw),
        release_id=release_id,
        corpus_snapshot=corpus_snapshot,
        embedding_fingerprint=embedding_fingerprint,
        rooms=rooms,
        raw=raw,
    )
