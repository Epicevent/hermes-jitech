"""D baseline: shared stateless models over one slot-local dense release."""

from __future__ import annotations

import hashlib
import math
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .dense_source import DenseMessageSource, DenseSourceReferenceUnavailable
from .dense_release import (
    DENSE_RELEASE_SCHEMA,
    D_PIPELINE_FINGERPRINT,
    EMBEDDING_FINGERPRINT,
    SEGMENT_TRANSFORM_ID,
)
from .jsonutil import canonical_json_bytes, is_sha256, loads_canonical_json_bytes
from .operation import OperationError
from .shared_gpu_contract import (
    KURE_DIMENSION,
    KURE_MODEL,
    KURE_REVISION,
    RERANK_MODEL,
    RERANK_REVISION,
)
from .shared_gpu_transport import GpuCallResult, GpuInferenceClient
from .slot_mount import SlotIndexScope, resolve_mounted_path


MAX_DENSE_CANDIDATES = 32
_DENSE_FIELDS = frozenset(
    {
        "schema_version",
        "pipeline_fingerprint",
        "segment_transform",
        "metadata_relative",
        "vectors_relative",
        "source_snapshot_relative",
        "embedding_model",
        "embedding_revision",
        "embedding_dimension",
        "segment_count",
        "production_eligible",
        "raw_content_in_release",
    }
)
_SOURCE_SNAPSHOT_FIELDS = frozenset(
    {
        "schema_version",
        "source_kind",
        "authorized_room_count",
        "authorized_room_set_sha256",
        "source_message_count",
        "indexable_message_count",
        "segment_count",
        "segment_transform",
        "embedding_model",
        "embedding_revision",
        "embedding_dimension",
        "embedding_execution",
        "builder_source_sha256",
        "production_eligible",
        "raw_content_present",
    }
)


class DensePipelineError(ValueError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class DenseMetadata:
    row_id: int
    segment_id: str
    room: str
    t_start: int
    t_end: int
    references: tuple[Mapping[str, Any], ...]
    source_text_sha256: str


@dataclass(frozen=True)
class DenseCandidate:
    metadata: DenseMetadata
    dense_score: float
    text: str
    message_ids: tuple[str, ...]
    rerank_score: float = 0.0


class SharedGpuDensePipeline:
    """Complete replaceable SearchPipeline implementation for baseline D."""

    def __init__(
        self,
        scope: SlotIndexScope,
        gpu: GpuInferenceClient,
        *,
        pool: int = 30,
        source: DenseMessageSource | None = None,
        allow_nonproduction_release: bool = False,
    ):
        if (
            isinstance(pool, bool)
            or not isinstance(pool, int)
            or not 1 <= pool <= MAX_DENSE_CANDIDATES
        ):
            raise DensePipelineError("dense_candidate_pool_invalid")
        if not isinstance(allow_nonproduction_release, bool):
            raise DensePipelineError("nonproduction_release_flag_invalid")
        if scope.readonly_required is not True:
            raise DensePipelineError("dense_scope_must_be_readonly")
        scope.assert_current()
        extension = scope.manifest.raw.get("kwrag_dense")
        if not isinstance(extension, Mapping) or set(extension) != _DENSE_FIELDS:
            raise DensePipelineError("dense_manifest_extension_invalid")
        if (
            extension.get("schema_version") != DENSE_RELEASE_SCHEMA
            or extension.get("pipeline_fingerprint") != D_PIPELINE_FINGERPRINT
            or scope.manifest.embedding_fingerprint != EMBEDDING_FINGERPRINT
            or extension.get("raw_content_in_release") is not False
            or extension.get("segment_transform") != SEGMENT_TRANSFORM_ID
        ):
            raise DensePipelineError("dense_manifest_identity_invalid")
        production_eligible = extension.get("production_eligible")
        if not isinstance(production_eligible, bool) or (
            not production_eligible and not allow_nonproduction_release
        ):
            raise DensePipelineError("dense_release_not_production_eligible")
        dimension = extension.get("embedding_dimension")
        segment_count = extension.get("segment_count")
        if (
            isinstance(dimension, bool)
            or not isinstance(dimension, int)
            or not 1 <= dimension <= 4_096
            or isinstance(segment_count, bool)
            or not isinstance(segment_count, int)
            or segment_count < 1
        ):
            raise DensePipelineError("dense_manifest_shape_invalid")
        embedding_model = extension.get("embedding_model")
        embedding_revision = extension.get("embedding_revision")
        if production_eligible:
            if (
                dimension != KURE_DIMENSION
                or embedding_model != KURE_MODEL
                or embedding_revision != KURE_REVISION
            ):
                raise DensePipelineError("dense_production_embedding_identity_invalid")
        else:
            if (
                not isinstance(embedding_model, str)
                or not embedding_model
                or len(embedding_model) > 256
                or not isinstance(embedding_revision, str)
                or not embedding_revision
                or len(embedding_revision) > 128
            ):
                raise DensePipelineError("dense_embedding_identity_invalid")
        expected_paths = {
            "metadata_relative": "segments.sqlite3",
            "vectors_relative": "vectors.npy",
            "source_snapshot_relative": "source-snapshot.json",
        }
        if any(
            extension.get(field) != relative
            for field, relative in expected_paths.items()
        ):
            raise DensePipelineError("dense_release_path_invalid")
        self.scope = scope
        self.gpu = gpu
        self.pool = pool
        self.extension = dict(extension)
        self.production_eligible = production_eligible
        self.dimension = dimension
        if source is None:
            # Compatibility for the historical immutable-generation caller.
            # The product runtime always supplies its live mounted source and
            # therefore never imports or executes this legacy admission path.
            from .crawler_source import CanonicalCrawlerSource

            source = CanonicalCrawlerSource(scope.mount_root)
        self.source = source
        metadata_path = resolve_mounted_path(
            scope.index_root, str(extension["metadata_relative"]), kind="file"
        )
        vectors_path = resolve_mounted_path(
            scope.index_root, str(extension["vectors_relative"]), kind="file"
        )
        source_snapshot_path = resolve_mounted_path(
            scope.index_root,
            str(extension["source_snapshot_relative"]),
            kind="file",
        )
        self._validate_source_snapshot(source_snapshot_path, segment_count)
        self._metadata = self._load_metadata(metadata_path, segment_count)
        try:
            import numpy as np
        except ImportError as exc:
            self.source.close()
            raise DensePipelineError("numpy_unavailable") from exc
        try:
            vectors = np.load(vectors_path, mmap_mode="r", allow_pickle=False)
        except (OSError, ValueError) as exc:
            self.source.close()
            raise DensePipelineError("dense_vectors_invalid") from exc
        if (
            vectors.ndim != 2
            or vectors.shape != (segment_count, dimension)
            or not np.isfinite(vectors).all()
        ):
            self.source.close()
            raise DensePipelineError("dense_vectors_shape_invalid")
        norms = np.linalg.norm(vectors, axis=1)
        if not np.all((norms > 0.99) & (norms < 1.01)):
            self.source.close()
            raise DensePipelineError("dense_vectors_not_normalized")
        self._np = np
        self._vectors = vectors

    def close(self) -> None:
        memory_map = getattr(getattr(self, "_vectors", None), "_mmap", None)
        if memory_map is not None:
            memory_map.close()
        self._vectors = None
        self.source.close()

    def _validate_source_snapshot(self, path: Path, expected_count: int) -> None:
        self.scope.assert_current()
        try:
            before = path.stat()
            if not 1 <= before.st_size <= 256 * 1024:
                raise DensePipelineError("dense_source_snapshot_size_invalid")
            payload = path.read_bytes()
            after = path.stat()
        except DensePipelineError:
            raise
        except OSError as exc:
            raise DensePipelineError("dense_source_snapshot_unavailable") from exc
        before_identity = (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_nlink,
            before.st_size,
            before.st_mtime_ns,
        )
        after_identity = (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
        )
        if before_identity != after_identity or len(payload) != before.st_size:
            raise DensePipelineError("dense_source_snapshot_changed")
        try:
            raw = loads_canonical_json_bytes(payload)
        except (UnicodeDecodeError, ValueError) as exc:
            raise DensePipelineError("dense_source_snapshot_not_canonical") from exc
        if not isinstance(raw, Mapping) or set(raw) != _SOURCE_SNAPSHOT_FIELDS:
            raise DensePipelineError("dense_source_snapshot_fields_invalid")
        rooms = sorted(self.scope.manifest.rooms)
        expected = {
            "schema_version": "kwrag-dense-index-input-v2",
            "authorized_room_count": len(rooms),
            "authorized_room_set_sha256": "sha256:"
            + hashlib.sha256(canonical_json_bytes(rooms)).hexdigest(),
            "segment_count": expected_count,
            "segment_transform": SEGMENT_TRANSFORM_ID,
            "embedding_model": self.extension["embedding_model"],
            "embedding_revision": self.extension["embedding_revision"],
            "embedding_dimension": self.dimension,
            "embedding_execution": "shared_stateless",
            "production_eligible": self.production_eligible,
            "raw_content_present": False,
        }
        if any(raw.get(field) != value for field, value in expected.items()):
            raise DensePipelineError("dense_source_snapshot_identity_invalid")
        source_kind = raw.get("source_kind")
        source_message_count = raw.get("source_message_count")
        if (
            not isinstance(source_kind, str)
            or not 1 <= len(source_kind) <= 128
            or isinstance(source_message_count, bool)
            or not isinstance(source_message_count, int)
            or source_message_count < 1
        ):
            raise DensePipelineError("dense_source_snapshot_shape_invalid")
        for field in ("authorized_room_set_sha256", "builder_source_sha256"):
            if not is_sha256(raw.get(field)):
                raise DensePipelineError("dense_source_snapshot_digest_invalid")
        indexable = raw.get("indexable_message_count")
        if (
            isinstance(indexable, bool)
            or not isinstance(indexable, int)
            or not 1 <= indexable <= source_message_count
        ):
            raise DensePipelineError("dense_source_snapshot_count_invalid")
        self.scope.assert_current()

    @staticmethod
    def _load_metadata(path: Path, expected_count: int) -> tuple[DenseMetadata, ...]:
        uri = path.resolve(strict=True).as_uri() + "?mode=ro&immutable=1"
        try:
            with closing(sqlite3.connect(uri, uri=True)) as connection:
                if connection.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
                    raise DensePipelineError("dense_metadata_integrity_invalid")
                columns = [
                    str(row[1])
                    for row in connection.execute("PRAGMA table_info(segments)")
                ]
                if columns != [
                    "row_id",
                    "segment_id",
                    "room_id",
                    "t_start",
                    "t_end",
                    "references_json",
                    "source_text_sha256",
                ]:
                    raise DensePipelineError("dense_metadata_schema_invalid")
                rows = connection.execute(
                    "SELECT row_id,segment_id,room_id,t_start,t_end,references_json,"
                    "source_text_sha256 FROM segments ORDER BY row_id"
                ).fetchall()
        except DensePipelineError:
            raise
        except sqlite3.Error as exc:
            raise DensePipelineError("dense_metadata_query_failed") from exc
        if len(rows) != expected_count:
            raise DensePipelineError("dense_metadata_count_invalid")
        output: list[DenseMetadata] = []
        for expected_row, row in enumerate(rows):
            row_id, segment_id, room, t_start, t_end, references_raw, text_digest = row
            if row_id != expected_row or not is_sha256(str(text_digest)):
                raise DensePipelineError("dense_metadata_identity_invalid")
            try:
                references = loads_canonical_json_bytes(
                    str(references_raw).encode("utf-8")
                )
            except (UnicodeDecodeError, ValueError) as exc:
                raise DensePipelineError("dense_metadata_references_invalid") from exc
            if not isinstance(references, list) or not references:
                raise DensePipelineError("dense_metadata_references_invalid")
            output.append(
                DenseMetadata(
                    row_id=int(row_id),
                    segment_id=str(segment_id),
                    room=str(room),
                    t_start=int(t_start),
                    t_end=int(t_end),
                    references=tuple(references),
                    source_text_sha256=str(text_digest),
                )
            )
        return tuple(output)

    def ready(self) -> dict[str, Any]:
        self.scope.assert_current()
        return {
            "ready": True,
            "backend_id": "shared-gpu-dense-rerank-v1",
            "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
            "release_id": self.scope.manifest.release_id,
            "segment_count": len(self._metadata),
        }

    def _require_call_identity(
        self,
        call: GpuCallResult,
        *,
        model: str,
        revision: str,
    ) -> None:
        if self.production_eligible and (
            not call.production_backend
            or call.model != model
            or call.revision != revision
        ):
            raise DensePipelineError("shared_gpu_call_identity_mismatch")

    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]:
        if (
            not isinstance(rooms, list)
            or len(rooms) != len(set(rooms))
            or set(rooms) - set(self.scope.available_rooms)
            or isinstance(k, bool)
            or not isinstance(k, int)
            or not 1 <= k <= 10
        ):
            raise OperationError(
                400, "invalid_request", "dense pipeline scope is invalid"
            )
        self.scope.assert_current()
        embed_call = self.gpu.embed_query(query)
        self._require_call_identity(
            embed_call, model=KURE_MODEL, revision=KURE_REVISION
        )
        raw_vectors = embed_call.output.get("vectors")
        if (
            not isinstance(raw_vectors, list)
            or len(raw_vectors) != 1
            or not isinstance(raw_vectors[0], list)
            or len(raw_vectors[0]) != self.dimension
        ):
            raise DensePipelineError("query_embedding_shape_invalid")
        query_vector = self._np.asarray(raw_vectors[0], dtype=self._np.float32)
        if not self._np.isfinite(query_vector).all():
            raise DensePipelineError("query_embedding_value_invalid")
        query_norm = float(self._np.linalg.norm(query_vector))
        if not math.isfinite(query_norm) or not 0.99 < query_norm < 1.01:
            raise DensePipelineError("query_embedding_not_normalized")
        room_set = set(rooms)
        indices = [
            metadata.row_id for metadata in self._metadata if metadata.room in room_set
        ]
        pool = min(self.pool, len(indices))
        selected: list[tuple[DenseMetadata, float]] = []
        if pool:
            scores = self._vectors[indices] @ query_vector
            ranked = sorted(
                range(len(indices)),
                key=lambda position: (
                    -float(scores[position]),
                    self._metadata[indices[position]].segment_id,
                ),
            )[:pool]
            for position in ranked:
                score = float(scores[position])
                if not math.isfinite(score):
                    raise DensePipelineError("dense_score_invalid")
                selected.append((self._metadata[indices[position]], score))
        candidates: list[DenseCandidate] = []
        for metadata, dense_score in selected:
            try:
                text, message_ids = self.source.resolve_references(
                    room=metadata.room,
                    references=metadata.references,
                    expected_text_sha256=metadata.source_text_sha256,
                )
            except DenseSourceReferenceUnavailable:
                if getattr(self.source, "stale_references_are_skipped", False) is True:
                    continue
                raise
            candidates.append(
                DenseCandidate(
                    metadata=metadata,
                    dense_score=dense_score,
                    text=text,
                    message_ids=message_ids,
                )
            )
        calls = [embed_call]
        if candidates:
            rerank_call = self.gpu.rerank(
                query, [candidate.text for candidate in candidates]
            )
            self._require_call_identity(
                rerank_call, model=RERANK_MODEL, revision=RERANK_REVISION
            )
            raw_scores = rerank_call.output.get("scores")
            if not isinstance(raw_scores, list) or len(raw_scores) != len(candidates):
                raise DensePipelineError("rerank_output_shape_invalid")
            candidates = [
                DenseCandidate(
                    metadata=candidate.metadata,
                    dense_score=candidate.dense_score,
                    text=candidate.text,
                    message_ids=candidate.message_ids,
                    rerank_score=float(score),
                )
                for candidate, score in zip(candidates, raw_scores)
            ]
            if any(
                not math.isfinite(candidate.rerank_score) for candidate in candidates
            ):
                raise DensePipelineError("rerank_score_invalid")
            calls.append(rerank_call)
        candidates.sort(
            key=lambda candidate: (
                -candidate.rerank_score,
                -candidate.dense_score,
                candidate.metadata.room,
                candidate.metadata.segment_id,
            )
        )
        operation_receipt_digest = self.gpu.commit_operation(calls)
        self.scope.assert_current()
        hits = [
            {
                "room": candidate.metadata.room,
                "level": "segment",
                "seg_id": candidate.metadata.segment_id,
                "message_ids": list(candidate.message_ids),
                "text": candidate.text,
                "score": candidate.rerank_score,
                "dense_score": candidate.dense_score,
                "t_start": candidate.metadata.t_start,
                "t_end": candidate.metadata.t_end,
            }
            for candidate in candidates[:k]
        ]
        return {
            "hits": hits,
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": "shared-gpu-dense-rerank-v1",
                "stages": [
                    {
                        "stage_id": "query_embedding",
                        "execution_scope": "shared_stateless",
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": 1,
                        "model": KURE_MODEL,
                        "revision": KURE_REVISION,
                    },
                    {
                        "stage_id": "dense_index_search",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": len(indices),
                        "output_count": len(candidates),
                        "model": None,
                        "revision": self.scope.manifest.digest,
                    },
                    {
                        "stage_id": "candidate_rerank",
                        "execution_scope": "shared_stateless",
                        "call_count": 1 if candidates else 0,
                        "input_count": len(candidates),
                        "output_count": len(candidates),
                        "model": RERANK_MODEL,
                        "revision": RERANK_REVISION,
                    },
                ],
                "candidate_count": len(candidates),
                "data_boundary": {
                    "bytes_sent_outside_slot": sum(
                        call.wire_bytes_sent for call in calls
                    ),
                    "external_persistence": "attested_none",
                    "persistence_receipt_digest": operation_receipt_digest,
                },
            },
        }
