"""Config-bound offline dense builder; it neither publishes nor activates."""

from __future__ import annotations

import argparse
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .crawler_source import CanonicalCrawlerSource, CrawlerSourceError
from .dense_release import DenseReleaseError, build_dense_release
from .jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from .shared_gpu_transport import (
    ContentFreeGpuJournal,
    SharedGpuTransportError,
    UnixSharedGpuClient,
)


_FIELDS = frozenset(
    {
        "schema_version",
        "source_mount_root",
        "output_root",
        "slot_namespace",
        "socket_path",
        "gpu_receipt_path",
        "expected_uid",
        "expected_gid",
        "deadline_ms",
    }
)


class DenseBuilderConfigError(ValueError):
    pass


@dataclass(frozen=True)
class DenseBuilderSpec:
    source_mount_root: Path
    output_root: Path
    slot_namespace: str
    socket_path: Path
    gpu_receipt_path: Path
    expected_uid: int
    expected_gid: int
    deadline_ms: int


def _absolute(value: Any, field: str) -> Path:
    if not isinstance(value, str) or not value or len(value) > 4_096:
        raise DenseBuilderConfigError(f"{field}_invalid")
    path = PurePosixPath(value)
    if (
        not path.is_absolute()
        or path.as_posix() != value
        or "\\" in value
        or ":" in value
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise DenseBuilderConfigError(f"{field}_invalid")
    return Path(value)


def _integer(value: Any, *, minimum: int, maximum: int, field: str) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= maximum
    ):
        raise DenseBuilderConfigError(f"{field}_invalid")
    return value


def load_builder_spec(path: Path) -> DenseBuilderSpec:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise DenseBuilderConfigError("builder_config_unavailable") from exc
    chunks: list[bytes] = []
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or not 1 <= before.st_size <= 64 * 1024
            or before.st_uid not in {0, os.geteuid()}
            or stat.S_IMODE(before.st_mode) & 0o022
        ):
            raise DenseBuilderConfigError("builder_config_identity_invalid")
        while True:
            block = os.read(descriptor, 16 * 1024)
            if not block:
                break
            chunks.append(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise DenseBuilderConfigError("builder_config_changed")
    finally:
        os.close(descriptor)
    try:
        raw = loads_canonical_json_bytes(b"".join(chunks))
    except (UnicodeDecodeError, ValueError) as exc:
        raise DenseBuilderConfigError("builder_config_not_canonical") from exc
    if (
        not isinstance(raw, Mapping)
        or set(raw) != _FIELDS
        or raw.get("schema_version") != "kwrag-dense-builder-config-v1"
    ):
        raise DenseBuilderConfigError("builder_config_fields_invalid")
    slot = raw.get("slot_namespace")
    if (
        not isinstance(slot, str)
        or re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", slot) is None
    ):
        raise DenseBuilderConfigError("slot_namespace_invalid")
    spec = DenseBuilderSpec(
        source_mount_root=_absolute(raw.get("source_mount_root"), "source_mount_root"),
        output_root=_absolute(raw.get("output_root"), "output_root"),
        slot_namespace=slot,
        socket_path=_absolute(raw.get("socket_path"), "socket_path"),
        gpu_receipt_path=_absolute(raw.get("gpu_receipt_path"), "gpu_receipt_path"),
        expected_uid=_integer(raw.get("expected_uid"), minimum=0, maximum=2**31 - 1, field="uid"),
        expected_gid=_integer(raw.get("expected_gid"), minimum=0, maximum=2**31 - 1, field="gid"),
        deadline_ms=_integer(raw.get("deadline_ms"), minimum=1, maximum=60_000, field="deadline"),
    )
    if os.geteuid() != spec.expected_uid or os.getegid() != spec.expected_gid:
        raise DenseBuilderConfigError("builder_principal_mismatch")
    return spec


def run(spec: DenseBuilderSpec) -> dict[str, Any]:
    source = CanonicalCrawlerSource(spec.source_mount_root)
    try:
        client = UnixSharedGpuClient(
            socket_path=spec.socket_path,
            slot=spec.slot_namespace,
            principal=f"uid:{spec.expected_uid}",
            journal=ContentFreeGpuJournal(spec.gpu_receipt_path),
            deadline_ms=spec.deadline_ms,
        )
        return build_dense_release(
            source=source,
            gpu=client,
            output_root=spec.output_root,
            slot_namespace=spec.slot_namespace,
            allow_nonproduction=False,
        )
    finally:
        source.close()


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build one inactive KWRAG D release.")
    parser.add_argument("--config", type=Path, required=True)
    return parser


def _sanitized_error_code(exc: BaseException) -> str:
    if isinstance(exc, DenseBuilderConfigError):
        return "builder_config_invalid"
    if isinstance(exc, OSError):
        return "builder_io_error"
    code = getattr(exc, "code", None)
    if isinstance(code, str) and re.fullmatch(r"[a-z][a-z0-9_]{0,127}", code):
        return code
    return "dense_build_failed"


def main() -> int:
    args = _parser().parse_args()
    try:
        inventory = run(load_builder_spec(args.config))
    except (
        CrawlerSourceError,
        DenseBuilderConfigError,
        DenseReleaseError,
        SharedGpuTransportError,
        OSError,
    ) as exc:
        print(
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-dense-build-error-v1",
                    "code": _sanitized_error_code(exc),
                }
            ).decode("utf-8")
        )
        return 2
    print(canonical_json_bytes(inventory).decode("utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
