"""Strict JSON helpers for security- and release-sensitive artifacts."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


class DuplicateKeyError(ValueError):
    pass


_SHA256 = re.compile(r"^sha256:[0-9a-f]{64}$")


def is_sha256(value: object) -> bool:
    return isinstance(value, str) and _SHA256.fullmatch(value) is not None


def _object_without_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise DuplicateKeyError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_strict_json(path: Path) -> Any:
    return loads_strict_json(Path(path).read_text(encoding="utf-8"))


def loads_strict_json(text: str) -> Any:
    return json.loads(text, object_pairs_hook=_object_without_duplicates)


def canonical_json_bytes(value: Any) -> bytes:
    """Return the one accepted UTF-8 representation for release artifacts.

    The encoder deliberately does not add a BOM, indentation, or trailing
    newline.  ``allow_nan=False`` and strict UTF-8 encoding reject values that
    cannot have a portable JSON identity, including non-finite floats and
    unpaired Unicode surrogates.
    """

    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def loads_canonical_json_bytes(payload: bytes) -> Any:
    """Strictly parse canonical JSON bytes and reject alternate encodings."""

    parsed = loads_strict_json(payload.decode("utf-8"))
    if payload != canonical_json_bytes(parsed):
        raise ValueError("JSON bytes are not canonical")
    return parsed
