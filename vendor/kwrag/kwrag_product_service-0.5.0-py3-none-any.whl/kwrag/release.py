"""Build deterministic index and authorization release artifacts."""

from __future__ import annotations

import hashlib
import os
import re
import stat
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

from .jsonutil import canonical_json_bytes, is_sha256, load_strict_json
from .manifest import IndexManifest, load_and_verify_manifest

_SAFE_ID = re.compile(r"^[A-Za-z0-9._-]+$")
_FULL_COMMIT = re.compile(r"^[0-9a-f]{40}$")
_MIN_GRANT_LIFETIME_SECONDS = 300
_MAX_GRANT_LIFETIME_SECONDS = 3600
_MAX_CLOCK_SKEW_SECONDS = 30


class ReleaseError(ValueError):
    pass


def _utc_timestamp(value: object, field: str) -> datetime:
    text = str(value or "").strip()
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ReleaseError(f"grant export {field} is invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ReleaseError(f"grant export {field} must be timezone-aware")
    return parsed.astimezone(timezone.utc)


def _canonical_digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def _runtime_group_gid() -> int:
    if os.name != "posix":
        raise ReleaseError("kwrag_rt group lookup is only available on POSIX")
    try:
        import grp

        return grp.getgrnam("kwrag_rt").gr_gid
    except (ImportError, KeyError, OSError) as exc:
        raise ReleaseError("kwrag_rt group lookup failed") from exc


def _file_digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return "sha256:" + digest.hexdigest()


def token_environment_name(instance_id: str) -> str:
    normalized = str(uuid.UUID(str(instance_id).strip().lower()))
    return "KWRAG_TOKEN_" + normalized.replace("-", "").upper()


def validate_projection_staging_output(path: Path, staging_root: Path) -> None:
    target = Path(os.path.abspath(path))
    root = Path(os.path.abspath(staging_root))
    prefix = ".staging-projection-"
    parent_name = target.parent.name
    if (
        target.parent.parent != root
        or not parent_name.startswith(prefix)
        or target.name != "token-projection.json"
    ):
        raise ReleaseError("projection CLI output must be an approved staging path")
    try:
        suffix = parent_name[len(prefix) :]
        if str(uuid.UUID(suffix)) != suffix:
            raise ValueError
    except ValueError as exc:
        raise ReleaseError("projection CLI staging directory UUID is invalid") from exc
    try:
        root_info = root.lstat()
        parent_info = target.parent.lstat()
    except OSError as exc:
        raise ReleaseError("projection CLI staging path is unavailable") from exc
    strict_posix_identity = os.name == "posix"
    expected_group = _runtime_group_gid() if strict_posix_identity else None
    if (
        stat.S_ISLNK(root_info.st_mode)
        or not stat.S_ISDIR(root_info.st_mode)
        or (
            strict_posix_identity
            and (
                root_info.st_uid != 0
                or root_info.st_gid != expected_group
                or stat.S_IMODE(root_info.st_mode) != 0o750
                or root_info.st_nlink < 2
            )
        )
    ):
        raise ReleaseError("projection CLI staging root identity is invalid")
    if (
        stat.S_ISLNK(parent_info.st_mode)
        or not stat.S_ISDIR(parent_info.st_mode)
        or (
            strict_posix_identity
            and (
                parent_info.st_uid != 0
                or parent_info.st_gid != 0
                or stat.S_IMODE(parent_info.st_mode) != 0o700
                or parent_info.st_nlink != 2
            )
        )
        or parent_info.st_dev != root_info.st_dev
    ):
        raise ReleaseError("projection CLI staging directory identity is invalid")
    if target.exists() or target.is_symlink():
        raise ReleaseError("projection CLI staging output already exists")


def write_private_json_exclusive(
    path: Path, staging_root: Path, value: Mapping[str, Any]
) -> None:
    """Create one private staging artifact through pinned directory fds on POSIX."""

    target = Path(os.path.abspath(path))
    root = Path(os.path.abspath(staging_root))
    validate_projection_staging_output(target, root)
    payload = canonical_json_bytes(value)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0)
    if not hasattr(os, "O_NOFOLLOW"):
        if os.name == "posix":
            raise ReleaseError("projection staging requires O_NOFOLLOW")
        nofollow = 0
    else:
        nofollow = os.O_NOFOLLOW
    flags |= nofollow
    root_descriptor: int | None = None
    parent_descriptor: int | None = None
    descriptor: int | None = None
    try:
        if os.name == "posix":
            if not hasattr(os, "O_DIRECTORY"):
                raise ReleaseError("projection staging requires O_DIRECTORY")
            directory_flags = (
                os.O_RDONLY
                | os.O_DIRECTORY
                | nofollow
                | getattr(os, "O_CLOEXEC", 0)
            )
            root_descriptor = os.open(root, directory_flags)
            root_info = os.fstat(root_descriptor)
            expected_group = _runtime_group_gid()
            parent_descriptor = os.open(
                target.parent.name,
                directory_flags,
                dir_fd=root_descriptor,
            )
            parent_info = os.fstat(parent_descriptor)
            if (
                not stat.S_ISDIR(root_info.st_mode)
                or root_info.st_uid != 0
                or root_info.st_gid != expected_group
                or stat.S_IMODE(root_info.st_mode) != 0o750
                or root_info.st_nlink < 2
                or not stat.S_ISDIR(parent_info.st_mode)
                or parent_info.st_uid != 0
                or parent_info.st_gid != 0
                or stat.S_IMODE(parent_info.st_mode) != 0o700
                or parent_info.st_nlink != 2
                or parent_info.st_dev != root_info.st_dev
            ):
                raise ReleaseError("projection staging fd identity is invalid")
            descriptor = os.open(
                target.name,
                flags,
                0o600,
                dir_fd=parent_descriptor,
            )
        else:
            descriptor = os.open(target, flags, 0o600)
        metadata = os.fstat(descriptor)
        if (
            not stat.S_ISREG(metadata.st_mode)
            or (
                os.name == "posix"
                and (
                    metadata.st_uid != 0
                    or metadata.st_gid != 0
                    or stat.S_IMODE(metadata.st_mode) != 0o600
                    or metadata.st_dev != root_info.st_dev
                )
            )
            or metadata.st_nlink != 1
        ):
            raise ReleaseError("projection staging artifact identity is invalid")
        view = memoryview(payload)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise ReleaseError("projection staging artifact write was incomplete")
            view = view[written:]
        os.fsync(descriptor)
    except OSError as exc:
        raise ReleaseError("projection staging artifact could not be created") from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if parent_descriptor is not None:
            os.close(parent_descriptor)
        if root_descriptor is not None:
            os.close(root_descriptor)


def _validate_grant_source(source: object, manifest_digest: str) -> tuple[str, str]:
    if not isinstance(source, dict):
        raise ReleaseError("grant export source must be an object")
    expected = {
        "schema",
        "ops_commit",
        "runtime_bindings_digest",
        "nas_views_digest",
        "membership_set_digest",
        "index_manifest_digest",
        "authoritative_state_digest",
    }
    if set(source) != expected or source.get("schema") != "kwrag-grant-source/v1":
        raise ReleaseError("grant export source fields are invalid")
    ops_commit = str(source.get("ops_commit") or "")
    if not _FULL_COMMIT.fullmatch(ops_commit):
        raise ReleaseError("grant export source ops_commit is invalid")
    digest_fields = {
        name: str(source.get(name) or "")
        for name in (
            "runtime_bindings_digest",
            "nas_views_digest",
            "membership_set_digest",
            "index_manifest_digest",
        )
    }
    if any(not is_sha256(value) for value in digest_fields.values()):
        raise ReleaseError("grant export source contains an invalid digest")
    if digest_fields["index_manifest_digest"] != manifest_digest:
        raise ReleaseError("grant export source targets a different index manifest")
    authoritative_payload = {
        "schema": "kwrag-grant-source/v1",
        "ops_commit": ops_commit,
        **digest_fields,
    }
    authoritative_state_digest = str(source.get("authoritative_state_digest") or "")
    if authoritative_state_digest != _canonical_digest(authoritative_payload):
        raise ReleaseError("grant export authoritative state digest is invalid")
    return ops_commit, authoritative_state_digest


def build_index_manifest(
    *,
    index_dir: Path,
    rooms: Mapping[str, str],
    release_id: str,
    corpus_snapshot: str,
    embedding_fingerprint: str,
) -> dict[str, Any]:
    if not release_id.strip() or not corpus_snapshot.strip():
        raise ReleaseError("release_id and corpus_snapshot are required")
    if not is_sha256(embedding_fingerprint):
        raise ReleaseError("embedding_fingerprint is required")
    if not rooms:
        raise ReleaseError("at least one corpus is required")
    root = Path(index_dir).resolve()
    entries: dict[str, Any] = {}
    for room, conversation_id in sorted(rooms.items()):
        room = str(room).strip()
        conversation_id = str(conversation_id).strip()
        if not _SAFE_ID.fullmatch(room) or not _SAFE_ID.fullmatch(conversation_id):
            raise ReleaseError("room or conversation_id is invalid")
        files = []
        for filename in (
            f"room_{conversation_id}.npy",
            f"room_{conversation_id}.meta.sqlite",
        ):
            path = root / filename
            if not path.is_file():
                raise ReleaseError(f"required index file is missing: {filename}")
            files.append(
                {"path": filename, "sha256": _file_digest(path), "bytes": path.stat().st_size}
            )
        entries[room] = {"conversation_id": conversation_id, "files": files}
    return {
        "version": 1,
        "release_id": release_id.strip(),
        "corpus_snapshot": corpus_snapshot.strip(),
        "embedding_fingerprint": embedding_fingerprint,
        "rooms": entries,
    }


def build_token_projection(
    *, manifest: IndexManifest, grant_export: Mapping[str, Any], environment: Mapping[str, str]
) -> dict[str, Any]:
    unknown_top_level = set(grant_export) - {
        "version",
        "source_ref",
        "source",
        "generated_at",
        "expires_at",
        "grants",
    }
    if unknown_top_level:
        raise ReleaseError("grant export has unknown fields")
    ops_commit, authoritative_state_digest = _validate_grant_source(
        grant_export.get("source"), manifest.digest
    )
    expected_source_ref = f"ops-grant-export:{ops_commit}:{authoritative_state_digest}"
    source_ref = str(grant_export.get("source_ref") or "").strip()
    if grant_export.get("version") != 1 or source_ref != expected_source_ref:
        raise ReleaseError("grant export version or source_ref is invalid")
    generated_at = _utc_timestamp(grant_export.get("generated_at"), "generated_at")
    expires_at = _utc_timestamp(grant_export.get("expires_at"), "expires_at")
    lifetime = (expires_at - generated_at).total_seconds()
    if (
        lifetime < _MIN_GRANT_LIFETIME_SECONDS
        or lifetime > _MAX_GRANT_LIFETIME_SECONDS
    ):
        raise ReleaseError("grant export validity must be between 300 and 3600 seconds")
    now = datetime.now(timezone.utc)
    if generated_at > now + timedelta(seconds=_MAX_CLOCK_SKEW_SECONDS):
        raise ReleaseError("grant export generated_at is in the future")
    if now >= expires_at:
        raise ReleaseError("grant export is expired")
    grants = grant_export.get("grants")
    if not isinstance(grants, list):
        raise ReleaseError("grant export grants must be a list")
    tokens: dict[str, Any] = {}
    slot_ids: set[str] = set()
    instance_ids: set[str] = set()
    ordered_instance_ids: list[str] = []
    for entry in grants:
        if not isinstance(entry, dict):
            raise ReleaseError("grant entry must be an object")
        if set(entry) != {"instance_id", "slot_id", "corpora"}:
            raise ReleaseError("grant entry fields are invalid")
        instance_id = str(entry.get("instance_id") or "").strip().lower()
        try:
            if str(uuid.UUID(instance_id)) != instance_id:
                raise ValueError
        except ValueError as exc:
            raise ReleaseError("grant entry instance_id is invalid") from exc
        slot_id = str(entry.get("slot_id") or "").strip()
        corpora_raw = entry.get("corpora")
        if (
            not _SAFE_ID.fullmatch(slot_id)
            or not isinstance(corpora_raw, list)
        ):
            raise ReleaseError("grant entry is incomplete")
        if any(not isinstance(item, str) for item in corpora_raw):
            raise ReleaseError("grant entry references an unavailable corpus")
        corpora_input = [item.strip() for item in corpora_raw]
        corpora = sorted(set(corpora_input))
        if (
            not corpora
            or corpora_input != corpora
            or any(not _SAFE_ID.fullmatch(item) for item in corpora)
            or set(corpora) - set(manifest.rooms)
        ):
            raise ReleaseError("grant entry references an unavailable corpus")
        if slot_id in slot_ids:
            raise ReleaseError("grant export contains a duplicate slot")
        if instance_id in instance_ids:
            raise ReleaseError("grant export contains a duplicate instance")
        token_env = token_environment_name(instance_id)
        token = environment.get(token_env, "")
        if (
            len(token) < 32
            or token.strip() != token
            or any(character.isspace() for character in token)
        ):
            raise ReleaseError(f"required token environment is missing or too short: {token_env}")
        if token in tokens:
            raise ReleaseError("two slots resolve to the same service token")
        tokens[token] = {
            "instance_id": instance_id,
            "slot_id": slot_id,
            "corpora": corpora,
        }
        slot_ids.add(slot_id)
        instance_ids.add(instance_id)
        ordered_instance_ids.append(instance_id)
    if ordered_instance_ids != sorted(ordered_instance_ids):
        raise ReleaseError("grant export entries are not sorted by instance_id")
    return {
        "version": 1,
        "index_manifest": manifest.digest,
        "source_digest": _canonical_digest(grant_export),
        "generated_at": generated_at.isoformat().replace("+00:00", "Z"),
        "expires_at": expires_at.isoformat().replace("+00:00", "Z"),
        "tokens": tokens,
    }


def write_json(path: Path, value: Mapping[str, Any], *, private: bool = False) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".tmp")
    temporary.write_bytes(canonical_json_bytes(value))
    if private:
        temporary.chmod(0o600)
    temporary.replace(target)


def manifest_cli() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Build a verified kwrag index manifest")
    parser.add_argument("--index-dir", required=True, type=Path)
    parser.add_argument("--rooms", required=True, type=Path)
    parser.add_argument("--release-id", required=True)
    parser.add_argument("--corpus-snapshot", required=True)
    parser.add_argument("--embedding-fingerprint", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    rooms = load_strict_json(args.rooms)
    if not isinstance(rooms, dict):
        raise ReleaseError("rooms file must be an object mapping corpus to conversation id")
    manifest = build_index_manifest(
        index_dir=args.index_dir,
        rooms=rooms,
        release_id=args.release_id,
        corpus_snapshot=args.corpus_snapshot,
        embedding_fingerprint=args.embedding_fingerprint,
    )
    write_json(args.output, manifest)
    print(_canonical_digest(manifest))


def projection_cli() -> None:
    import argparse

    parser = argparse.ArgumentParser(
        description=(
            "Derive a private slot-token projection staging artifact; "
            "this command is not the live publisher"
        )
    )
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--index-dir", required=True, type=Path)
    parser.add_argument("--grant-export", required=True, type=Path)
    parser.add_argument("--staging-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    validate_projection_staging_output(args.output, args.staging_root)
    manifest = load_and_verify_manifest(args.manifest, args.index_dir)
    grant_export = load_strict_json(args.grant_export)
    if not isinstance(grant_export, dict):
        raise ReleaseError("grant export must be an object")
    projection = build_token_projection(
        manifest=manifest, grant_export=grant_export, environment=os.environ
    )
    write_private_json_exclusive(args.output, args.staging_root, projection)
    print(_canonical_digest({"projection": projection["source_digest"], "manifest": manifest.digest}))
