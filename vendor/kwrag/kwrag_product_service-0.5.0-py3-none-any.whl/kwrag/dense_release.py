"""Disposable slot-Workspace dense indexes derived from mounted messages."""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import sqlite3
import stat
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence
from uuid import uuid4

from .dense_source import DenseMessageSource, SourceMessage
from .jsonutil import (
    canonical_json_bytes,
    is_sha256,
    loads_canonical_json_bytes,
)
from .manifest import load_and_verify_manifest
from .shared_gpu_contract import (
    KURE_DIMENSION,
    KURE_MODEL,
    KURE_REVISION,
    MODEL_MAX_TOKENS,
)
from .shared_gpu_transport import GpuCallResult, GpuInferenceClient


DENSE_RELEASE_SCHEMA = "kwrag-dense-release-v2"
DENSE_POINTER_SCHEMA = "kwrag-dense-release-pointer-v1"
SEGMENT_TRANSFORM_ID = "kwrag-adaptive-message-segments-v2"
MAX_SEGMENT_CHARS = 4_000
MAX_SEGMENT_MESSAGES = 32
MAX_RELEASE_ROOMS = 4_096
MAX_RELEASE_SEGMENTS = 10_000_000
MAX_POINTER_BYTES = 64 * 1024

_SLOT_RE = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")


class DenseReleaseError(ValueError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _canonical_directory(path: Path, *, code: str) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise DenseReleaseError(code)
    try:
        metadata = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise DenseReleaseError(code) from exc
    if (
        supplied.is_symlink()
        or not stat.S_ISDIR(metadata.st_mode)
        or resolved != supplied.absolute()
    ):
        raise DenseReleaseError(code)
    return resolved


EMBEDDING_FINGERPRINT = _sha256(
    canonical_json_bytes(
        {
            "model": KURE_MODEL,
            "revision": KURE_REVISION,
            "dimension": KURE_DIMENSION,
            "max_tokens": MODEL_MAX_TOKENS,
            "normalize": True,
        }
    )
)
D_PIPELINE_FINGERPRINT = _sha256(
    canonical_json_bytes(
        {
            "schema_version": "kwrag-d-pipeline-identity-v1",
            "embedding_fingerprint": EMBEDDING_FINGERPRINT,
            "index_placement": "slot_workspace",
            "embedding_execution": "shared_stateless",
            "rerank_execution": "shared_stateless",
            "rerank_model": "BAAI/bge-reranker-v2-m3",
            "rerank_revision": "953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e",
            "model_max_tokens": MODEL_MAX_TOKENS,
            "source_resolution": "current_slot_mounted_source",
            "segment_transform": SEGMENT_TRANSFORM_ID,
            "fallback": None,
        }
    )
)


@dataclass(frozen=True)
class SegmentReference:
    message_id: str
    start: int
    end: int

    def as_mapping(self) -> dict[str, Any]:
        return {
            "message_id": self.message_id,
            "start": self.start,
            "end": self.end,
        }


@dataclass(frozen=True)
class DenseSegment:
    segment_id: str
    room: str
    t_start: int
    t_end: int
    references: tuple[SegmentReference, ...]
    text: str
    text_sha256: str


def _segment(
    *,
    room: str,
    t_start: int,
    t_end: int,
    references: Sequence[SegmentReference],
    pieces: Sequence[str],
) -> DenseSegment:
    text = " ".join(pieces)
    if not text or len(text) > MAX_SEGMENT_CHARS or not references:
        raise DenseReleaseError("segment_bounds_invalid")
    identity = {
        "transform": SEGMENT_TRANSFORM_ID,
        "room": room,
        "references": [reference.as_mapping() for reference in references],
    }
    return DenseSegment(
        segment_id="s-" + hashlib.sha256(canonical_json_bytes(identity)).hexdigest(),
        room=room,
        t_start=t_start,
        t_end=t_end,
        references=tuple(references),
        text=text,
        text_sha256=_sha256(text.encode("utf-8")),
    )


def derive_dense_segments(messages: Sequence[SourceMessage]) -> list[DenseSegment]:
    """Deterministically merge bounded same-user turns and chunk long messages."""

    if not messages:
        raise DenseReleaseError("source_messages_missing")
    by_room: dict[str, list[SourceMessage]] = {}
    for message in messages:
        by_room.setdefault(message.room, []).append(message)
    output: list[DenseSegment] = []
    for room in sorted(by_room):
        ordered = sorted(
            by_room[room],
            key=lambda item: (
                item.sent_time,
                item.message_id,
                item.user_id,
                item.user_name,
            ),
        )
        gaps = sorted(
            max(0, ordered[index].sent_time - ordered[index - 1].sent_time)
            for index in range(1, len(ordered))
        )
        adaptive_gap = max(30, gaps[len(gaps) // 2] if gaps else 60)
        active_user: str | None = None
        active_start = 0
        active_end = 0
        refs: list[SegmentReference] = []
        pieces: list[str] = []

        def flush() -> None:
            nonlocal active_user, active_start, active_end, refs, pieces
            if refs:
                output.append(
                    _segment(
                        room=room,
                        t_start=active_start,
                        t_end=active_end,
                        references=refs,
                        pieces=pieces,
                    )
                )
            active_user = None
            active_start = 0
            active_end = 0
            refs = []
            pieces = []

        for message in ordered:
            if len(message.text) > MAX_SEGMENT_CHARS:
                flush()
                for start in range(0, len(message.text), MAX_SEGMENT_CHARS):
                    end = min(len(message.text), start + MAX_SEGMENT_CHARS)
                    output.append(
                        _segment(
                            room=room,
                            t_start=message.sent_time,
                            t_end=message.sent_time,
                            references=(
                                SegmentReference(message.message_id, start, end),
                            ),
                            pieces=(message.text[start:end],),
                        )
                    )
                continue
            proposed_chars = (
                sum(len(piece) for piece in pieces) + len(pieces) + len(message.text)
            )
            can_merge = (
                bool(refs)
                and message.user_id == active_user
                and message.sent_time - active_end <= adaptive_gap
                and len(refs) < MAX_SEGMENT_MESSAGES
                and proposed_chars <= MAX_SEGMENT_CHARS
            )
            if not can_merge:
                flush()
                active_user = message.user_id
                active_start = message.sent_time
            refs.append(SegmentReference(message.message_id, 0, len(message.text)))
            pieces.append(message.text)
            active_end = message.sent_time
        flush()
    if not output or len(output) > MAX_RELEASE_SEGMENTS:
        raise DenseReleaseError("segment_count_invalid")
    identifiers = [segment.segment_id for segment in output]
    if len(identifiers) != len(set(identifiers)):
        raise DenseReleaseError("segment_identity_collision")
    return output


def _write_new(path: Path, payload: bytes, *, mode: int = 0o600) -> tuple[str, int]:
    if path.exists() or path.is_symlink():
        raise DenseReleaseError("release_output_collision")
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(
        path,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
        mode,
    )
    try:
        view = memoryview(payload)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise DenseReleaseError("release_write_failed")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    return _sha256(payload), len(payload)


def _file_digest(
    path: Path, *, maximum: int = 8 * 1024 * 1024 * 1024
) -> tuple[str, int]:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(Path(path), flags)
    except OSError as exc:
        raise DenseReleaseError("release_file_unavailable") from exc
    digest = hashlib.sha256()
    total = 0
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size < 1
            or before.st_size > maximum
        ):
            raise DenseReleaseError("release_file_identity_invalid")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise DenseReleaseError("release_file_identity_invalid")
            digest.update(block)
        after = os.fstat(descriptor)
        identity_before = (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_nlink,
            before.st_size,
            before.st_mtime_ns,
        )
        identity_after = (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
        )
        if identity_before != identity_after or total != before.st_size:
            raise DenseReleaseError("release_file_changed")
    finally:
        os.close(descriptor)
    return "sha256:" + digest.hexdigest(), total


def _stable_payload(path: Path, *, maximum: int) -> bytes:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(Path(path), flags)
    except OSError as exc:
        raise DenseReleaseError("release_file_unavailable") from exc
    chunks: list[bytes] = []
    total = 0
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or not 1 <= before.st_size <= maximum
        ):
            raise DenseReleaseError("release_file_identity_invalid")
        while True:
            block = os.read(descriptor, min(64 * 1024, maximum + 1 - total))
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise DenseReleaseError("release_file_identity_invalid")
            chunks.append(block)
        after = os.fstat(descriptor)
        before_identity = (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_nlink,
            before.st_size,
            before.st_mtime_ns,
        )
        after_identity = (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
        )
        if before_identity != after_identity or total != before.st_size:
            raise DenseReleaseError("release_file_changed")
    finally:
        os.close(descriptor)
    return b"".join(chunks)


def _metadata_database(path: Path, segments: Sequence[DenseSegment]) -> tuple[str, int]:
    if path.exists() or path.is_symlink():
        raise DenseReleaseError("release_output_collision")
    connection = sqlite3.connect(path)
    try:
        connection.executescript(
            """
            PRAGMA page_size=4096;
            PRAGMA auto_vacuum=NONE;
            PRAGMA journal_mode=DELETE;
            PRAGMA synchronous=FULL;
            PRAGMA temp_store=MEMORY;
            PRAGMA application_id=1264017732;
            PRAGMA user_version=1;
            CREATE TABLE segments(
                row_id INTEGER PRIMARY KEY,
                segment_id TEXT NOT NULL UNIQUE,
                room_id TEXT NOT NULL,
                t_start INTEGER NOT NULL,
                t_end INTEGER NOT NULL,
                references_json TEXT NOT NULL,
                source_text_sha256 TEXT NOT NULL
            );
            CREATE INDEX segments_room_row ON segments(room_id,row_id);
            """
        )
        for row_id, segment in enumerate(segments):
            references = canonical_json_bytes(
                [reference.as_mapping() for reference in segment.references]
            ).decode("utf-8")
            connection.execute(
                "INSERT INTO segments VALUES(?,?,?,?,?,?,?)",
                (
                    row_id,
                    segment.segment_id,
                    segment.room,
                    segment.t_start,
                    segment.t_end,
                    references,
                    segment.text_sha256,
                ),
            )
        connection.commit()
        connection.execute("VACUUM")
    except sqlite3.Error as exc:
        raise DenseReleaseError("metadata_database_build_failed") from exc
    finally:
        connection.close()
    os.chmod(path, 0o600)
    uri = path.resolve(strict=True).as_uri() + "?mode=ro&immutable=1"
    with closing(sqlite3.connect(uri, uri=True)) as verify:
        if verify.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise DenseReleaseError("metadata_database_integrity_invalid")
        if int(verify.execute("SELECT COUNT(*) FROM segments").fetchone()[0]) != len(
            segments
        ):
            raise DenseReleaseError("metadata_database_count_invalid")
        text_columns = {
            str(row[1]).lower()
            for row in verify.execute("PRAGMA table_info(segments)")
            if "text" in str(row[1]).lower()
        }
        if text_columns != {"source_text_sha256"}:
            raise DenseReleaseError("metadata_database_raw_text_column_forbidden")
    return _file_digest(path)


def _vectors_file(path: Path, vectors: Sequence[Sequence[float]]) -> tuple[str, int]:
    try:
        import numpy as np
    except ImportError as exc:
        raise DenseReleaseError("numpy_unavailable") from exc
    array = np.asarray(vectors, dtype=np.float32)
    if (
        array.ndim != 2
        or array.shape[0] != len(vectors)
        or array.shape[1] < 1
        or not np.isfinite(array).all()
    ):
        raise DenseReleaseError("embedding_matrix_invalid")
    norms = np.linalg.norm(array, axis=1)
    if not np.all((norms > 0.99) & (norms < 1.01)):
        raise DenseReleaseError("embedding_matrix_not_normalized")
    if path.exists() or path.is_symlink():
        raise DenseReleaseError("release_output_collision")
    with path.open("xb") as handle:
        np.save(handle, array, allow_pickle=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(path, 0o600)
    return _file_digest(path)


def _builder_digest() -> str:
    return _file_digest(Path(__file__).resolve(strict=True), maximum=2 * 1024 * 1024)[0]


def build_dense_release(
    *,
    source: DenseMessageSource,
    gpu: GpuInferenceClient,
    output_root: Path,
    slot_namespace: str,
    allow_nonproduction: bool = False,
) -> dict[str, Any]:
    """Build one inactive content-addressed release; never advance a live pointer."""

    if _SLOT_RE.fullmatch(slot_namespace) is None:
        raise DenseReleaseError("slot_namespace_invalid")
    if not isinstance(allow_nonproduction, bool):
        raise DenseReleaseError("nonproduction_flag_invalid")
    output = Path(output_root)
    if not output.is_absolute():
        raise DenseReleaseError("output_root_invalid")
    output.mkdir(parents=True, exist_ok=True, mode=0o700)
    output = _canonical_directory(output, code="output_root_invalid")
    slot_root = output / slot_namespace
    staging = slot_root / f".dense-staging-{uuid4()}"
    staging.mkdir(parents=True, mode=0o700)
    try:
        messages = source.message_snapshot()
        segments = derive_dense_segments(messages)
        source_rooms = tuple(sorted({message.room for message in messages}))
        if not 1 <= len(source_rooms) <= MAX_RELEASE_ROOMS:
            raise DenseReleaseError("source_room_count_invalid")
        vectors: list[list[float]] = []
        calls: list[GpuCallResult] = []
        for offset in range(0, len(segments), 32):
            batch = segments[offset : offset + 32]
            call = gpu.embed_corpus([segment.text for segment in batch])
            if (
                call.production_backend
                and (call.model != KURE_MODEL or call.revision != KURE_REVISION)
            ) or (not call.production_backend and not allow_nonproduction):
                raise DenseReleaseError("embedding_execution_identity_invalid")
            raw_vectors = call.output.get("vectors")
            if not isinstance(raw_vectors, list) or len(raw_vectors) != len(batch):
                raise DenseReleaseError("embedding_output_invalid")
            vectors.extend(raw_vectors)
            calls.append(call)
        build_gpu_receipt = gpu.commit_operation(calls)
        metadata_path = staging / "segments.sqlite3"
        vectors_path = staging / "vectors.npy"
        metadata_digest, metadata_bytes = _metadata_database(metadata_path, segments)
        vectors_digest, vectors_bytes = _vectors_file(vectors_path, vectors)
        dimension = len(vectors[0])
        production_eligible = all(call.production_backend for call in calls)
        if production_eligible and dimension != KURE_DIMENSION:
            raise DenseReleaseError("production_embedding_dimension_invalid")
        snapshot = {
            "schema_version": "kwrag-dense-index-input-v2",
            "source_kind": str(getattr(source, "source_kind", "message_source")),
            "authorized_room_count": len(source_rooms),
            "authorized_room_set_sha256": _sha256(
                canonical_json_bytes(list(source_rooms))
            ),
            "source_message_count": len(messages),
            "indexable_message_count": len(messages),
            "segment_count": len(segments),
            "segment_transform": SEGMENT_TRANSFORM_ID,
            "embedding_model": KURE_MODEL if production_eligible else calls[0].model,
            "embedding_revision": (
                KURE_REVISION if production_eligible else calls[0].revision
            ),
            "embedding_dimension": dimension,
            "embedding_execution": "shared_stateless",
            "builder_source_sha256": _builder_digest(),
            "production_eligible": production_eligible,
            "raw_content_present": False,
        }
        snapshot_payload = canonical_json_bytes(snapshot)
        snapshot_digest, snapshot_bytes = _write_new(
            staging / "source-snapshot.json", snapshot_payload
        )
        release_identity = {
            "schema_version": DENSE_RELEASE_SCHEMA,
            "slot_namespace": slot_namespace,
            "source_snapshot_sha256": snapshot_digest,
            "metadata_sha256": metadata_digest,
            "vectors_sha256": vectors_digest,
            "embedding_fingerprint": EMBEDDING_FINGERPRINT,
            "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
        }
        release_id = (
            "d-" + hashlib.sha256(canonical_json_bytes(release_identity)).hexdigest()
        )
        declared_files = [
            {"path": "segments.sqlite3", "sha256": metadata_digest},
            {"path": "vectors.npy", "sha256": vectors_digest},
            {"path": "source-snapshot.json", "sha256": snapshot_digest},
        ]
        rooms = {
            room: {
                "conversation_id": room,
                "files": declared_files,
            }
            for room in source_rooms
        }
        manifest = {
            "version": 1,
            "release_id": release_id,
            "corpus_snapshot": snapshot_digest,
            "embedding_fingerprint": EMBEDDING_FINGERPRINT,
            "rooms": rooms,
            "kwrag_dense": {
                "schema_version": DENSE_RELEASE_SCHEMA,
                "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
                "segment_transform": SEGMENT_TRANSFORM_ID,
                "metadata_relative": "segments.sqlite3",
                "vectors_relative": "vectors.npy",
                "source_snapshot_relative": "source-snapshot.json",
                "embedding_model": KURE_MODEL
                if production_eligible
                else calls[0].model,
                "embedding_revision": (
                    KURE_REVISION if production_eligible else calls[0].revision
                ),
                "embedding_dimension": dimension,
                "segment_count": len(segments),
                "production_eligible": production_eligible,
                "raw_content_in_release": False,
            },
        }
        manifest_payload = canonical_json_bytes(manifest)
        manifest_digest, manifest_bytes = _write_new(
            staging / "index-manifest.json", manifest_payload
        )
        verified = load_and_verify_manifest(staging / "index-manifest.json", staging)
        if verified.digest != manifest_digest or verified.release_id != release_id:
            raise DenseReleaseError("dense_manifest_verification_failed")
        destination = slot_root / "releases" / release_id
        destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if destination.exists() or destination.is_symlink():
            existing = destination / "index-manifest.json"
            if not existing.is_file() or _file_digest(existing)[0] != manifest_digest:
                raise DenseReleaseError("release_identity_collision")
            shutil.rmtree(staging)
        else:
            staging.replace(destination)
            os.chmod(destination, 0o700)
        return {
            "schema_version": "kwrag-dense-release-build-inventory-v1",
            "status": "PRIVATE_INACTIVE_RELEASE",
            "slot_namespace": slot_namespace,
            "release_id": release_id,
            "release_relative": f"{slot_namespace}/releases/{release_id}",
            "manifest_sha256": manifest_digest,
            "manifest_bytes": manifest_bytes,
            "metadata_sha256": metadata_digest,
            "metadata_bytes": metadata_bytes,
            "vectors_sha256": vectors_digest,
            "vectors_bytes": vectors_bytes,
            "source_snapshot_sha256": snapshot_digest,
            "source_snapshot_bytes": snapshot_bytes,
            "segment_count": len(segments),
            "embedding_dimension": dimension,
            "embedding_operation_receipt_digest": build_gpu_receipt,
            "production_eligible": production_eligible,
            "credential_used": False,
            "publication_performed": False,
            "runtime_mutation": False,
            "raw_content_in_inventory": False,
        }
    except Exception:
        if staging.exists() and staging.is_dir() and not staging.is_symlink():
            shutil.rmtree(staging)
        raise


def _load_pointer(path: Path) -> Mapping[str, Any] | None:
    if not path.exists() and not path.is_symlink():
        return None
    payload = _stable_payload(path, maximum=MAX_POINTER_BYTES)
    try:
        raw = loads_canonical_json_bytes(payload)
    except (UnicodeDecodeError, ValueError) as exc:
        raise DenseReleaseError("dense_pointer_not_canonical") from exc
    fields = {
        "schema_version",
        "sequence",
        "current_release_id",
        "current_manifest_sha256",
        "previous_release_id",
        "previous_manifest_sha256",
    }
    if not isinstance(raw, Mapping) or set(raw) != fields:
        raise DenseReleaseError("dense_pointer_fields_invalid")
    if raw.get("schema_version") != DENSE_POINTER_SCHEMA:
        raise DenseReleaseError("dense_pointer_schema_invalid")
    sequence = raw.get("sequence")
    current_release = raw.get("current_release_id")
    if (
        isinstance(sequence, bool)
        or not isinstance(sequence, int)
        or not 1 <= sequence <= 2**63 - 1
        or not isinstance(current_release, str)
        or re.fullmatch(r"d-[0-9a-f]{64}", current_release) is None
    ):
        raise DenseReleaseError("dense_pointer_identity_invalid")
    if not is_sha256(raw.get("current_manifest_sha256")):
        raise DenseReleaseError("dense_pointer_digest_invalid")
    previous = raw.get("previous_release_id")
    previous_digest = raw.get("previous_manifest_sha256")
    if (previous is None) != (previous_digest is None) or (
        (
            previous is not None
            and re.fullmatch(r"d-[0-9a-f]{64}", str(previous)) is None
        )
        or (previous_digest is not None and not is_sha256(previous_digest))
    ):
        raise DenseReleaseError("dense_pointer_previous_invalid")
    return raw


def activate_dense_release(
    *,
    slot_root: Path,
    release_id: str,
    manifest_sha256: str,
    expected_previous_release_id: str | None,
) -> dict[str, Any]:
    """Atomically advance one local pointer after verifying an immutable release."""

    root = _canonical_directory(Path(slot_root), code="slot_release_root_invalid")
    if not re.fullmatch(r"d-[0-9a-f]{64}", release_id) or not is_sha256(
        manifest_sha256
    ):
        raise DenseReleaseError("release_activation_identity_invalid")
    manifest_path = root / "releases" / release_id / "index-manifest.json"
    if _file_digest(manifest_path)[0] != manifest_sha256:
        raise DenseReleaseError("release_activation_manifest_mismatch")
    verified = load_and_verify_manifest(manifest_path, manifest_path.parent)
    if verified.release_id != release_id or verified.digest != manifest_sha256:
        raise DenseReleaseError("release_activation_verification_failed")
    pointer_path = root / "current.json"
    current = _load_pointer(pointer_path)
    current_id = current.get("current_release_id") if current else None
    if current_id != expected_previous_release_id:
        raise DenseReleaseError("release_activation_previous_mismatch")
    sequence = int(current.get("sequence", 0)) + 1 if current else 1
    pointer = {
        "schema_version": DENSE_POINTER_SCHEMA,
        "sequence": sequence,
        "current_release_id": release_id,
        "current_manifest_sha256": manifest_sha256,
        "previous_release_id": current_id,
        "previous_manifest_sha256": (
            current.get("current_manifest_sha256") if current else None
        ),
    }
    temporary = root / f".current-{uuid4()}.json"
    digest, size = _write_new(temporary, canonical_json_bytes(pointer))
    temporary.replace(pointer_path)
    if os.name == "posix":
        parent_descriptor = os.open(root, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(parent_descriptor)
        finally:
            os.close(parent_descriptor)
    return {
        "schema_version": "kwrag-dense-release-activation-receipt-v1",
        "sequence": sequence,
        "current_release_id": release_id,
        "previous_release_id": current_id,
        "pointer_sha256": digest,
        "pointer_bytes": size,
        "atomic_replace": True,
        "raw_content_present": False,
    }


def rollback_dense_release(
    *, slot_root: Path, expected_current_release_id: str
) -> dict[str, Any]:
    root = _canonical_directory(Path(slot_root), code="slot_release_root_invalid")
    current = _load_pointer(root / "current.json")
    if (
        current is None
        or current.get("current_release_id") != expected_current_release_id
    ):
        raise DenseReleaseError("rollback_current_mismatch")
    previous = current.get("previous_release_id")
    previous_digest = current.get("previous_manifest_sha256")
    if not isinstance(previous, str) or not isinstance(previous_digest, str):
        raise DenseReleaseError("rollback_previous_unavailable")
    return activate_dense_release(
        slot_root=slot_root,
        release_id=previous,
        manifest_sha256=previous_digest,
        expected_previous_release_id=expected_current_release_id,
    )


def dense_gc_candidates(slot_root: Path) -> list[str]:
    """List only releases that are neither current nor previous; delete nothing."""

    root = _canonical_directory(Path(slot_root), code="slot_release_root_invalid")
    pointer = _load_pointer(root / "current.json")
    retained = set()
    if pointer:
        retained.add(str(pointer["current_release_id"]))
        if pointer.get("previous_release_id") is not None:
            retained.add(str(pointer["previous_release_id"]))
    releases = root / "releases"
    if not releases.is_dir() or releases.is_symlink():
        return []
    candidates = []
    for entry in releases.iterdir():
        if (
            entry.is_dir()
            and not entry.is_symlink()
            and re.fullmatch(r"d-[0-9a-f]{64}", entry.name)
            and entry.name not in retained
        ):
            candidates.append(entry.name)
    return sorted(candidates)
