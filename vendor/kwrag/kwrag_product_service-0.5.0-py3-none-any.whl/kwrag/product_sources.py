"""Registry-backed mounted sources for the product-native dense runtime.

The product mount and opened source files are authoritative.  This module
only composes the fixed source adapters selected by the caller's bounded
scope; it does not accept paths, generations, manifests, or recovery policy
from a retrieval request.
"""

from __future__ import annotations

import stat
from dataclasses import replace
from pathlib import Path
from typing import Mapping, Sequence

from .dense_source import DenseSourceReferenceUnavailable, SourceMessage
from .live_groupware import LiveGroupwareSource, LiveGroupwareSourceError
from .live_kakao import LiveKakaoPackageSource, LiveKakaoSourceError
from .product_contract import (
    ProductContractError,
    decode_product_corpus,
    encode_product_corpus,
    product_source_adapter,
)


_FATAL_SOURCE_CODES = frozenset(
    {
        "membership_invalid",
        "membership_size_invalid",
        "source_document_identity_collision",
        "source_message_identity_invalid",
        "source_mount_is_writable",
        "source_package_file_invalid",
        "source_package_root_invalid",
        "source_snapshot_unbounded",
        "source_tree_unbounded",
    }
)


class ProductMountedSourceError(ValueError):
    """One fixed mounted-source composition cannot safely serve a request."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _error_code(exc: BaseException) -> str:
    code = getattr(exc, "code", None)
    if isinstance(code, str) and code:
        return code
    rendered = str(exc)
    return rendered if rendered else "source_unavailable"


def _real_directory(path: Path) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise ProductMountedSourceError("product_mount_root_invalid")
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise ProductMountedSourceError("product_mount_root_unavailable") from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise ProductMountedSourceError("product_mount_root_invalid")
    return resolved


def _fatal(code: str) -> bool:
    return code in _FATAL_SOURCE_CODES


class ProductMountedSource:
    """One or more fixed source adapters behind the dense-source protocol."""

    stale_references_are_skipped = True

    def __init__(
        self,
        *,
        package_root: Path,
        selected_source_names: Sequence[str],
        sources: Mapping[str, object],
        unavailable_source_codes: Sequence[tuple[str, str]] = (),
    ):
        names = tuple(sorted(selected_source_names))
        if not names or len(names) != len(set(names)):
            raise ProductMountedSourceError("product_source_selection_invalid")
        if set(sources) - set(names) or not sources:
            raise ProductMountedSourceError("product_mounted_sources_unavailable")
        self.package_root = _real_directory(package_root)
        self.selected_source_names = names
        self.source_names = tuple(sorted(sources))
        self._sources = dict(sources)
        self._unavailable = dict(unavailable_source_codes)
        self.source_kind = (
            str(getattr(next(iter(self._sources.values())), "source_kind"))
            if len(self._sources) == 1
            else "product_mounted_sources_v1"
        )

    @property
    def unavailable_source_codes(self) -> tuple[tuple[str, str], ...]:
        return tuple(sorted(self._unavailable.items()))

    def _source_failed(self, source_name: str, exc: BaseException) -> None:
        code = _error_code(exc)
        if _fatal(code):
            raise ProductMountedSourceError(code) from exc
        self._unavailable[source_name] = code

    @property
    def rooms(self) -> tuple[str, ...]:
        corpora: list[str] = []
        for source_name in self.source_names:
            source = self._sources[source_name]
            try:
                source_rooms = tuple(getattr(source, "rooms"))
            except (OSError, ValueError) as exc:
                self._source_failed(source_name, exc)
                continue
            corpora.extend(
                encode_product_corpus(source_name, room) for room in source_rooms
            )
            self._unavailable.pop(source_name, None)
        if not corpora:
            raise ProductMountedSourceError("product_mounted_sources_unavailable")
        if len(corpora) != len(set(corpora)):
            raise ProductMountedSourceError("product_corpus_identity_collision")
        return tuple(sorted(corpora))

    def assert_available(self) -> None:
        available = 0
        for source_name in self.source_names:
            source = self._sources[source_name]
            try:
                getattr(source, "assert_available")()
                available += 1
                self._unavailable.pop(source_name, None)
            except (OSError, ValueError) as exc:
                self._source_failed(source_name, exc)
        if available == 0:
            raise ProductMountedSourceError("product_mounted_sources_unavailable")

    def message_snapshot(self) -> list[SourceMessage]:
        messages: list[SourceMessage] = []
        for source_name in self.source_names:
            source = self._sources[source_name]
            try:
                snapshot = getattr(source, "message_snapshot")()
            except (OSError, ValueError) as exc:
                self._source_failed(source_name, exc)
                continue
            for message in snapshot:
                messages.append(
                    replace(
                        message,
                        room=encode_product_corpus(source_name, message.room),
                    )
                )
            self._unavailable.pop(source_name, None)
        if not messages:
            raise ProductMountedSourceError("product_mounted_sources_unavailable")
        return sorted(
            messages,
            key=lambda message: (
                message.room,
                message.sent_time,
                message.message_id,
                message.user_id,
                message.user_name,
            ),
        )

    def resolve_references(
        self,
        *,
        room: str,
        references: Sequence[Mapping[str, object]],
        expected_text_sha256: str,
    ) -> tuple[str, tuple[str, ...]]:
        try:
            selector = decode_product_corpus(room)
            source = self._sources[selector.source]
        except (KeyError, ProductContractError) as exc:
            raise DenseSourceReferenceUnavailable(
                "segment_source_unavailable"
            ) from exc
        try:
            return getattr(source, "resolve_references")(
                room=selector.room_id,
                references=references,
                expected_text_sha256=expected_text_sha256,
            )
        except DenseSourceReferenceUnavailable:
            raise
        except (OSError, ValueError) as exc:
            code = _error_code(exc)
            if _fatal(code):
                raise ProductMountedSourceError(code) from exc
            self._unavailable[selector.source] = code
            raise DenseSourceReferenceUnavailable(
                "segment_source_unavailable"
            ) from exc

    def close(self) -> None:
        for source in self._sources.values():
            getattr(source, "close")()


def _open_source(source_name: str, root: Path, require_readonly: bool) -> object:
    if source_name == "kakao":
        return LiveKakaoPackageSource(root, require_readonly=require_readonly)
    if source_name == "groupware":
        return LiveGroupwareSource(root, require_readonly=require_readonly)
    raise ProductMountedSourceError("product_source_selection_invalid")


def open_product_mounted_source(
    mount_root: Path,
    source_names: Sequence[str],
    *,
    require_readonly: bool = True,
) -> ProductMountedSource:
    """Open selected adapters only from their fixed product-mount routes."""

    root = _real_directory(mount_root)
    names = tuple(sorted(source_names))
    if not names or len(names) != len(set(names)):
        raise ProductMountedSourceError("product_source_selection_invalid")
    sources: dict[str, object] = {}
    unavailable: list[tuple[str, str]] = []
    for source_name in names:
        try:
            adapter = product_source_adapter(source_name)
            sources[source_name] = _open_source(
                source_name,
                adapter.package_root(root),
                require_readonly,
            )
        except ProductContractError as exc:
            raise ProductMountedSourceError("product_source_selection_invalid") from exc
        except (LiveGroupwareSourceError, LiveKakaoSourceError, OSError) as exc:
            code = _error_code(exc)
            if _fatal(code):
                for opened in sources.values():
                    getattr(opened, "close")()
                raise ProductMountedSourceError(code) from exc
            unavailable.append((source_name, code))
    if not sources:
        raise ProductMountedSourceError("product_mounted_sources_unavailable")
    return ProductMountedSource(
        package_root=root,
        selected_source_names=names,
        sources=sources,
        unavailable_source_codes=unavailable,
    )


def open_kakao_package_source(
    package_root: Path,
    *,
    require_readonly: bool = True,
) -> ProductMountedSource:
    """Preserve the historical Kakao package-root runtime entrypoint."""

    root = _real_directory(package_root)
    try:
        source = LiveKakaoPackageSource(root, require_readonly=require_readonly)
    except (LiveKakaoSourceError, OSError) as exc:
        raise ProductMountedSourceError(_error_code(exc)) from exc
    return ProductMountedSource(
        package_root=root,
        selected_source_names=("kakao",),
        sources={"kakao": source},
    )


__all__ = [
    "ProductMountedSource",
    "ProductMountedSourceError",
    "open_kakao_package_source",
    "open_product_mounted_source",
]
