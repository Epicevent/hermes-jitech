"""Product-native Kakao RAG over one slot's corpus and Workspace index.

The read-only Kakao package is the live corpus. The disposable dense index
lives in the slot's writable Workspace. A caller chooses whether to search;
this module does not generate a query or choose a provider. It only connects
the existing KURE embedding and BGE reranker service to the local vector index.
"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .dense_release import D_PIPELINE_FINGERPRINT
from .jsonutil import canonical_json_bytes
from .operation import ReceiptWriter
from .shared_gpu_transport import ContentFreeGpuJournal, UnixSharedGpuClient
from .slot_api import SlotSearchExchange
from .workspace_dense import (
    WorkspaceDenseRuntime,
    open_workspace_dense_runtime,
    rebuild_workspace_dense_index,
)


class ProductRuntimeError(ValueError):
    """The current slot cannot serve or rebuild its Kakao RAG index."""


def _require_slot_namespace(value: str) -> str:
    if (
        not isinstance(value, str)
        or re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", value) is None
    ):
        raise ProductRuntimeError("slot_namespace_invalid")
    return value


@dataclass(frozen=True)
class ProductRuntimeIdentity:
    index_manifest: str
    pipeline_fingerprint: str
    digest: str


def _principal() -> str:
    geteuid = getattr(os, "geteuid", None)
    if not callable(geteuid):
        raise ProductRuntimeError("product_runtime_requires_posix_identity")
    return f"uid:{geteuid()}"


def _gpu_client(
    *,
    socket_path: Path,
    slot_namespace: str,
    gpu_receipt_path: Path,
    deadline_ms: int,
) -> UnixSharedGpuClient:
    return UnixSharedGpuClient(
        socket_path=Path(socket_path),
        slot=slot_namespace,
        principal=_principal(),
        journal=ContentFreeGpuJournal(Path(gpu_receipt_path)),
        deadline_ms=deadline_ms,
    )


class KakaoProductRuntime:
    """One search handle over the current Workspace release and live corpus."""

    def __init__(self, runtime: WorkspaceDenseRuntime, *, slot_namespace: str):
        self._runtime = runtime
        body = {
            "schema_version": "kwrag-kakao-product-runtime-identity-v2",
            "slot_namespace": slot_namespace,
            "index_manifest": runtime.scope.manifest.digest,
            "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
        }
        self.identity = ProductRuntimeIdentity(
            index_manifest=runtime.scope.manifest.digest,
            pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
            digest="sha256:" + hashlib.sha256(canonical_json_bytes(body)).hexdigest(),
        )

    def search_exchange(self, request: dict[str, Any]) -> SlotSearchExchange:
        return self._runtime.search_exchange(request)

    def close(self) -> None:
        self._runtime.close()

    def __enter__(self) -> "KakaoProductRuntime":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


def open_kakao_product_runtime(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int = 30_000,
    max_concurrent: int = 1,
    _allow_nonproduction_release: bool = False,
) -> KakaoProductRuntime:
    """Open the already-built current Workspace index for one product call."""

    try:
        slot_namespace = _require_slot_namespace(slot_namespace)
        client = _gpu_client(
            socket_path=socket_path,
            slot_namespace=slot_namespace,
            gpu_receipt_path=gpu_receipt_path,
            deadline_ms=deadline_ms,
        )
        runtime = open_workspace_dense_runtime(
            package_root=Path(package_root),
            slot_root=Path(workspace_root) / slot_namespace,
            gpu=client,
            receipt_writer=ReceiptWriter(Path(receipt_path)),
            max_concurrent=max_concurrent,
            allow_nonproduction_release=_allow_nonproduction_release,
        )
        return KakaoProductRuntime(runtime, slot_namespace=slot_namespace)
    except ProductRuntimeError:
        raise
    except (OSError, ValueError) as exc:
        raise ProductRuntimeError("Kakao product RAG is unavailable") from exc


def rebuild_kakao_product_index(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int = 30_000,
) -> dict[str, Any]:
    """Explicitly rebuild and activate the disposable Workspace index."""

    try:
        slot_namespace = _require_slot_namespace(slot_namespace)
        client = _gpu_client(
            socket_path=socket_path,
            slot_namespace=slot_namespace,
            gpu_receipt_path=gpu_receipt_path,
            deadline_ms=deadline_ms,
        )
        return rebuild_workspace_dense_index(
            package_root=Path(package_root),
            workspace_root=Path(workspace_root),
            slot_namespace=slot_namespace,
            gpu=client,
        )
    except ProductRuntimeError:
        raise
    except (OSError, ValueError) as exc:
        raise ProductRuntimeError("Kakao product index rebuild failed") from exc


__all__ = [
    "KakaoProductRuntime",
    "ProductRuntimeError",
    "ProductRuntimeIdentity",
    "open_kakao_product_runtime",
    "rebuild_kakao_product_index",
]
