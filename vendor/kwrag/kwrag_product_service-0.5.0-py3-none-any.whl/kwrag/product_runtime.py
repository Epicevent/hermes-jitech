"""Product-native RAG over one slot's mounted corpora and Workspace index.

The read-only mounted sources are the live corpora. The disposable dense index
lives in the slot's writable Workspace. A caller chooses whether to search;
this module does not generate a query or choose a provider.
"""

from __future__ import annotations

import hashlib
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .dense_release import D_PIPELINE_FINGERPRINT
from .jsonutil import canonical_json_bytes
from .operation import OperationError, ReceiptWriter
from .product_contract import (
    PRODUCT_SOURCE_ADAPTERS,
    ProductContractError,
    ProductScope,
    decode_product_corpus,
    normalize_product_search_request,
)
from .product_index import (
    ProductIndexError,
    kwrag_index_build,
    kwrag_index_status,
)
from .shared_gpu_transport import ContentFreeGpuJournal, UnixSharedGpuClient
from .product_sources import (
    open_kakao_package_source,
    open_product_mounted_source,
)
from .slot_api import SlotSearchExchange
from .workspace_dense import (
    WorkspaceDenseRuntime,
    open_workspace_dense_runtime,
    rebuild_workspace_dense_index,
)


class ProductRuntimeError(ValueError):
    """The current slot cannot serve or rebuild its mounted-source RAG index."""


def _require_slot_namespace(value: str) -> str:
    if (
        not isinstance(value, str)
        or re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", value) is None
    ):
        raise ProductRuntimeError("slot_namespace_invalid")
    return value


@dataclass(frozen=True)
class ProductRuntimeIdentity:
    """Content-free observation of the opened runtime, never admission."""

    active_index_id: str
    pipeline_fingerprint: str
    digest: str
    index_manifest: str
    slot_namespace: str


def _real_directory(path: Path, code: str) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise ProductRuntimeError(code)
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise ProductRuntimeError(code) from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise ProductRuntimeError(code)
    return resolved


def _workspace_receipt(path: Path, workspace: Path) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise ProductRuntimeError("product_receipt_path_invalid")
    resolved = supplied.resolve(strict=False)
    try:
        relative = resolved.relative_to(workspace)
    except ValueError as exc:
        raise ProductRuntimeError("product_receipt_outside_workspace") from exc
    if not relative.parts:
        raise ProductRuntimeError("product_receipt_path_invalid")
    return resolved


def _principal() -> str:
    geteuid = getattr(os, "geteuid", None)
    if not callable(geteuid):
        raise ProductRuntimeError("product_runtime_requires_posix_identity")
    return f"uid:{geteuid()}"


def _gpu_client(
    *,
    socket_path: Path,
    slot_namespace: str,
    gpu_receipt_path: Path,
    deadline_ms: int,
) -> UnixSharedGpuClient:
    return UnixSharedGpuClient(
        socket_path=Path(socket_path),
        slot=slot_namespace,
        principal=_principal(),
        journal=ContentFreeGpuJournal(Path(gpu_receipt_path)),
        deadline_ms=deadline_ms,
    )


class ProductRuntime:
    """One search handle over the current Workspace release and live corpus."""

    def __init__(self, runtime: WorkspaceDenseRuntime, *, slot_namespace: str):
        self._runtime = runtime
        index_manifest = runtime.scope.manifest.digest
        body = {
            "schema_version": "kwrag-product-runtime-identity-v1",
            "slot_namespace": slot_namespace,
            "active_index_id": runtime.scope.manifest.release_id,
            "index_manifest": index_manifest,
            "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
        }
        self.identity = ProductRuntimeIdentity(
            active_index_id=runtime.scope.manifest.release_id,
            pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
            digest="sha256:" + hashlib.sha256(canonical_json_bytes(body)).hexdigest(),
            slot_namespace=slot_namespace,
            index_manifest=index_manifest,
        )

    def search_exchange(self, request: dict[str, Any]) -> SlotSearchExchange:
        """Run one explicit public product request through the current runtime."""

        try:
            normalized = normalize_product_search_request(request)
        except ProductContractError as exc:
            raise OperationError(
                400, "invalid_request", "product search request is invalid"
            ) from exc
        slot_request = dict(normalized.slot_request)
        if normalized.scope.rooms is None and isinstance(request.get("scope"), Mapping):
            try:
                selected_rooms = [
                    corpus
                    for corpus in self._runtime.scope.available_rooms
                    if decode_product_corpus(corpus).source
                    in normalized.scope.sources
                ]
            except ProductContractError as exc:
                raise OperationError(
                    503, "not_ready", "mounted product scope is invalid", retryable=True
                ) from exc
            if not selected_rooms:
                raise OperationError(
                    403,
                    "outside_mounted_scope",
                    "requested source is outside the mounted index",
                )
            slot_request["rooms"] = selected_rooms
        return self._runtime.search_exchange(slot_request)

    def close(self) -> None:
        self._runtime.close()

    def __enter__(self) -> "ProductRuntime":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


KakaoProductRuntime = ProductRuntime
_PRODUCT_DEADLINE_MS = 30_000
_PRODUCT_MAX_CONCURRENT = 1


def build_index(
    scope: ProductScope | Any = None,
    rebuild: bool = False,
) -> dict[str, Any]:
    """Ensure or explicitly rebuild the runtime-configured product index."""

    return kwrag_index_build(scope=scope, rebuild=rebuild)


def index_status(scope: ProductScope | Any = None) -> dict[str, Any]:
    """Observe the runtime-configured source and active Workspace index."""

    return kwrag_index_status(scope=scope)


def _open_product_runtime(
    *,
    source_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int,
    max_concurrent: int,
    allow_nonproduction_release: bool,
) -> ProductRuntime:
    try:
        slot_namespace = _require_slot_namespace(slot_namespace)
        source = _real_directory(source_root, "product_source_root_invalid")
        workspace = _real_directory(
            workspace_root,
            "product_workspace_root_invalid",
        )
        if (
            source == workspace
            or source in workspace.parents
            or workspace in source.parents
        ):
            raise ProductRuntimeError("product_source_workspace_overlap")
        receipt = _workspace_receipt(receipt_path, workspace)
        gpu_receipt = _workspace_receipt(gpu_receipt_path, workspace)
        client = _gpu_client(
            socket_path=socket_path,
            slot_namespace=slot_namespace,
            gpu_receipt_path=gpu_receipt,
            deadline_ms=deadline_ms,
        )
        if source.name == "package" and source.parent.name == "kw":
            mounted_source = open_kakao_package_source(source)
        else:
            mounted_source = open_product_mounted_source(
                source,
                tuple(sorted(PRODUCT_SOURCE_ADAPTERS)),
            )
        runtime = open_workspace_dense_runtime(
            source=mounted_source,
            slot_root=workspace / "dense" / slot_namespace,
            gpu=client,
            receipt_writer=ReceiptWriter(receipt),
            max_concurrent=max_concurrent,
            allow_nonproduction_release=allow_nonproduction_release,
        )
        return ProductRuntime(runtime, slot_namespace=slot_namespace)
    except ProductRuntimeError:
        raise
    except (OSError, ValueError) as exc:
        raise ProductRuntimeError("product RAG is unavailable") from exc


def open_product_runtime(
    *,
    source_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    _allow_nonproduction_release: bool = False,
) -> ProductRuntime:
    """Open the current index through the stable product-owned search seam."""

    return _open_product_runtime(
        source_root=source_root,
        workspace_root=workspace_root,
        slot_namespace=slot_namespace,
        socket_path=socket_path,
        receipt_path=receipt_path,
        gpu_receipt_path=gpu_receipt_path,
        deadline_ms=_PRODUCT_DEADLINE_MS,
        max_concurrent=_PRODUCT_MAX_CONCURRENT,
        allow_nonproduction_release=_allow_nonproduction_release,
    )


def open_kakao_product_runtime(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int = 30_000,
    max_concurrent: int = 1,
    _allow_nonproduction_release: bool = False,
) -> KakaoProductRuntime:
    """Compatibility name; new Hermes wiring should use open_product_runtime."""

    return _open_product_runtime(
        source_root=package_root,
        workspace_root=workspace_root,
        slot_namespace=slot_namespace,
        socket_path=socket_path,
        receipt_path=receipt_path,
        gpu_receipt_path=gpu_receipt_path,
        deadline_ms=deadline_ms,
        max_concurrent=max_concurrent,
        allow_nonproduction_release=_allow_nonproduction_release,
    )


def rebuild_kakao_product_index(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int = 30_000,
) -> dict[str, Any]:
    """Explicitly rebuild and activate the disposable Workspace index."""

    try:
        slot_namespace = _require_slot_namespace(slot_namespace)
        source = _real_directory(package_root, "product_source_root_invalid")
        workspace = _real_directory(
            workspace_root,
            "product_workspace_root_invalid",
        )
        if (
            source == workspace
            or source in workspace.parents
            or workspace in source.parents
        ):
            raise ProductRuntimeError("product_source_workspace_overlap")
        gpu_receipt = _workspace_receipt(gpu_receipt_path, workspace)
        client = _gpu_client(
            socket_path=socket_path,
            slot_namespace=slot_namespace,
            gpu_receipt_path=gpu_receipt,
            deadline_ms=deadline_ms,
        )
        return rebuild_workspace_dense_index(
            package_root=source,
            workspace_root=workspace / "dense",
            slot_namespace=slot_namespace,
            gpu=client,
        )
    except ProductRuntimeError:
        raise
    except (OSError, ValueError) as exc:
        raise ProductRuntimeError("Kakao product index rebuild failed") from exc


__all__ = [
    "build_index",
    "index_status",
    "KakaoProductRuntime",
    "ProductIndexError",
    "ProductRuntime",
    "ProductRuntimeError",
    "ProductRuntimeIdentity",
    "open_kakao_product_runtime",
    "open_product_runtime",
    "rebuild_kakao_product_index",
]
