"""Product-native RAG over one slot's mounted corpora and Workspace index.

The read-only mounted sources are the live corpora. The disposable dense index
lives in the slot's writable Workspace. A caller chooses whether to search;
this module does not generate a query or choose a provider.
"""

from __future__ import annotations

import hashlib
import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .dense_release import D_PIPELINE_FINGERPRINT
from .jsonutil import canonical_json_bytes
from .operation import OperationError, ReceiptWriter
from .product_contract import (
    PRODUCT_SOURCE_ADAPTERS,
    ProductContractError,
    ProductScope,
    decode_product_corpus,
    normalize_product_search_request,
)
from .product_index import (
    ProductIndexError,
    kwrag_index_build,
    kwrag_index_status,
)
from .shared_gpu_transport import ContentFreeGpuJournal, UnixSharedGpuClient
from .product_sources import (
    open_kakao_package_source,
    open_product_mounted_source,
)
from .slot_api import SlotSearchExchange
from .workspace_dense import (
    WorkspaceDenseRuntime,
    open_workspace_dense_runtime,
    rebuild_workspace_dense_index,
)


class ProductRuntimeError(ValueError):
    """The current slot cannot serve or rebuild its mounted-source RAG index."""


def _require_slot_namespace(value: str) -> str:
    if (
        not isinstance(value, str)
        or re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", value) is None
    ):
        raise ProductRuntimeError("slot_namespace_invalid")
    return value


@dataclass(frozen=True)
class ProductRuntimeIdentity:
    """Content-free observation of the opened runtime, never admission."""

    active_index_id: str
    pipeline_fingerprint: str
    digest: str
    index_manifest: str
    slot_namespace: str


def _real_directory(path: Path, code: str) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise ProductRuntimeError(code)
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise ProductRuntimeError(code) from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise ProductRuntimeError(code)
    return resolved


def _workspace_receipt(path: Path, workspace: Path) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise ProductRuntimeError("product_receipt_path_invalid")
    resolved = supplied.resolve(strict=False)
    try:
        relative = resolved.relative_to(workspace)
    except ValueError as exc:
        raise ProductRuntimeError("product_receipt_outside_workspace") from exc
    if not relative.parts:
        raise ProductRuntimeError("product_receipt_path_invalid")
    return resolved


def _principal() -> str:
    geteuid = getattr(os, "geteuid", None)
    if not callable(geteuid):
        raise ProductRuntimeError("product_runtime_requires_posix_identity")
    return f"uid:{geteuid()}"


def _gpu_client(
    *,
    socket_path: Path,
    slot_namespace: str,
    gpu_receipt_path: Path,
    deadline_ms: int,
) -> UnixSharedGpuClient:
    return UnixSharedGpuClient(
        socket_path=Path(socket_path),
        slot=slot_namespace,
        principal=_principal(),
        journal=ContentFreeGpuJournal(Path(gpu_receipt_path)),
        deadline_ms=deadline_ms,
    )


class ProductRuntime:
    """One search handle over the current Workspace release and live corpus."""

    def __init__(self, runtime: WorkspaceDenseRuntime, *, slot_namespace: str):
        self._runtime = runtime
        index_manifest = runtime.scope.manifest.digest
        body = {
            "schema_version": "kwrag-product-runtime-identity-v1",
            "slot_namespace": slot_namespace,
            "active_index_id": runtime.scope.manifest.release_id,
            "index_manifest": index_manifest,
            "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
        }
        self.identity = ProductRuntimeIdentity(
            active_index_id=runtime.scope.manifest.release_id,
            pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
            digest="sha256:" + hashlib.sha256(canonical_json_bytes(body)).hexdigest(),
            slot_namespace=slot_namespace,
            index_manifest=index_manifest,
        )

    @property
    def available_source_names(self) -> tuple[str, ...]:
        """Return the source adapters that remain live on this opened handle."""

        try:
            return tuple(
                sorted(
                    {
                        decode_product_corpus(corpus).source
                        for corpus in self.available_room_names
                    }
                )
            )
        except ProductContractError as exc:
            raise OperationError(
                503, "not_ready", "mounted product scope is invalid", retryable=True
            ) from exc

    @property
    def indexed_source_names(self) -> tuple[str, ...]:
        """Return the source adapters represented by the active index."""

        return tuple(
            sorted(
                {
                    decode_product_corpus(corpus).source
                    for corpus in self.indexed_room_names
                }
            )
        )

    @property
    def available_room_names(self) -> tuple[str, ...]:
        """Return every corpus currently visible through the mounted adapters."""

        source = getattr(self._runtime.scope, "source", None)
        assert_available = getattr(source, "assert_available", None)
        if not callable(assert_available):
            raise OperationError(
                503, "not_ready", "mounted product scope is unavailable", retryable=True
            )
        try:
            assert_available()
            rooms = tuple(getattr(source, "rooms"))
        except (OSError, TypeError, ValueError) as exc:
            raise OperationError(
                503, "not_ready", "mounted product scope is unavailable", retryable=True
            ) from exc
        if not rooms or any(not isinstance(room, str) or not room for room in rooms):
            raise OperationError(
                503, "not_ready", "mounted product scope is invalid", retryable=True
            )
        try:
            for room in rooms:
                decode_product_corpus(room)
        except ProductContractError as exc:
            raise OperationError(
                503, "not_ready", "mounted product scope is invalid", retryable=True
            ) from exc
        return tuple(sorted(set(rooms)))

    @property
    def indexed_room_names(self) -> tuple[str, ...]:
        """Return every corpus represented by the active index."""

        rooms = getattr(self._runtime.scope.manifest, "rooms", None)
        if not isinstance(rooms, Mapping) or not rooms:
            raise OperationError(
                503, "not_ready", "active product index is invalid", retryable=True
            )
        try:
            normalized = tuple(sorted(rooms))
            for corpus in normalized:
                decode_product_corpus(corpus)
            return normalized
        except ProductContractError as exc:
            raise OperationError(
                503, "not_ready", "active product index is invalid", retryable=True
            ) from exc

    def search_exchange(self, request: dict[str, Any]) -> SlotSearchExchange:
        """Run one explicit public product request through the current runtime."""

        try:
            normalized = normalize_product_search_request(request)
        except ProductContractError as exc:
            raise OperationError(
                400, "invalid_request", "product search request is invalid"
            ) from exc
        slot_request = dict(normalized.slot_request)
        explicit_scope = isinstance(request.get("scope"), Mapping)
        available_rooms = set(self.available_room_names)
        indexed_rooms = set(self.indexed_room_names)
        available_sources = {
            decode_product_corpus(corpus).source for corpus in available_rooms
        }
        indexed_sources = {
            decode_product_corpus(corpus).source for corpus in indexed_rooms
        }
        requested_unavailable = explicit_scope and bool(
            set(normalized.scope.sources) - available_sources
        )
        federated_unindexed = not explicit_scope and bool(
            available_sources - indexed_sources or available_rooms - indexed_rooms
        )
        if requested_unavailable:
            raise OperationError(
                503,
                "not_ready",
                "requested source is unavailable",
                retryable=True,
            )
        if federated_unindexed:
            raise OperationError(
                503,
                "not_ready",
                "active index does not cover mounted sources",
                retryable=True,
            )
        if normalized.scope.rooms is None and explicit_scope:
            try:
                selected_rooms = [
                    corpus
                    for corpus in available_rooms
                    if decode_product_corpus(corpus).source in normalized.scope.sources
                ]
            except ProductContractError as exc:
                raise OperationError(
                    503, "not_ready", "mounted product scope is invalid", retryable=True
                ) from exc
            selected_sources = {
                decode_product_corpus(corpus).source for corpus in selected_rooms
            }
            if set(normalized.scope.sources) - selected_sources:
                raise OperationError(
                    503,
                    "not_ready",
                    "requested source is unavailable",
                    retryable=True,
                )
            if set(selected_rooms) - indexed_rooms:
                raise OperationError(
                    503,
                    "not_ready",
                    "active index does not cover requested sources",
                    retryable=True,
                )
            slot_request["rooms"] = selected_rooms
        return self._runtime.search_exchange(slot_request)

    def close(self) -> None:
        self._runtime.close()

    def __enter__(self) -> "ProductRuntime":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


KakaoProductRuntime = ProductRuntime
_PRODUCT_DEADLINE_MS = 30_000
_PRODUCT_MAX_CONCURRENT = 1


def build_index(
    scope: ProductScope | Any = None,
    rebuild: bool = False,
) -> dict[str, Any]:
    """Ensure or explicitly rebuild the runtime-configured product index."""

    return kwrag_index_build(scope=scope, rebuild=rebuild)


def index_status(scope: ProductScope | Any = None) -> dict[str, Any]:
    """Observe the runtime-configured source and active Workspace index."""

    return kwrag_index_status(scope=scope)


def _open_product_runtime(
    *,
    source_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int,
    max_concurrent: int,
    allow_nonproduction_release: bool,
) -> ProductRuntime:
    try:
        slot_namespace = _require_slot_namespace(slot_namespace)
        source = _real_directory(source_root, "product_source_root_invalid")
        workspace = _real_directory(
            workspace_root,
            "product_workspace_root_invalid",
        )
        if (
            source == workspace
            or source in workspace.parents
            or workspace in source.parents
        ):
            raise ProductRuntimeError("product_source_workspace_overlap")
        receipt = _workspace_receipt(receipt_path, workspace)
        gpu_receipt = _workspace_receipt(gpu_receipt_path, workspace)
        client = _gpu_client(
            socket_path=socket_path,
            slot_namespace=slot_namespace,
            gpu_receipt_path=gpu_receipt,
            deadline_ms=deadline_ms,
        )
        if source.name == "package" and source.parent.name == "kw":
            mounted_source = open_kakao_package_source(source)
        else:
            mounted_source = open_product_mounted_source(
                source,
                tuple(sorted(PRODUCT_SOURCE_ADAPTERS)),
            )
        runtime = open_workspace_dense_runtime(
            source=mounted_source,
            slot_root=workspace / "dense" / slot_namespace,
            gpu=client,
            receipt_writer=ReceiptWriter(receipt),
            max_concurrent=max_concurrent,
            allow_nonproduction_release=allow_nonproduction_release,
        )
        return ProductRuntime(runtime, slot_namespace=slot_namespace)
    except ProductRuntimeError:
        raise
    except (OSError, ValueError) as exc:
        raise ProductRuntimeError("product RAG is unavailable") from exc


def open_product_runtime(
    *,
    source_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    _allow_nonproduction_release: bool = False,
) -> ProductRuntime:
    """Open the current index through the stable product-owned search seam."""

    return _open_product_runtime(
        source_root=source_root,
        workspace_root=workspace_root,
        slot_namespace=slot_namespace,
        socket_path=socket_path,
        receipt_path=receipt_path,
        gpu_receipt_path=gpu_receipt_path,
        deadline_ms=_PRODUCT_DEADLINE_MS,
        max_concurrent=_PRODUCT_MAX_CONCURRENT,
        allow_nonproduction_release=_allow_nonproduction_release,
    )


def open_kakao_product_runtime(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    receipt_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int = 30_000,
    max_concurrent: int = 1,
    _allow_nonproduction_release: bool = False,
) -> KakaoProductRuntime:
    """Compatibility name; new Hermes wiring should use open_product_runtime."""

    return _open_product_runtime(
        source_root=package_root,
        workspace_root=workspace_root,
        slot_namespace=slot_namespace,
        socket_path=socket_path,
        receipt_path=receipt_path,
        gpu_receipt_path=gpu_receipt_path,
        deadline_ms=deadline_ms,
        max_concurrent=max_concurrent,
        allow_nonproduction_release=_allow_nonproduction_release,
    )


def rebuild_kakao_product_index(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    socket_path: Path,
    gpu_receipt_path: Path,
    deadline_ms: int = 30_000,
) -> dict[str, Any]:
    """Explicitly rebuild and activate the disposable Workspace index."""

    try:
        slot_namespace = _require_slot_namespace(slot_namespace)
        source = _real_directory(package_root, "product_source_root_invalid")
        workspace = _real_directory(
            workspace_root,
            "product_workspace_root_invalid",
        )
        if (
            source == workspace
            or source in workspace.parents
            or workspace in source.parents
        ):
            raise ProductRuntimeError("product_source_workspace_overlap")
        gpu_receipt = _workspace_receipt(gpu_receipt_path, workspace)
        client = _gpu_client(
            socket_path=socket_path,
            slot_namespace=slot_namespace,
            gpu_receipt_path=gpu_receipt,
            deadline_ms=deadline_ms,
        )
        return rebuild_workspace_dense_index(
            package_root=source,
            workspace_root=workspace / "dense",
            slot_namespace=slot_namespace,
            gpu=client,
        )
    except ProductRuntimeError:
        raise
    except (OSError, ValueError) as exc:
        raise ProductRuntimeError("Kakao product index rebuild failed") from exc


__all__ = [
    "build_index",
    "index_status",
    "KakaoProductRuntime",
    "ProductIndexError",
    "ProductRuntime",
    "ProductRuntimeError",
    "ProductRuntimeIdentity",
    "open_kakao_product_runtime",
    "open_product_runtime",
    "rebuild_kakao_product_index",
]
