"""Bounded reader for the live, read-only Groupware document corpus.

The mounted filesystem is the authority.  This adapter never accepts a path
from a retrieval request and never treats a digest as admission state.  It
opens source files without following symlinks, checks the opened filesystem's
read-only fact, and skips an individual document when normal source churn or a
format error makes only that document unusable.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import selectors
import stat
import subprocess
import time
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence
from xml.etree import ElementTree

from .dense_source import DenseSourceReferenceUnavailable, SourceMessage
from .jsonutil import is_sha256


MAX_ROOMS = 64
MAX_TREE_DEPTH = 8
MAX_TREE_ENTRIES = 20_000
MAX_DIRECTORIES = 2_048
MAX_SOURCE_FILES = 10_000
MAX_SOURCE_INPUT_BYTES = 2 * 1024 * 1024 * 1024
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_JSON_BYTES = 16 * 1024 * 1024
MAX_DOCUMENT_TEXT_UTF8_BYTES = 1 * 1024 * 1024
MAX_SOURCE_TEXT_UTF8_BYTES = 512 * 1024 * 1024
MAX_ZIP_ENTRIES = 2_048
MAX_ZIP_MEMBER_BYTES = 16 * 1024 * 1024
MAX_ZIP_TOTAL_BYTES = 64 * 1024 * 1024
MAX_ZIP_COMPRESSION_RATIO = 200
PDF_EXTRACT_TIMEOUT_SECONDS = 10
MAX_REFERENCE_COUNT = 32
MAX_READ_ATTEMPTS = 3

_SUPPORTED_SUFFIXES = frozenset({".json", ".pdf", ".docx"})
_MESSAGE_ID = re.compile(r"g-[0-9a-f]{64}\Z")
_WORD_NAMESPACE = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_APPROVAL_STRING_FIELDS = frozenset(
    {
        "author",
        "category",
        "content",
        "content_html",
        "data_id",
        "doc_no",
        "title",
        "type",
        "written_date",
    }
)
_MAIL_STRING_FIELDS = frozenset(
    {
        "content",
        "content_html",
        "folder_id",
        "folder_name",
        "gw_user_id",
        "mail_date",
        "mail_id",
        "sender",
        "subject",
        "type",
    }
)
_FATAL_CODES = frozenset(
    {
        "source_mount_is_writable",
        "source_readonly_state_unavailable",
        "source_package_root_invalid",
        "source_tree_unbounded",
        "source_document_identity_collision",
    }
)


class LiveGroupwareSourceError(ValueError):
    """The mounted Groupware corpus violates a stable source boundary."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


class _DocumentSkip(ValueError):
    """One document is unavailable or unsupported without invalidating peers."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class _Candidate:
    room: str
    relative_parts: tuple[str, ...]
    suffix: str
    observed_size: int

    @property
    def message_id(self) -> str:
        relative = "/".join(self.relative_parts).encode("utf-8")
        digest = hashlib.sha256(b"kwrag-groupware-path-v1\0" + relative).hexdigest()
        return "g-" + digest


@dataclass(frozen=True)
class _ParsedDocument:
    text: str
    user_id: str
    user_name: str
    sent_time: int


def _path_is_readonly(path: Path) -> bool:
    """Patchable wrapper around the kernel mount flag for a path."""

    statvfs = getattr(os, "statvfs", None)
    readonly = getattr(os, "ST_RDONLY", None)
    if not callable(statvfs) or readonly is None:
        raise OSError("statvfs read-only state unavailable")
    return bool(statvfs(path).f_flag & readonly)


def _fd_is_readonly(descriptor: int) -> bool:
    """Patchable wrapper around the kernel mount flag for an opened fd."""

    fstatvfs = getattr(os, "fstatvfs", None)
    readonly = getattr(os, "ST_RDONLY", None)
    if not callable(fstatvfs) or readonly is None:
        raise OSError("fstatvfs read-only state unavailable")
    return bool(fstatvfs(descriptor).f_flag & readonly)


def _normalized_text(value: Any) -> str:
    return unicodedata.normalize(
        "NFC", str(value or "").replace("\r\n", "\n").replace("\r", "\n")
    ).strip()


def _text_within_bounds(text: str) -> str:
    normalized = _normalized_text(text)
    if (
        not normalized
        or len(normalized.encode("utf-8")) > MAX_DOCUMENT_TEXT_UTF8_BYTES
    ):
        raise _DocumentSkip("source_document_text_invalid")
    return normalized


def _safe_component(value: str) -> bool:
    return (
        isinstance(value, str)
        and 1 <= len(value) <= 256
        and value == value.strip()
        and value == unicodedata.normalize("NFC", value)
        and value not in {".", ".."}
        and "/" not in value
        and "\\" not in value
        and "\x00" not in value
    )


def _real_directory(path: Path) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise LiveGroupwareSourceError("source_package_root_invalid")
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise LiveGroupwareSourceError("source_package_root_unavailable") from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise LiveGroupwareSourceError("source_package_root_invalid")
    return resolved


def _directory_flags() -> int:
    return (
        os.O_RDONLY
        | getattr(os, "O_DIRECTORY", 0)
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
    )


def _file_flags() -> int:
    return (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )


def _identity(info: os.stat_result) -> tuple[int, int, int, int]:
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)


def _read_descriptor(descriptor: int, maximum: int) -> bytes:
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = os.read(descriptor, min(1024 * 1024, maximum + 1 - total))
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)
        total += len(chunk)
        if total > maximum:
            raise _DocumentSkip("source_document_size_invalid")


def _render_fields(value: Mapping[str, Any], fields: Sequence[str]) -> str:
    pieces = []
    for name in fields:
        item = _normalized_text(value.get(name))
        if item:
            pieces.append(f"{name}: {item}")
    return _text_within_bounds("\n".join(pieces))


def _parse_json(payload: bytes, sent_time: int) -> _ParsedDocument:
    if not 1 <= len(payload) <= MAX_JSON_BYTES:
        raise _DocumentSkip("source_json_size_invalid")
    try:
        value = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _DocumentSkip("source_json_invalid") from exc
    if not isinstance(value, Mapping):
        raise _DocumentSkip("source_json_schema_invalid")

    if _APPROVAL_STRING_FIELDS <= set(value) and all(
        isinstance(value.get(field), str) for field in _APPROVAL_STRING_FIELDS
    ):
        text = _render_fields(
            value,
            ("title", "author", "category", "written_date", "doc_no", "content"),
        )
        author = _normalized_text(value.get("author")) or "groupware"
        return _ParsedDocument(text, author, author, sent_time)

    if (
        _MAIL_STRING_FIELDS <= set(value)
        and all(isinstance(value.get(field), str) for field in _MAIL_STRING_FIELDS)
        and isinstance(value.get("is_shared"), bool)
    ):
        text = _render_fields(
            value,
            ("subject", "sender", "mail_date", "folder_name", "content"),
        )
        user_id = _normalized_text(value.get("gw_user_id")) or "groupware"
        sender = _normalized_text(value.get("sender")) or "groupware"
        return _ParsedDocument(text, user_id, sender, sent_time)

    raise _DocumentSkip("source_json_schema_invalid")


def _zip_member_name(name: str) -> str:
    normalized = unicodedata.normalize("NFC", name.replace("\\", "/"))
    pure = PurePosixPath(normalized)
    if (
        not normalized
        or normalized.startswith("/")
        or "\x00" in normalized
        or any(part in {"", ".", ".."} for part in pure.parts)
    ):
        raise _DocumentSkip("source_docx_member_invalid")
    return pure.as_posix()


def _parse_docx(payload: bytes, sent_time: int) -> _ParsedDocument:
    try:
        archive = zipfile.ZipFile(io.BytesIO(payload))
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        raise _DocumentSkip("source_docx_invalid") from exc
    with archive:
        infos = archive.infolist()
        if not 1 <= len(infos) <= MAX_ZIP_ENTRIES:
            raise _DocumentSkip("source_docx_unbounded")
        names: set[str] = set()
        total = 0
        document_info: zipfile.ZipInfo | None = None
        for info in infos:
            name = _zip_member_name(info.filename)
            if name in names:
                raise _DocumentSkip("source_docx_member_invalid")
            names.add(name)
            mode = info.external_attr >> 16
            if mode and stat.S_ISLNK(mode):
                raise _DocumentSkip("source_docx_member_invalid")
            if info.file_size < 0 or info.compress_size < 0:
                raise _DocumentSkip("source_docx_unbounded")
            total += info.file_size
            if total > MAX_ZIP_TOTAL_BYTES:
                raise _DocumentSkip("source_docx_unbounded")
            if info.file_size and (
                info.compress_size == 0
                or info.file_size > info.compress_size * MAX_ZIP_COMPRESSION_RATIO
            ):
                raise _DocumentSkip("source_docx_unbounded")
            if name == "word/document.xml":
                document_info = info
        if (
            document_info is None
            or not 1 <= document_info.file_size <= MAX_ZIP_MEMBER_BYTES
        ):
            raise _DocumentSkip("source_docx_invalid")
        try:
            with archive.open(document_info, "r") as member:
                document_xml = member.read(MAX_ZIP_MEMBER_BYTES + 1)
        except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
            raise _DocumentSkip("source_docx_invalid") from exc
        if len(document_xml) != document_info.file_size:
            raise _DocumentSkip("source_docx_invalid")
    try:
        root = ElementTree.fromstring(document_xml)
    except ElementTree.ParseError as exc:
        raise _DocumentSkip("source_docx_invalid") from exc

    paragraphs: list[str] = []
    paragraph_tag = f"{{{_WORD_NAMESPACE}}}p"
    text_tag = f"{{{_WORD_NAMESPACE}}}t"
    tab_tag = f"{{{_WORD_NAMESPACE}}}tab"
    break_tag = f"{{{_WORD_NAMESPACE}}}br"
    for paragraph in root.iter(paragraph_tag):
        pieces: list[str] = []
        for element in paragraph.iter():
            if element.tag == text_tag and element.text:
                pieces.append(element.text)
            elif element.tag == tab_tag:
                pieces.append("\t")
            elif element.tag == break_tag:
                pieces.append("\n")
        rendered = _normalized_text("".join(pieces))
        if rendered:
            paragraphs.append(rendered)
    text = _text_within_bounds("\n".join(paragraphs))
    return _ParsedDocument(text, "groupware", "groupware", sent_time)


_PDFTOTEXT = Path("/usr/bin/pdftotext")


def _run_pdftotext(payload: bytes) -> bytes:
    """Run the fixed extractor without a shell, bounding time and stdout."""

    try:
        tool = _PDFTOTEXT.resolve(strict=True)
        tool_info = _PDFTOTEXT.stat()
    except OSError as exc:
        raise _DocumentSkip("source_pdf_parser_unavailable") from exc
    if not stat.S_ISREG(tool_info.st_mode) or not os.access(tool, os.X_OK):
        raise _DocumentSkip("source_pdf_parser_unavailable")
    memfd_create = getattr(os, "memfd_create", None)
    if not callable(memfd_create):
        raise _DocumentSkip("source_pdf_parser_unavailable")
    input_descriptor = memfd_create(
        "kwrag-groupware-pdf",
        getattr(os, "MFD_CLOEXEC", 0),
    )
    process: subprocess.Popen[bytes] | None = None
    selector: selectors.BaseSelector | None = None
    try:
        view = memoryview(payload)
        while view:
            written = os.write(input_descriptor, view)
            if written <= 0:
                raise _DocumentSkip("source_pdf_invalid")
            view = view[written:]
        os.lseek(input_descriptor, 0, os.SEEK_SET)
        process = subprocess.Popen(
            (
                str(tool),
                "-enc",
                "UTF-8",
                "-nopgbrk",
                "-",
                "-",
            ),
            stdin=input_descriptor,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            env={"LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"},
        )
        if process.stdout is None:
            raise _DocumentSkip("source_pdf_invalid")
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ)
        deadline = time.monotonic() + PDF_EXTRACT_TIMEOUT_SECONDS
        output = bytearray()
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise _DocumentSkip("source_pdf_timeout")
            events = selector.select(remaining)
            if not events:
                raise _DocumentSkip("source_pdf_timeout")
            chunk = os.read(
                process.stdout.fileno(),
                min(64 * 1024, MAX_DOCUMENT_TEXT_UTF8_BYTES + 1 - len(output)),
            )
            if not chunk:
                break
            output.extend(chunk)
            if len(output) > MAX_DOCUMENT_TEXT_UTF8_BYTES:
                raise _DocumentSkip("source_document_text_invalid")
        remaining = max(0.001, deadline - time.monotonic())
        try:
            returncode = process.wait(timeout=remaining)
        except subprocess.TimeoutExpired as exc:
            raise _DocumentSkip("source_pdf_timeout") from exc
        if returncode != 0:
            raise _DocumentSkip("source_pdf_invalid")
        return bytes(output)
    except OSError as exc:
        raise _DocumentSkip("source_pdf_parser_unavailable") from exc
    finally:
        if selector is not None:
            selector.close()
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        if process is not None and process.stdout is not None:
            process.stdout.close()
        os.close(input_descriptor)


def _parse_pdf(payload: bytes, sent_time: int) -> _ParsedDocument:
    try:
        rendered = _run_pdftotext(payload).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise _DocumentSkip("source_pdf_invalid") from exc
    text = _text_within_bounds(rendered)
    return _ParsedDocument(text, "groupware", "groupware", sent_time)


def _parse_document(suffix: str, payload: bytes, sent_time: int) -> _ParsedDocument:
    if suffix == ".json":
        return _parse_json(payload, sent_time)
    if suffix == ".docx":
        return _parse_docx(payload, sent_time)
    if suffix == ".pdf":
        return _parse_pdf(payload, sent_time)
    raise _DocumentSkip("source_document_type_unsupported")


class LiveGroupwareSource:
    """Current bounded Groupware document source visible to one product slot."""

    source_kind = "groupware_live_documents_v1"
    stale_references_are_skipped = True

    def __init__(self, package_root: Path, *, require_readonly: bool = True):
        if not isinstance(require_readonly, bool):
            raise LiveGroupwareSourceError("readonly_requirement_invalid")
        self.package_root = _real_directory(package_root)
        self.require_readonly = require_readonly
        self.assert_available()

    def _open_root(self) -> int:
        try:
            descriptor = os.open(self.package_root, _directory_flags())
            info = os.fstat(descriptor)
            if not stat.S_ISDIR(info.st_mode):
                raise LiveGroupwareSourceError("source_package_root_invalid")
            if self.require_readonly and not _fd_is_readonly(descriptor):
                raise LiveGroupwareSourceError("source_mount_is_writable")
            return descriptor
        except LiveGroupwareSourceError:
            try:
                os.close(descriptor)
            except (NameError, OSError):
                pass
            raise
        except OSError as exc:
            try:
                os.close(descriptor)
            except (NameError, OSError):
                pass
            raise LiveGroupwareSourceError("source_package_root_unavailable") from exc

    def assert_available(self) -> None:
        _real_directory(self.package_root)
        if self.require_readonly:
            try:
                readonly = _path_is_readonly(self.package_root)
            except OSError as exc:
                raise LiveGroupwareSourceError(
                    "source_readonly_state_unavailable"
                ) from exc
            if not readonly:
                raise LiveGroupwareSourceError("source_mount_is_writable")
        descriptor = self._open_root()
        os.close(descriptor)

    def _room_names(self, root_descriptor: int) -> tuple[str, ...]:
        rooms: list[str] = []
        entries = 0
        try:
            with os.scandir(root_descriptor) as iterator:
                for entry in iterator:
                    entries += 1
                    if entries > MAX_TREE_ENTRIES:
                        raise LiveGroupwareSourceError("source_tree_unbounded")
                    if not _safe_component(entry.name) or entry.is_symlink():
                        continue
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            rooms.append(entry.name)
                    except OSError:
                        continue
        except LiveGroupwareSourceError:
            raise
        except OSError as exc:
            raise LiveGroupwareSourceError("source_package_root_unavailable") from exc
        rooms = sorted(set(rooms))
        if not rooms:
            raise LiveGroupwareSourceError("source_rooms_unavailable")
        if len(rooms) > MAX_ROOMS:
            raise LiveGroupwareSourceError("source_tree_unbounded")
        return tuple(rooms)

    @property
    def rooms(self) -> tuple[str, ...]:
        descriptor = self._open_root()
        try:
            return self._room_names(descriptor)
        finally:
            os.close(descriptor)

    def _enumerate_candidates(self) -> list[_Candidate]:
        root_descriptor = self._open_root()
        candidates: list[_Candidate] = []
        state = {"entries": 0, "directories": 0, "files": 0, "bytes": 0}

        def walk(
            descriptor: int,
            relative_parts: tuple[str, ...],
            room: str,
            depth: int,
        ) -> None:
            try:
                with os.scandir(descriptor) as iterator:
                    names = sorted(entry.name for entry in iterator)
            except OSError:
                return
            for name in names:
                state["entries"] += 1
                if state["entries"] > MAX_TREE_ENTRIES:
                    raise LiveGroupwareSourceError("source_tree_unbounded")
                if not _safe_component(name):
                    continue
                try:
                    info = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
                except OSError:
                    continue
                parts = (*relative_parts, name)
                if stat.S_ISLNK(info.st_mode):
                    continue
                if stat.S_ISDIR(info.st_mode):
                    state["directories"] += 1
                    if (
                        depth >= MAX_TREE_DEPTH
                        or state["directories"] > MAX_DIRECTORIES
                    ):
                        raise LiveGroupwareSourceError("source_tree_unbounded")
                    try:
                        child = os.open(name, _directory_flags(), dir_fd=descriptor)
                    except OSError:
                        continue
                    try:
                        if not stat.S_ISDIR(os.fstat(child).st_mode):
                            continue
                        if self.require_readonly and not _fd_is_readonly(child):
                            raise LiveGroupwareSourceError("source_mount_is_writable")
                        walk(child, parts, room, depth + 1)
                    except OSError:
                        continue
                    finally:
                        os.close(child)
                    continue
                if not stat.S_ISREG(info.st_mode):
                    continue
                state["files"] += 1
                if state["files"] > MAX_SOURCE_FILES:
                    raise LiveGroupwareSourceError("source_tree_unbounded")
                suffix = Path(name).suffix.casefold()
                if suffix not in _SUPPORTED_SUFFIXES:
                    continue
                if not 1 <= info.st_size <= MAX_FILE_BYTES:
                    continue
                state["bytes"] += info.st_size
                if state["bytes"] > MAX_SOURCE_INPUT_BYTES:
                    raise LiveGroupwareSourceError("source_tree_unbounded")
                candidates.append(_Candidate(room, parts, suffix, info.st_size))

        try:
            rooms = self._room_names(root_descriptor)
            for room in rooms:
                try:
                    room_descriptor = os.open(
                        room, _directory_flags(), dir_fd=root_descriptor
                    )
                except OSError:
                    continue
                try:
                    if self.require_readonly and not _fd_is_readonly(room_descriptor):
                        raise LiveGroupwareSourceError("source_mount_is_writable")
                    state["directories"] += 1
                    walk(room_descriptor, (room,), room, 1)
                finally:
                    os.close(room_descriptor)
        finally:
            os.close(root_descriptor)
        identifiers = [candidate.message_id for candidate in candidates]
        if len(identifiers) != len(set(identifiers)):
            raise LiveGroupwareSourceError("source_document_identity_collision")
        return candidates

    def _open_candidate(self, candidate: _Candidate) -> int:
        root_descriptor = self._open_root()
        current = root_descriptor
        try:
            for component in candidate.relative_parts[:-1]:
                child = os.open(component, _directory_flags(), dir_fd=current)
                if current != root_descriptor:
                    os.close(current)
                current = child
            descriptor = os.open(
                candidate.relative_parts[-1], _file_flags(), dir_fd=current
            )
            return descriptor
        except OSError as exc:
            raise _DocumentSkip("source_document_unavailable") from exc
        finally:
            if current != root_descriptor:
                try:
                    os.close(current)
                except OSError:
                    pass
            os.close(root_descriptor)

    def _read_candidate(self, candidate: _Candidate) -> tuple[bytes, int]:
        last_skip: _DocumentSkip | None = None
        for _attempt in range(MAX_READ_ATTEMPTS):
            descriptor: int | None = None
            try:
                descriptor = self._open_candidate(candidate)
                before = os.fstat(descriptor)
                if (
                    not stat.S_ISREG(before.st_mode)
                    or before.st_nlink < 1
                    or not 1 <= before.st_size <= MAX_FILE_BYTES
                ):
                    raise _DocumentSkip("source_document_file_invalid")
                if self.require_readonly and not _fd_is_readonly(descriptor):
                    raise LiveGroupwareSourceError("source_mount_is_writable")
                payload = _read_descriptor(descriptor, MAX_FILE_BYTES)
                after = os.fstat(descriptor)
                if (
                    _identity(before) != _identity(after)
                    or len(payload) != before.st_size
                ):
                    raise _DocumentSkip("source_document_changed")
                return payload, before.st_mtime_ns // 1_000_000_000
            except LiveGroupwareSourceError:
                raise
            except OSError:
                last_skip = _DocumentSkip("source_document_unavailable")
            except _DocumentSkip as exc:
                last_skip = exc
                if exc.code not in {
                    "source_document_changed",
                    "source_document_unavailable",
                }:
                    break
            finally:
                if descriptor is not None:
                    os.close(descriptor)
        raise last_skip or _DocumentSkip("source_document_unavailable")

    def _parse_candidate(self, candidate: _Candidate) -> _ParsedDocument:
        payload, sent_time = self._read_candidate(candidate)
        return _parse_document(candidate.suffix, payload, sent_time)

    def message_snapshot(self) -> list[SourceMessage]:
        output: list[SourceMessage] = []
        total_text_bytes = 0
        for candidate in self._enumerate_candidates():
            try:
                parsed = self._parse_candidate(candidate)
            except _DocumentSkip:
                continue
            total_text_bytes += len(parsed.text.encode("utf-8"))
            if total_text_bytes > MAX_SOURCE_TEXT_UTF8_BYTES:
                raise LiveGroupwareSourceError("source_tree_unbounded")
            output.append(
                SourceMessage(
                    room=candidate.room,
                    message_id=candidate.message_id,
                    user_id=parsed.user_id,
                    user_name=parsed.user_name,
                    sent_time=parsed.sent_time,
                    text=parsed.text,
                )
            )
        if not output:
            raise LiveGroupwareSourceError("source_has_no_indexable_documents")
        return sorted(
            output,
            key=lambda message: (
                message.room,
                message.sent_time,
                message.message_id,
                message.user_id,
                message.user_name,
            ),
        )

    def resolve_references(
        self,
        *,
        room: str,
        references: Sequence[Mapping[str, Any]],
        expected_text_sha256: str,
    ) -> tuple[str, tuple[str, ...]]:
        if (
            not isinstance(room, str)
            or not is_sha256(expected_text_sha256)
            or isinstance(references, (str, bytes))
            or not 1 <= len(references) <= MAX_REFERENCE_COUNT
        ):
            raise LiveGroupwareSourceError("segment_reference_invalid")
        normalized: list[tuple[str, int, int]] = []
        for reference in references:
            if not isinstance(reference, Mapping) or set(reference) != {
                "message_id",
                "start",
                "end",
            }:
                raise LiveGroupwareSourceError("segment_reference_invalid")
            message_id = reference.get("message_id")
            start = reference.get("start")
            end = reference.get("end")
            if (
                not isinstance(message_id, str)
                or _MESSAGE_ID.fullmatch(message_id) is None
                or isinstance(start, bool)
                or not isinstance(start, int)
                or isinstance(end, bool)
                or not isinstance(end, int)
                or not 0 <= start < end
            ):
                raise LiveGroupwareSourceError("segment_reference_invalid")
            normalized.append((message_id, start, end))

        try:
            candidates = {
                candidate.message_id: candidate
                for candidate in self._enumerate_candidates()
                if candidate.room == room
            }
        except LiveGroupwareSourceError as exc:
            if exc.code in _FATAL_CODES:
                raise
            raise DenseSourceReferenceUnavailable(
                "segment_source_unavailable"
            ) from exc
        identifiers = tuple(dict.fromkeys(item[0] for item in normalized))
        if set(identifiers) - set(candidates):
            raise DenseSourceReferenceUnavailable("segment_reference_missing")
        documents: dict[str, str] = {}
        for identifier in identifiers:
            try:
                documents[identifier] = self._parse_candidate(
                    candidates[identifier]
                ).text
            except _DocumentSkip as exc:
                raise DenseSourceReferenceUnavailable(
                    "segment_reference_unavailable"
                ) from exc
        pieces: list[str] = []
        for message_id, start, end in normalized:
            text = documents[message_id]
            if end > len(text):
                raise DenseSourceReferenceUnavailable(
                    "segment_reference_bounds_changed"
                )
            pieces.append(text[start:end])
        rendered = " ".join(pieces)
        digest = "sha256:" + hashlib.sha256(rendered.encode("utf-8")).hexdigest()
        if digest != expected_text_sha256:
            raise DenseSourceReferenceUnavailable("segment_source_text_changed")
        return rendered, identifiers

    def close(self) -> None:
        return None


__all__ = ["LiveGroupwareSource", "LiveGroupwareSourceError"]
