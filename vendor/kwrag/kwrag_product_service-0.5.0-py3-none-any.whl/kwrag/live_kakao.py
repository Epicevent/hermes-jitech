"""Read the Kakao package currently visible in one product slot.

The slot's read-only mount and membership file define the corpus.  No
generation identifier, publisher epoch, or copied release manifest is an
admission requirement here.  Index builds read one SQLite snapshot; searches
resolve candidates against the current package and may skip stale references.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import stat
import unicodedata
from pathlib import Path
from typing import Any, Mapping, Sequence

from .dense_source import DenseSourceReferenceUnavailable, SourceMessage
from .jsonutil import is_sha256


MAX_MEMBERSHIP_BYTES = 4 * 1024 * 1024
MAX_ROOM_COUNT = 4_096
MAX_MESSAGE_ID_CHARS = 256


class LiveKakaoSourceError(ValueError):
    """The currently mounted Kakao package is not readable as a corpus."""


def _require_readonly(path: Path) -> None:
    statvfs = getattr(os, "statvfs", None)
    readonly_flag = getattr(os, "ST_RDONLY", None)
    if statvfs is None or readonly_flag is None:
        raise LiveKakaoSourceError("source_readonly_state_unavailable")
    try:
        flags = statvfs(path).f_flag
    except OSError as exc:
        raise LiveKakaoSourceError("source_readonly_state_unavailable") from exc
    if not flags & readonly_flag:
        raise LiveKakaoSourceError("source_mount_is_writable")


def _real_directory(path: Path) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise LiveKakaoSourceError("source_package_root_invalid")
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise LiveKakaoSourceError("source_package_root_unavailable") from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise LiveKakaoSourceError("source_package_root_invalid")
    return resolved


def _regular(path: Path) -> Path:
    try:
        info = path.lstat()
        resolved = path.resolve(strict=True)
    except OSError as exc:
        raise LiveKakaoSourceError("source_package_file_unavailable") from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISREG(info.st_mode)
        or info.st_nlink < 1
        or resolved != path.absolute()
    ):
        raise LiveKakaoSourceError("source_package_file_invalid")
    return resolved


def _read_membership(path: Path) -> tuple[str, ...]:
    for _attempt in range(3):
        try:
            before = path.stat()
            if not 1 <= before.st_size <= MAX_MEMBERSHIP_BYTES:
                raise LiveKakaoSourceError("membership_size_invalid")
            payload = path.read_bytes()
            after = path.stat()
        except LiveKakaoSourceError:
            raise
        except OSError:
            continue
        identity_before = (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        )
        identity_after = (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        )
        if identity_before != identity_after or len(payload) != before.st_size:
            continue
        try:
            raw = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise LiveKakaoSourceError("membership_invalid") from exc
        rooms = raw.get("conversation_ids") if isinstance(raw, Mapping) else None
        if (
            not isinstance(rooms, list)
            or not 1 <= len(rooms) <= MAX_ROOM_COUNT
            or any(
                not isinstance(room, str)
                or not 1 <= len(room) <= 256
                or room != room.strip()
                or "/" in room
                or "\\" in room
                or room in {".", ".."}
                for room in rooms
            )
            or len(rooms) != len(set(rooms))
        ):
            raise LiveKakaoSourceError("membership_invalid")
        return tuple(sorted(rooms))
    raise LiveKakaoSourceError("membership_changed_while_reading")


def _normalized_text(value: Any) -> str:
    return unicodedata.normalize(
        "NFC",
        str(value or "").replace("\r\n", "\n").replace("\r", "\n"),
    ).strip()


class LiveKakaoPackageSource:
    """Current per-user ``kw/package`` source visible to a product slot."""

    source_kind = "kakao_live_package_v1"
    stale_references_are_skipped = True

    def __init__(self, package_root: Path, *, require_readonly: bool = True):
        if not isinstance(require_readonly, bool):
            raise LiveKakaoSourceError("readonly_requirement_invalid")
        self.package_root = _real_directory(package_root)
        self.require_readonly = require_readonly
        self.membership_path = _regular(self.package_root / "membership.json")
        self.database_path = _regular(self.package_root / "messages.sqlite")
        self.profile_path = _regular(self.package_root / "profile.json")
        self.assert_available()

    @property
    def rooms(self) -> tuple[str, ...]:
        self.assert_available()
        return _read_membership(self.membership_path)

    def assert_available(self) -> None:
        if self.require_readonly:
            _require_readonly(self.package_root)
        for path in (self.membership_path, self.database_path, self.profile_path):
            _regular(path)

    def _connect(self) -> sqlite3.Connection:
        self.assert_available()
        try:
            connection = sqlite3.connect(
                self.database_path.as_uri() + "?mode=ro",
                uri=True,
            )
            connection.execute("PRAGMA query_only=ON")
            if connection.execute("PRAGMA query_only").fetchone() != (1,):
                raise LiveKakaoSourceError("sqlite_readonly_mode_invalid")
            return connection
        except LiveKakaoSourceError:
            try:
                connection.close()
            except (NameError, sqlite3.Error):
                pass
            raise
        except sqlite3.Error as exc:
            raise LiveKakaoSourceError("database_query_failed") from exc

    def message_snapshot(self) -> list[SourceMessage]:
        rooms = self.rooms
        placeholders = ",".join("?" for _ in rooms)
        connection = self._connect()
        try:
            connection.execute("BEGIN")
            rows = connection.execute(
                "SELECT conversation_id,message_id,user_id,user_name,sent_time,plain_text "
                "FROM messages WHERE conversation_id IN ("
                + placeholders
                + ") AND plain_text IS NOT NULL AND TRIM(plain_text) != '' "
                "ORDER BY conversation_id,sent_time,message_id,user_id,user_name",
                rooms,
            ).fetchall()
        except sqlite3.Error as exc:
            raise LiveKakaoSourceError("database_query_failed") from exc
        finally:
            connection.close()
        seen: set[tuple[str, str]] = set()
        output: list[SourceMessage] = []
        for room, message_id, user_id, user_name, sent_time, raw_text in rows:
            room = str(room)
            message_id = str(message_id)
            identity = (room, message_id)
            if (
                room not in rooms
                or not 1 <= len(message_id) <= MAX_MESSAGE_ID_CHARS
                or identity in seen
            ):
                raise LiveKakaoSourceError("source_message_identity_invalid")
            seen.add(identity)
            text = _normalized_text(raw_text)
            if not text:
                continue
            output.append(
                SourceMessage(
                    room=room,
                    message_id=message_id,
                    user_id=unicodedata.normalize("NFC", str(user_id or "?")),
                    user_name=unicodedata.normalize("NFC", str(user_name or "?")),
                    sent_time=int(sent_time or 0),
                    text=text,
                )
            )
        if not output:
            raise LiveKakaoSourceError("source_has_no_indexable_messages")
        return output

    def resolve_references(
        self,
        *,
        room: str,
        references: Sequence[Mapping[str, Any]],
        expected_text_sha256: str,
    ) -> tuple[str, tuple[str, ...]]:
        if room not in self.rooms or not is_sha256(expected_text_sha256):
            raise DenseSourceReferenceUnavailable("segment_source_binding_changed")
        if not 1 <= len(references) <= 32:
            raise LiveKakaoSourceError("segment_reference_count_invalid")
        normalized: list[tuple[str, int, int]] = []
        for reference in references:
            if not isinstance(reference, Mapping) or set(reference) != {
                "message_id",
                "start",
                "end",
            }:
                raise LiveKakaoSourceError("segment_reference_invalid")
            message_id = reference.get("message_id")
            start = reference.get("start")
            end = reference.get("end")
            if (
                not isinstance(message_id, str)
                or not 1 <= len(message_id) <= MAX_MESSAGE_ID_CHARS
                or isinstance(start, bool)
                or not isinstance(start, int)
                or isinstance(end, bool)
                or not isinstance(end, int)
                or not 0 <= start < end
            ):
                raise LiveKakaoSourceError("segment_reference_invalid")
            normalized.append((message_id, start, end))
        identifiers = list(dict.fromkeys(item[0] for item in normalized))
        placeholders = ",".join("?" for _ in identifiers)
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT message_id,plain_text FROM messages WHERE conversation_id=? "
                f"AND message_id IN ({placeholders})",
                (room, *identifiers),
            ).fetchall()
        except sqlite3.Error as exc:
            raise LiveKakaoSourceError("database_query_failed") from exc
        finally:
            connection.close()
        by_id = {str(message_id): _normalized_text(text) for message_id, text in rows}
        if set(by_id) != set(identifiers):
            raise DenseSourceReferenceUnavailable("segment_reference_missing")
        pieces: list[str] = []
        for message_id, start, end in normalized:
            text = by_id[message_id]
            if end > len(text):
                raise DenseSourceReferenceUnavailable(
                    "segment_reference_bounds_changed"
                )
            pieces.append(text[start:end])
        rendered = " ".join(pieces)
        digest = "sha256:" + hashlib.sha256(rendered.encode("utf-8")).hexdigest()
        if digest != expected_text_sha256:
            raise DenseSourceReferenceUnavailable("segment_source_text_changed")
        return rendered, tuple(identifiers)

    def close(self) -> None:
        return None


__all__ = ["LiveKakaoPackageSource", "LiveKakaoSourceError"]
