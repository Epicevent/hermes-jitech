"""Shared caller contract for product-native mounted-source retrieval.

The registry maps a stable product source name to the runtime-visible package
layout.  It does not grant access: the opened read-only mount and the current
Workspace runtime remain authoritative.  Scope and request normalization only
make the caller's explicit selection bounded and unambiguous.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping


PRODUCT_REQUEST_SCHEMA = "kwrag-product-cli-request-v1"
SLOT_SEARCH_REQUEST_SCHEMA = "kwrag-slot-search-request-v1"
MAX_SOURCE_SELECTORS = 64
MAX_ROOM_SELECTORS = 64
MAX_ROOM_ID_CHARS = 256
MAX_PRODUCT_CORPUS_CHARS = 321
MAX_QUERY_CHARS = 4_000
MAX_CORRELATION_CHARS = 128
_SOURCE_NAME = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
_SCOPE_FIELDS = frozenset({"sources", "rooms"})
_ROOM_FIELDS = frozenset({"source", "room_id"})
_SEARCH_FIELDS = frozenset(
    {
        "schema_version",
        "operation",
        "query",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "max_results",
        "scope",
    }
)


class ProductContractError(ValueError):
    """A caller value is outside the bounded product contract."""


@dataclass(frozen=True)
class ProductSourceAdapter:
    """One real mounted-source route; never an access grant."""

    source: str
    package_relative: tuple[str, ...]
    source_kind: str

    def package_root(self, mount_root: Path) -> Path:
        return Path(mount_root).joinpath(*self.package_relative)


@dataclass(frozen=True, order=True)
class ProductRoomSelector:
    source: str
    room_id: str


@dataclass(frozen=True)
class ProductScope:
    """Deterministic explicit scope; ``rooms=None`` means all mounted rooms."""

    sources: tuple[str, ...]
    rooms: tuple[ProductRoomSelector, ...] | None

    def room_ids(self, source: str) -> tuple[str, ...] | None:
        if self.rooms is None:
            return None
        return tuple(room.room_id for room in self.rooms if room.source == source)

    def observation(self) -> dict[str, Any]:
        return {
            "sources": list(self.sources),
            "rooms": (
                None
                if self.rooms is None
                else [
                    {"source": room.source, "room_id": room.room_id}
                    for room in self.rooms
                ]
            ),
        }


@dataclass(frozen=True)
class ProductSearchRequest:
    """Validated public search plus its private slot-runtime translation."""

    scope: ProductScope
    slot_request: dict[str, Any]


_KAKAO_ADAPTER = ProductSourceAdapter(
    source="kakao",
    package_relative=("kw", "package"),
    source_kind="kakao_live_package_v1",
)
_GROUPWARE_ADAPTER = ProductSourceAdapter(
    source="groupware",
    package_relative=("groupware",),
    source_kind="groupware_live_documents_v1",
)
PRODUCT_SOURCE_ADAPTERS: Mapping[str, ProductSourceAdapter] = MappingProxyType(
    {
        "groupware": _GROUPWARE_ADAPTER,
        "kakao": _KAKAO_ADAPTER,
    }
)


def product_source_adapter(source: str) -> ProductSourceAdapter:
    try:
        return PRODUCT_SOURCE_ADAPTERS[source]
    except (KeyError, TypeError) as exc:
        raise ProductContractError("scope_source_unsupported") from exc


def _source_name(value: Any) -> str:
    if not isinstance(value, str) or _SOURCE_NAME.fullmatch(value) is None:
        raise ProductContractError("scope_source_invalid")
    if value not in PRODUCT_SOURCE_ADAPTERS:
        raise ProductContractError("scope_source_unsupported")
    return value


def _room_id(value: Any) -> str:
    if (
        not isinstance(value, str)
        or not 1 <= len(value) <= MAX_ROOM_ID_CHARS
        or value != value.strip()
        or "/" in value
        or "\\" in value
        or value in {".", ".."}
    ):
        raise ProductContractError("scope_room_invalid")
    return value


def encode_product_corpus(source: str, room_id: str) -> str:
    """Encode one source-qualified room without changing legacy Kakao ids."""

    normalized_source = _source_name(source)
    normalized_room = _room_id(room_id)
    if normalized_source == "kakao":
        return normalized_room
    encoded = f"{normalized_source}/{normalized_room}"
    if len(encoded) > MAX_PRODUCT_CORPUS_CHARS:
        raise ProductContractError("scope_room_invalid")
    return encoded


def decode_product_corpus(value: Any) -> ProductRoomSelector:
    """Decode an internal corpus key into the stable public selector."""

    if not isinstance(value, str) or not value:
        raise ProductContractError("scope_room_invalid")
    if "/" not in value:
        return ProductRoomSelector(source="kakao", room_id=_room_id(value))
    source, room_id = value.split("/", 1)
    if source == "kakao":
        raise ProductContractError("scope_room_invalid")
    selector = ProductRoomSelector(
        source=_source_name(source),
        room_id=_room_id(room_id),
    )
    if encode_product_corpus(selector.source, selector.room_id) != value:
        raise ProductContractError("scope_room_invalid")
    return selector


def normalize_product_scope(value: Any = None) -> ProductScope:
    """Validate and deterministically normalize one optional product scope."""

    if isinstance(value, ProductScope):
        value = {
            "sources": list(value.sources),
            **(
                {
                    "rooms": [
                        {"source": room.source, "room_id": room.room_id}
                        for room in value.rooms
                    ]
                }
                if value.rooms is not None
                else {}
            ),
        }
    if value is None:
        return ProductScope(tuple(sorted(PRODUCT_SOURCE_ADAPTERS)), None)
    if not isinstance(value, Mapping):
        raise ProductContractError("scope_invalid")
    fields = set(value)
    if not fields or fields - _SCOPE_FIELDS:
        raise ProductContractError("scope_invalid")

    if "sources" in value:
        raw_sources = value.get("sources")
        if (
            not isinstance(raw_sources, list)
            or not 1 <= len(raw_sources) <= MAX_SOURCE_SELECTORS
        ):
            raise ProductContractError("scope_sources_invalid")
        sources = tuple(_source_name(item) for item in raw_sources)
        if len(sources) != len(set(sources)):
            raise ProductContractError("scope_sources_duplicate")
    else:
        sources = ()

    if "rooms" in value:
        raw_rooms = value.get("rooms")
        if (
            not isinstance(raw_rooms, list)
            or not 1 <= len(raw_rooms) <= MAX_ROOM_SELECTORS
        ):
            raise ProductContractError("scope_rooms_invalid")
        rooms: list[ProductRoomSelector] = []
        for raw_room in raw_rooms:
            if not isinstance(raw_room, Mapping) or set(raw_room) != _ROOM_FIELDS:
                raise ProductContractError("scope_room_invalid")
            rooms.append(
                ProductRoomSelector(
                    source=_source_name(raw_room.get("source")),
                    room_id=_room_id(raw_room.get("room_id")),
                )
            )
        if len(rooms) != len(set(rooms)):
            raise ProductContractError("scope_rooms_duplicate")
        normalized_rooms: tuple[ProductRoomSelector, ...] | None = tuple(
            sorted(rooms)
        )
    else:
        normalized_rooms = None

    if not sources:
        if normalized_rooms is None:
            raise ProductContractError("scope_invalid")
        sources = tuple(sorted({room.source for room in normalized_rooms}))
    else:
        sources = tuple(sorted(sources))
    if normalized_rooms is not None and any(
        room.source not in sources for room in normalized_rooms
    ):
        raise ProductContractError("scope_room_source_mismatch")
    return ProductScope(sources=sources, rooms=normalized_rooms)


def _optional_text(value: Any, maximum: int) -> None:
    if value is not None and (
        not isinstance(value, str) or not 1 <= len(value) <= maximum
    ):
        raise ProductContractError("search_correlation_invalid")


def normalize_product_search_request(value: Any) -> ProductSearchRequest:
    """Validate the public search request and derive its private room list."""

    if not isinstance(value, Mapping) or set(value) - _SEARCH_FIELDS:
        raise ProductContractError("search_request_invalid")
    if (
        value.get("schema_version") != PRODUCT_REQUEST_SCHEMA
        or value.get("operation") != "search"
    ):
        raise ProductContractError("search_request_invalid")
    query = value.get("query")
    if (
        not isinstance(query, str)
        or not 1 <= len(query) <= MAX_QUERY_CHARS
        or not query.strip()
    ):
        raise ProductContractError("search_query_invalid")
    for name in ("request_id", "operation_id", "run_id"):
        _optional_text(value.get(name), MAX_CORRELATION_CHARS)
    attempt = value.get("attempt", 1)
    max_results = value.get("max_results", 5)
    if (
        isinstance(attempt, bool)
        or not isinstance(attempt, int)
        or not 1 <= attempt <= 16
        or isinstance(max_results, bool)
        or not isinstance(max_results, int)
        or not 1 <= max_results <= 10
    ):
        raise ProductContractError("search_integer_invalid")

    scope = normalize_product_scope(value.get("scope"))
    slot_request = {
        name: item
        for name, item in value.items()
        if name not in {"schema_version", "operation", "scope"}
    }
    slot_request["schema_version"] = SLOT_SEARCH_REQUEST_SCHEMA
    if scope.rooms is not None:
        slot_request["rooms"] = [
            encode_product_corpus(room.source, room.room_id)
            for room in scope.rooms
        ]
    return ProductSearchRequest(scope=scope, slot_request=slot_request)


__all__ = [
    "MAX_CORRELATION_CHARS",
    "MAX_QUERY_CHARS",
    "MAX_ROOM_ID_CHARS",
    "MAX_ROOM_SELECTORS",
    "MAX_PRODUCT_CORPUS_CHARS",
    "MAX_SOURCE_SELECTORS",
    "PRODUCT_REQUEST_SCHEMA",
    "PRODUCT_SOURCE_ADAPTERS",
    "ProductContractError",
    "ProductRoomSelector",
    "ProductScope",
    "ProductSearchRequest",
    "ProductSourceAdapter",
    "decode_product_corpus",
    "encode_product_corpus",
    "normalize_product_scope",
    "normalize_product_search_request",
    "product_source_adapter",
]
