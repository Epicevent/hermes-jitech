"""Digest-pinned retrieval engines injected behind the backend-neutral ABI."""
