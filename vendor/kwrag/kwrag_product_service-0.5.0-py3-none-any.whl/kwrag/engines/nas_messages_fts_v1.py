"""Bounded read-only adapter for crawler-owned NAS user-package SQLite.

This module does not create, migrate, rebuild, or publish SQLite.  It exposes
message-only FTS retrieval as an explicit method.  Attachment retrieval is a
separate unresolved product decision and therefore fails closed.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
import stat
import threading
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


SCHEMA_VERSION = "kwrag-nas-messages-fts-adapter-v1"
BACKEND_ID = "nas-user-package-messages-fts5-unicode61-read-only-v1"

MAX_DATABASE_BYTES = 512 * 1024 * 1024
MAX_MEMBERSHIP_BYTES = 1024 * 1024
MAX_CONVERSATIONS = 512
MAX_IDENTIFIER_CHARACTERS = 256
MAX_QUERY_CHARACTERS = 4_000
MAX_QUERY_TERMS = 12
MAX_RESULTS = 10
MAX_CANDIDATES = 1_000
MAX_RESULT_CHARACTERS = 20_000

_SHA256_RE = re.compile(r"sha256:[0-9a-f]{64}")
_MESSAGE_COLUMNS = (
    "conversation_id",
    "message_id",
    "room_name",
    "request_id",
    "user_id",
    "user_name",
    "sent_time",
    "text_kind",
    "plain_text",
    "decrypt_status",
)
_FTS_COLUMNS = (
    "plain_text",
    "user_name",
    "room_name",
    "file_name",
    "conversation_id",
    "message_id",
)
_ATTACHMENT_COLUMNS = (
    "conversation_id",
    "message_id",
    "block_index",
    "block_type",
    "file_name",
    "mime_type",
    "nas_path",
)
_BINDING_FIELDS = frozenset(
    {"databaseSha256", "membershipSha256", "authority"}
)
_AUTHORITY_FIELDS = frozenset(
    {"mode", "readOnlyObserved", "receiptDigest"}
)


class NasMessagesFtsError(ValueError):
    """The direct NAS source did not satisfy the bounded adapter contract."""


class AttachmentSemanticsUnresolved(NasMessagesFtsError):
    """Attachment retrieval is blocked pending an explicit product decision."""


@dataclass(frozen=True)
class _FileIdentity:
    device: int
    inode: int
    mode: int
    links: int
    size: int
    mtime_ns: int


@dataclass(frozen=True)
class MessageFtsHit:
    conversation_id: str
    message_id: str
    request_id: str
    user_id: str
    user_name: str
    sent_time: int
    text_kind: str
    text: str
    score: float


def _identity(metadata: os.stat_result) -> _FileIdentity:
    return _FileIdentity(
        device=metadata.st_dev,
        inode=metadata.st_ino,
        mode=metadata.st_mode,
        links=metadata.st_nlink,
        size=metadata.st_size,
        mtime_ns=metadata.st_mtime_ns,
    )


def _validate_metadata(
    metadata: os.stat_result, *, maximum: int, code: str
) -> None:
    if (
        not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
        or not 1 <= metadata.st_size <= maximum
    ):
        raise NasMessagesFtsError(code)


def _open_stable(
    path: Path, *, maximum: int, retain: bool
) -> tuple[Any, _FileIdentity]:
    source = Path(path)
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise NasMessagesFtsError("package_file_unavailable") from exc
    chunks: list[bytes] = []
    digest = hashlib.sha256()
    try:
        before = os.fstat(descriptor)
        _validate_metadata(
            before,
            maximum=maximum,
            code="package_file_identity_invalid",
        )
        total = 0
        while True:
            block = os.read(descriptor, min(1024 * 1024, maximum + 1 - total))
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise NasMessagesFtsError("package_file_size_invalid")
            digest.update(block)
            if retain:
                chunks.append(block)
        after = os.fstat(descriptor)
        if _identity(before) != _identity(after):
            raise NasMessagesFtsError("package_file_identity_changed")
    finally:
        os.close(descriptor)
    payload: Any = b"".join(chunks) if retain else "sha256:" + digest.hexdigest()
    return payload, _identity(after)


def _assert_identity(path: Path, expected: _FileIdentity) -> None:
    try:
        metadata = Path(path).lstat()
    except OSError as exc:
        raise NasMessagesFtsError("package_file_unavailable") from exc
    if _identity(metadata) != expected:
        raise NasMessagesFtsError("package_file_identity_changed")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for key, value in pairs:
        if key in output:
            raise NasMessagesFtsError("membership_duplicate_key")
        output[key] = value
    return output


def _membership(payload: bytes) -> tuple[str, ...]:
    try:
        raw = json.loads(payload, object_pairs_hook=_unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise NasMessagesFtsError("membership_json_invalid") from exc
    if not isinstance(raw, Mapping) or set(raw) != {
        "schema",
        "updated_at",
        "user_id",
        "conversation_ids",
    }:
        raise NasMessagesFtsError("membership_fields_invalid")
    if raw.get("schema") != "kw-corpus-nas-user":
        raise NasMessagesFtsError("membership_schema_invalid")
    for field in ("updated_at", "user_id"):
        value = raw.get(field)
        if (
            not isinstance(value, str)
            or not 1 <= len(value) <= MAX_IDENTIFIER_CHARACTERS
            or value != value.strip()
        ):
            raise NasMessagesFtsError("membership_identity_invalid")
    rooms = raw.get("conversation_ids")
    if (
        not isinstance(rooms, list)
        or not 1 <= len(rooms) <= MAX_CONVERSATIONS
        or any(
            not isinstance(room, str)
            or not 1 <= len(room) <= MAX_IDENTIFIER_CHARACTERS
            or room != room.strip()
            for room in rooms
        )
        or len(rooms) != len(set(rooms))
    ):
        raise NasMessagesFtsError("membership_conversations_invalid")
    return tuple(rooms)


def _columns(connection: sqlite3.Connection, table: str) -> tuple[str, ...]:
    return tuple(
        str(row[1])
        for row in connection.execute(f"PRAGMA table_info({table})")
    )


def _schema_and_linkage(connection: sqlite3.Connection) -> None:
    tables = {
        str(row[0])
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        )
    }
    if not {"messages", "messages_fts", "attachments"}.issubset(tables):
        raise NasMessagesFtsError("database_tables_invalid")
    if (
        _columns(connection, "messages") != _MESSAGE_COLUMNS
        or _columns(connection, "messages_fts") != _FTS_COLUMNS
        or _columns(connection, "attachments") != _ATTACHMENT_COLUMNS
    ):
        raise NasMessagesFtsError("database_columns_invalid")
    row = connection.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='messages_fts'"
    ).fetchone()
    ddl = str(row[0]) if row and row[0] is not None else ""
    normalized = " ".join(ddl.lower().split())
    if (
        "using fts5" not in normalized
        or re.search(r"tokenize\s*=\s*['\"]unicode61['\"]", normalized) is None
        or re.search(r"conversation_id\s+unindexed", normalized) is None
        or re.search(r"message_id\s+unindexed", normalized) is None
    ):
        raise NasMessagesFtsError("messages_fts_schema_invalid")
    message_count = int(
        connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    )
    fts_count = int(
        connection.execute("SELECT COUNT(*) FROM messages_fts").fetchone()[0]
    )
    if message_count != fts_count:
        raise NasMessagesFtsError("fts_message_coverage_invalid")
    mismatch = connection.execute(
        """
        SELECT 1
        FROM messages_fts AS f
        LEFT JOIN messages AS m ON m.rowid=f.rowid
        WHERE m.rowid IS NULL
           OR f.conversation_id IS NULL
           OR f.message_id IS NULL
           OR f.conversation_id<>m.conversation_id
           OR f.message_id<>m.message_id
           OR NOT (f.plain_text IS m.plain_text)
           OR NOT (f.user_name IS m.user_name)
           OR NOT (f.room_name IS m.room_name)
        LIMIT 1
        """
    ).fetchone()
    if mismatch is not None:
        raise NasMessagesFtsError("fts_message_linkage_invalid")


def _normalize_terms(text: str) -> list[str]:
    normalized = unicodedata.normalize("NFC", text).casefold()
    normalized = " ".join(normalized.split())
    cleaned = re.sub(r'["\'()*:^+]+', " ", normalized)
    return list(
        dict.fromkeys(term for term in cleaned.split() if len(term) >= 3)
    )[:MAX_QUERY_TERMS]


def _message_expression(text: str) -> str | None:
    terms = _normalize_terms(text)
    if not terms:
        return None
    phrases = " OR ".join(
        '"' + term.replace('"', '""') + '"' for term in terms
    )
    # file_name is intentionally absent.  Its attachment semantics require a
    # separate product decision before this adapter may search it.
    return "{plain_text user_name room_name} : (" + phrases + ")"


class NasMessagesFtsAdapter:
    """Direct message search over one crawler-owned NAS user package."""

    def __init__(
        self,
        database_path: Path,
        membership_path: Path,
        binding: Mapping[str, Any],
    ):
        if not isinstance(binding, Mapping) or set(binding) != _BINDING_FIELDS:
            raise NasMessagesFtsError("binding_fields_invalid")
        database = Path(database_path)
        membership_file = Path(membership_path)
        if (
            database.name != "messages.sqlite"
            or membership_file.name != "membership.json"
            or database.parent.resolve(strict=True)
            != membership_file.parent.resolve(strict=True)
        ):
            raise NasMessagesFtsError("package_file_scope_invalid")
        for suffix in ("-journal", "-wal", "-shm"):
            sidecar = database.with_name(database.name + suffix)
            if sidecar.exists() or sidecar.is_symlink():
                raise NasMessagesFtsError("database_sidecar_present")

        authority = binding.get("authority")
        if not isinstance(authority, Mapping) or set(authority) != _AUTHORITY_FIELDS:
            raise NasMessagesFtsError("authority_fields_invalid")
        if authority.get("mode") not in {
            "offline_fixture_read_only",
            "slot_local_read_only_nas",
        } or authority.get("readOnlyObserved") is not True:
            raise NasMessagesFtsError("read_only_authority_invalid")
        receipt = authority.get("receiptDigest")
        expected_database = binding.get("databaseSha256")
        expected_membership = binding.get("membershipSha256")
        if any(
            not isinstance(value, str) or _SHA256_RE.fullmatch(value) is None
            for value in (receipt, expected_database, expected_membership)
        ):
            raise NasMessagesFtsError("binding_digest_invalid")

        database_digest, database_identity = _open_stable(
            database, maximum=MAX_DATABASE_BYTES, retain=False
        )
        membership_payload, membership_identity = _open_stable(
            membership_file, maximum=MAX_MEMBERSHIP_BYTES, retain=True
        )
        if (
            database_digest != expected_database
            or "sha256:" + hashlib.sha256(membership_payload).hexdigest()
            != expected_membership
        ):
            raise NasMessagesFtsError("package_digest_mismatch")

        self.allowed_conversation_ids = _membership(membership_payload)
        self.database_path = database.resolve(strict=True)
        self.membership_path = membership_file.resolve(strict=True)
        self._database_identity = database_identity
        self._membership_identity = membership_identity
        self._lock = threading.RLock()
        self._connection: sqlite3.Connection | None = None
        try:
            connection = sqlite3.connect(
                self.database_path.as_uri() + "?mode=ro&immutable=1",
                uri=True,
                check_same_thread=False,
            )
            connection.execute("PRAGMA query_only=ON")
            if connection.execute("PRAGMA query_only").fetchone() != (1,):
                raise NasMessagesFtsError("sqlite_read_only_mode_invalid")
            _schema_and_linkage(connection)
            self._connection = connection
            self._assert_current()
        except Exception:
            try:
                connection.close()
            except (NameError, sqlite3.Error):
                pass
            raise

    def _assert_current(self) -> None:
        _assert_identity(self.database_path, self._database_identity)
        _assert_identity(self.membership_path, self._membership_identity)

    def close(self) -> None:
        with self._lock:
            if self._connection is not None:
                self._connection.close()
                self._connection = None

    def __enter__(self) -> "NasMessagesFtsAdapter":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def search_messages(
        self, query: str, *, limit: int = MAX_RESULTS
    ) -> list[MessageFtsHit]:
        if (
            not isinstance(query, str)
            or not 1 <= len(query) <= MAX_QUERY_CHARACTERS
            or not query.strip()
            or isinstance(limit, bool)
            or not isinstance(limit, int)
            or not 1 <= limit <= MAX_RESULTS
        ):
            raise NasMessagesFtsError("message_search_request_invalid")
        expression = _message_expression(query)
        if expression is None:
            return []
        rooms = self.allowed_conversation_ids
        placeholders = ",".join("?" for _ in rooms)
        statement = f"""
            SELECT m.conversation_id,m.message_id,m.request_id,m.user_id,
                   m.user_name,m.sent_time,m.text_kind,m.plain_text,
                   bm25(messages_fts)
            FROM messages_fts AS f
            JOIN messages AS m
              ON m.rowid=f.rowid
             AND m.conversation_id=f.conversation_id
             AND m.message_id=f.message_id
            WHERE messages_fts MATCH ?
              AND m.conversation_id IN ({placeholders})
            ORDER BY bm25(messages_fts),m.conversation_id,m.sent_time,m.message_id
            LIMIT ?
        """
        with self._lock:
            connection = self._connection
            if connection is None:
                raise NasMessagesFtsError("adapter_closed")
            self._assert_current()
            try:
                rows = connection.execute(
                    statement, (expression, *rooms, MAX_CANDIDATES)
                ).fetchall()
            except sqlite3.Error as exc:
                raise NasMessagesFtsError("message_fts_query_failed") from exc
            self._assert_current()

        output: list[MessageFtsHit] = []
        seen: set[tuple[str, str]] = set()
        used = 0
        allowed = set(rooms)
        for raw in rows:
            (
                conversation_id,
                message_id,
                request_id,
                user_id,
                user_name,
                sent_time,
                text_kind,
                plain_text,
                score,
            ) = raw
            conversation_id = str(conversation_id)
            message_id = str(message_id)
            identity = (conversation_id, message_id)
            text = str(plain_text or "")
            numeric_score = -float(score)
            if (
                conversation_id not in allowed
                or not 1 <= len(message_id) <= MAX_IDENTIFIER_CHARACTERS
                or identity in seen
                or not math.isfinite(numeric_score)
            ):
                raise NasMessagesFtsError("message_result_identity_invalid")
            seen.add(identity)
            if used + len(text) > MAX_RESULT_CHARACTERS:
                continue
            output.append(
                MessageFtsHit(
                    conversation_id=conversation_id,
                    message_id=message_id,
                    request_id=str(request_id or ""),
                    user_id=str(user_id or ""),
                    user_name=str(user_name or ""),
                    sent_time=int(sent_time or 0),
                    text_kind=str(text_kind),
                    text=text,
                    score=numeric_score,
                )
            )
            used += len(text)
            if len(output) >= limit:
                break
        return output

    def search_attachments(self, *_args: Any, **_kwargs: Any) -> None:
        raise AttachmentSemanticsUnresolved(
            "attachment_search_semantics_unresolved"
        )


__all__ = [
    "AttachmentSemanticsUnresolved",
    "BACKEND_ID",
    "MessageFtsHit",
    "NasMessagesFtsAdapter",
    "NasMessagesFtsError",
    "SCHEMA_VERSION",
]
