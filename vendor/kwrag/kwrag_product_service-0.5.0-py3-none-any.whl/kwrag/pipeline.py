"""The single retrieval path shared by serving and offline evaluation."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Protocol

import numpy as np

from .config import KwRagConfig
from .corpus import Corpus, Unit


def _torch_dtype(name: str):
    import torch

    return {
        "float32": torch.float32,
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
    }[name]


class Embedder:
    def __init__(self, config):
        self.config = config
        self._instance = None

    def _model(self):
        if self._instance is None:
            from sentence_transformers import SentenceTransformer

            self._instance = SentenceTransformer(
                self.config.model,
                device=self.config.device,
                revision=self.config.revision,
                local_files_only=self.config.local_files_only,
                model_kwargs={"torch_dtype": _torch_dtype(self.config.dtype)},
            )
        return self._instance

    def encode(self, texts: list[str]) -> np.ndarray:
        limit = int(self.config.query_max_chars)
        return self._model().encode(
            [text[:limit] for text in texts],
            normalize_embeddings=self.config.normalize,
            batch_size=128,
            show_progress_bar=False,
        )

    def encode_one(self, text: str) -> np.ndarray:
        return self.encode([text])[0]


@dataclass
class Candidate:
    unit: Unit
    dense_score: float
    score: float = 0.0


class Retriever(Protocol):
    level: str

    def candidates(
        self, query: str, query_vector: np.ndarray, room: str, pool: int
    ) -> list[Candidate]: ...


class DenseRetriever:
    def __init__(self, corpus: Corpus, embedder: Embedder, level: str = "segment"):
        self.corpus = corpus
        self.embedder = embedder
        self.level = level

    def candidates(
        self, query: str, query_vector: np.ndarray, room: str, pool: int
    ) -> list[Candidate]:
        index = self.corpus.room(room)
        units = index.units(self.level, self.embedder)
        similarities = index.embeddings(self.level, self.embedder) @ query_vector
        top = np.argsort(-similarities)[:pool]
        return [
            Candidate(units[int(row)], float(similarities[int(row)])) for row in top
        ]


class DenseOrderRanker:
    def warm(self) -> None:
        return

    def rank(self, query: str, candidates: list[Candidate]) -> list[Candidate]:
        for candidate in candidates:
            candidate.score = candidate.dense_score
        return sorted(candidates, key=lambda candidate: -candidate.score)


class CrossEncoderRanker:
    def __init__(self, config):
        self.config = config
        self._instance = None

    def _model(self):
        if self._instance is None:
            from sentence_transformers import CrossEncoder

            self._instance = CrossEncoder(
                self.config.model,
                device=self.config.device,
                revision=self.config.revision,
                local_files_only=self.config.local_files_only,
                max_length=self.config.max_length,
                model_kwargs={"torch_dtype": _torch_dtype(self.config.dtype)},
            )
        return self._instance

    def warm(self) -> None:
        self._model()

    def rank(self, query: str, candidates: list[Candidate]) -> list[Candidate]:
        if not candidates:
            return []
        limit = int(self.config.passage_max_chars)
        pairs = [(query, candidate.unit.text[:limit]) for candidate in candidates]
        scores = self._model().predict(
            pairs, batch_size=self.config.batch_size, show_progress_bar=False
        )
        for candidate, score in zip(candidates, scores):
            candidate.score = float(score)
        return sorted(candidates, key=lambda candidate: -candidate.score)


class UnitReturner:
    def render(self, _query, _query_vector, ranked, k) -> list[Candidate]:
        return ranked[:k]


class TwoStageReturner:
    def __init__(self, corpus: Corpus, embedder: Embedder, turns: int):
        self.corpus = corpus
        self.embedder = embedder
        self.turns = turns

    def render(self, _query, query_vector, ranked, k) -> list[Candidate]:
        picked: list[Unit] = []
        for candidate in ranked[:k]:
            picked.extend(
                self.corpus.room(candidate.unit.room).turns_of_segment(
                    candidate.unit.uid, self.embedder
                )
            )
        if not picked:
            return ranked[:k]
        by_room: dict[str, list[Unit]] = {}
        for unit in picked:
            by_room.setdefault(unit.room, []).append(unit)
        scored: list[tuple[float, Unit]] = []
        for room, units in by_room.items():
            index = self.corpus.room(room)
            all_turns = index.units("turn", self.embedder)
            row = {unit.uid: position for position, unit in enumerate(all_turns)}
            embeddings = index.embeddings("turn", self.embedder)
            similarities = embeddings[[row[unit.uid] for unit in units]] @ query_vector
            scored.extend(
                (float(score), unit) for score, unit in zip(similarities, units)
            )
        return [
            Candidate(unit=unit, dense_score=score, score=score)
            for score, unit in sorted(scored, key=lambda item: -item[0])[: self.turns]
        ]


class Pipeline:
    def __init__(self, config: KwRagConfig, *, cache_namespace: str | None = None):
        self.config = config
        self.corpus = Corpus(
            config.index_dir,
            config.cache_dir,
            config.rooms,
            cache_namespace or config.embedding_fingerprint(),
        )
        self.embedder = Embedder(config.embedding)
        level = "turn" if config.ret.unit == "turn" else "segment"
        self.retriever = DenseRetriever(self.corpus, self.embedder, level)
        self.ranker = (
            CrossEncoderRanker(config.rerank)
            if config.rerank.enabled
            else DenseOrderRanker()
        )
        self.returner = (
            TwoStageReturner(self.corpus, self.embedder, config.ret.turns)
            if config.ret.unit == "two_stage"
            else UnitReturner()
        )

    def warm(self) -> None:
        self.embedder.encode_one("warmup")
        self.ranker.warm()
        for room in self.corpus.room_keys():
            self.corpus.room(room).units(self.retriever.level, self.embedder)
            if self.config.ret.unit == "two_stage":
                self.corpus.room(room).units("turn", self.embedder)

    def trace(self, query: str, rooms: list[str], k: int) -> dict:
        started = time.monotonic()
        bounded_k = min(int(k), int(self.config.ret.max_k))
        query_vector = self.embedder.encode_one(query)
        embedded = time.monotonic()
        candidates: list[Candidate] = []
        for room in rooms:
            candidates.extend(
                self.retriever.candidates(
                    query, query_vector, room, self.config.retrieval.pool_for(room)
                )
            )
        ranked = self.ranker.rank(query, candidates)
        reranked = time.monotonic()
        selected = self.returner.render(query, query_vector, ranked, bounded_k)
        return {
            "rooms": rooms,
            "k": bounded_k,
            "candidates": candidates,
            "ranked": ranked,
            "units": [candidate.unit for candidate in selected],
            "selected": selected,
            "timing_ms": {
                "embed": round((embedded - started) * 1_000),
                "rank": round((reranked - embedded) * 1_000),
                "total": round((time.monotonic() - started) * 1_000),
            },
        }

    def search(self, query: str, rooms: list[str], k: int) -> dict:
        trace = self.trace(query, rooms, k)
        hits = []
        for rank, candidate in enumerate(trace["selected"], 1):
            unit = candidate.unit
            hits.append(
                {
                    "rank": rank,
                    "score": round(candidate.score, 4),
                    "dense_score": round(candidate.dense_score, 4),
                    "room": unit.room,
                    "level": unit.level,
                    "seg_id": unit.uid,
                    "t_start": unit.t_start,
                    "t_end": unit.t_end,
                    "message_ids": sorted(unit.mids),
                    **({"text": unit.text} if self.config.ret.include_text else {}),
                }
            )
        return {
            "mode": self.config.mode_label(),
            "hits": hits,
            "n_candidates": len(trace["candidates"]),
            "timing_ms": trace["timing_ms"],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": "dense-rerank-v1",
                "stages": [
                    {
                        "stage_id": "embedding",
                        "execution_scope": "slot_local",
                        "model": self.config.embedding.model,
                        "revision": self.config.embedding.revision,
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": 1,
                    },
                    {
                        "stage_id": "index_search",
                        "execution_scope": "slot_local",
                        "model": None,
                        "revision": None,
                        "call_count": len(rooms),
                        "input_count": len(rooms),
                        "output_count": len(trace["candidates"]),
                    },
                    {
                        "stage_id": "rerank",
                        "execution_scope": "slot_local",
                        "model": (
                            self.config.rerank.model
                            if self.config.rerank.enabled
                            else None
                        ),
                        "revision": (
                            self.config.rerank.revision
                            if self.config.rerank.enabled
                            else None
                        ),
                        "call_count": 1,
                        "input_count": len(trace["candidates"]),
                        "output_count": len(trace["candidates"]),
                    },
                ],
                "candidate_count": len(trace["candidates"]),
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }
