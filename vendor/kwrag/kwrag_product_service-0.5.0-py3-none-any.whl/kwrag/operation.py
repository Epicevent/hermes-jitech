"""Search-operation primitives that do not decide corpus authorization."""

from __future__ import annotations

import hashlib
import math
import os
import stat
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from .jsonutil import canonical_json_bytes, is_sha256

MAX_QUERY_CHARS = 4_000
MAX_SNIPPET_CHARS = 8_000
MAX_CORRELATION_CHARS = 128
SLOT_PIPELINE_EVIDENCE_SCHEMA = "kwrag-slot-pipeline-evidence-v1"

_SLOT_EVIDENCE_FIELDS = frozenset(
    {
        "schema_version",
        "backend_id",
        "stages",
        "candidate_count",
        "data_boundary",
    }
)
_SLOT_STAGE_FIELDS = frozenset(
    {
        "stage_id",
        "execution_scope",
        "call_count",
        "input_count",
        "output_count",
        "model",
        "revision",
    }
)
_SLOT_DATA_BOUNDARY_FIELDS = frozenset(
    {
        "bytes_sent_outside_slot",
        "external_persistence",
        "persistence_receipt_digest",
    }
)


class SearchPipeline(Protocol):
    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]: ...


@dataclass
class OperationError(Exception):
    status: int
    code: str
    message: str
    retryable: bool = False


@dataclass(frozen=True)
class ReceiptWriteResult:
    status: str
    digest: str | None


class ReceiptWriter:
    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.Lock()

    def write(self, entry: dict[str, Any]) -> ReceiptWriteResult:
        try:
            canonical = canonical_json_bytes(entry)
            digest = "sha256:" + hashlib.sha256(canonical).hexdigest()
            line = canonical + b"\n"
            with self._lock:
                if os.name == "posix":
                    self._write_posix(line)
                else:
                    self._write_portable(line)
            return ReceiptWriteResult(status="written", digest=digest)
        except (OSError, TypeError, ValueError, UnicodeEncodeError):
            return ReceiptWriteResult(status="unavailable", digest=None)

    def _write_portable(self, line: bytes) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        flags = (
            os.O_WRONLY
            | os.O_CREAT
            | os.O_APPEND
            | getattr(os, "O_CLOEXEC", 0)
            | getattr(os, "O_NOFOLLOW", 0)
            | getattr(os, "O_BINARY", 0)
        )
        descriptor = os.open(self.path, flags, 0o600)
        try:
            self._verify_descriptor(descriptor, require_owner_mode=False)
            self._write_all(descriptor, line)
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _write_posix(self, line: bytes) -> None:
        if not self.path.is_absolute():
            raise OSError("POSIX receipt sink must be absolute")
        if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
            raise OSError("POSIX receipt sink requires no-follow directory opens")
        directory_flags = (
            os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0)
        )
        opened: list[int] = []
        parent_created = False
        try:
            current = os.open("/", directory_flags)
            opened.append(current)
            for part in self.path.parent.parts[1:]:
                try:
                    following = os.open(part, directory_flags, dir_fd=current)
                except FileNotFoundError:
                    os.mkdir(part, 0o700, dir_fd=current)
                    parent_created = True
                    following = os.open(part, directory_flags, dir_fd=current)
                info = os.fstat(following)
                if not stat.S_ISDIR(info.st_mode) or info.st_nlink < 1:
                    os.close(following)
                    raise OSError("receipt parent identity is invalid")
                opened.append(following)
                current = following

            existed = True
            try:
                os.stat(self.path.name, dir_fd=current, follow_symlinks=False)
            except FileNotFoundError:
                existed = False
            flags = (
                os.O_WRONLY
                | os.O_CREAT
                | os.O_APPEND
                | os.O_CLOEXEC
                | os.O_NOFOLLOW
            )
            descriptor = os.open(self.path.name, flags, 0o600, dir_fd=current)
            try:
                self._verify_descriptor(descriptor, require_owner_mode=True)
                import fcntl

                fcntl.flock(descriptor, fcntl.LOCK_EX)
                try:
                    self._write_all(descriptor, line)
                    os.fsync(descriptor)
                finally:
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
            finally:
                os.close(descriptor)
            if not existed or parent_created:
                os.fsync(current)
        finally:
            for descriptor in reversed(opened):
                os.close(descriptor)

    @staticmethod
    def _verify_descriptor(descriptor: int, *, require_owner_mode: bool) -> None:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise OSError("receipt sink is not a single-link regular file")
        if require_owner_mode and (
            info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o600
        ):
            raise OSError("receipt sink owner or mode is invalid")

    @staticmethod
    def _write_all(descriptor: int, line: bytes) -> None:
        view = memoryview(line)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise OSError("receipt sink made no forward progress")
            view = view[written:]


def pipeline_evidence(
    raw: Any, result_count: int, corpus_count: int
) -> dict[str, Any]:
    if (
        not isinstance(raw, dict)
        or not isinstance(raw.get("operation_evidence"), dict)
        or raw["operation_evidence"].get("schema_version")
        != "kwrag-local-pipeline-evidence-v1"
    ):
        return {
            "status": "unavailable",
            "candidate_count": None,
            "returned_count": result_count,
            "corpus_count": corpus_count,
        }
    source = raw["operation_evidence"]

    def bounded_text(value: Any) -> str | None:
        return str(value)[:256] if isinstance(value, str) else None

    def nonnegative(value: Any) -> int | None:
        return (
            value
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0
            else None
        )

    embedding = source.get("embedding") if isinstance(source.get("embedding"), dict) else {}
    vector = (
        source.get("vector_search")
        if isinstance(source.get("vector_search"), dict)
        else {}
    )
    rerank = source.get("rerank") if isinstance(source.get("rerank"), dict) else {}
    timing = source.get("timing_ms") if isinstance(source.get("timing_ms"), dict) else {}
    return {
        "status": "available",
        "schema_version": "kwrag-local-pipeline-evidence-v1",
        "embedding": {
            "execution": bounded_text(embedding.get("execution")),
            "model": bounded_text(embedding.get("model")),
            "revision": bounded_text(embedding.get("revision")),
            "call_count": nonnegative(embedding.get("call_count")),
            "input_count": nonnegative(embedding.get("input_count")),
        },
        "vector_search": {
            "execution": bounded_text(vector.get("execution")),
            "call_count": nonnegative(vector.get("call_count")),
            "corpus_count": nonnegative(vector.get("corpus_count")),
        },
        "rerank": {
            "execution": bounded_text(rerank.get("execution")),
            "model": bounded_text(rerank.get("model")),
            "revision": bounded_text(rerank.get("revision")),
            "stage_call_count": nonnegative(rerank.get("stage_call_count")),
            "model_call_count": nonnegative(rerank.get("model_call_count")),
            "pair_count": nonnegative(rerank.get("pair_count")),
        },
        "candidate_count": nonnegative(source.get("candidate_count")),
        "returned_count": result_count,
        "corpus_count": corpus_count,
        "timing_ms": {
            "embed": nonnegative(timing.get("embed")),
            "rank": nonnegative(timing.get("rank")),
            "total": nonnegative(timing.get("total")),
        },
    }


def slot_pipeline_evidence(
    raw: Any, result_count: int, corpus_count: int
) -> dict[str, Any]:
    """Return the strict backend-neutral evidence envelope for an in-slot call.

    Missing or malformed evidence never becomes an invented zero-cost or
    zero-transfer claim.  Search results may still be returned, but the
    receipt records the evidence as unavailable.
    """

    unavailable = {
        "status": "unavailable",
        "schema_version": SLOT_PIPELINE_EVIDENCE_SCHEMA,
        "backend_id": None,
        "stages": [],
        "candidate_count": None,
        "returned_count": result_count,
        "corpus_count": corpus_count,
        "data_boundary": {
            "bytes_sent_outside_slot": None,
            "external_persistence": "unavailable",
            "persistence_receipt_digest": None,
        },
    }
    if not isinstance(raw, dict):
        return unavailable
    source = raw.get("operation_evidence")
    if not isinstance(source, dict) or set(source) != _SLOT_EVIDENCE_FIELDS:
        return unavailable
    if source.get("schema_version") != SLOT_PIPELINE_EVIDENCE_SCHEMA:
        return unavailable

    backend_id = source.get("backend_id")
    stages = source.get("stages")
    candidate_count = source.get("candidate_count")
    boundary = source.get("data_boundary")
    if (
        not isinstance(backend_id, str)
        or not 1 <= len(backend_id) <= 128
        or not isinstance(stages, list)
        or not 1 <= len(stages) <= 16
        or isinstance(candidate_count, bool)
        or not isinstance(candidate_count, int)
        or candidate_count < result_count
        or not isinstance(boundary, dict)
        or set(boundary) != _SLOT_DATA_BOUNDARY_FIELDS
    ):
        return unavailable

    normalized_stages: list[dict[str, Any]] = []
    stage_ids: set[str] = set()
    for stage in stages:
        if not isinstance(stage, dict) or set(stage) != _SLOT_STAGE_FIELDS:
            return unavailable
        stage_id = stage.get("stage_id")
        execution_scope = stage.get("execution_scope")
        if (
            not isinstance(stage_id, str)
            or not 1 <= len(stage_id) <= 64
            or stage_id in stage_ids
            or execution_scope not in {"slot_local", "shared_stateless"}
        ):
            return unavailable
        counts: dict[str, int] = {}
        for field in ("call_count", "input_count", "output_count"):
            value = stage.get(field)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                return unavailable
            counts[field] = value
        text_fields: dict[str, str | None] = {}
        for field in ("model", "revision"):
            value = stage.get(field)
            if value is not None and (
                not isinstance(value, str) or not 1 <= len(value) <= 256
            ):
                return unavailable
            text_fields[field] = value
        stage_ids.add(stage_id)
        normalized_stages.append(
            {
                "stage_id": stage_id,
                "execution_scope": execution_scope,
                **counts,
                **text_fields,
            }
        )

    bytes_sent = boundary.get("bytes_sent_outside_slot")
    persistence = boundary.get("external_persistence")
    persistence_receipt = boundary.get("persistence_receipt_digest")
    if (
        isinstance(bytes_sent, bool)
        or not isinstance(bytes_sent, int)
        or bytes_sent < 0
        or persistence not in {"not_applicable", "attested_none", "unavailable"}
        or (persistence_receipt is not None and not is_sha256(persistence_receipt))
    ):
        return unavailable
    has_external_stage = any(
        stage["execution_scope"] == "shared_stateless" for stage in normalized_stages
    )
    if has_external_stage and (
        bytes_sent == 0
        or persistence not in {"attested_none", "unavailable"}
        or (persistence == "attested_none" and persistence_receipt is None)
        or (persistence == "unavailable" and persistence_receipt is not None)
    ):
        return unavailable
    if not has_external_stage and (
        bytes_sent != 0
        or persistence != "not_applicable"
        or persistence_receipt is not None
    ):
        return unavailable

    return {
        "status": "partial" if persistence == "unavailable" else "available",
        "schema_version": SLOT_PIPELINE_EVIDENCE_SCHEMA,
        "backend_id": backend_id,
        "stages": normalized_stages,
        "candidate_count": candidate_count,
        "returned_count": result_count,
        "corpus_count": corpus_count,
        "data_boundary": {
            "bytes_sent_outside_slot": bytes_sent,
            "external_persistence": persistence,
            "persistence_receipt_digest": persistence_receipt,
        },
    }


def map_results(
    raw_hits: Any, limit: int, allowed_rooms: set[str]
) -> list[dict[str, Any]]:
    if not isinstance(raw_hits, list):
        raise OperationError(
            503, "not_ready", "pipeline returned no hit list", retryable=True
        )
    results: list[dict[str, Any]] = []
    for hit in raw_hits[:limit]:
        if not isinstance(hit, dict):
            continue
        room = str(hit.get("room") or "")
        level = str(hit.get("level") or "")
        raw_unit_id = hit.get("seg_id")
        unit_id = "" if raw_unit_id is None else str(raw_unit_id)
        text = hit.get("text")
        score = hit.get("score")
        if not room or not level or not unit_id or not isinstance(text, str):
            continue
        if room not in allowed_rooms:
            raise OperationError(
                503,
                "not_ready",
                "pipeline returned an out-of-scope result",
                retryable=True,
            )
        if (
            isinstance(score, bool)
            or not isinstance(score, (int, float))
            or not math.isfinite(score)
        ):
            continue
        identifier = f"{room}:{level}:{unit_id}"
        raw_source_ids = hit.get("message_ids", [])
        source_ids = (
            raw_source_ids if isinstance(raw_source_ids, (list, tuple, set)) else []
        )
        results.append(
            {
                "id": identifier,
                "corpus": room,
                "path": f"conversation://{room}/{level}/{unit_id}",
                "title": room,
                "snippet": text[:MAX_SNIPPET_CHARS],
                "score": float(score),
                "source_ids": [str(item)[:256] for item in list(source_ids)[:100]],
            }
        )
    return results
