"""Fixed, host-portless KWRAG producer for caller-explicit slot retrieval."""

from __future__ import annotations

import hashlib
import math
import os
import stat
import sys
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .engines import p1_attachment_fts_v1 as selected_engine
from .jsonutil import (
    canonical_json_bytes,
    is_sha256,
    loads_canonical_json_bytes,
    loads_strict_json,
)
from .operation import OperationError, ReceiptWriter
from .slot_consumer import SlotConsumptionError, verify_slot_search_exchange
from .slot_mount import SlotIndexScope, resolve_mounted_path
from .slot_runtime import SlotRuntimeError, SlotRuntimeSpec, build_slot_runtime


DEFAULT_BINDING_PATH = Path("/run/kwrag/fixed-producer-binding.json")
MAX_STDIN_BYTES = 16 * 1024
MAX_BINDING_BYTES = 64 * 1024
MAX_DATABASE_BYTES = 512 * 1024 * 1024
MAX_SOURCE_SNAPSHOT_BYTES = 16 * 1024 * 1024
MAX_CONSUMABLE_CHARACTERS = 20_000

FACTORY_SOURCE_DIGEST = (
    "sha256:104276b46fa427d741fcf63db87b70d9a6d8a2ad32e63c4a43e87692041ed43e"
)
FACTORY_SOURCE_BYTES = 6_567
ENGINE_CONTRACT_DIGEST = (
    "sha256:46dbce894e5987fb47598b26d0c29bf3c13c297f705a17c313d550cc6dbc844a"
)
ENGINE_CONTRACT_BYTES = 1_519
RESEARCH_DECISION_SOURCE_DIGEST = (
    "sha256:2245278aa9ad4e16ad8502287a0e10340c90a83fa93a2e26210c8f43c6f8f5e1"
)
RESEARCH_DECISION_SOURCE_BYTES = 4_732
OWNER_MANIFEST_DIGEST = (
    "sha256:60cc8be1962f7c75b1829c7facc3a484d5edb2eee0a120dfaad91b694749bf82"
)
OWNER_MANIFEST_BYTES = 2_031
PIPELINE_FACTORY_DIGEST = (
    "sha256:0dbe54f5a8bc56a6c821e181a0dc6cfda85d25be8cea6a01235cb5e347782f0e"
)
PIPELINE_FINGERPRINT = (
    "sha256:53e14752cc9d147dfb4129e00234d1c7fb9f6558df00da7c03189db8da8e4606"
)
RESEARCH_DECISION_DIGEST = (
    "sha256:81e6f4d83e6cde6a9c83a9aa435c65354a1122dded735bf607462c3497e9b25d"
)

_REQUEST_FIELDS = frozenset(
    {
        "schema_version",
        "query",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "max_results",
        "corpus",
    }
)
_BINDING_FIELDS = frozenset(
    {
        "schema_version",
        "enabled",
        "mount_root",
        "index_manifest_relative",
        "index_manifest_digest",
        "operation_receipt_path",
        "producer_receipt_path",
        "max_concurrent",
        "selected_engine",
        "corpora",
    }
)
_ENGINE_IDENTITY_FIELDS = frozenset(
    {
        "status",
        "backend_id",
        "factory_source_digest",
        "contract_source_digest",
        "research_decision_source_digest",
        "pipeline_factory_digest",
        "pipeline_fingerprint",
        "research_decision_digest",
    }
)
_CORPUS_BINDING_FIELDS = frozenset(
    {
        "database_relative",
        "database_sha256",
        "source_snapshot_relative",
        "source_snapshot_digest",
        "authority_receipt_digest",
    }
)
_OUTPUT_FIELDS = frozenset({"schema_version", "consumable", "linkage"})
_CONSUMABLE_FIELDS = frozenset(
    {
        "schema_version",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "index_manifest",
        "pipeline_fingerprint",
        "result_status",
        "results",
    }
)
_LINKAGE_FIELDS = frozenset(
    {
        "operation_receipt_digest",
        "result_digest",
        "source_exchange_digest",
        "producer_receipt_digest",
    }
)
_PRODUCER_RECEIPT_FIELDS = frozenset(
    {
        "schema_version",
        "status",
        "binding_digest",
        "index_manifest",
        "pipeline_fingerprint",
        "operation_receipt_digest",
        "result_digest",
        "source_exchange_digest",
        "consumable_payload_digest",
        "result_status",
        "result_count",
        "output_characters",
    }
)


class FixedProducerError(ValueError):
    def __init__(self, code: str, *, exit_status: int = 4):
        super().__init__(code)
        self.code = code
        self.exit_status = exit_status


@dataclass(frozen=True)
class CorpusBinding:
    database_relative: str
    database_sha256: str
    source_snapshot_relative: str
    source_snapshot_digest: str
    authority_receipt_digest: str


@dataclass(frozen=True)
class FixedProducerBinding:
    enabled: bool
    mount_root: Path
    index_manifest_relative: str
    index_manifest_digest: str
    operation_receipt_path: Path
    producer_receipt_path: Path
    max_concurrent: int
    engine_identity: Mapping[str, str]
    corpora: Mapping[str, CorpusBinding]
    digest: str


@dataclass(frozen=True)
class FixedProducerExecution:
    output_bytes: bytes
    operation_receipt: Mapping[str, Any]
    producer_receipt: Mapping[str, Any]
    binding_digest: str


def _sha256_bytes(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _binding_trust_is_valid(metadata: os.stat_result) -> bool:
    if os.name != "posix":
        return True
    try:
        effective_uid = os.geteuid()
    except (AttributeError, OSError):
        return False
    return (
        metadata.st_uid in {0, effective_uid}
        and stat.S_IMODE(metadata.st_mode) & 0o022 == 0
    )


def _read_stable_file(
    path: Path,
    *,
    maximum: int,
    binding_trust: bool = False,
) -> bytes:
    source = Path(path)
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise FixedProducerError("bound_file_unavailable") from exc
    chunks: list[bytes] = []
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
            raise FixedProducerError("bound_file_identity_invalid")
        if binding_trust and not _binding_trust_is_valid(before):
            raise FixedProducerError("binding_trust_invalid")
        if before.st_size < 0 or before.st_size > maximum:
            raise FixedProducerError("bound_file_size_invalid")
        total = 0
        while True:
            block = os.read(descriptor, min(1024 * 1024, maximum + 1 - total))
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise FixedProducerError("bound_file_size_invalid")
            chunks.append(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_nlink,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise FixedProducerError("bound_file_identity_changed")
    finally:
        os.close(descriptor)
    return b"".join(chunks)


def _streaming_digest(path: Path, *, maximum: int) -> str:
    return _sha256_bytes(_read_stable_file(path, maximum=maximum))


def _exact_mapping(value: Any, fields: frozenset[str], code: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise FixedProducerError(code)
    return value


def _bounded_text(value: Any, *, minimum: int = 1, maximum: int) -> str:
    if (
        not isinstance(value, str)
        or not minimum <= len(value) <= maximum
        or value != value.strip()
    ):
        raise FixedProducerError("text_field_invalid")
    return value


def _integer(value: Any, *, minimum: int, maximum: int) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= maximum
    ):
        raise FixedProducerError("integer_field_invalid")
    return value


def _safe_relative(value: Any, *, maximum: int = 1_024) -> str:
    raw = _bounded_text(value, maximum=maximum)
    relative = PurePosixPath(raw)
    if (
        relative.is_absolute()
        or relative.as_posix() != raw
        or "\\" in raw
        or ":" in raw
        or any(part in {"", ".", ".."} for part in relative.parts)
    ):
        raise FixedProducerError("relative_path_invalid")
    return raw


def _absolute_posix(value: Any) -> Path:
    raw = _bounded_text(value, maximum=4_096)
    pure = PurePosixPath(raw)
    if (
        not pure.is_absolute()
        or pure.as_posix() != raw
        or "\\" in raw
        or ":" in raw
        or any(part in {"", ".", ".."} for part in pure.parts)
    ):
        raise FixedProducerError("absolute_path_invalid")
    return Path(raw)


def _packaged_engine_identity() -> dict[str, str]:
    module_path = Path(selected_engine.__file__).resolve(strict=True)
    module_bytes = _read_stable_file(module_path, maximum=64 * 1024)
    artifact_root = Path(__file__).with_name("engine_artifacts")
    contract_bytes = _read_stable_file(
        artifact_root / "p1-attachment-fts-contract.json",
        maximum=64 * 1024,
    )
    decision_bytes = _read_stable_file(
        artifact_root / "p1-15b-reassessment.json",
        maximum=64 * 1024,
    )
    owner_manifest_bytes = _read_stable_file(
        artifact_root / "kwrag-owner-source-transfer-manifest.json",
        maximum=64 * 1024,
    )
    if (
        len(module_bytes) != FACTORY_SOURCE_BYTES
        or _sha256_bytes(module_bytes) != FACTORY_SOURCE_DIGEST
        or len(contract_bytes) != ENGINE_CONTRACT_BYTES
        or _sha256_bytes(contract_bytes) != ENGINE_CONTRACT_DIGEST
        or len(decision_bytes) != RESEARCH_DECISION_SOURCE_BYTES
        or _sha256_bytes(decision_bytes) != RESEARCH_DECISION_SOURCE_DIGEST
        or len(owner_manifest_bytes) != OWNER_MANIFEST_BYTES
        or _sha256_bytes(owner_manifest_bytes) != OWNER_MANIFEST_DIGEST
    ):
        raise FixedProducerError("selected_engine_bytes_mismatch")
    try:
        loads_strict_json(contract_bytes.decode("utf-8"))
        decision = loads_strict_json(decision_bytes.decode("utf-8"))
        owner_manifest = loads_strict_json(owner_manifest_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise FixedProducerError("selected_engine_artifact_invalid") from exc
    if not isinstance(decision, dict) or not isinstance(owner_manifest, dict):
        raise FixedProducerError("selected_engine_artifact_invalid")
    owner_inputs = owner_manifest.get("selectedEngineInputs")
    owner_identity = (
        owner_inputs.get("p1Identity") if isinstance(owner_inputs, dict) else None
    )
    expected_owner_identity = {
        "status": "research_selected_p1_attachment_probe_candidate",
        "pipelineFactoryDigest": PIPELINE_FACTORY_DIGEST,
        "backendId": selected_engine.BACKEND_ID,
        "pipelineFingerprint": PIPELINE_FINGERPRINT,
        "researchDecisionDigest": RESEARCH_DECISION_DIGEST,
    }
    if owner_identity != expected_owner_identity:
        raise FixedProducerError("selected_engine_owner_attestation_mismatch")

    # The transferred reassessment packet is provenance for retiring gate 15b.
    # The owner manifest separately attests the P1 research-decision identity.
    # Materialize only the factory/contract-dependent fields here; do not
    # silently treat the reassessment packet as that distinct decision object.
    materialized = selected_engine.build_p1_identity(
        decision={},
        contract_sha256=ENGINE_CONTRACT_DIGEST,
    )
    if {
        "status": materialized.get("status"),
        "pipelineFactoryDigest": materialized.get("pipelineFactoryDigest"),
        "backendId": materialized.get("backendId"),
        "pipelineFingerprint": materialized.get("pipelineFingerprint"),
    } != {
        "status": expected_owner_identity["status"],
        "pipelineFactoryDigest": expected_owner_identity["pipelineFactoryDigest"],
        "backendId": expected_owner_identity["backendId"],
        "pipelineFingerprint": expected_owner_identity["pipelineFingerprint"],
    }:
        raise FixedProducerError("selected_engine_identity_mismatch")
    return {
        "status": expected_owner_identity["status"],
        "backend_id": expected_owner_identity["backendId"],
        "factory_source_digest": FACTORY_SOURCE_DIGEST,
        "contract_source_digest": ENGINE_CONTRACT_DIGEST,
        "research_decision_source_digest": RESEARCH_DECISION_SOURCE_DIGEST,
        "pipeline_factory_digest": expected_owner_identity["pipelineFactoryDigest"],
        "pipeline_fingerprint": expected_owner_identity["pipelineFingerprint"],
        "research_decision_digest": expected_owner_identity[
            "researchDecisionDigest"
        ],
    }

def load_fixed_producer_binding(path: Path = DEFAULT_BINDING_PATH) -> FixedProducerBinding:
    payload = _read_stable_file(
        path,
        maximum=MAX_BINDING_BYTES,
        binding_trust=True,
    )
    try:
        raw = loads_canonical_json_bytes(payload)
    except (UnicodeDecodeError, ValueError) as exc:
        raise FixedProducerError("binding_not_canonical") from exc
    value = _exact_mapping(raw, _BINDING_FIELDS, "binding_fields_invalid")
    if value.get("schema_version") != "kwrag-fixed-producer-binding-v1":
        raise FixedProducerError("binding_schema_invalid")
    enabled = value.get("enabled")
    if not isinstance(enabled, bool):
        raise FixedProducerError("binding_enabled_invalid")
    mount_root = _absolute_posix(value.get("mount_root"))
    manifest_relative = _safe_relative(value.get("index_manifest_relative"))
    manifest_digest = value.get("index_manifest_digest")
    if not is_sha256(manifest_digest):
        raise FixedProducerError("binding_manifest_digest_invalid")
    operation_receipt_path = _absolute_posix(value.get("operation_receipt_path"))
    producer_receipt_path = _absolute_posix(value.get("producer_receipt_path"))
    if operation_receipt_path == producer_receipt_path:
        raise FixedProducerError("binding_receipt_paths_invalid")
    for receipt_path in (operation_receipt_path, producer_receipt_path):
        try:
            receipt_path.relative_to(mount_root)
        except ValueError:
            pass
        else:
            raise FixedProducerError("binding_receipt_inside_mount")
    max_concurrent = _integer(value.get("max_concurrent"), minimum=1, maximum=64)

    expected_engine = _packaged_engine_identity()
    engine = _exact_mapping(
        value.get("selected_engine"),
        _ENGINE_IDENTITY_FIELDS,
        "binding_engine_fields_invalid",
    )
    if dict(engine) != expected_engine:
        raise FixedProducerError("binding_engine_identity_mismatch")

    corpora_raw = value.get("corpora")
    if not isinstance(corpora_raw, Mapping) or not 1 <= len(corpora_raw) <= 512:
        raise FixedProducerError("binding_corpora_invalid")
    corpora: dict[str, CorpusBinding] = {}
    database_paths: set[str] = set()
    source_paths: set[str] = set()
    for raw_corpus, raw_spec in sorted(corpora_raw.items()):
        corpus = _bounded_text(raw_corpus, maximum=256)
        spec = _exact_mapping(
            raw_spec,
            _CORPUS_BINDING_FIELDS,
            "binding_corpus_fields_invalid",
        )
        database_relative = _safe_relative(spec.get("database_relative"))
        source_relative = _safe_relative(spec.get("source_snapshot_relative"))
        if (
            database_relative in database_paths
            or source_relative in source_paths
            or database_relative == source_relative
        ):
            raise FixedProducerError("binding_corpus_paths_reused")
        database_paths.add(database_relative)
        source_paths.add(source_relative)
        digests = {
            field: spec.get(field)
            for field in (
                "database_sha256",
                "source_snapshot_digest",
                "authority_receipt_digest",
            )
        }
        if any(not is_sha256(item) for item in digests.values()):
            raise FixedProducerError("binding_corpus_digest_invalid")
        corpora[corpus] = CorpusBinding(
            database_relative=database_relative,
            database_sha256=digests["database_sha256"],
            source_snapshot_relative=source_relative,
            source_snapshot_digest=digests["source_snapshot_digest"],
            authority_receipt_digest=digests["authority_receipt_digest"],
        )
    return FixedProducerBinding(
        enabled=enabled,
        mount_root=mount_root,
        index_manifest_relative=manifest_relative,
        index_manifest_digest=manifest_digest,
        operation_receipt_path=operation_receipt_path,
        producer_receipt_path=producer_receipt_path,
        max_concurrent=max_concurrent,
        engine_identity=expected_engine,
        corpora=corpora,
        digest=_sha256_bytes(payload),
    )


def load_fixed_producer_request(payload: bytes) -> dict[str, Any]:
    if not isinstance(payload, bytes) or not 1 <= len(payload) <= MAX_STDIN_BYTES:
        raise FixedProducerError("request_size_invalid", exit_status=2)
    try:
        raw = loads_canonical_json_bytes(payload)
    except (UnicodeDecodeError, ValueError) as exc:
        raise FixedProducerError("request_not_canonical", exit_status=2) from exc
    if not isinstance(raw, Mapping) or set(raw) != _REQUEST_FIELDS:
        raise FixedProducerError("request_fields_invalid", exit_status=2)
    value = raw
    if value.get("schema_version") != "kwrag-slot-search-request-v1":
        raise FixedProducerError("request_schema_invalid", exit_status=2)
    query = value.get("query")
    if (
        not isinstance(query, str)
        or not 1 <= len(query) <= 4_000
        or not query.strip()
    ):
        raise FixedProducerError("request_query_invalid", exit_status=2)
    for field in ("request_id", "operation_id"):
        item = value.get(field)
        if not isinstance(item, str) or not 1 <= len(item) <= 128:
            raise FixedProducerError("request_correlation_invalid", exit_status=2)
    run_id = value.get("run_id")
    if run_id is not None and (
        not isinstance(run_id, str) or not 1 <= len(run_id) <= 128
    ):
        raise FixedProducerError("request_correlation_invalid", exit_status=2)
    attempt = value.get("attempt")
    max_results = value.get("max_results")
    if (
        isinstance(attempt, bool)
        or not isinstance(attempt, int)
        or not 1 <= attempt <= 16
        or isinstance(max_results, bool)
        or not isinstance(max_results, int)
        or not 1 <= max_results <= 10
    ):
        raise FixedProducerError("request_integer_invalid", exit_status=2)
    corpus = value.get("corpus")
    if corpus is not None and (
        not isinstance(corpus, str) or not 1 <= len(corpus) <= 256
    ):
        raise FixedProducerError("request_corpus_invalid", exit_status=2)
    return dict(value)


def _manifest_files(scope: SlotIndexScope, corpus: str) -> dict[str, str]:
    rooms = scope.manifest.raw.get("rooms")
    entry = rooms.get(corpus) if isinstance(rooms, Mapping) else None
    files = entry.get("files") if isinstance(entry, Mapping) else None
    if not isinstance(files, list):
        raise FixedProducerError("manifest_corpus_invalid")
    output: dict[str, str] = {}
    for raw in files:
        if not isinstance(raw, Mapping):
            raise FixedProducerError("manifest_corpus_invalid")
        path = raw.get("path")
        digest = raw.get("sha256")
        if not isinstance(path, str) or not is_sha256(digest) or path in output:
            raise FixedProducerError("manifest_corpus_invalid")
        output[path] = digest
    return output


class FixedFtsSearchPipeline:
    def __init__(self, scope: SlotIndexScope, binding: FixedProducerBinding):
        if set(scope.available_rooms) != set(binding.corpora):
            raise FixedProducerError("binding_manifest_corpora_mismatch")
        expected_snapshot = _sha256_bytes(
            canonical_json_bytes(
                {
                    corpus: binding.corpora[corpus].source_snapshot_digest
                    for corpus in sorted(binding.corpora)
                }
            )
        )
        if scope.manifest.corpus_snapshot != expected_snapshot:
            raise FixedProducerError("manifest_source_snapshot_mismatch")
        self._engines: dict[str, selected_engine.FtsAttachmentPipeline] = {}
        self._binding = binding
        try:
            for corpus in sorted(binding.corpora):
                spec = binding.corpora[corpus]
                declared = _manifest_files(scope, corpus)
                if (
                    declared.get(spec.database_relative) != spec.database_sha256
                    or declared.get(spec.source_snapshot_relative)
                    != spec.source_snapshot_digest
                ):
                    raise FixedProducerError("binding_manifest_file_mismatch")
                database_path = resolve_mounted_path(
                    scope.index_root,
                    spec.database_relative,
                    kind="file",
                )
                source_path = resolve_mounted_path(
                    scope.index_root,
                    spec.source_snapshot_relative,
                    kind="file",
                )
                if (
                    _streaming_digest(database_path, maximum=MAX_DATABASE_BYTES)
                    != spec.database_sha256
                    or _streaming_digest(
                        source_path,
                        maximum=MAX_SOURCE_SNAPSHOT_BYTES,
                    )
                    != spec.source_snapshot_digest
                ):
                    raise FixedProducerError("bound_source_digest_mismatch")
                self._engines[corpus] = selected_engine.FtsAttachmentPipeline(
                    database_path,
                    {
                        "databaseSha256": spec.database_sha256,
                        "authority": {
                            "mode": "slot_local_read_only_nas",
                            "readOnlyObserved": True,
                            "receiptDigest": spec.authority_receipt_digest,
                        },
                        "sourceSnapshotDigest": spec.source_snapshot_digest,
                    },
                )
        except Exception:
            self.close()
            raise

    def close(self) -> None:
        for engine in self._engines.values():
            engine.close()
        self._engines.clear()

    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]:
        if (
            not isinstance(rooms, list)
            or not rooms
            or any(room not in self._engines for room in rooms)
            or isinstance(k, bool)
            or not isinstance(k, int)
            or not 1 <= k <= 10
        ):
            raise FixedProducerError("pipeline_scope_invalid")
        candidates: list[dict[str, Any]] = []
        for corpus in rooms:
            for raw in self._engines[corpus].search(query):
                if not isinstance(raw, Mapping) or set(raw) != {
                    "sourceIds",
                    "text",
                    "score",
                    "unitId",
                }:
                    raise FixedProducerError("selected_engine_result_invalid")
                source_ids = raw.get("sourceIds")
                text = raw.get("text")
                score = raw.get("score")
                unit_id = raw.get("unitId")
                if (
                    not isinstance(source_ids, list)
                    or not source_ids
                    or len(source_ids) > 100
                    or any(
                        not isinstance(source_id, str)
                        or len(source_id) > 256
                        for source_id in source_ids
                    )
                    or not isinstance(text, str)
                    or not isinstance(unit_id, str)
                    or not 1 <= len(unit_id) <= 1_024
                    or isinstance(score, bool)
                    or not isinstance(score, (int, float))
                    or not math.isfinite(float(score))
                ):
                    raise FixedProducerError("selected_engine_result_invalid")
                candidates.append(
                    {
                        "room": corpus,
                        "level": "turn",
                        "seg_id": unit_id,
                        "message_ids": list(source_ids),
                        "text": text,
                        "score": float(score),
                    }
                )
        candidates.sort(
            key=lambda item: (
                -item["score"],
                item["room"],
                item["seg_id"],
                tuple(item["message_ids"]),
            )
        )
        hits = candidates[:k]
        return {
            "hits": hits,
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": self._binding.engine_identity["backend_id"],
                "stages": [
                    {
                        "stage_id": "fts5_search",
                        "execution_scope": "slot_local",
                        "call_count": len(rooms),
                        "input_count": len(rooms),
                        "output_count": len(candidates),
                        "model": None,
                        "revision": self._binding.engine_identity[
                            "factory_source_digest"
                        ],
                    }
                ],
                "candidate_count": len(candidates),
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }


def _build_runtime(
    binding: FixedProducerBinding,
) -> tuple[Any, FixedFtsSearchPipeline]:
    pipeline_holder: list[FixedFtsSearchPipeline] = []

    def factory(scope: SlotIndexScope) -> FixedFtsSearchPipeline:
        pipeline = FixedFtsSearchPipeline(scope, binding)
        pipeline_holder.append(pipeline)
        return pipeline

    runtime = build_slot_runtime(
        SlotRuntimeSpec(
            mount_root=binding.mount_root,
            index_manifest_relative=binding.index_manifest_relative,
            index_manifest_digest=binding.index_manifest_digest,
            receipt_path=binding.operation_receipt_path,
            pipeline_fingerprint=binding.engine_identity["pipeline_fingerprint"],
            max_concurrent=binding.max_concurrent,
        ),
        pipeline_factory=factory,
    )
    if len(pipeline_holder) != 1:
        raise FixedProducerError("pipeline_factory_count_invalid")
    return runtime, pipeline_holder[0]


def _source_exchange_digest(
    *,
    binding: FixedProducerBinding,
    corpora: list[str],
    operation_receipt_digest: str,
    result_digest: str,
) -> str:
    source_exchange = {
        "schema_version": "kwrag-fixed-source-exchange-v1",
        "binding_digest": binding.digest,
        "index_manifest": binding.index_manifest_digest,
        "pipeline_fingerprint": binding.engine_identity["pipeline_fingerprint"],
        "operation_receipt_digest": operation_receipt_digest,
        "result_digest": result_digest,
        "sources": [
            {
                "corpus": corpus,
                "database_sha256": binding.corpora[corpus].database_sha256,
                "source_snapshot_digest": binding.corpora[
                    corpus
                ].source_snapshot_digest,
                "authority_receipt_digest": binding.corpora[
                    corpus
                ].authority_receipt_digest,
            }
            for corpus in corpora
        ],
    }
    return _sha256_bytes(canonical_json_bytes(source_exchange))


def _failure_receipt(
    *,
    binding: FixedProducerBinding,
    code: str,
    operation_receipt_digest: str,
    result_digest: str,
    source_exchange_digest: str,
    output_characters: int,
) -> None:
    ReceiptWriter(binding.producer_receipt_path).write(
        {
            "schema_version": "kwrag-fixed-producer-failure-receipt-v1",
            "status": "rejected",
            "code": code,
            "binding_digest": binding.digest,
            "index_manifest": binding.index_manifest_digest,
            "pipeline_fingerprint": binding.engine_identity[
                "pipeline_fingerprint"
            ],
            "operation_receipt_digest": operation_receipt_digest,
            "result_digest": result_digest,
            "source_exchange_digest": source_exchange_digest,
            "output_characters": output_characters,
        }
    )


def execute_fixed_producer(
    request_payload: bytes,
    *,
    binding_path: Path = DEFAULT_BINDING_PATH,
) -> FixedProducerExecution:
    request = load_fixed_producer_request(request_payload)
    binding = load_fixed_producer_binding(binding_path)
    if binding.enabled is not True:
        raise FixedProducerError("producer_disabled", exit_status=3)
    runtime = None
    pipeline = None
    try:
        runtime, pipeline = _build_runtime(binding)
        exchange = runtime.search_exchange(request)
        verified = verify_slot_search_exchange(
            request,
            exchange.response,
            exchange.operation_receipt,
            expected_index_manifest=binding.index_manifest_digest,
            expected_pipeline_fingerprint=binding.engine_identity[
                "pipeline_fingerprint"
            ],
            max_result_characters=MAX_CONSUMABLE_CHARACTERS,
        )
        corpora = exchange.operation_receipt.get("corpora")
        if (
            not isinstance(corpora, list)
            or not corpora
            or any(corpus not in binding.corpora for corpus in corpora)
        ):
            raise FixedProducerError("receipt_source_scope_invalid")
        source_digest = _source_exchange_digest(
            binding=binding,
            corpora=corpora,
            operation_receipt_digest=verified.operation_receipt_digest,
            result_digest=verified.result_digest,
        )
        consumable = {
            "schema_version": "kwrag-fixed-consumable-v1",
            "request_id": verified.request_id,
            "operation_id": verified.operation_id,
            "run_id": verified.run_id,
            "attempt": verified.attempt,
            "index_manifest": verified.index_manifest,
            "pipeline_fingerprint": verified.pipeline_fingerprint,
            "result_status": verified.result_status,
            "results": verified.results(),
        }
        consumable_digest = _sha256_bytes(canonical_json_bytes(consumable))
        placeholder_output = {
            "schema_version": "kwrag-fixed-producer-output-v1",
            "consumable": consumable,
            "linkage": {
                "operation_receipt_digest": verified.operation_receipt_digest,
                "result_digest": verified.result_digest,
                "source_exchange_digest": source_digest,
                "producer_receipt_digest": "sha256:" + "0" * 64,
            },
        }
        placeholder_bytes = canonical_json_bytes(placeholder_output)
        output_characters = len(placeholder_bytes.decode("utf-8"))
        if output_characters > MAX_CONSUMABLE_CHARACTERS:
            _failure_receipt(
                binding=binding,
                code="payload_budget_exceeded",
                operation_receipt_digest=verified.operation_receipt_digest,
                result_digest=verified.result_digest,
                source_exchange_digest=source_digest,
                output_characters=output_characters,
            )
            raise FixedProducerError("payload_budget_exceeded")
        producer_receipt = {
            "schema_version": "kwrag-fixed-producer-receipt-v1",
            "status": "verified",
            "binding_digest": binding.digest,
            "index_manifest": verified.index_manifest,
            "pipeline_fingerprint": verified.pipeline_fingerprint,
            "operation_receipt_digest": verified.operation_receipt_digest,
            "result_digest": verified.result_digest,
            "source_exchange_digest": source_digest,
            "consumable_payload_digest": consumable_digest,
            "result_status": verified.result_status,
            "result_count": verified.result_count,
            "output_characters": output_characters,
        }
        receipt_result = ReceiptWriter(binding.producer_receipt_path).write(
            producer_receipt
        )
        if receipt_result.status != "written" or receipt_result.digest is None:
            raise FixedProducerError("producer_receipt_unavailable")
        output = dict(placeholder_output)
        output["linkage"] = dict(placeholder_output["linkage"])
        output["linkage"]["producer_receipt_digest"] = receipt_result.digest
        output_bytes = canonical_json_bytes(output)
        if len(output_bytes.decode("utf-8")) != output_characters:
            raise FixedProducerError("payload_budget_identity_changed")
        verify_fixed_producer_output(
            output_bytes,
            producer_receipt,
            request=request,
            expected_binding_digest=binding.digest,
        )
        return FixedProducerExecution(
            output_bytes=output_bytes,
            operation_receipt=exchange.operation_receipt,
            producer_receipt=producer_receipt,
            binding_digest=binding.digest,
        )
    finally:
        if pipeline is not None:
            pipeline.close()


def verify_fixed_producer_output(
    output_payload: bytes,
    producer_receipt: Any,
    *,
    request: Mapping[str, Any],
    expected_binding_digest: str,
) -> list[dict[str, Any]]:
    if not isinstance(output_payload, bytes) or not is_sha256(
        expected_binding_digest
    ):
        raise FixedProducerError("producer_output_budget_or_identity_invalid")
    try:
        output_text = output_payload.decode("utf-8")
        raw = loads_canonical_json_bytes(output_payload)
    except (UnicodeDecodeError, ValueError) as exc:
        raise FixedProducerError("producer_output_not_canonical") from exc
    if len(output_text) > MAX_CONSUMABLE_CHARACTERS:
        raise FixedProducerError("producer_output_budget_or_identity_invalid")
    output = _exact_mapping(raw, _OUTPUT_FIELDS, "producer_output_fields_invalid")
    if output.get("schema_version") != "kwrag-fixed-producer-output-v1":
        raise FixedProducerError("producer_output_schema_invalid")
    consumable = _exact_mapping(
        output.get("consumable"),
        _CONSUMABLE_FIELDS,
        "producer_consumable_fields_invalid",
    )
    linkage = _exact_mapping(
        output.get("linkage"),
        _LINKAGE_FIELDS,
        "producer_linkage_fields_invalid",
    )
    receipt = _exact_mapping(
        producer_receipt,
        _PRODUCER_RECEIPT_FIELDS,
        "producer_receipt_fields_invalid",
    )
    if (
        receipt.get("schema_version") != "kwrag-fixed-producer-receipt-v1"
        or receipt.get("status") != "verified"
        or receipt.get("binding_digest") != expected_binding_digest
        or linkage.get("producer_receipt_digest")
        != _sha256_bytes(canonical_json_bytes(receipt))
    ):
        raise FixedProducerError("producer_receipt_binding_invalid")
    for field in (
        "operation_receipt_digest",
        "result_digest",
        "source_exchange_digest",
    ):
        if not is_sha256(linkage.get(field)) or linkage.get(field) != receipt.get(
            field
        ):
            raise FixedProducerError("producer_linkage_invalid")
    if consumable.get("schema_version") != "kwrag-fixed-consumable-v1":
        raise FixedProducerError("producer_consumable_schema_invalid")
    for field in ("request_id", "operation_id", "run_id", "attempt"):
        if consumable.get(field) != request.get(field):
            raise FixedProducerError("producer_correlation_invalid")
    if (
        consumable.get("index_manifest") != receipt.get("index_manifest")
        or consumable.get("pipeline_fingerprint")
        != receipt.get("pipeline_fingerprint")
        or consumable.get("result_status") != receipt.get("result_status")
        or receipt.get("output_characters")
        != len(output_payload.decode("utf-8"))
    ):
        raise FixedProducerError("producer_identity_invalid")
    results = consumable.get("results")
    if not isinstance(results, list) or len(results) > 10:
        raise FixedProducerError("producer_results_invalid")
    result_status = "hits" if results else "zero_hits"
    if (
        result_status != consumable.get("result_status")
        or len(results) != receipt.get("result_count")
        or _sha256_bytes(canonical_json_bytes(results))
        != linkage.get("result_digest")
        or _sha256_bytes(canonical_json_bytes(consumable))
        != receipt.get("consumable_payload_digest")
    ):
        raise FixedProducerError("producer_result_binding_invalid")
    return loads_canonical_json_bytes(canonical_json_bytes(results))


def _read_stdin() -> bytes:
    payload = sys.stdin.buffer.read(MAX_STDIN_BYTES + 1)
    if len(payload) > MAX_STDIN_BYTES:
        raise FixedProducerError("request_size_invalid", exit_status=2)
    return payload


def _write_error(code: str) -> None:
    sys.stderr.buffer.write(
        canonical_json_bytes(
            {
                "schema_version": "kwrag-fixed-producer-error-v1",
                "code": code,
            }
        )
    )
    sys.stderr.buffer.flush()


def main() -> int:
    if len(sys.argv) != 1:
        _write_error("arbitrary_argv_forbidden")
        return 2
    try:
        execution = execute_fixed_producer(_read_stdin())
    except FixedProducerError as exc:
        _write_error(exc.code)
        return exc.exit_status
    except OperationError as exc:
        _write_error(exc.code)
        return 4
    except (SlotRuntimeError, SlotConsumptionError):
        _write_error("verified_exchange_unavailable")
        return 4
    except (OSError, TypeError, ValueError):
        _write_error("producer_not_ready")
        return 4
    sys.stdout.buffer.write(execution.output_bytes)
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
