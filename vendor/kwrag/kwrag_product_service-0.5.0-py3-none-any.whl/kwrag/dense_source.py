"""Small source seam used by the dense indexer and search pipeline.

The mounted corpus is authoritative and may change normally.  Implementations
must therefore distinguish a stale index reference from an unavailable corpus:
the former may be skipped by a search, while the latter still fails the call.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence


@dataclass(frozen=True)
class SourceMessage:
    """One current mounted-corpus message used to build disposable segments."""

    room: str
    message_id: str
    user_id: str
    user_name: str
    sent_time: int
    text: str


class DenseSourceReferenceUnavailable(ValueError):
    """One indexed reference no longer names the current live source text."""


class DenseMessageSource(Protocol):
    source_kind: str
    stale_references_are_skipped: bool

    def message_snapshot(self) -> list[SourceMessage]: ...

    def resolve_references(
        self,
        *,
        room: str,
        references: Sequence[Mapping[str, Any]],
        expected_text_sha256: str,
    ) -> tuple[str, tuple[str, ...]]: ...

    def close(self) -> None: ...


__all__ = [
    "DenseMessageSource",
    "DenseSourceReferenceUnavailable",
    "SourceMessage",
]
