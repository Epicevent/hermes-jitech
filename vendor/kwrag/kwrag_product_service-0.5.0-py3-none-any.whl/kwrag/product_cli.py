"""Bounded JSON command transport for the product-native KWRAG surface.

The command name is the only argv input. Requests arrive as one bounded JSON
object on stdin and results leave as one canonical JSON object on stdout. No
shell, provider, prompt, query-generation, or artifact-admission policy lives
here; the module only invokes the existing product-owned Python APIs.
"""

from __future__ import annotations

import sys
from dataclasses import asdict
from typing import Any, BinaryIO, Sequence

from .jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from .operation import OperationError
from .product_contract import (
    PRODUCT_REQUEST_SCHEMA,
    ProductContractError,
    normalize_product_scope,
    normalize_product_search_request,
    product_source_adapter,
)
from .product_index import ProductIndexError, _runtime_layout
from .product_runtime import (
    ProductRuntimeError,
    build_index,
    index_status,
    open_product_runtime,
)


MAX_REQUEST_BYTES = 16 * 1024
_BUILD_FIELDS = frozenset(
    {
        "schema_version",
        "operation",
        "scope",
        "rebuild",
    }
)
_STATUS_FIELDS = frozenset({"schema_version", "operation", "scope"})
_SEARCH_FIELDS = frozenset(
    {
        "schema_version",
        "operation",
        "query",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "max_results",
        "scope",
    }
)


class _CliRequestError(ValueError):
    pass


def _read_request(stream: BinaryIO) -> dict[str, Any]:
    payload = stream.read(MAX_REQUEST_BYTES + 1)
    if (
        not isinstance(payload, bytes)
        or not payload
        or len(payload) > MAX_REQUEST_BYTES
    ):
        raise _CliRequestError
    try:
        value = loads_canonical_json_bytes(payload)
    except (UnicodeDecodeError, ValueError) as exc:
        raise _CliRequestError from exc
    if not isinstance(value, dict):
        raise _CliRequestError
    return value


def _write(stream: BinaryIO, value: dict[str, Any]) -> None:
    stream.write(canonical_json_bytes(value))


def _error(code: str) -> dict[str, Any]:
    return {
        "schema_version": "kwrag-product-cli-error-v1",
        "status": "error",
        "code": code,
    }


def _exact_fields(body: dict[str, Any], allowed: frozenset[str]) -> None:
    if set(body) - allowed:
        raise _CliRequestError


def _build_request(body: dict[str, Any]) -> dict[str, Any]:
    _exact_fields(body, _BUILD_FIELDS)
    try:
        scope = normalize_product_scope(body.get("scope"))
    except ProductContractError as exc:
        raise _CliRequestError from exc
    rebuild = body.get("rebuild", False)
    if not isinstance(rebuild, bool):
        raise _CliRequestError
    return build_index(scope=scope, rebuild=rebuild)


def _search_request(body: dict[str, Any]) -> dict[str, Any]:
    _exact_fields(body, _SEARCH_FIELDS)
    try:
        normalized = normalize_product_search_request(body)
    except ProductContractError as exc:
        raise _CliRequestError from exc
    layout = _runtime_layout()
    source_root = (
        product_source_adapter("kakao").package_root(layout.mount_root)
        if normalized.scope.sources == ("kakao",)
        else layout.mount_root
    )
    with open_product_runtime(
        source_root=source_root,
        workspace_root=layout.workspace_root,
        slot_namespace=layout.slot_namespace,
        socket_path=layout.socket_path,
        receipt_path=layout.workspace_root / "receipts" / "product-search.jsonl",
        gpu_receipt_path=layout.workspace_root / "receipts" / "gpu.jsonl",
    ) as runtime:
        exchange = runtime.search_exchange(body)
        return {
            "schema_version": "kwrag-product-cli-search-exchange-v1",
            "identity": asdict(runtime.identity),
            "response": exchange.response,
            "operation_receipt": exchange.operation_receipt,
        }


def _execute(body: dict[str, Any]) -> dict[str, Any]:
    if body.get("schema_version") != PRODUCT_REQUEST_SCHEMA:
        raise _CliRequestError
    operation = body.get("operation")
    if operation == "build_index":
        return _build_request(body)
    if operation == "index_status":
        _exact_fields(body, _STATUS_FIELDS)
        try:
            scope = normalize_product_scope(body.get("scope"))
        except ProductContractError as exc:
            raise _CliRequestError from exc
        return index_status(scope=scope)
    if operation == "search":
        return _search_request(body)
    raise _CliRequestError


def main(
    argv: Sequence[str] | None = None,
    *,
    stdin: BinaryIO | None = None,
    stdout: BinaryIO | None = None,
    stderr: BinaryIO | None = None,
) -> int:
    """Run one fixed product operation without interpreting shell input."""

    arguments = tuple(sys.argv[1:] if argv is None else argv)
    input_stream = sys.stdin.buffer if stdin is None else stdin
    output_stream = sys.stdout.buffer if stdout is None else stdout
    error_stream = sys.stderr.buffer if stderr is None else stderr
    if arguments:
        _write(error_stream, _error("arbitrary_argv_forbidden"))
        return 2
    try:
        result = _execute(_read_request(input_stream))
        _write(output_stream, result)
    except _CliRequestError:
        _write(error_stream, _error("invalid_request"))
        return 2
    except ProductIndexError:
        _write(error_stream, _error("index_operation_failed"))
        return 4
    except ProductRuntimeError:
        _write(error_stream, _error("runtime_unavailable"))
        return 4
    except OperationError:
        _write(error_stream, _error("search_failed"))
        return 4
    except Exception:
        _write(error_stream, _error("product_operation_failed"))
        return 4
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
