"""Root-owned binding adapter from one product slot to baseline D."""

from __future__ import annotations

import os
import re
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .dense_pipeline import SharedGpuDensePipeline
from .dense_release import D_PIPELINE_FINGERPRINT
from .jsonutil import loads_canonical_json_bytes
from .shared_gpu_transport import ContentFreeGpuJournal, UnixSharedGpuClient
from .slot_mount import SlotIndexScope


MAX_ADAPTER_BINDING_BYTES = 64 * 1024
_FIELDS = frozenset(
    {
        "schema_version",
        "enabled",
        "slot",
        "expected_uid",
        "expected_gid",
        "socket_path",
        "gpu_receipt_path",
        "deadline_ms",
        "candidate_pool",
        "pipeline_fingerprint",
    }
)


class DenseAdapterError(ValueError):
    pass


@dataclass(frozen=True)
class DenseAdapterSpec:
    enabled: bool
    slot: str
    expected_uid: int
    expected_gid: int
    socket_path: Path
    gpu_receipt_path: Path
    deadline_ms: int
    candidate_pool: int


def _absolute(value: Any, field: str) -> Path:
    if not isinstance(value, str) or not value or len(value) > 4_096:
        raise DenseAdapterError(f"{field}_invalid")
    path = PurePosixPath(value)
    if (
        not path.is_absolute()
        or path.as_posix() != value
        or "\\" in value
        or ":" in value
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise DenseAdapterError(f"{field}_invalid")
    return Path(value)


def _integer(value: Any, *, minimum: int, maximum: int, field: str) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= maximum
    ):
        raise DenseAdapterError(f"{field}_invalid")
    return value


def load_dense_adapter_spec(path: Path) -> DenseAdapterSpec:
    source = Path(path)
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(source, flags)
    except OSError as exc:
        raise DenseAdapterError("adapter_binding_unavailable") from exc
    chunks: list[bytes] = []
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size < 1
            or before.st_size > MAX_ADAPTER_BINDING_BYTES
            or before.st_uid not in {0, os.geteuid()}
            or stat.S_IMODE(before.st_mode) & 0o022
        ):
            raise DenseAdapterError("adapter_binding_identity_invalid")
        while True:
            block = os.read(descriptor, 16 * 1024)
            if not block:
                break
            chunks.append(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise DenseAdapterError("adapter_binding_changed")
    finally:
        os.close(descriptor)
    try:
        raw = loads_canonical_json_bytes(b"".join(chunks))
    except (UnicodeDecodeError, ValueError) as exc:
        raise DenseAdapterError("adapter_binding_not_canonical") from exc
    if not isinstance(raw, Mapping) or set(raw) != _FIELDS:
        raise DenseAdapterError("adapter_binding_fields_invalid")
    if (
        raw.get("schema_version") != "kwrag-dense-adapter-binding-v1"
        or raw.get("pipeline_fingerprint") != D_PIPELINE_FINGERPRINT
        or not isinstance(raw.get("enabled"), bool)
    ):
        raise DenseAdapterError("adapter_binding_identity_invalid")
    slot = raw.get("slot")
    if (
        not isinstance(slot, str)
        or re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", slot) is None
    ):
        raise DenseAdapterError("adapter_slot_invalid")
    return DenseAdapterSpec(
        enabled=bool(raw["enabled"]),
        slot=slot,
        expected_uid=_integer(
            raw.get("expected_uid"), minimum=0, maximum=2**31 - 1, field="uid"
        ),
        expected_gid=_integer(
            raw.get("expected_gid"), minimum=0, maximum=2**31 - 1, field="gid"
        ),
        socket_path=_absolute(raw.get("socket_path"), "socket_path"),
        gpu_receipt_path=_absolute(
            raw.get("gpu_receipt_path"), "gpu_receipt_path"
        ),
        deadline_ms=_integer(
            raw.get("deadline_ms"), minimum=1, maximum=60_000, field="deadline"
        ),
        candidate_pool=_integer(
            raw.get("candidate_pool"), minimum=1, maximum=32, field="candidate_pool"
        ),
    )


def build_bound_dense_pipeline(
    scope: SlotIndexScope,
    spec: DenseAdapterSpec,
) -> SharedGpuDensePipeline:
    if spec.enabled is not True:
        raise DenseAdapterError("dense_adapter_disabled")
    if os.geteuid() != spec.expected_uid or os.getegid() != spec.expected_gid:
        raise DenseAdapterError("dense_adapter_principal_mismatch")
    mount_root = scope.mount_root.resolve(strict=False)
    for path in (spec.socket_path, spec.gpu_receipt_path):
        try:
            path.resolve(strict=False).relative_to(mount_root)
        except ValueError:
            pass
        else:
            raise DenseAdapterError("dense_adapter_writable_path_inside_mount")
    client = UnixSharedGpuClient(
        socket_path=spec.socket_path,
        slot=spec.slot,
        principal=f"uid:{spec.expected_uid}",
        journal=ContentFreeGpuJournal(spec.gpu_receipt_path),
        deadline_ms=spec.deadline_ms,
    )
    return SharedGpuDensePipeline(scope, client, pool=spec.candidate_pool)
