"""Focused product-native index and Hermes search seam tests."""

from __future__ import annotations

import inspect
import json
import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

from kwrag.live_kakao import LiveKakaoSourceError
from kwrag.operation import OperationError, ReceiptWriteResult
from kwrag.product_index import (
    ProductIndexError,
    _ProductIndexLayout,
    _runtime_layout,
    _slot_root,
)
from kwrag.product_runtime import (
    ProductRuntime,
    build_index,
    index_status,
    open_kakao_product_runtime,
    open_product_runtime,
)
from kwrag.shared_gpu_core import (
    CallerIdentity,
    SharedGpuCore,
    SharedGpuCoreConfig,
)
from kwrag.shared_gpu_models import NonProductionDeterministicBackend
from kwrag.shared_gpu_transport import (
    ContentFreeGpuJournal,
    InProcessSharedGpuClient,
    SharedGpuTransportError,
)


def _write_package(root: Path, text: str) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "membership.json").write_text(
        json.dumps({"user_id": "7519030", "conversation_ids": ["room-a"]}),
        encoding="utf-8",
    )
    (root / "profile.json").write_text(
        json.dumps({"user_id": "7519030"}),
        encoding="utf-8",
    )
    database = root / "messages.sqlite"
    if database.exists():
        database.unlink()
    with closing(sqlite3.connect(database)) as connection:
        connection.execute(
            "CREATE TABLE messages("
            "conversation_id TEXT NOT NULL,message_id TEXT NOT NULL,"
            "user_id TEXT,user_name TEXT,sent_time INTEGER,plain_text TEXT)"
        )
        connection.execute(
            "INSERT INTO messages VALUES(?,?,?,?,?,?)",
            ("room-a", "message-1", "user-1", "owner", 1, text),
        )
        connection.commit()


class ProductIndexTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.root = Path(self.temp.name)
        self.mount = self.root / "nas_docs"
        self.package = self.mount / "kw" / "package"
        self.workspace = self.root / "workspace" / ".kwrag"
        self.workspace.mkdir(parents=True)
        _write_package(self.package, "live kakao dense evidence")
        self.layout = _ProductIndexLayout(
            mount_root=self.mount,
            workspace_root=self.workspace,
            socket_path=self.root / "unused.sock",
            slot_namespace="hermes",
            allow_nonproduction=True,
        )
        self.core = SharedGpuCore(
            NonProductionDeterministicBackend(8),
            SharedGpuCoreConfig(allow_nonproduction_backend=True),
        )
        self.core.start()
        uid = getattr(os, "geteuid", lambda: 0)()
        gid = getattr(os, "getegid", lambda: 0)()
        self.client = InProcessSharedGpuClient(
            core=self.core,
            caller=CallerIdentity(
                slot="hermes",
                principal=f"uid:{uid}",
                peer_uid=uid,
                peer_gid=gid,
            ),
            journal=ContentFreeGpuJournal(
                self.workspace / "receipts" / "gpu-test.jsonl"
            ),
        )

    def tearDown(self) -> None:
        self.core.shutdown(grace_seconds=1)
        self.temp.cleanup()

    def _build(self, **kwargs: object) -> dict:
        with (
            patch("kwrag.product_index._runtime_layout", return_value=self.layout),
            patch("kwrag.live_kakao._require_readonly", lambda _path: None),
            patch("kwrag.product_index._gpu_client", return_value=self.client),
        ):
            return build_index(**kwargs)

    def _status(self) -> dict:
        with (
            patch("kwrag.product_index._runtime_layout", return_value=self.layout),
            patch("kwrag.live_kakao._require_readonly", lambda _path: None),
        ):
            return index_status()

    def test_atomic_current_previous_and_no_double_workspace(self) -> None:
        first = self._build(scope="kakao")
        self.assertEqual(first["status"], "activated")
        pointer_path = self.workspace / "dense" / "hermes" / "current.json"
        self.assertTrue(pointer_path.is_file())
        self.assertFalse((self.workspace / ".kwrag").exists())
        ready = self._status()
        self.assertEqual(ready["status"], "ready")
        self.assertEqual(ready["active_index_id"], first["active_index_id"])
        self.assertEqual(self._build(scope="kakao")["status"], "already_built")
        self.assertEqual(self._build()["status"], "already_built")

        _write_package(self.package, "replacement after ordinary crawler rewrite")
        second = self._build(rebuild=True)
        self.assertEqual(second["status"], "activated")
        self.assertNotEqual(second["active_index_id"], first["active_index_id"])
        self.assertEqual(second["previous_index_id"], first["active_index_id"])
        pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
        self.assertEqual(pointer["current_release_id"], second["active_index_id"])
        self.assertEqual(pointer["previous_release_id"], first["active_index_id"])

    def test_retryable_source_failure_skips_and_preserves_active(self) -> None:
        first = self._build()
        pointer_path = self.workspace / "dense" / "hermes" / "current.json"
        before = pointer_path.read_bytes()
        with (
            patch("kwrag.product_index._runtime_layout", return_value=self.layout),
            patch(
                "kwrag.product_index.LiveKakaoPackageSource",
                side_effect=LiveKakaoSourceError("database_query_failed"),
            ),
        ):
            result = build_index(rebuild=True)
        self.assertEqual(result["status"], "source_skipped")
        self.assertEqual(result["source_attempts"], 3)
        self.assertEqual(result["active_index_id"], first["active_index_id"])
        self.assertEqual(pointer_path.read_bytes(), before)

    def test_gpu_build_failure_preserves_active(self) -> None:
        first = self._build()
        pointer_path = self.workspace / "dense" / "hermes" / "current.json"
        before = pointer_path.read_bytes()
        _write_package(self.package, "new source that requires another embedding")
        with patch.object(
            self.client,
            "embed_corpus",
            side_effect=SharedGpuTransportError(
                "shared_gpu_transport_unavailable",
                retryable=True,
            ),
        ):
            result = self._build(rebuild=True)
        self.assertEqual(result["status"], "build_failed")
        self.assertEqual(result["active_index_id"], first["active_index_id"])
        self.assertEqual(pointer_path.read_bytes(), before)

    def test_public_selector_layout_and_signatures(self) -> None:
        signature = inspect.signature(build_index)
        self.assertEqual(list(signature.parameters), ["scope", "exclude", "rebuild"])
        self.assertIsNone(signature.parameters["scope"].default)
        self.assertIsNone(signature.parameters["exclude"].default)
        self.assertIs(signature.parameters["rebuild"].default, False)
        self.assertEqual(list(inspect.signature(index_status).parameters), [])
        with self.assertRaisesRegex(ProductIndexError, "scope_unsupported"):
            self._build(scope="kw")
        with self.assertRaisesRegex(ProductIndexError, "scope_unsupported"):
            self._build(scope=["kakao", "room-a"])
        self.assertEqual(
            self._build(exclude="kakao")["status"],
            "no_sources_selected",
        )

        with patch.dict(
            os.environ,
            {
                "JITECH_KWRAG_SHARED_GPU_SOCKET": "/run/custom/kwrag.sock",
                "JITECH_KWRAG_SLOT_NAMESPACE": "hermes-ui",
            },
        ):
            layout = _runtime_layout()
        self.assertEqual(layout.mount_root, Path("/workspace/nas_docs"))
        self.assertEqual(layout.workspace_root, Path("/workspace/.kwrag"))
        self.assertEqual(layout.socket_path, Path("/run/custom/kwrag.sock"))
        self.assertEqual(layout.slot_namespace, "hermes-ui")
        self.assertEqual(
            _slot_root(layout.workspace_root, layout),
            Path("/workspace/.kwrag/dense/hermes-ui"),
        )
        self.assertEqual(
            list(inspect.signature(open_product_runtime).parameters),
            [
                "source_root",
                "workspace_root",
                "slot_namespace",
                "socket_path",
                "receipt_path",
                "gpu_receipt_path",
            ],
        )

    def test_receipt_failure_is_observability_only(self) -> None:
        with patch(
            "kwrag.operation.ReceiptWriter.write",
            return_value=ReceiptWriteResult(status="unavailable", digest=None),
        ):
            result = self._build()
        self.assertEqual(result["status"], "activated")
        self.assertEqual(result["receipt_status"], "unavailable")
        self.assertIsNone(result["embedding_operation_receipt_digest"])
        self.assertTrue(
            (self.workspace / "dense" / "hermes" / "current.json").is_file()
        )

    def test_preferred_search_api_runs_dense_and_rerank(self) -> None:
        built = self._build()
        with (
            patch("kwrag.live_kakao._require_readonly", lambda _path: None),
            patch("kwrag.product_runtime._gpu_client", return_value=self.client),
            patch(
                "kwrag.product_runtime._PRODUCT_ALLOW_NONPRODUCTION_RELEASE",
                True,
            ),
            open_product_runtime(
                source_root=self.package,
                workspace_root=self.workspace,
                slot_namespace="hermes",
                socket_path=self.root / "unused.sock",
                receipt_path=self.workspace / "receipts" / "search.jsonl",
                gpu_receipt_path=self.workspace / "receipts" / "search-gpu.jsonl",
            ) as runtime,
        ):
            exchange = runtime.search_exchange(
                {
                    "schema_version": "kwrag-slot-search-request-v1",
                    "query": "live kakao dense evidence",
                    "max_results": 2,
                }
            )
            with self.assertRaises(OperationError) as rejected:
                runtime.search_exchange(
                    {
                        "schema_version": "kwrag-slot-search-request-v1",
                        "query": "live kakao dense evidence",
                        "max_results": 2,
                        "corpus": ["room-a", "room-b"],
                    }
                )
            self.assertEqual(rejected.exception.code, "invalid_request")
        self.assertIsInstance(runtime, ProductRuntime)
        self.assertEqual(runtime.identity.active_index_id, built["active_index_id"])
        self.assertFalse(hasattr(runtime.identity, "index_manifest"))
        self.assertEqual(exchange.response["result_status"], "hits")
        self.assertNotIn(
            "live kakao dense evidence",
            json.dumps(exchange.operation_receipt, sort_keys=True),
        )
        self.assertEqual(
            [
                stage["stage_id"]
                for stage in exchange.operation_receipt["pipeline_evidence"]["stages"]
            ],
            ["query_embedding", "dense_index_search", "candidate_rerank"],
        )

        with (
            patch("kwrag.live_kakao._require_readonly", lambda _path: None),
            patch("kwrag.product_runtime._gpu_client", return_value=self.client),
        ):
            compatibility = open_kakao_product_runtime(
                package_root=self.package,
                workspace_root=self.workspace,
                slot_namespace="hermes",
                socket_path=self.root / "unused.sock",
                receipt_path=self.workspace / "receipts" / "compat.jsonl",
                gpu_receipt_path=self.workspace / "receipts" / "compat-gpu.jsonl",
                _allow_nonproduction_release=True,
            )
            compatibility.close()
        self.assertIsInstance(compatibility, ProductRuntime)


if __name__ == "__main__":
    unittest.main()
