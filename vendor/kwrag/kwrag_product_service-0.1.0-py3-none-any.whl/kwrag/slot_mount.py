"""Backend-neutral confinement to one slot-visible NAS mount.

This module does not infer authorization from a slot id, a grant export, or a
token.  The caller supplies the root already mounted into one slot, and every
index path must resolve beneath that root.  The mount itself is the visibility
boundary; index manifests add integrity, not additional access.
"""

from __future__ import annotations

import hashlib
import os
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Sequence

from .jsonutil import loads_strict_json
from .manifest import IndexManifest, ManifestError, load_and_verify_manifest


class SlotMountError(ValueError):
    pass


@dataclass(frozen=True)
class MountedFileIdentity:
    path: Path
    device: int
    inode: int
    mode: int
    links: int
    size: int
    mtime_ns: int


def _file_identity(path: Path) -> MountedFileIdentity:
    try:
        metadata = Path(path).lstat()
    except OSError as exc:
        raise SlotMountError("mounted file identity is unavailable") from exc
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
        raise SlotMountError("mounted file identity is not a regular file")
    if metadata.st_nlink < 1:
        raise SlotMountError("mounted file link identity is invalid")
    return MountedFileIdentity(
        path=Path(path),
        device=metadata.st_dev,
        inode=metadata.st_ino,
        mode=metadata.st_mode,
        links=metadata.st_nlink,
        size=metadata.st_size,
        mtime_ns=metadata.st_mtime_ns,
    )


def _read_mounted_file(
    path: Path,
    *,
    digest_only: bool,
) -> tuple[bytes | None, str, MountedFileIdentity]:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise SlotMountError("mounted file could not be opened safely") from exc
    digest = hashlib.sha256()
    payload = None if digest_only else bytearray()
    try:
        before = os.fstat(descriptor)
        if stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode):
            raise SlotMountError("mounted file identity is not a regular file")
        if before.st_nlink < 1:
            raise SlotMountError("mounted file link identity is invalid")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            digest.update(block)
            if payload is not None:
                payload.extend(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_nlink,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise SlotMountError("mounted file identity changed while reading")
    finally:
        os.close(descriptor)
    identity = MountedFileIdentity(
        path=Path(path),
        device=after.st_dev,
        inode=after.st_ino,
        mode=after.st_mode,
        links=after.st_nlink,
        size=after.st_size,
        mtime_ns=after.st_mtime_ns,
    )
    return (
        bytes(payload) if payload is not None else None,
        "sha256:" + digest.hexdigest(),
        identity,
    )


def _require_readonly_mount(path: Path) -> None:
    statvfs = getattr(os, "statvfs", None)
    readonly_flag = getattr(os, "ST_RDONLY", None)
    if statvfs is None or readonly_flag is None:
        raise SlotMountError("slot mount read-only state cannot be attested")
    try:
        flags = statvfs(path).f_flag
    except OSError as exc:
        raise SlotMountError("slot mount read-only state is unavailable") from exc
    if not flags & readonly_flag:
        raise SlotMountError("slot mount must be read-only")


def _relative_posix(value: str | Path, field: str) -> PurePosixPath:
    raw = str(value)
    path = PurePosixPath(raw)
    if (
        not raw
        or raw.startswith("/")
        or "\\" in raw
        or ":" in raw
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise SlotMountError(f"{field} must be a safe mount-relative POSIX path")
    return path


def _root(path: Path) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise SlotMountError("slot mount root must be absolute")
    try:
        metadata = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise SlotMountError("slot mount root is unavailable") from exc
    if supplied.is_symlink() or not supplied.is_dir():
        raise SlotMountError("slot mount root must be a real directory")
    if resolved != supplied.absolute():
        raise SlotMountError("slot mount root cannot traverse a symlink")
    if not os.path.isdir(resolved) or metadata.st_nlink < 1:
        raise SlotMountError("slot mount root identity is invalid")
    return resolved


def resolve_mounted_path(
    mount_root: Path,
    relative: str | Path,
    *,
    kind: str,
) -> Path:
    """Resolve a file or directory without allowing a symlink or root escape."""

    if kind not in {"file", "directory"}:
        raise ValueError("kind must be file or directory")
    root = _root(mount_root)
    rel = _relative_posix(relative, "mounted path")
    current = root
    for part in rel.parts:
        current = current / part
        try:
            current.lstat()
        except OSError as exc:
            raise SlotMountError("mounted path is unavailable") from exc
        if current.is_symlink():
            raise SlotMountError("mounted path cannot traverse a symlink")
    try:
        resolved = current.resolve(strict=True)
        resolved.relative_to(root)
    except (OSError, ValueError) as exc:
        raise SlotMountError("mounted path escapes the slot mount root") from exc
    if kind == "file" and not resolved.is_file():
        raise SlotMountError("mounted path is not a regular file")
    if kind == "directory" and not resolved.is_dir():
        raise SlotMountError("mounted path is not a directory")
    return resolved


@dataclass(frozen=True)
class SlotIndexScope:
    mount_root: Path
    index_root: Path
    manifest_path: Path
    manifest: IndexManifest
    mount_device: int
    mount_inode: int
    file_identities: tuple[MountedFileIdentity, ...]
    readonly_required: bool = False

    @property
    def available_rooms(self) -> tuple[str, ...]:
        return tuple(sorted(self.manifest.rooms))

    def select_rooms(self, requested: Sequence[str] | None = None) -> list[str]:
        """Return only rooms already present in this mounted index manifest."""

        available = set(self.manifest.rooms)
        if requested is None:
            return sorted(available)
        if isinstance(requested, (str, bytes)):
            raise SlotMountError("requested rooms must be a sequence of room ids")
        normalized = [str(room).strip() for room in requested]
        if not normalized or any(not room for room in normalized):
            raise SlotMountError("requested rooms contain an empty room id")
        if len(normalized) != len(set(normalized)):
            raise SlotMountError("requested rooms contain a duplicate room id")
        unknown = set(normalized) - available
        if unknown:
            raise SlotMountError("requested room is outside the slot-mounted index")
        return normalized

    def assert_current(self) -> None:
        """Fail if the mounted root or verified snapshot objects were replaced."""

        root = _root(self.mount_root)
        if self.readonly_required:
            _require_readonly_mount(root)
        root_metadata = root.lstat()
        if (
            root_metadata.st_dev != self.mount_device
            or root_metadata.st_ino != self.mount_inode
        ):
            raise SlotMountError("slot mount root identity drifted")
        for expected in self.file_identities:
            current = _file_identity(expected.path)
            if current != expected:
                raise SlotMountError("slot-mounted snapshot identity drifted")


def load_slot_index_scope(
    mount_root: Path,
    manifest_relative: str | Path,
    *,
    require_readonly: bool = False,
) -> SlotIndexScope:
    """Load an index whose manifest and referenced files are inside one mount."""

    if not isinstance(require_readonly, bool):
        raise SlotMountError("require_readonly must be a boolean")
    root = _root(mount_root)
    if require_readonly:
        _require_readonly_mount(root)
    manifest_rel = _relative_posix(manifest_relative, "index manifest")
    manifest_path = resolve_mounted_path(root, manifest_rel, kind="file")
    index_root = manifest_path.parent
    index_rel = PurePosixPath(index_root.relative_to(root).as_posix())
    manifest_bytes, _manifest_file_digest, manifest_identity = _read_mounted_file(
        manifest_path,
        digest_only=False,
    )
    try:
        raw_manifest = loads_strict_json((manifest_bytes or b"").decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise SlotMountError("mounted index manifest is invalid") from exc
    resolved_identities: dict[Path, MountedFileIdentity] = {
        manifest_path: manifest_identity,
    }

    def verify_manifest_file(relative: str, expected_digest: str) -> None:
        file_rel = index_rel / _relative_posix(relative, "index file")
        resolved = resolve_mounted_path(root, file_rel, kind="file")
        _payload, actual_digest, identity = _read_mounted_file(
            resolved,
            digest_only=True,
        )
        if actual_digest != expected_digest:
            raise ManifestError("index digest mismatch")
        resolved_identities[resolved] = identity

    try:
        manifest = load_and_verify_manifest(
            manifest_path,
            index_root,
            verify_file=verify_manifest_file,
            raw_manifest=raw_manifest,
        )
    except ManifestError as exc:
        raise SlotMountError("mounted index manifest verification failed") from exc

    root_metadata = root.lstat()
    identities = tuple(resolved_identities[path] for path in sorted(resolved_identities))
    scope = SlotIndexScope(
        mount_root=root,
        index_root=index_root,
        manifest_path=manifest_path,
        manifest=manifest,
        mount_device=root_metadata.st_dev,
        mount_inode=root_metadata.st_ino,
        file_identities=identities,
        readonly_required=require_readonly,
    )
    scope.assert_current()
    return scope
