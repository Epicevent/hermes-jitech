"""Backend-neutral validation seam for an optional product-owned consumer.

The caller still decides whether retrieval runs and whether validated evidence
is consumed.  This module selects no backend, invocation trigger, prompt shape,
retry policy, or fallback policy.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from typing import Any, Mapping

from .jsonutil import canonical_json_bytes, is_sha256, loads_strict_json


class SlotConsumptionError(ValueError):
    """The search exchange is not safe to record as consumed evidence."""


_REQUEST_FIELDS = frozenset(
    {
        "schema_version",
        "query",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "max_results",
        "corpus",
    }
)
_RESPONSE_FIELDS = frozenset(
    {
        "schema_version",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "authorization_basis",
        "index_manifest",
        "pipeline_fingerprint",
        "result_digest",
        "result_status",
        "operation_receipt",
        "results",
        "duration_ms",
    }
)
_RECEIPT_FIELDS = frozenset(
    {
        "schema_version",
        "recorded_at",
        "operation_id",
        "operation_id_source",
        "request_id",
        "run_id",
        "attempt",
        "authorization_basis",
        "corpora",
        "query_chars",
        "requested_max_results",
        "index_manifest",
        "pipeline_fingerprint",
        "execution_status",
        "result_status",
        "duration_ms",
        "result_count",
        "result_digest",
        "pipeline_evidence",
        "provider_billing",
        "full_economic_cost",
        "error_code",
    }
)
_RESULT_FIELDS = frozenset(
    {"id", "corpus", "path", "title", "snippet", "score", "source_ids"}
)
_PIPELINE_FIELDS = frozenset(
    {
        "status",
        "schema_version",
        "backend_id",
        "stages",
        "candidate_count",
        "returned_count",
        "corpus_count",
        "data_boundary",
    }
)
_STAGE_FIELDS = frozenset(
    {
        "stage_id",
        "execution_scope",
        "call_count",
        "input_count",
        "output_count",
        "model",
        "revision",
    }
)
_DATA_BOUNDARY_FIELDS = frozenset(
    {
        "bytes_sent_outside_slot",
        "external_persistence",
        "persistence_receipt_digest",
    }
)
_COST_FIELDS = frozenset({"status", "amount", "currency", "reason"})


@dataclass(frozen=True)
class VerifiedSlotSearchExchange:
    """Immutable identities plus canonical result bytes after validation."""

    request_id: str
    operation_id: str
    run_id: str | None
    attempt: int
    index_manifest: str
    pipeline_fingerprint: str
    result_status: str
    result_digest: str
    operation_receipt_digest: str
    result_count: int
    result_characters: int
    canonical_results: bytes

    def results(self) -> list[dict[str, Any]]:
        """Return a fresh parsed copy of the validated untrusted evidence."""

        parsed = loads_strict_json(self.canonical_results.decode("utf-8"))
        if not isinstance(parsed, list):  # defensive; construction guarantees this
            raise SlotConsumptionError("validated result bytes are not a list")
        return parsed


def _integer(value: Any, *, minimum: int = 0, maximum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise SlotConsumptionError("integer field is invalid")
    if maximum is not None and value > maximum:
        raise SlotConsumptionError("integer field exceeds its bound")
    return value


def _bounded_text(value: Any, *, minimum: int = 1, maximum: int) -> str:
    if not isinstance(value, str) or not minimum <= len(value) <= maximum:
        raise SlotConsumptionError("text field is invalid")
    return value


def _exact_fields(value: Any, expected: frozenset[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != expected:
        raise SlotConsumptionError(f"{label} fields are invalid")
    return value


def _validate_request(request: Any) -> tuple[str, str, str | None, int, int, str | None, str]:
    value = _exact_fields(request, _REQUEST_FIELDS, "request")
    if value.get("schema_version") != "kwrag-slot-search-request-v1":
        raise SlotConsumptionError("request schema is invalid")
    query = _bounded_text(value.get("query"), maximum=4_000).strip()
    if not query:
        raise SlotConsumptionError("request query is empty")
    request_id = _bounded_text(value.get("request_id"), maximum=128)
    operation_id = _bounded_text(value.get("operation_id"), maximum=128)
    run_id = value.get("run_id")
    if run_id is not None:
        run_id = _bounded_text(run_id, maximum=128)
    attempt = _integer(value.get("attempt"), minimum=1, maximum=16)
    max_results = _integer(value.get("max_results"), minimum=1, maximum=10)
    corpus = value.get("corpus")
    if corpus is not None:
        corpus = _bounded_text(corpus, maximum=256)
    return request_id, operation_id, run_id, attempt, max_results, corpus, query


def _validate_results(value: Any, *, max_results: int, max_chars: int) -> tuple[bytes, int]:
    if not isinstance(value, list) or len(value) > max_results:
        raise SlotConsumptionError("result list is invalid")
    total_characters = 0
    for item in value:
        result = _exact_fields(item, _RESULT_FIELDS, "result")
        _bounded_text(result.get("id"), maximum=8_000)
        _bounded_text(result.get("corpus"), maximum=256)
        _bounded_text(result.get("path"), maximum=8_000)
        _bounded_text(result.get("title"), minimum=0, maximum=8_000)
        snippet = _bounded_text(result.get("snippet"), minimum=0, maximum=8_000)
        score = result.get("score")
        if isinstance(score, bool) or not isinstance(score, (int, float)):
            raise SlotConsumptionError("result score is invalid")
        if not math.isfinite(float(score)):
            raise SlotConsumptionError("result score is not finite")
        source_ids = result.get("source_ids")
        if not isinstance(source_ids, list) or len(source_ids) > 100:
            raise SlotConsumptionError("result source_ids are invalid")
        for source_id in source_ids:
            _bounded_text(source_id, minimum=0, maximum=256)
        total_characters += len(snippet)
    if total_characters > max_chars:
        raise SlotConsumptionError("result character budget is exceeded")
    try:
        canonical = canonical_json_bytes(value)
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise SlotConsumptionError("results are not canonicalizable") from exc
    return canonical, total_characters


def _validate_pipeline_evidence(
    value: Any, *, result_count: int, corpus_count: int
) -> bool:
    evidence = _exact_fields(value, _PIPELINE_FIELDS, "pipeline evidence")
    if (
        evidence.get("status") != "available"
        or evidence.get("schema_version") != "kwrag-slot-pipeline-evidence-v1"
    ):
        raise SlotConsumptionError("pipeline evidence is not fully attested")
    _bounded_text(evidence.get("backend_id"), maximum=128)
    candidate_count = _integer(evidence.get("candidate_count"))
    if candidate_count < result_count:
        raise SlotConsumptionError("pipeline candidate count is inconsistent")
    if _integer(evidence.get("returned_count")) != result_count:
        raise SlotConsumptionError("pipeline result count is inconsistent")
    if _integer(evidence.get("corpus_count"), minimum=1) != corpus_count:
        raise SlotConsumptionError("pipeline corpus count is inconsistent")

    stages = evidence.get("stages")
    if not isinstance(stages, list) or not 1 <= len(stages) <= 16:
        raise SlotConsumptionError("pipeline stages are invalid")
    stage_ids: set[str] = set()
    has_external_stage = False
    for item in stages:
        stage = _exact_fields(item, _STAGE_FIELDS, "pipeline stage")
        stage_id = _bounded_text(stage.get("stage_id"), maximum=64)
        if stage_id in stage_ids:
            raise SlotConsumptionError("pipeline stage ids are not unique")
        stage_ids.add(stage_id)
        scope = stage.get("execution_scope")
        if scope not in {"slot_local", "shared_stateless"}:
            raise SlotConsumptionError("pipeline execution scope is invalid")
        has_external_stage = has_external_stage or scope == "shared_stateless"
        for field in ("call_count", "input_count", "output_count"):
            _integer(stage.get(field))
        for field in ("model", "revision"):
            field_value = stage.get(field)
            if field_value is not None:
                _bounded_text(field_value, maximum=256)

    boundary = _exact_fields(
        evidence.get("data_boundary"), _DATA_BOUNDARY_FIELDS, "data boundary"
    )
    bytes_sent = _integer(boundary.get("bytes_sent_outside_slot"))
    persistence = boundary.get("external_persistence")
    persistence_digest = boundary.get("persistence_receipt_digest")
    if has_external_stage:
        if (
            bytes_sent <= 0
            or persistence != "attested_none"
            or not is_sha256(persistence_digest)
        ):
            raise SlotConsumptionError("shared-stateless persistence is not attested")
    elif bytes_sent != 0 or persistence != "not_applicable" or persistence_digest is not None:
        raise SlotConsumptionError("slot-local data boundary is inconsistent")
    return has_external_stage


def _validate_cost(value: Any, *, expected_status: str, label: str) -> None:
    cost = _exact_fields(value, _COST_FIELDS, label)
    if (
        cost.get("status") != expected_status
        or cost.get("amount") is not None
        or cost.get("currency") is not None
    ):
        raise SlotConsumptionError(f"{label} status is invalid")
    _bounded_text(cost.get("reason"), maximum=512)


def verify_slot_search_exchange(
    request: Any,
    response: Any,
    operation_receipt: Any,
    *,
    expected_index_manifest: str,
    expected_pipeline_fingerprint: str,
    max_result_characters: int,
) -> VerifiedSlotSearchExchange:
    """Bind a completed search exchange before a product records consumption.

    Validation is deliberately strict and fail-closed.  The returned results
    remain untrusted evidence; this function does not assemble a prompt or
    claim that the product actually consumed them.
    """

    if not is_sha256(expected_index_manifest) or not is_sha256(
        expected_pipeline_fingerprint
    ):
        raise SlotConsumptionError("expected runtime identity is invalid")
    max_chars = _integer(max_result_characters, minimum=0, maximum=80_000)
    (
        request_id,
        operation_id,
        run_id,
        attempt,
        max_results,
        requested_corpus,
        query,
    ) = _validate_request(request)
    response_value = _exact_fields(response, _RESPONSE_FIELDS, "response")
    receipt = _exact_fields(operation_receipt, _RECEIPT_FIELDS, "operation receipt")

    if response_value.get("schema_version") != "kwrag-slot-search-response-v1":
        raise SlotConsumptionError("response schema is invalid")
    if receipt.get("schema_version") != "kwrag-slot-search-operation-receipt-v1":
        raise SlotConsumptionError("operation receipt schema is invalid")

    expected = {
        "request_id": request_id,
        "operation_id": operation_id,
        "run_id": run_id,
        "attempt": attempt,
        "authorization_basis": "slot_mounted_storage",
        "index_manifest": expected_index_manifest,
        "pipeline_fingerprint": expected_pipeline_fingerprint,
    }
    for field, expected_value in expected.items():
        if response_value.get(field) != expected_value or receipt.get(field) != expected_value:
            raise SlotConsumptionError(f"{field} binding is invalid")

    if receipt.get("operation_id_source") != "client":
        raise SlotConsumptionError("operation id was not supplied by the consumer")
    if receipt.get("execution_status") != "completed" or receipt.get("error_code") is not None:
        raise SlotConsumptionError("operation did not complete")
    if _integer(response_value.get("attempt"), minimum=1, maximum=16) != attempt:
        raise SlotConsumptionError("response attempt is invalid")
    if _integer(receipt.get("attempt"), minimum=1, maximum=16) != attempt:
        raise SlotConsumptionError("receipt attempt is invalid")
    if _integer(receipt.get("requested_max_results"), minimum=1, maximum=10) != max_results:
        raise SlotConsumptionError("requested result limit is not bound")
    if _integer(receipt.get("query_chars"), minimum=1, maximum=4_000) != len(query):
        raise SlotConsumptionError("query length is not bound")
    response_duration = _integer(response_value.get("duration_ms"))
    receipt_duration = _integer(receipt.get("duration_ms"))
    if response_duration != receipt_duration:
        raise SlotConsumptionError("duration is not bound")
    _bounded_text(receipt.get("recorded_at"), maximum=64)

    corpora = receipt.get("corpora")
    if (
        not isinstance(corpora, list)
        or not corpora
        or any(not isinstance(corpus, str) or not corpus for corpus in corpora)
        or len(set(corpora)) != len(corpora)
    ):
        raise SlotConsumptionError("receipt corpora are invalid")
    if requested_corpus is not None and corpora != [requested_corpus]:
        raise SlotConsumptionError("requested corpus is not bound")

    results_value = response_value.get("results")
    canonical_results, result_characters = _validate_results(
        results_value,
        max_results=max_results,
        max_chars=max_chars,
    )
    result_count = len(results_value)
    status = "hits" if result_count else "zero_hits"
    result_digest = "sha256:" + hashlib.sha256(canonical_results).hexdigest()
    if (
        response_value.get("result_status") != status
        or receipt.get("result_status") != status
        or response_value.get("result_digest") != result_digest
        or receipt.get("result_digest") != result_digest
        or _integer(receipt.get("result_count"), maximum=10) != result_count
    ):
        raise SlotConsumptionError("result binding is invalid")
    if any(result["corpus"] not in corpora for result in results_value):
        raise SlotConsumptionError("result corpus is outside the receipt scope")

    try:
        receipt_bytes = canonical_json_bytes(operation_receipt)
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise SlotConsumptionError("operation receipt is not canonicalizable") from exc
    receipt_digest = "sha256:" + hashlib.sha256(receipt_bytes).hexdigest()
    if response_value.get("operation_receipt") != {
        "status": "written",
        "digest": receipt_digest,
    }:
        raise SlotConsumptionError("written operation receipt is not bound")

    has_external_stage = _validate_pipeline_evidence(
        receipt.get("pipeline_evidence"),
        result_count=result_count,
        corpus_count=len(corpora),
    )
    _validate_cost(
        receipt.get("provider_billing"),
        expected_status="unavailable" if has_external_stage else "not_applicable",
        label="provider billing",
    )
    _validate_cost(
        receipt.get("full_economic_cost"),
        expected_status="unavailable",
        label="full economic cost",
    )
    return VerifiedSlotSearchExchange(
        request_id=request_id,
        operation_id=operation_id,
        run_id=run_id,
        attempt=attempt,
        index_manifest=expected_index_manifest,
        pipeline_fingerprint=expected_pipeline_fingerprint,
        result_status=status,
        result_digest=result_digest,
        operation_receipt_digest=receipt_digest,
        result_count=result_count,
        result_characters=result_characters,
        canonical_results=canonical_results,
    )
