from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from kwrag.manifest import IndexManifest
from kwrag.jsonutil import canonical_json_bytes
from kwrag.release import (
    ReleaseError,
    build_index_manifest,
    build_token_projection,
    token_environment_name,
    validate_projection_staging_output,
    write_private_json_exclusive,
)

INSTANCE_A = "00000000-0000-0000-0000-000000000001"
INSTANCE_B = "00000000-0000-0000-0000-000000000002"


def _manifest() -> IndexManifest:
    return IndexManifest(
        digest="sha256:" + "a" * 64,
        release_id="release-1",
        corpus_snapshot="snapshot-1",
        embedding_fingerprint="sha256:" + "b" * 64,
        rooms={"alpha": "123"},
        raw={},
    )


def _digest(value: object) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _source() -> dict[str, str]:
    source = {
        "schema": "kwrag-grant-source/v1",
        "ops_commit": "0" * 40,
        "runtime_bindings_digest": "sha256:" + "1" * 64,
        "nas_views_digest": "sha256:" + "2" * 64,
        "membership_set_digest": "sha256:" + "3" * 64,
        "index_manifest_digest": _manifest().digest,
    }
    return {**source, "authoritative_state_digest": _digest(source)}


def _export(grants: list[dict[str, object]]) -> dict[str, object]:
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    source = _source()
    return {
        "version": 1,
        "source_ref": (
            f"ops-grant-export:{source['ops_commit']}:"
            f"{source['authoritative_state_digest']}"
        ),
        "source": source,
        "generated_at": generated.isoformat(),
        "expires_at": (generated + timedelta(minutes=15)).isoformat(),
        "grants": grants,
    }


def test_build_index_manifest_hashes_expected_files(tmp_path: Path) -> None:
    (tmp_path / "room_123.npy").write_bytes(b"vectors")
    (tmp_path / "room_123.meta.sqlite").write_bytes(b"database")

    result = build_index_manifest(
        index_dir=tmp_path,
        rooms={"alpha": "123"},
        release_id="release-1",
        corpus_snapshot="snapshot-1",
        embedding_fingerprint="sha256:" + "b" * 64,
    )

    assert result["rooms"]["alpha"]["files"][0]["sha256"].startswith("sha256:")
    assert result["rooms"]["alpha"]["files"][0]["bytes"] == 7


def test_projection_uses_derived_environment_token_and_authorized_corpora() -> None:
    export = _export(
        [{"instance_id": INSTANCE_A, "slot_id": "example-slot", "corpora": ["alpha"]}]
    )
    token = "x" * 32
    environment_name = token_environment_name(INSTANCE_A)

    projection = build_token_projection(
        manifest=_manifest(),
        grant_export=export,
        environment={environment_name: token},
    )

    assert projection["tokens"][token] == {
        "instance_id": INSTANCE_A,
        "slot_id": "example-slot",
        "corpora": ["alpha"],
    }
    assert environment_name not in projection["tokens"]


def test_projection_rejects_unknown_corpus_and_reused_token() -> None:
    bad_corpus = _export(
        [{"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["beta"]}]
    )
    with pytest.raises(ReleaseError, match="unavailable corpus"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=bad_corpus,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )

    reused = _export(
        [
            {"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]},
            {"instance_id": INSTANCE_B, "slot_id": "example-b", "corpora": ["alpha"]},
        ]
    )
    with pytest.raises(ReleaseError, match="same service token"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=reused,
            environment={
                token_environment_name(INSTANCE_A): "a" * 32,
                token_environment_name(INSTANCE_B): "a" * 32,
            },
        )


def test_projection_rejects_ambiguous_grant_export_contract() -> None:
    base = _export(
        [{"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]}]
    )

    unknown = dict(base, unexpected=True)
    with pytest.raises(ReleaseError, match="unknown fields"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=unknown,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )

    duplicate_slot = dict(
        base,
        grants=[
            {"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]},
            {"instance_id": INSTANCE_B, "slot_id": "example-a", "corpora": ["alpha"]},
        ],
    )
    with pytest.raises(ReleaseError, match="duplicate slot"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=duplicate_slot,
            environment={
                token_environment_name(INSTANCE_A): "a" * 32,
                token_environment_name(INSTANCE_B): "b" * 32,
            },
        )

    duplicate_instance = dict(
        base,
        grants=[
            {"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]},
            {"instance_id": INSTANCE_A, "slot_id": "example-b", "corpora": ["alpha"]},
        ],
    )
    with pytest.raises(ReleaseError, match="duplicate instance"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=duplicate_instance,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )

    invalid_source = json.loads(json.dumps(base))
    invalid_source["source"]["runtime_bindings_digest"] = "sha256:" + "f" * 64
    with pytest.raises(ReleaseError, match="authoritative state digest"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=invalid_source,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )


def test_projection_rejects_short_lifetime_and_wrong_manifest_source() -> None:
    short = _export(
        [{"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]}]
    )
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    short["generated_at"] = generated.isoformat()
    short["expires_at"] = (generated + timedelta(seconds=299)).isoformat()
    with pytest.raises(ReleaseError, match="between 300 and 3600"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=short,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )

    wrong_manifest = _export(
        [{"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]}]
    )
    wrong_manifest["source"]["index_manifest_digest"] = "sha256:" + "f" * 64
    with pytest.raises(ReleaseError, match="different index manifest"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=wrong_manifest,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )


def test_projection_rejects_future_time_and_unsorted_grants() -> None:
    future = _export(
        [{"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]}]
    )
    generated = datetime.now(timezone.utc).replace(microsecond=0) + timedelta(minutes=2)
    future["generated_at"] = generated.isoformat()
    future["expires_at"] = (generated + timedelta(minutes=15)).isoformat()
    with pytest.raises(ReleaseError, match="in the future"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=future,
            environment={token_environment_name(INSTANCE_A): "a" * 32},
        )

    unsorted = _export(
        [
            {"instance_id": INSTANCE_B, "slot_id": "example-b", "corpora": ["alpha"]},
            {"instance_id": INSTANCE_A, "slot_id": "example-a", "corpora": ["alpha"]},
        ]
    )
    with pytest.raises(ReleaseError, match="not sorted"):
        build_token_projection(
            manifest=_manifest(),
            grant_export=unsorted,
            environment={
                token_environment_name(INSTANCE_A): "a" * 32,
                token_environment_name(INSTANCE_B): "b" * 32,
            },
        )


def test_projection_builds_empty_revoke_all_state() -> None:
    projection = build_token_projection(
        manifest=_manifest(),
        grant_export=_export([]),
        environment={},
    )

    assert projection["tokens"] == {}


def test_projection_staging_output_is_confined(tmp_path: Path) -> None:
    tmp_path.chmod(0o750)
    staging = tmp_path / ".staging-projection-00000000-0000-0000-0000-000000000001"
    staging.mkdir()
    staging.chmod(0o700)
    target = staging / "token-projection.json"
    validate_projection_staging_output(target, tmp_path)

    with pytest.raises(ReleaseError, match="approved staging path"):
        validate_projection_staging_output(tmp_path / "token-projection.json", tmp_path)

    target.write_text("occupied", encoding="utf-8")
    with pytest.raises(ReleaseError, match="already exists"):
        validate_projection_staging_output(target, tmp_path)


def test_private_projection_staging_write_is_exclusive(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    if not hasattr(os, "O_NOFOLLOW"):
        monkeypatch.setattr(os, "O_NOFOLLOW", 0, raising=False)
    tmp_path.chmod(0o750)
    staging = tmp_path / ".staging-projection-00000000-0000-0000-0000-000000000001"
    staging.mkdir()
    staging.chmod(0o700)
    target = staging / "token-projection.json"

    write_private_json_exclusive(target, tmp_path, {"version": 1})
    assert json.loads(target.read_text(encoding="utf-8")) == {"version": 1}
    assert target.read_bytes() == b'{"version":1}'

    with pytest.raises(ReleaseError, match="already exists"):
        write_private_json_exclusive(target, tmp_path, {"version": 2})


def test_canonical_json_bytes_rejects_nonfinite_and_unpaired_surrogate() -> None:
    with pytest.raises(ValueError, match="JSON compliant"):
        canonical_json_bytes({"value": float("nan")})

    with pytest.raises(UnicodeEncodeError):
        canonical_json_bytes({"value": "\ud800"})
