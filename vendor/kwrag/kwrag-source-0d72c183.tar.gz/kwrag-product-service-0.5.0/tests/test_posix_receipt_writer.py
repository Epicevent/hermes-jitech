from __future__ import annotations

import os
from pathlib import Path

import pytest

from kwrag.operation import ReceiptWriter


pytestmark = pytest.mark.skipif(os.name != "posix", reason="requires POSIX dir_fd")


def test_posix_receipt_writer_creates_private_tree_and_appends(tmp_path: Path) -> None:
    sink = tmp_path / "private" / "nested" / "receipts.jsonl"
    writer = ReceiptWriter(sink)

    first = writer.write({"sequence": 1})
    second = writer.write({"sequence": 2})

    assert first.status == second.status == "written"
    assert sink.read_bytes() == b'{"sequence":1}\n{"sequence":2}\n'
    assert sink.stat().st_mode & 0o777 == 0o600


def test_posix_receipt_writer_rejects_symlinked_parent(tmp_path: Path) -> None:
    outside = tmp_path / "outside"
    outside.mkdir()
    linked = tmp_path / "linked"
    linked.symlink_to(outside, target_is_directory=True)

    result = ReceiptWriter(linked / "receipts.jsonl").write({"safe": True})

    assert result.status == "unavailable"
    assert not (outside / "receipts.jsonl").exists()


def test_posix_receipt_writer_rejects_symlinked_leaf(tmp_path: Path) -> None:
    outside = tmp_path / "outside.jsonl"
    outside.write_bytes(b"")
    outside.chmod(0o600)
    parent = tmp_path / "runtime"
    parent.mkdir()
    (parent / "receipts.jsonl").symlink_to(outside)

    result = ReceiptWriter(parent / "receipts.jsonl").write({"safe": True})

    assert result.status == "unavailable"
    assert outside.read_bytes() == b""


def test_posix_receipt_writer_rejects_existing_loose_mode(tmp_path: Path) -> None:
    sink = tmp_path / "receipts.jsonl"
    sink.write_bytes(b"")
    sink.chmod(0o640)

    result = ReceiptWriter(sink).write({"safe": True})

    assert result.status == "unavailable"
    assert sink.read_bytes() == b""
