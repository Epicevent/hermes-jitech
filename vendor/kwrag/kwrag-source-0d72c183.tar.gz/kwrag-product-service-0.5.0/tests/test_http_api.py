from __future__ import annotations

import json
import hashlib
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest

from kwrag.auth import ProjectionError, ProjectionStore, SlotGrant, TokenProjection
from kwrag.jsonutil import canonical_json_bytes
from kwrag.http_api import ApiError, ReceiptWriter, SearchApplication, make_handler
from kwrag.manifest import IndexManifest

TOKEN = "secret-token-which-is-long-enough-0001"
INSTANCE_ID = "00000000-0000-0000-0000-000000000001"


class FakePipeline:
    def search(self, query: str, rooms: list[str], k: int):
        return {
            "hits": [
                {
                    "room": rooms[0],
                    "level": "segment",
                    "seg_id": 0,
                    "text": "retrieved text",
                    "score": 0.9,
                    "message_ids": ["m1"],
                }
            ]
        }


class CrossCorpusPipeline:
    def search(self, query: str, rooms: list[str], k: int):
        return {
            "hits": [
                {
                    "room": "beta",
                    "level": "segment",
                    "seg_id": 1,
                    "text": "must never cross the authorization boundary",
                    "score": 1.0,
                }
            ]
        }


class EmptyPipeline:
    def search(self, query: str, rooms: list[str], k: int):
        return {
            "hits": [],
            "operation_evidence": {
                "schema_version": "kwrag-local-pipeline-evidence-v1",
                "embedding": {
                    "execution": "local_model",
                    "model": "example/embed",
                    "revision": "embed-revision",
                    "call_count": 1,
                    "input_count": 1,
                },
                "vector_search": {
                    "execution": "local_index",
                    "call_count": len(rooms),
                    "corpus_count": len(rooms),
                },
                "rerank": {
                    "execution": "local_model",
                    "model": "example/reranker",
                    "revision": "rerank-revision",
                    "stage_call_count": 1,
                    "model_call_count": 0,
                    "pair_count": 0,
                },
                "candidate_count": 0,
                "returned_count": 0,
                "timing_ms": {"embed": 1, "rank": 0, "total": 1},
            },
        }


def _application(tmp_path: Path, *, corpora=frozenset({"alpha"}), receipts=None):
    manifest = IndexManifest(
        digest="sha256:" + "a" * 64,
        release_id="release-1",
        corpus_snapshot="snapshot-1",
        embedding_fingerprint="sha256:" + "b" * 64,
        rooms={"alpha": "123"},
        raw={},
    )
    projection = TokenProjection(
        index_manifest=manifest.digest,
        source_digest="sha256:" + "c" * 64,
        projection_digest="sha256:" + "d" * 64,
        generated_at=datetime.now(timezone.utc) - timedelta(minutes=1),
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=14),
        grants={
            TOKEN: SlotGrant(
                instance_id=INSTANCE_ID,
                slot_id="example-slot",
                corpora=corpora,
            )
        },
    )
    return SearchApplication(
        pipeline=FakePipeline(),
        projection=projection,
        index_manifest=manifest,
        pipeline_fingerprint="sha256:" + "e" * 64,
        receipt_writer=receipts or ReceiptWriter(tmp_path / "receipts.jsonl"),
    )


def test_search_maps_zero_segment_id_and_writes_safe_receipt(tmp_path: Path) -> None:
    application = _application(tmp_path)
    secret_query = "do not write this query"

    response = application.search(TOKEN, {"query": secret_query, "request_id": "req-1"})

    assert response["results"][0]["id"] == "alpha:segment:0"
    receipt = (tmp_path / "receipts.jsonl").read_text(encoding="utf-8")
    assert secret_query not in receipt
    assert TOKEN not in receipt
    entry = json.loads(receipt)
    assert entry["query_chars"] == len(secret_query)
    assert entry["schema_version"] == "kwrag-search-operation-receipt-v1"
    assert entry["execution_status"] == "completed"
    assert entry["result_status"] == "hits"
    assert entry["result_digest"] == response["result_digest"]
    assert entry["provider_billing"] == {
        "amount": None,
        "currency": None,
        "reason": "local_pipeline_has_no_external_provider_billing_receipt",
        "status": "not_applicable",
    }
    assert entry["full_economic_cost"]["status"] == "unavailable"
    expected_receipt_digest = (
        "sha256:" + hashlib.sha256(canonical_json_bytes(entry)).hexdigest()
    )
    assert response["operation_receipt"] == {
        "status": "written",
        "digest": expected_receipt_digest,
    }


def test_zero_hits_are_receipted_separately_from_failure(tmp_path: Path) -> None:
    application = _application(tmp_path)
    application.pipeline = EmptyPipeline()

    response = application.search(
        TOKEN,
        {
            "query": "no matching result",
            "request_id": "attempt-1",
            "operation_id": "operation-1",
            "run_id": "run-1",
            "attempt": 1,
        },
    )

    assert response["results"] == []
    assert response["result_status"] == "zero_hits"
    assert response["operation_id"] == "operation-1"
    assert response["run_id"] == "run-1"
    entry = json.loads((tmp_path / "receipts.jsonl").read_text(encoding="utf-8"))
    assert entry["execution_status"] == "completed"
    assert entry["result_status"] == "zero_hits"
    assert entry["result_count"] == 0
    assert entry["result_digest"] == response["result_digest"]
    assert entry["pipeline_evidence"]["embedding"]["call_count"] == 1
    assert entry["pipeline_evidence"]["rerank"]["model_call_count"] == 0


def test_retries_preserve_logical_operation_and_separate_attempts(
    tmp_path: Path,
) -> None:
    application = _application(tmp_path)

    first = application.search(
        TOKEN,
        {"query": "same", "request_id": "req-1", "operation_id": "op-1", "attempt": 1},
    )
    second = application.search(
        TOKEN,
        {"query": "same", "request_id": "req-2", "operation_id": "op-1", "attempt": 2},
    )

    entries = [
        json.loads(line)
        for line in (tmp_path / "receipts.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
    ]
    assert [
        (entry["operation_id"], entry["request_id"], entry["attempt"])
        for entry in entries
    ] == [
        ("op-1", "req-1", 1),
        ("op-1", "req-2", 2),
    ]
    assert first["result_digest"] == second["result_digest"]
    assert first["operation_receipt"]["digest"] != second["operation_receipt"]["digest"]


@pytest.mark.parametrize(
    "field,value",
    [
        ("operation_id", ""),
        ("operation_id", "x" * 129),
        ("run_id", ""),
        ("run_id", "x" * 129),
        ("attempt", 0),
        ("attempt", 17),
        ("attempt", True),
    ],
)
def test_invalid_operation_correlation_is_rejected(
    tmp_path: Path, field: str, value: object
) -> None:
    application = _application(tmp_path)

    with pytest.raises(ApiError) as rejected:
        application.search(TOKEN, {"query": "q", field: value})

    assert rejected.value.status == 400
    assert not (tmp_path / "receipts.jsonl").exists()


def test_authorization_and_stale_projection_fail_closed(tmp_path: Path) -> None:
    application = _application(tmp_path)

    with pytest.raises(ApiError) as unauthorized:
        application.search("wrong", {"query": "q"})
    assert unauthorized.value.status == 401

    with pytest.raises(ApiError) as forbidden:
        application.search(TOKEN, {"query": "q", "corpus": "beta"})
    assert forbidden.value.status == 403

    stale = _application(tmp_path, corpora=frozenset({"beta"}))
    with pytest.raises(ApiError) as unavailable:
        stale.search(TOKEN, {"query": "q"})
    assert unavailable.value.status == 409

    expired = _application(tmp_path)
    object.__setattr__(
        expired.projection,
        "expires_at",
        datetime.now(timezone.utc) - timedelta(seconds=1),
    )
    with pytest.raises(ApiError) as stale_projection:
        expired.search(TOKEN, {"query": "q"})
    assert stale_projection.value.status == 409
    assert expired.ready()["ready"] is False


def test_revoke_all_projection_is_ready_but_authorizes_nobody(tmp_path: Path) -> None:
    application = _application(tmp_path)
    object.__setattr__(application.projection, "grants", {})

    assert application.ready()["ready"] is True
    with pytest.raises(ApiError) as rejected:
        application.search(TOKEN, {"query": "q"})
    assert rejected.value.status == 401


def test_receipt_sink_failure_does_not_break_search(tmp_path: Path) -> None:
    not_a_directory = tmp_path / "not-a-directory"
    not_a_directory.write_text("occupied", encoding="utf-8")
    application = _application(
        tmp_path, receipts=ReceiptWriter(not_a_directory / "receipts.jsonl")
    )

    response = application.search(TOKEN, {"query": "still succeeds"})

    assert len(response["results"]) == 1
    assert response["operation_receipt"] == {"status": "unavailable", "digest": None}


def test_pipeline_cannot_return_a_corpus_outside_the_projection(tmp_path: Path) -> None:
    application = _application(tmp_path)
    application.pipeline = CrossCorpusPipeline()

    with pytest.raises(ApiError) as failure:
        application.search(TOKEN, {"query": "boundary"})

    assert failure.value.status == 503
    assert "beta" not in failure.value.message
    entry = json.loads((tmp_path / "receipts.jsonl").read_text(encoding="utf-8"))
    assert entry["execution_status"] == "failed"
    assert entry["result_status"] == "error"
    assert entry["result_digest"] is None
    assert entry["error_code"] == "not_ready"


def test_receipt_writer_rejects_hardlinked_sink_without_appending(
    tmp_path: Path,
) -> None:
    sink = tmp_path / "receipts.jsonl"
    sibling = tmp_path / "second-link.jsonl"
    sink.write_bytes(b"")
    sibling.hardlink_to(sink)
    writer = ReceiptWriter(sink)

    result = writer.write({"safe": True})

    assert result.status == "unavailable"
    assert result.digest is None
    assert sink.read_bytes() == b""


def test_http_contract_requires_bearer_and_returns_versioned_json(
    tmp_path: Path,
) -> None:
    application = _application(tmp_path)
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(application))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{server.server_port}/v1/search"
    body = json.dumps({"query": "contract", "request_id": "req-http"}).encode()
    try:
        with pytest.raises(HTTPError) as unauthorized:
            urlopen(
                Request(url, data=body, headers={"Content-Type": "application/json"}),
                timeout=2,
            )
        assert unauthorized.value.code == 401

        request = Request(
            url,
            data=body,
            headers={
                "Authorization": f"Bearer {TOKEN}",
                "Content-Type": "application/json",
            },
        )
        with urlopen(request, timeout=2) as response:
            payload = json.loads(response.read())
        assert payload["version"] == "1"
        assert payload["request_id"] == "req-http"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_http_contract_rejects_duplicate_json_keys(tmp_path: Path) -> None:
    application = _application(tmp_path)
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(application))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{server.server_port}/v1/search"
    body = b'{"query":"allowed","query":"ambiguous"}'
    try:
        request = Request(
            url,
            data=body,
            headers={
                "Authorization": f"Bearer {TOKEN}",
                "Content-Type": "application/json",
            },
        )
        with pytest.raises(HTTPError) as rejected:
            urlopen(request, timeout=2)
        payload = json.loads(rejected.value.read())
        assert rejected.value.code == 400
        assert payload["version"] == "1"
        assert payload["error"]["code"] == "invalid_request"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def test_dynamic_projection_failure_closes_ready_and_search(tmp_path: Path) -> None:
    application = _application(tmp_path)

    def unavailable() -> TokenProjection:
        raise ProjectionError("private detail")

    application._projection_loader = unavailable
    ready = application.ready()
    assert ready["ready"] is False
    assert ready["projection_status"] == "unavailable"
    assert "private detail" not in json.dumps(ready)

    with pytest.raises(ApiError) as failure:
        application.search(TOKEN, {"query": "q"})
    assert failure.value.status == 503
    assert failure.value.code == "not_ready"


def test_search_uses_atomic_projection_replacement_without_restart(
    tmp_path: Path,
) -> None:
    path = tmp_path / "token-projection.json"
    manifest = "sha256:" + "a" * 64
    second_token = "replacement-token-which-is-long-enough-0002"
    generated = datetime.now(timezone.utc).replace(microsecond=0)

    def publish(token: str, source: str, offset_seconds: int = 0) -> None:
        published = generated + timedelta(seconds=offset_seconds)
        replacement = path.with_suffix(".tmp")
        replacement.write_bytes(
            canonical_json_bytes(
                {
                    "version": 1,
                    "index_manifest": manifest,
                    "source_digest": source,
                    "generated_at": published.isoformat(),
                    "expires_at": (published + timedelta(minutes=15)).isoformat(),
                    "tokens": {
                        token: {
                            "instance_id": INSTANCE_ID,
                            "slot_id": "example-slot",
                            "corpora": ["alpha"],
                        }
                    },
                }
            )
        )
        replacement.replace(path)

    publish(TOKEN, "sha256:" + "1" * 64)
    store = ProjectionStore(path, manifest)
    application = _application(tmp_path)
    application.projection = store.current()
    application._projection_loader = store.current

    first = application.search(TOKEN, {"query": "first"})
    first_projection = application.ready()["projection_digest"]
    assert len(first["results"]) == 1

    publish(second_token, "sha256:" + "2" * 64, 1)
    with pytest.raises(ApiError) as revoked:
        application.search(TOKEN, {"query": "revoked"})
    assert revoked.value.status == 401
    second = application.search(second_token, {"query": "second"})
    second_projection = application.ready()["projection_digest"]

    assert len(second["results"]) == 1
    assert second_projection != first_projection
    receipts = [
        json.loads(line)
        for line in (tmp_path / "receipts.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
    ]
    assert [entry["projection_digest"] for entry in receipts] == [
        first_projection,
        second_projection,
    ]
