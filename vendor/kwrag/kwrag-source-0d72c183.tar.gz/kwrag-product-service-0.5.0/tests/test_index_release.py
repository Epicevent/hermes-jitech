from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path, PurePath

from kwrag.fixed_producer import load_fixed_producer_binding
from kwrag.index_publisher import (
    IndexPublisherError,
    load_publication_plan,
    preflight_publication,
    publish_release,
)
from kwrag.index_release import (
    IndexReleaseError,
    build_release,
    materialize_binding,
)
from kwrag.jsonutil import canonical_json_bytes, loads_strict_json
from kwrag.manifest import load_and_verify_manifest


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


class PackageFixture:
    def __init__(
        self,
        root: Path,
        *,
        name: str = "package-a",
        room: str = "room-a",
        marker: str = "alpha-marker",
    ) -> None:
        self.path = root / name
        self.path.mkdir()
        self.room = room
        membership = {
            "schema": "kw-corpus-nas-user",
            "conversation_ids": [room],
            "published_at": "ignored-by-transform",
        }
        (self.path / "membership.json").write_bytes(
            canonical_json_bytes(membership)
        )
        connection = sqlite3.connect(self.path / "messages.sqlite")
        connection.executescript(
            """
            CREATE TABLE messages(
                conversation_id TEXT,
                message_id TEXT,
                room_name TEXT,
                request_id TEXT,
                user_id TEXT,
                user_name TEXT,
                sent_time INTEGER,
                text_kind TEXT,
                plain_text TEXT,
                decrypt_status TEXT
            );
            CREATE VIRTUAL TABLE messages_fts USING fts5(
                plain_text,user_name,room_name,file_name,
                conversation_id,message_id
            );
            """
        )
        rows = [
            (
                room,
                "message-2",
                "room",
                "request-2",
                "user-a",
                "name-a",
                2,
                "cipher",
                f"second {marker}",
                "ok",
            ),
            (
                room,
                "message-1",
                "room",
                "request-1",
                "user-a",
                "name-a",
                1,
                "cipher",
                f"first {marker}",
                "ok",
            ),
            (
                room,
                "message-3",
                "room",
                "request-3",
                "user-b",
                "name-b",
                3,
                "plain",
                f"third {marker}",
                "ok",
            ),
        ]
        connection.executemany(
            "INSERT INTO messages VALUES(?,?,?,?,?,?,?,?,?,?)",
            rows,
        )
        connection.executemany(
            """
            INSERT INTO messages_fts(
                plain_text,user_name,room_name,file_name,
                conversation_id,message_id
            ) VALUES(?,?,?,?,?,?)
            """,
            [
                (row[8], row[5], row[2], "", row[0], row[1])
                for row in rows
            ],
        )
        connection.commit()
        connection.close()


class FakeTransport:
    def __init__(self, package: str) -> None:
        self.files: dict[str, bytes] = {
            f"{package}/membership.json": b"membership",
            f"{package}/messages.sqlite": b"database",
        }
        self.puts: list[str] = []
        self.closed = False

    def _children(self, remote_dir: str) -> list[dict]:
        prefix = remote_dir.rstrip("/") + "/"
        children: dict[str, bool] = {}
        for path in self.files:
            if not path.startswith(prefix):
                continue
            tail = path[len(prefix) :]
            name, separator, _rest = tail.partition("/")
            is_directory = bool(separator)
            children[name] = children.get(name, False) or is_directory
        return [
            {"name": name, "isdir": children[name]}
            for name in sorted(children)
        ]

    def list_dir(
        self,
        remote_dir: str,
        *,
        limit: int = 1000,
        offset: int = 0,
    ) -> list[dict]:
        return self._children(remote_dir)[offset : offset + limit]

    def put_file_atomic(self, local_path: Path, remote_path: str) -> None:
        self.puts.append(remote_path)
        self.files[remote_path] = local_path.read_bytes()

    def read_bytes(self, remote_path: str) -> bytes:
        return self.files[remote_path]

    def close(self) -> None:
        self.closed = True


class IndexReleaseTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.package = PackageFixture(self.root)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def build(self, name: str = "build", slot: str = "oc14") -> tuple[Path, dict]:
        root = self.root / name
        inventory = build_release(
            slot=slot,
            package=self.package.path,
            output=root,
            publisher_remote_package=(
                f"/kakao-work/users/{self.package.path.name}"
            ),
        )
        return root, inventory

    def test_double_build_is_byte_identical_and_content_free(self) -> None:
        first, first_inventory = self.build("first")
        second, second_inventory = self.build("second")
        self.assertEqual(first_inventory, second_inventory)

        def files(root: Path) -> dict[str, bytes]:
            return {
                path.relative_to(root).as_posix(): path.read_bytes()
                for path in sorted(root.rglob("*"))
                if path.is_file()
            }

        first_files = files(first)
        self.assertEqual(first_files, files(second))
        release = first / first_inventory["release_relative"]
        database = sqlite3.connect(
            (release / "turns.sqlite3").resolve().as_uri() + "?mode=ro&immutable=1",
            uri=True,
        )
        try:
            self.assertEqual(
                database.execute(
                    "SELECT text FROM turns ORDER BY turn_id"
                ).fetchall(),
                [
                    ("first alpha-marker second alpha-marker",),
                    ("third alpha-marker",),
                ],
            )
            self.assertEqual(
                database.execute("SELECT COUNT(*) FROM turns_fts").fetchone()[0],
                2,
            )
            self.assertEqual(
                database.execute("SELECT COUNT(*) FROM turn_mids").fetchone()[0],
                3,
            )
            fts_sql = database.execute(
                "SELECT sql FROM sqlite_master WHERE name='turns_fts'"
            ).fetchone()[0]
            self.assertIn("trigram", fts_sql)
        finally:
            database.close()
        snapshot = (release / "source-snapshot.json").read_bytes()
        self.assertNotIn(b"alpha-marker", snapshot)
        self.assertNotIn(b"room-a", snapshot)
        self.assertNotIn(b"message-1", snapshot)
        self.assertEqual(first_inventory["source_message_count"], 3)
        self.assertEqual(first_inventory["indexable_message_count"], 3)
        self.assertEqual(first_inventory["turn_count"], 2)

    def test_manifest_binding_input_and_later_materialization_match_runtime(self) -> None:
        root, inventory = self.build()
        release = root / inventory["release_relative"]
        manifest = load_and_verify_manifest(
            release / "index-manifest.json",
            release,
        )
        self.assertEqual(manifest.release_id, inventory["release_id"])
        binding_input = root / "control/oc14/fixed-producer-binding-input.json"
        raw = loads_strict_json(binding_input.read_text(encoding="utf-8"))
        self.assertIsNone(
            raw["value"]["corpora"]["kakao"]["authority_receipt_digest"]
        )
        self.assertEqual(
            raw["value"]["mount_root"],
            "/home/node/nas_docs/kw/package",
        )
        self.assertEqual(
            raw["value"]["index_manifest_relative"],
            f"kwrag/releases/{inventory['release_id']}/index-manifest.json",
        )
        self.assertEqual(raw["binding_projection"]["owner"], "root:root")
        destination = root / "materialized-binding.json"
        authority = "sha256:" + "a" * 64
        result = materialize_binding(
            binding_input_path=binding_input,
            authority_receipt_digest=authority,
            destination=destination,
        )
        loaded = load_fixed_producer_binding(destination)
        self.assertFalse(loaded.enabled)
        self.assertEqual(
            loaded.corpora["kakao"].authority_receipt_digest,
            authority,
        )
        self.assertEqual(result["binding_sha256"], _digest(destination.read_bytes()))

    def test_duplicate_membership_key_is_rejected(self) -> None:
        (self.package.path / "membership.json").write_text(
            '{"schema":"kw-corpus-nas-user",'
            '"conversation_ids":["a"],"conversation_ids":["b"]}',
            encoding="utf-8",
        )
        with self.assertRaises(IndexReleaseError):
            self.build()

    def test_membership_and_database_scope_must_be_exact(self) -> None:
        membership = {
            "schema": "kw-corpus-nas-user",
            "conversation_ids": ["another-room"],
        }
        (self.package.path / "membership.json").write_bytes(
            canonical_json_bytes(membership)
        )
        with self.assertRaisesRegex(
            IndexReleaseError,
            "source_membership_database_scope_mismatch",
        ):
            self.build()

    def test_wrong_remote_package_and_source_nested_output_are_rejected(self) -> None:
        with self.assertRaisesRegex(
            IndexReleaseError,
            "publisher_remote_package_invalid",
        ):
            build_release(
                slot="oc14",
                package=self.package.path,
                output=self.root / "wrong",
                publisher_remote_package="/kakao-work/users/someone-else",
            )
        with self.assertRaisesRegex(
            IndexReleaseError,
            "output_cannot_be_inside_source_package",
        ):
            build_release(
                slot="oc14",
                package=self.package.path,
                output=self.package.path / "private",
                publisher_remote_package=(
                    f"/kakao-work/users/{self.package.path.name}"
                ),
            )

    def test_distinct_slot_packages_never_reuse_release_identity(self) -> None:
        other = PackageFixture(
            self.root,
            name="package-b",
            room="room-a",
            marker="different-slot-marker",
        )
        first_root, first = self.build("slot-a", "oc14")
        second_root = self.root / "slot-b"
        second = build_release(
            slot="oc20",
            package=other.path,
            output=second_root,
            publisher_remote_package="/kakao-work/users/package-b",
        )
        self.assertNotEqual(first["release_id"], second["release_id"])
        self.assertNotEqual(first["files"][0]["sha256"], second["files"][0]["sha256"])
        self.assertIn("/oc14/", first["release_relative"])
        self.assertIn("/oc20/", second["release_relative"])


class IndexPublisherTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.package = PackageFixture(self.root)
        self.build_root = self.root / "build"
        self.inventory = build_release(
            slot="oc14",
            package=self.package.path,
            output=self.build_root,
            publisher_remote_package="/kakao-work/users/package-a",
        )
        self.plan_path = (
            self.build_root / "control/oc14/publication-plan.json"
        )
        self.plan, self.plan_digest = load_publication_plan(self.plan_path)
        self.transport = FakeTransport("/kakao-work/users/package-a")

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def publish(self, receipt_name: str | None = None) -> dict:
        return publish_release(
            transport=self.transport,
            build_root=self.build_root,
            plan_path=self.plan_path,
            expected_plan_digest=self.plan_digest,
            receipt_path=(
                self.root / receipt_name if receipt_name is not None else None
            ),
        )

    def test_manifest_last_readback_and_idempotent_retry(self) -> None:
        receipt = self.publish("receipt.json")
        self.assertEqual(
            [PurePath(path).name for path in self.transport.puts],
            [
                "turns.sqlite3",
                "source-snapshot.json",
                "index-manifest.json",
            ],
        )
        self.assertFalse(receipt["active_reference_changed"])
        self.assertFalse(receipt["runtime_changed"])
        encoded = canonical_json_bytes(receipt)
        self.assertNotIn(b"alpha-marker", encoded)
        self.assertNotIn(b"NAS_DSM_PASSWORD", encoded)
        self.assertEqual(
            (self.root / "receipt.json").read_bytes(),
            encoded,
        )
        self.transport.puts.clear()
        retry = self.publish()
        self.assertEqual(self.transport.puts, [])
        self.assertEqual(
            {item["disposition"] for item in retry["files"]},
            {"reused"},
        )

    def test_existing_immutable_mismatch_fails_without_write(self) -> None:
        self.publish()
        remote_release = self.plan["release"]["remote_release"]
        self.transport.files[f"{remote_release}/turns.sqlite3"] = b"tampered"
        self.transport.puts.clear()
        with self.assertRaisesRegex(
            IndexPublisherError,
            "remote_immutable_file_mismatch",
        ):
            self.publish()
        self.assertEqual(self.transport.puts, [])

    def test_partial_without_manifest_resumes_manifest_last(self) -> None:
        release = self.build_root / self.inventory["release_relative"]
        remote = self.plan["release"]["remote_release"]
        self.transport.files[f"{remote}/turns.sqlite3"] = (
            release / "turns.sqlite3"
        ).read_bytes()
        receipt = self.publish()
        self.assertEqual(
            [PurePath(path).name for path in self.transport.puts],
            ["source-snapshot.json", "index-manifest.json"],
        )
        self.assertEqual(receipt["files"][0]["disposition"], "reused")

    def test_manifest_without_data_fails_closed(self) -> None:
        release = self.build_root / self.inventory["release_relative"]
        remote = self.plan["release"]["remote_release"]
        self.transport.files[f"{remote}/index-manifest.json"] = (
            release / "index-manifest.json"
        ).read_bytes()
        with self.assertRaisesRegex(
            IndexPublisherError,
            "remote_committed_release_incomplete",
        ):
            self.publish()
        self.assertEqual(self.transport.puts, [])

    def test_unknown_remote_entry_fails_closed(self) -> None:
        self.publish()
        remote = self.plan["release"]["remote_release"]
        self.transport.files[f"{remote}/unexpected"] = b"x"
        self.transport.puts.clear()
        with self.assertRaisesRegex(
            IndexPublisherError,
            "remote_release_file_set_invalid",
        ):
            self.publish()
        self.assertEqual(self.transport.puts, [])

    def test_digest_confirmation_precedes_transport(self) -> None:
        with self.assertRaisesRegex(
            IndexPublisherError,
            "publication_plan_digest_mismatch",
        ):
            preflight_publication(
                build_root=self.build_root,
                plan_path=self.plan_path,
                expected_plan_digest="sha256:" + "0" * 64,
            )


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(
        __import__(__name__)
    )
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        print(
            "KWRAG_INDEX_PUBLICATION_SELFTEST=PASS cases=12 "
            "network=0 credentials=0 publication=simulated"
        )
    raise SystemExit(0 if result.wasSuccessful() else 1)
