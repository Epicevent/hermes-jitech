import hashlib
import json
from pathlib import Path

import pytest

from kwrag.slot_mount import SlotMountError, load_slot_index_scope, resolve_mounted_path


def _sha256(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _mounted_index(tmp_path: Path) -> tuple[Path, Path]:
    mount = (tmp_path / "nas_docs").resolve()
    index = mount / "kw" / "package" / "index"
    index.mkdir(parents=True)
    vector = index / "room_123.npy"
    database = index / "room_123.meta.sqlite"
    vector.write_bytes(b"vector")
    database.write_bytes(b"database")
    manifest = {
        "version": 1,
        "release_id": "slot-local-1",
        "created_at": "2026-07-27T00:00:00Z",
        "corpus_snapshot": "package-1",
        "embedding_fingerprint": "sha256:" + "a" * 64,
        "rooms": {
            "alpha": {
                "conversation_id": "123",
                "files": [
                    {"path": vector.name, "sha256": _sha256(vector)},
                    {"path": database.name, "sha256": _sha256(database)},
                ],
            }
        },
    }
    manifest_path = index / "index-manifest.json"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    return mount, manifest_path


def test_slot_scope_uses_only_rooms_in_the_mounted_manifest(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    relative = manifest.relative_to(mount).as_posix()
    scope = load_slot_index_scope(mount, relative)

    assert scope.mount_root == mount
    assert scope.index_root == manifest.parent
    assert scope.available_rooms == ("alpha",)
    assert scope.select_rooms() == ["alpha"]
    assert scope.select_rooms(["alpha"]) == ["alpha"]
    scope.assert_current()

    with pytest.raises(SlotMountError, match="outside the slot-mounted index"):
        scope.select_rooms(["beta"])


@pytest.mark.parametrize("relative", ["../outside.json", "/outside.json", "C:/outside.json"])
def test_slot_scope_rejects_non_relative_manifest_paths(tmp_path: Path, relative: str) -> None:
    mount, _manifest = _mounted_index(tmp_path)
    with pytest.raises(SlotMountError, match="mount-relative"):
        load_slot_index_scope(mount, relative)


def test_slot_scope_rejects_manifest_outside_mount_even_when_it_exists(tmp_path: Path) -> None:
    mount, _manifest = _mounted_index(tmp_path)
    outside = tmp_path / "outside.json"
    outside.write_text("{}", encoding="utf-8")
    with pytest.raises(SlotMountError):
        load_slot_index_scope(mount, outside)


def test_slot_scope_rejects_symlink_in_visible_path(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    link = mount / "linked-index"
    try:
        link.symlink_to(manifest.parent, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks are unavailable to this test account")

    with pytest.raises(SlotMountError, match="symlink"):
        load_slot_index_scope(mount, "linked-index/index-manifest.json")


def test_slot_scope_rejects_symlinked_index_file(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    index = manifest.parent
    target = index / "real.npy"
    target.write_bytes((index / "room_123.npy").read_bytes())
    (index / "room_123.npy").unlink()
    try:
        (index / "room_123.npy").symlink_to(target)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks are unavailable to this test account")

    with pytest.raises(SlotMountError, match="symlink"):
        load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())


def test_slot_scope_rejects_escaping_index_file_before_content_read(
    tmp_path: Path, monkeypatch
) -> None:
    mount, manifest = _mounted_index(tmp_path)
    outside = tmp_path / "outside-secret.txt"
    outside.write_bytes(b"must never be read by the slot loader")
    raw = json.loads(manifest.read_text(encoding="utf-8"))
    raw["rooms"]["alpha"]["files"] = [
        {
            "path": "../../../../outside-secret.txt",
            "sha256": _sha256(outside),
        }
    ]
    manifest.write_text(json.dumps(raw), encoding="utf-8")

    observed_reads: list[Path] = []
    from kwrag import manifest as manifest_module

    original_sha256 = manifest_module._file_sha256

    def observed_sha256(path: Path) -> str:
        observed_reads.append(Path(path))
        return original_sha256(path)

    monkeypatch.setattr(manifest_module, "_file_sha256", observed_sha256)

    with pytest.raises(SlotMountError, match="mount-relative"):
        load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())

    assert observed_reads == []


def test_slot_scope_exposes_manifest_failures_as_boundary_errors(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    raw = json.loads(manifest.read_text(encoding="utf-8"))
    raw["rooms"]["alpha"]["files"][0]["sha256"] = "sha256:" + "0" * 64
    manifest.write_text(json.dumps(raw), encoding="utf-8")

    with pytest.raises(SlotMountError, match="manifest verification failed"):
        load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())


def test_slot_scope_hashes_declared_files_through_the_confined_open_file(
    tmp_path: Path, monkeypatch,
) -> None:
    mount, manifest = _mounted_index(tmp_path)
    from kwrag import manifest as manifest_module

    def path_reopen_forbidden(_path: Path) -> str:
        raise AssertionError("slot loader must not reopen a verified path for hashing")

    monkeypatch.setattr(manifest_module, "_file_sha256", path_reopen_forbidden)

    scope = load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())

    assert scope.available_rooms == ("alpha",)
    assert len(scope.file_identities) == 3


def test_slot_scope_rejects_same_byte_manifest_replacement(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    scope = load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())
    original = manifest.read_bytes()

    manifest.unlink()
    manifest.write_bytes(original)

    with pytest.raises(SlotMountError, match="identity drifted"):
        scope.assert_current()


def test_slot_scope_rejects_in_place_index_file_change(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    scope = load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())

    (manifest.parent / "room_123.npy").write_bytes(b"changed vector bytes")

    with pytest.raises(SlotMountError, match="identity drifted"):
        scope.assert_current()


def test_room_selection_rejects_empty_duplicate_and_scalar_requests(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    scope = load_slot_index_scope(mount, manifest.relative_to(mount).as_posix())

    with pytest.raises(SlotMountError, match="empty"):
        scope.select_rooms([])
    with pytest.raises(SlotMountError, match="duplicate"):
        scope.select_rooms(["alpha", "alpha"])
    with pytest.raises(SlotMountError, match="sequence"):
        scope.select_rooms("alpha")


def test_resolver_requires_an_absolute_real_root(tmp_path: Path) -> None:
    mount, manifest = _mounted_index(tmp_path)
    with pytest.raises(SlotMountError, match="absolute"):
        resolve_mounted_path(Path("nas_docs"), "kw", kind="directory")

    root_link = tmp_path / "nas_docs_link"
    try:
        root_link.symlink_to(mount, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks are unavailable to this test account")
    with pytest.raises(SlotMountError, match="real directory"):
        load_slot_index_scope(root_link, manifest.relative_to(mount).as_posix())
