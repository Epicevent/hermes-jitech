from __future__ import annotations

import hashlib
import os
import socketserver
import sqlite3
import tempfile
import threading
import time
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from kwrag.crawler_fixed_producer import (
    CRAWLER_F_PIPELINE_FINGERPRINT,
    execute_crawler_fixed_producer,
)
from kwrag.crawler_source import (
    CanonicalCrawlerSource,
    CrawlerFtsSearchPipeline,
    CrawlerSourceError,
)
from kwrag.dense_pipeline import SharedGpuDensePipeline
from kwrag.dense_release import (
    D_PIPELINE_FINGERPRINT,
    DenseReleaseError,
    activate_dense_release,
    build_dense_release,
    dense_gc_candidates,
    rollback_dense_release,
)
from kwrag.jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from kwrag.operation import ReceiptWriter, slot_pipeline_evidence
from kwrag.shared_gpu_contract import (
    REQUEST_SCHEMA,
    SharedGpuContractError,
    validate_request,
    validate_response,
)
from kwrag.shared_gpu_core import CallerIdentity, SharedGpuCore, SharedGpuCoreConfig
from kwrag.shared_gpu_models import NonProductionDeterministicBackend
from kwrag.shared_gpu_transport import (
    ContentFreeGpuJournal,
    InProcessSharedGpuClient,
    PeerAuthorizer,
    SharedGpuTransportError,
    SharedGpuUnixServer,
    SlotPeerGrant,
    UnixSharedGpuClient,
)
from kwrag.slot_api import SlotSearchApplication
from kwrag.slot_mount import load_slot_index_scope


def _effective_uid() -> int:
    return os.geteuid() if hasattr(os, "geteuid") else 1000


def _effective_gid() -> int:
    return os.getegid() if hasattr(os, "getegid") else 1000


def _readonly_flag() -> int:
    return int(getattr(os, "ST_RDONLY", 1))


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    path.chmod(0o600)


def _database(
    path: Path,
    rows: list[tuple[str, str, str]],
    *,
    trigram: bool,
    compatibility_tokenizer: str = "unicode61",
) -> None:
    if compatibility_tokenizer not in {"unicode61", "porter"}:
        raise ValueError("unsupported test tokenizer")
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path)) as connection:
        with connection:
            connection.executescript(
                """
            CREATE TABLE messages(
                conversation_id TEXT NOT NULL,
                message_id TEXT NOT NULL UNIQUE,
                user_id TEXT NOT NULL,
                user_name TEXT NOT NULL,
                sent_time INTEGER NOT NULL,
                text_kind TEXT NOT NULL,
                plain_text TEXT NOT NULL
            );
            CREATE TABLE attachments(message_id TEXT, name TEXT);
            """
            )
            connection.execute(
                "CREATE VIRTUAL TABLE messages_fts USING fts5("
                "plain_text,content='messages',content_rowid='rowid',tokenize="
                f"'{compatibility_tokenizer}')"
            )
            if trigram:
                connection.execute(
                    "CREATE VIRTUAL TABLE messages_fts_trigram USING fts5("
                    "plain_text,content='messages',content_rowid='rowid',tokenize='trigram')"
                )
            for index, (room, message_id, text) in enumerate(rows, 1):
                connection.execute(
                    "INSERT INTO messages VALUES(?,?,?,?,?,?,?)",
                    (room, message_id, "u", "name", index, "text", text),
                )
            connection.execute(
                "INSERT INTO messages_fts(messages_fts) VALUES('rebuild')"
            )
            if trigram:
                connection.execute(
                    "INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild')"
                )
    path.chmod(0o600)


def _generation(
    root: Path,
    *,
    token: str,
    sequence: int,
    rows: list[tuple[str, str, str]],
    membership_rooms: list[str] | None = None,
    trigram: bool = True,
    compatibility_tokenizer: str = "unicode61",
    activation_slot: str = "a",
    previous: str | None = None,
    corrupt_database: bool = False,
) -> str:
    generation_root = root / "kwrag" / "source" / "generations"
    generation = generation_root / f".fixture-staging-{token}"
    rooms = membership_rooms or sorted({row[0] for row in rows})
    membership = canonical_json_bytes(
        {"schema": "kw-corpus-nas-user", "conversation_ids": rooms}
    )
    profile = canonical_json_bytes({"schema": "kw-corpus-profile", "version": 1})
    _write(generation / "membership.json", membership)
    _write(generation / "profile.json", profile)
    if corrupt_database:
        _write(generation / "messages.sqlite", b"not-a-database")
    else:
        _database(
            generation / "messages.sqlite",
            rows,
            trigram=trigram,
            compatibility_tokenizer=compatibility_tokenizer,
        )
    files = []
    for name in ("membership.json", "messages.sqlite", "profile.json"):
        payload = (generation / name).read_bytes()
        files.append({"name": name, "sha256": _digest(payload), "bytes": len(payload)})
    manifest = {
        "schema_version": "kw-corpus-package-manifest-v1",
        "files": files,
        "membership_conversation_set_sha256": _digest(
            canonical_json_bytes(sorted(rooms))
        ),
        "room_count": len(rooms),
        "message_count": len(rows),
        "messages_fts_count": len(rows),
        "fts_tokenizers": {
            "messages_fts": "unicode61",
            "messages_fts_trigram": "trigram" if trigram else None,
        },
    }
    generation_id = "g-" + hashlib.sha256(canonical_json_bytes(manifest)).hexdigest()
    destination = generation.parent / generation_id
    generation.replace(destination)
    generation = destination
    manifest["generation_id"] = generation_id
    manifest_payload = canonical_json_bytes(manifest)
    _write(generation / "package-manifest.json", manifest_payload)
    activation = {
        "schema_version": "kw-corpus-package-activation-v1",
        "sequence": sequence,
        "generation_id": generation_id,
        "manifest_relative": (
            f"kwrag/source/generations/{generation_id}/package-manifest.json"
        ),
        "manifest_sha256": _digest(manifest_payload),
        "previous_generation_id": previous,
    }
    _write(
        root / "kwrag" / "source" / f"activation-{activation_slot}.json",
        canonical_json_bytes(activation),
    )
    return generation_id


def _request(
    operation: str,
    payload: dict,
    *,
    request_id: str,
    slot: str = "slot-a",
    uid: int | None = None,
    deadline_ms: int = 10_000,
) -> dict:
    uid = _effective_uid() if uid is None else uid
    return {
        "schema_version": REQUEST_SCHEMA,
        "request_id": request_id,
        "operation": operation,
        "slot": slot,
        "principal": f"uid:{uid}",
        "deadline_unix_ms": int(time.time() * 1_000) + deadline_ms,
        "payload": payload,
    }


def _caller(slot: str = "slot-a") -> CallerIdentity:
    return CallerIdentity(
        slot=slot,
        principal=f"uid:{_effective_uid()}",
        peer_uid=_effective_uid(),
        peer_gid=_effective_gid(),
    )


class _BlockingBackend(NonProductionDeterministicBackend):
    def __init__(self) -> None:
        super().__init__(dimension=8)
        self.entered = threading.Event()
        self.release = threading.Event()

    def embed(self, texts, *, corpus, cancelled, deadline_unix_ms):
        self.entered.set()
        while not self.release.wait(0.005):
            if cancelled():
                raise SharedGpuContractError("cancelled")
            if int(time.time() * 1_000) >= deadline_unix_ms:
                raise SharedGpuContractError("deadline_exceeded", retryable=True)
        return super().embed(
            texts,
            corpus=corpus,
            cancelled=cancelled,
            deadline_unix_ms=deadline_unix_ms,
        )


@unittest.skipUnless(
    os.name == "posix" and hasattr(os, "statvfs") and hasattr(os, "ST_RDONLY"),
    "crawler-generation mount contract requires POSIX",
)
class CrawlerGenerationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.readonly = patch(
            "kwrag.crawler_source.os.statvfs",
            return_value=SimpleNamespace(f_flag=_readonly_flag()),
            create=True,
        )
        self.readonly.start()

    def tearDown(self) -> None:
        self.readonly.stop()
        self.temp.cleanup()

    def test_same_generation_trigram_preference_and_direct_fts(self) -> None:
        _generation(
            self.root,
            token="1",
            sequence=1,
            rows=[("room-a", "m1", "가나다라마 내부 검색")],
        )
        with CanonicalCrawlerSource(self.root) as source:
            self.assertEqual(source.generation.lexical_tokenizer, "trigram")
            self.assertEqual(
                source.search("나다라", ["room-a"], limit=5)[0].message_id, "m1"
            )
            result = CrawlerFtsSearchPipeline(source).search("나다라", ["room-a"], 1)
            self.assertIn("trigram", result["operation_evidence"]["backend_id"])

    def test_unicode61_compatibility_does_not_claim_substring(self) -> None:
        _generation(
            self.root,
            token="2",
            sequence=1,
            rows=[("room-a", "m1", "가나다라마 내부 검색")],
            trigram=False,
        )
        with CanonicalCrawlerSource(self.root) as source:
            self.assertEqual(source.search("나다라", ["room-a"], limit=5), [])
            result = CrawlerFtsSearchPipeline(source).search(
                "가나다라마", ["room-a"], 1
            )
            self.assertIn(
                "unicode61-compat", result["operation_evidence"]["backend_id"]
            )

    def test_unsupported_fts_tokenizer_is_not_misidentified(self) -> None:
        _generation(
            self.root,
            token="9",
            sequence=1,
            rows=[("room-a", "m1", "tokenizer contract")],
            trigram=False,
            compatibility_tokenizer="porter",
        )
        with self.assertRaisesRegex(CrawlerSourceError, "fts_tokenizer_unsupported"):
            CanonicalCrawlerSource(self.root)

    def test_mixed_membership_database_and_corrupt_sqlite_rejected(self) -> None:
        _generation(
            self.root,
            token="3",
            sequence=1,
            rows=[("room-a", "m1", "text")],
            membership_rooms=["room-b"],
        )
        with self.assertRaisesRegex(
            CrawlerSourceError, "membership_database_scope_mismatch"
        ):
            CanonicalCrawlerSource(self.root)
        other = self.root / "corrupt"
        other.mkdir()
        _generation(
            other,
            token="4",
            sequence=1,
            rows=[("room-a", "m1", "text")],
            corrupt_database=True,
        )
        with self.assertRaisesRegex(CrawlerSourceError, "database_query_failed"):
            CanonicalCrawlerSource(other)

    def test_generation_rollover_reopens_and_mutation_fails_closed(self) -> None:
        first = _generation(
            self.root,
            token="5",
            sequence=1,
            rows=[("room-a", "m1", "first generation")],
        )
        with CanonicalCrawlerSource(self.root) as source:
            _generation(
                self.root,
                token="6",
                sequence=2,
                rows=[("room-a", "m2", "second generation")],
                activation_slot="b",
                previous=first,
            )
            self.assertEqual(
                source.search("second", ["room-a"], limit=5)[0].message_id, "m2"
            )
            database = source.generation.database_path
            metadata = database.stat()
            os.utime(database, ns=(metadata.st_atime_ns, metadata.st_mtime_ns + 1))
            with self.assertRaisesRegex(
                CrawlerSourceError, "generation_file_identity_changed"
            ):
                source.search("second", ["room-a"], limit=5)

    def test_writable_mount_and_cross_room_request_rejected(self) -> None:
        _generation(
            self.root,
            token="7",
            sequence=1,
            rows=[("room-a", "m1", "text")],
        )
        self.readonly.stop()
        try:
            with self.assertRaisesRegex(CrawlerSourceError, "mount_root_not_readonly"):
                CanonicalCrawlerSource(self.root)
        finally:
            self.readonly.start()
        with CanonicalCrawlerSource(self.root) as source:
            with self.assertRaisesRegex(CrawlerSourceError, "room_outside_generation"):
                source.search("text", ["room-b"], limit=5)

    def test_caller_explicit_fixed_producer_reads_authoritative_sqlite(self) -> None:
        package = self.root / "package"
        package.mkdir()
        _generation(
            package,
            token="8",
            sequence=1,
            rows=[
                ("room-a", "m1", "가나다라마 direct crawler result"),
                ("room-b", "m2", "other room content"),
            ],
        )
        receipts = self.root / "receipts"
        receipts.mkdir()
        operation_receipt = receipts / "operation.jsonl"
        producer_receipt = receipts / "producer.jsonl"
        binding_path = self.root / "crawler-fixed-binding.json"
        _write(
            binding_path,
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-crawler-fixed-producer-binding-v1",
                    "enabled": True,
                    "mount_root": package.as_posix(),
                    "operation_receipt_path": operation_receipt.as_posix(),
                    "producer_receipt_path": producer_receipt.as_posix(),
                    "max_concurrent": 1,
                    "expected_uid": _effective_uid(),
                    "expected_gid": _effective_gid(),
                    "pipeline_fingerprint": CRAWLER_F_PIPELINE_FINGERPRINT,
                }
            ),
        )
        query = "나다라"
        request = canonical_json_bytes(
            {
                "schema_version": "kwrag-slot-search-request-v1",
                "query": query,
                "request_id": "crawler-request-1",
                "operation_id": "crawler-operation-1",
                "run_id": "crawler-run-1",
                "attempt": 1,
                "max_results": 2,
                "corpus": "room-a",
            }
        )
        execution = execute_crawler_fixed_producer(request, binding_path=binding_path)
        output = loads_canonical_json_bytes(execution.output_bytes)
        self.assertEqual(output["consumable"]["result_status"], "hits")
        self.assertEqual(
            output["consumable"]["pipeline_fingerprint"],
            CRAWLER_F_PIPELINE_FINGERPRINT,
        )
        self.assertEqual(output["consumable"]["results"][0]["corpus"], "room-a")
        self.assertEqual(execution.producer_receipt["status"], "verified")
        receipt_bytes = operation_receipt.read_bytes() + producer_receipt.read_bytes()
        self.assertNotIn(query.encode("utf-8"), receipt_bytes)
        self.assertNotIn(b"direct crawler result", receipt_bytes)


class SharedGpuCoreTests(unittest.TestCase):
    def _core(self, backend=None, **kwargs) -> SharedGpuCore:
        core = SharedGpuCore(
            backend or NonProductionDeterministicBackend(8),
            SharedGpuCoreConfig(allow_nonproduction_backend=True, **kwargs),
        )
        core.start()
        self.addCleanup(lambda: core.shutdown(grace_seconds=1))
        return core

    def test_fixed_contract_and_nonproduction_readiness(self) -> None:
        core = self._core()
        caller = _caller()
        raw = _request("embed_query", {"text": "literal query"}, request_id="q-1")
        validated = validate_request(raw)
        response = core.execute(raw, caller=caller)
        validate_response(response, request=validated)
        self.assertFalse(response["receipt"]["production_backend"])
        ready = core.execute(_request("ready", {}, request_id="ready-1"), caller=caller)
        self.assertFalse(ready["output"]["ready"])
        self.assertNotIn("literal query", repr(core.__dict__))
        self.assertEqual(core.snapshot()["active_count"], 0)

    def test_unknown_field_and_identity_mismatch_rejected(self) -> None:
        raw = _request("embed_query", {"text": "q"}, request_id="q-2")
        raw["model"] = "arbitrary"
        with self.assertRaisesRegex(SharedGpuContractError, "request_fields_invalid"):
            validate_request(raw)
        core = self._core()
        with self.assertRaisesRegex(SharedGpuContractError, "caller_identity_mismatch"):
            core.execute(
                _request("embed_query", {"text": "q"}, request_id="q-3", slot="slot-b"),
                caller=_caller("slot-a"),
            )

    def test_cancel_and_deadline_are_bounded(self) -> None:
        backend = _BlockingBackend()
        core = self._core(backend=backend)
        result: list[dict] = []
        worker = threading.Thread(
            target=lambda: result.append(
                core.execute(
                    _request(
                        "embed_query", {"text": "cancel me"}, request_id="cancel-target"
                    ),
                    caller=_caller(),
                )
            )
        )
        worker.start()
        self.assertTrue(backend.entered.wait(1))
        cancel = core.execute(
            _request(
                "cancel",
                {"target_request_id": "cancel-target"},
                request_id="cancel-control",
            ),
            caller=_caller(),
        )
        self.assertTrue(cancel["output"]["cancelled"])
        worker.join(2)
        self.assertEqual(result[0]["error"]["code"], "cancelled")

        deadline_backend = _BlockingBackend()
        deadline_core = self._core(backend=deadline_backend)
        deadline_response = deadline_core.execute(
            _request(
                "embed_query",
                {"text": "deadline"},
                request_id="deadline-target",
                deadline_ms=30,
            ),
            caller=_caller(),
        )
        self.assertEqual(deadline_response["error"]["code"], "deadline_exceeded")

    def test_queue_bound_and_shutdown(self) -> None:
        backend = _BlockingBackend()
        core = self._core(backend=backend, max_concurrent=1, max_queue=1)
        responses: list[dict] = []
        first = threading.Thread(
            target=lambda: responses.append(
                core.execute(
                    _request("embed_query", {"text": "one"}, request_id="queue-1"),
                    caller=_caller(),
                )
            )
        )
        second = threading.Thread(
            target=lambda: responses.append(
                core.execute(
                    _request("embed_query", {"text": "two"}, request_id="queue-2"),
                    caller=_caller(),
                )
            )
        )
        first.start()
        self.assertTrue(backend.entered.wait(1))
        second.start()
        deadline = time.monotonic() + 1
        while core.snapshot()["active_count"] < 2 and time.monotonic() < deadline:
            time.sleep(0.005)
        third = core.execute(
            _request("embed_query", {"text": "three"}, request_id="queue-3"),
            caller=_caller(),
        )
        self.assertEqual(third["error"]["code"], "queue_full")
        backend.release.set()
        first.join(2)
        second.join(2)
        self.assertEqual(len(responses), 2)
        self.assertTrue(core.shutdown(grace_seconds=1))


class SharedGpuTransportTests(unittest.TestCase):
    @unittest.skipUnless(
        os.name == "posix" and hasattr(socketserver, "UnixStreamServer"),
        "Unix-domain server execution requires POSIX",
    )
    def test_uds_peer_binding_roundtrip_and_zero_content_journal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            core = SharedGpuCore(
                NonProductionDeterministicBackend(8),
                SharedGpuCoreConfig(allow_nonproduction_backend=True),
            )
            core.start()
            server = SharedGpuUnixServer(
                socket_path=root / "gpu.sock",
                socket_mode=0o600,
                core=core,
                authorizer=PeerAuthorizer(
                    [SlotPeerGrant("slot-a", _effective_uid(), _effective_gid())]
                ),
            )
            server.serve_in_thread()
            try:
                journal = ContentFreeGpuJournal(root / "receipts" / "gpu.jsonl")
                client = UnixSharedGpuClient(
                    socket_path=root / "gpu.sock",
                    slot="slot-a",
                    principal=f"uid:{_effective_uid()}",
                    journal=journal,
                )
                first = client.embed_query("secret-literal-query")
                second = client.rerank(
                    "secret-literal-query", ["secret-passage-content"]
                )
                operation_digest = client.commit_operation([first, second])
                self.assertIsNotNone(operation_digest)
                self.assertTrue(operation_digest.startswith("sha256:"))
                receipt_bytes = journal.path.read_bytes()
                self.assertNotIn(b"secret-literal-query", receipt_bytes)
                self.assertNotIn(b"secret-passage-content", receipt_bytes)
                self.assertNotIn(str(first.output).encode(), receipt_bytes)
                self.assertEqual(core.snapshot()["active_count"], 0)

                with patch.object(
                    journal.writer,
                    "write",
                    return_value=SimpleNamespace(status="unavailable", digest=None),
                ):
                    unjournaled = client.embed_query("completed-without-journal")
                    self.assertIsNone(unjournaled.journal_receipt_digest)
                    self.assertIsNone(client.commit_operation([unjournaled]))
                    self.assertEqual(len(unjournaled.output["vectors"]), 1)

                wrong = UnixSharedGpuClient(
                    socket_path=root / "gpu.sock",
                    slot="slot-b",
                    principal=f"uid:{_effective_uid()}",
                    journal=journal,
                )
                with self.assertRaises(SharedGpuTransportError):
                    wrong.embed_query("denied")
            finally:
                server.shutdown()
                core.shutdown(grace_seconds=1)
            self.assertFalse((root / "gpu.sock").exists())

    def test_authorizer_forbids_one_peer_from_multiple_slots(self) -> None:
        with self.assertRaisesRegex(ValueError, "one-to-one"):
            PeerAuthorizer(
                [
                    SlotPeerGrant("slot-a", 1000, 1000),
                    SlotPeerGrant("slot-b", 1000, 1000),
                ]
            )


class DenseProductTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.package = self.root / "package"
        self.package.mkdir()
        _generation(
            self.package,
            token="a",
            sequence=1,
            rows=[
                ("room-a", "m1", "unique-alpha-content dense evidence"),
                ("room-a", "m2", "other room a evidence"),
                ("room-b", "m3", "separate room b content"),
            ],
        )
        self.source = CanonicalCrawlerSource(self.package, require_readonly=False)
        self.core = SharedGpuCore(
            NonProductionDeterministicBackend(8),
            SharedGpuCoreConfig(allow_nonproduction_backend=True),
        )
        self.core.start()
        self.journal = ContentFreeGpuJournal(self.root / "gpu-receipts.jsonl")
        self.client = InProcessSharedGpuClient(
            core=self.core,
            caller=_caller("slot-a"),
            journal=self.journal,
        )

    def tearDown(self) -> None:
        self.source.close()
        self.core.shutdown(grace_seconds=1)
        self.temp.cleanup()

    def _build(self, slot: str = "slot-a") -> dict:
        return build_dense_release(
            source=self.source,
            gpu=self.client,
            output_root=self.package,
            slot_namespace=slot,
            allow_nonproduction=True,
        )

    def test_double_build_is_deterministic_and_release_has_no_raw_text(self) -> None:
        first = self._build()
        second = self._build()
        self.assertEqual(first["release_id"], second["release_id"])
        self.assertEqual(first["manifest_sha256"], second["manifest_sha256"])
        release = self.package / first["release_relative"]
        for path in release.iterdir():
            if path.is_file():
                self.assertNotIn(b"unique-alpha-content", path.read_bytes())
        with closing(sqlite3.connect(release / "segments.sqlite3")) as connection:
            columns = [
                row[1] for row in connection.execute("PRAGMA table_info(segments)")
            ]
            self.assertNotIn("text", columns)
            self.assertNotIn("plain_text", columns)
        self.assertFalse(first["production_eligible"])
        self.assertFalse(first["publication_performed"])

    def test_slot_namespaces_are_not_reused(self) -> None:
        first = self._build("slot-a")
        other_caller = CallerIdentity(
            slot="slot-b",
            principal=f"uid:{_effective_uid()}",
            peer_uid=_effective_uid(),
            peer_gid=_effective_gid(),
        )
        other_client = InProcessSharedGpuClient(
            core=self.core,
            caller=other_caller,
            journal=self.journal,
        )
        second = build_dense_release(
            source=self.source,
            gpu=other_client,
            output_root=self.package,
            slot_namespace="slot-b",
            allow_nonproduction=True,
        )
        self.assertNotEqual(first["release_id"], second["release_id"])
        self.assertNotEqual(first["release_relative"], second["release_relative"])

    def test_activation_rollback_and_gc_contract(self) -> None:
        first = self._build()
        slot_root = self.package / "slot-a"
        activate_dense_release(
            slot_root=slot_root,
            release_id=first["release_id"],
            manifest_sha256=first["manifest_sha256"],
            expected_previous_release_id=None,
        )
        previous_generation = self.source.generation.generation_id
        _generation(
            self.package,
            token="b",
            sequence=2,
            rows=[("room-a", "m4", "new generation dense evidence")],
            activation_slot="b",
            previous=previous_generation,
        )
        self.source.refresh(force=True)
        second = self._build()
        activate_dense_release(
            slot_root=slot_root,
            release_id=second["release_id"],
            manifest_sha256=second["manifest_sha256"],
            expected_previous_release_id=first["release_id"],
        )
        rollback = rollback_dense_release(
            slot_root=slot_root,
            expected_current_release_id=second["release_id"],
        )
        self.assertEqual(rollback["current_release_id"], first["release_id"])
        extra = slot_root / "releases" / ("d-" + "f" * 64)
        extra.mkdir()
        self.assertEqual(dense_gc_candidates(slot_root), [extra.name])

    def test_dense_pointer_rejects_symlink_and_invalid_identity(self) -> None:
        slot_root = self.package / "slot-pointer"
        slot_root.mkdir()
        external = self.root / "external-pointer.json"
        _write(
            external,
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-dense-release-pointer-v1",
                    "sequence": 1,
                    "current_release_id": "d-" + "0" * 64,
                    "current_manifest_sha256": "sha256:" + "0" * 64,
                    "previous_release_id": None,
                    "previous_manifest_sha256": None,
                }
            ),
        )
        pointer = slot_root / "current.json"
        try:
            pointer.symlink_to(external)
        except OSError as exc:
            self.skipTest(f"symlink creation unavailable: {exc}")
        with self.assertRaisesRegex(DenseReleaseError, "release_file_unavailable"):
            dense_gc_candidates(slot_root)
        pointer.unlink()
        _write(
            pointer,
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-dense-release-pointer-v1",
                    "sequence": 0,
                    "current_release_id": "d-" + "0" * 64,
                    "current_manifest_sha256": "sha256:" + "0" * 64,
                    "previous_release_id": None,
                    "previous_manifest_sha256": None,
                }
            ),
        )
        with self.assertRaisesRegex(
            DenseReleaseError, "dense_pointer_identity_invalid"
        ):
            dense_gc_candidates(slot_root)

    def test_complete_d_pipeline_and_slot_receipt(self) -> None:
        inventory = self._build()
        manifest_relative = (
            Path(inventory["release_relative"]) / "index-manifest.json"
        ).as_posix()
        with (
            patch("kwrag.slot_mount._require_readonly_mount", lambda _path: None),
            patch("kwrag.crawler_source.os.ST_RDONLY", _readonly_flag(), create=True),
            patch(
                "kwrag.crawler_source.os.statvfs",
                return_value=SimpleNamespace(f_flag=_readonly_flag()),
                create=True,
            ),
        ):
            scope = load_slot_index_scope(
                self.package, manifest_relative, require_readonly=True
            )
            pipeline = SharedGpuDensePipeline(
                scope,
                self.client,
                allow_nonproduction_release=True,
            )
            try:
                raw = pipeline.search("dense evidence", ["room-a"], 2)
                self.assertTrue(raw["hits"])
                evidence = slot_pipeline_evidence(raw, len(raw["hits"]), 1)
                self.assertEqual(evidence["status"], "available")
                self.assertEqual(
                    evidence["data_boundary"]["external_persistence"],
                    "attested_none",
                )
                with tempfile.TemporaryDirectory() as receipts:
                    app = SlotSearchApplication(
                        pipeline=pipeline,
                        scope=scope,
                        pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
                        receipt_writer=ReceiptWriter(Path(receipts) / "slot.jsonl"),
                    )
                    response = app.search(
                        {
                            "schema_version": "kwrag-slot-search-request-v1",
                            "query": "dense evidence",
                            "request_id": "slot-request-1",
                            "operation_id": "slot-operation-1",
                            "run_id": None,
                            "attempt": 1,
                            "max_results": 2,
                            "corpus": "room-a",
                        }
                    )
                    self.assertEqual(response["result_status"], "hits")
                    self.assertEqual(response["operation_receipt"]["status"], "written")
            finally:
                pipeline.close()

    def test_dense_release_has_no_source_generation_admission(self) -> None:
        inventory = self._build()
        manifest_relative = (
            Path(inventory["release_relative"]) / "index-manifest.json"
        ).as_posix()
        manifest = loads_canonical_json_bytes(
            (self.package / manifest_relative).read_bytes()
        )
        extension = manifest["kwrag_dense"]
        self.assertNotIn("source_generation_id", extension)
        self.assertNotIn("source_generation_manifest_sha256", extension)
        self.assertNotIn("source_database_sha256", extension)


if __name__ == "__main__":
    unittest.main()
