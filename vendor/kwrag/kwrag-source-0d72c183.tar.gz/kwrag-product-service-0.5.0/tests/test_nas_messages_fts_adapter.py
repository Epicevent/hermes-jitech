from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from kwrag.engines.nas_messages_fts_v1 import (
    AttachmentSemanticsUnresolved,
    NasMessagesFtsAdapter,
    NasMessagesFtsError,
)


def _sha256(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _make_package(
    root: Path,
    *,
    rows: list[tuple[str, str, str]],
    membership_rooms: list[str],
    corrupt_fts_identity: bool = False,
    attachment_file_name: str | None = None,
) -> tuple[Path, Path, dict]:
    package = root / "package"
    package.mkdir()
    database = package / "messages.sqlite"
    with sqlite3.connect(database) as connection:
        connection.executescript(
            """
            CREATE TABLE messages (
              conversation_id TEXT NOT NULL,
              message_id TEXT NOT NULL,
              room_name TEXT,
              request_id TEXT,
              user_id TEXT,
              user_name TEXT,
              sent_time INTEGER,
              text_kind TEXT NOT NULL,
              plain_text TEXT,
              decrypt_status TEXT,
              PRIMARY KEY (conversation_id, message_id)
            );
            CREATE INDEX idx_user_messages_room
              ON messages(conversation_id);
            CREATE INDEX idx_user_messages_sent
              ON messages(sent_time);
            CREATE TABLE attachments (
              conversation_id TEXT NOT NULL,
              message_id TEXT NOT NULL,
              block_index INTEGER NOT NULL,
              block_type TEXT,
              file_name TEXT,
              mime_type TEXT,
              nas_path TEXT,
              PRIMARY KEY (conversation_id, message_id, block_index)
            );
            CREATE VIRTUAL TABLE messages_fts USING fts5(
              plain_text,
              user_name,
              room_name,
              file_name,
              conversation_id UNINDEXED,
              message_id UNINDEXED,
              tokenize='unicode61'
            );
            """
        )
        for index, (room, message_id, text) in enumerate(rows, 1):
            cursor = connection.execute(
                """
                INSERT INTO messages(
                  conversation_id,message_id,room_name,request_id,user_id,
                  user_name,sent_time,text_kind,plain_text,decrypt_status
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    room,
                    message_id,
                    "Room " + room,
                    "request-" + message_id,
                    "user-1",
                    "User One",
                    index,
                    "text",
                    text,
                    "ok",
                ),
            )
            fts_message_id = (
                "mismatched-message"
                if corrupt_fts_identity and index == 1
                else message_id
            )
            connection.execute(
                """
                INSERT INTO messages_fts(
                  rowid,plain_text,user_name,room_name,file_name,
                  conversation_id,message_id
                ) VALUES(?,?,?,?,?,?,?)
                """,
                (
                    cursor.lastrowid,
                    text,
                    "User One",
                    "Room " + room,
                    attachment_file_name or "",
                    room,
                    fts_message_id,
                ),
            )
        if attachment_file_name is not None:
            # The observed crawler schema provides no proven foreign-key
            # meaning for attachments.message_id.  Preserve that ambiguity in
            # the fixture instead of inventing a join.
            connection.execute(
                """
                INSERT INTO attachments(
                  conversation_id,message_id,block_index,block_type,
                  file_name,mime_type,nas_path
                ) VALUES(?,?,?,?,?,?,?)
                """,
                (
                    rows[0][0],
                    "attachment-object-1",
                    0,
                    "file",
                    attachment_file_name,
                    "application/octet-stream",
                    "/opaque/test/path",
                ),
            )

    membership = package / "membership.json"
    membership.write_text(
        json.dumps(
            {
                "schema": "kw-corpus-nas-user",
                "updated_at": "2026-08-05T00:00:00+00:00",
                "user_id": "fixture-user",
                "conversation_ids": membership_rooms,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        encoding="utf-8",
    )
    database.chmod(0o400)
    membership.chmod(0o400)
    binding = {
        "databaseSha256": _sha256(database),
        "membershipSha256": _sha256(membership),
        "authority": {
            "mode": "offline_fixture_read_only",
            "readOnlyObserved": True,
            "receiptDigest": "sha256:" + "1" * 64,
        },
    }
    return database, membership, binding


class NasMessagesFtsAdapterTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def test_membership_is_applied_at_the_returned_message_row(self) -> None:
        database, membership, binding = _make_package(
            self.root,
            rows=[
                ("room-allowed", "message-allowed", "needle allowed text"),
                ("room-denied", "message-denied", "needle denied text"),
            ],
            membership_rooms=["room-allowed"],
        )
        before = _sha256(database)
        with NasMessagesFtsAdapter(database, membership, binding) as adapter:
            hits = adapter.search_messages("needle", limit=10)
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0].conversation_id, "room-allowed")
        self.assertEqual(hits[0].message_id, "message-allowed")
        self.assertEqual(hits[0].text, "needle allowed text")
        self.assertEqual(_sha256(database), before)
        self.assertFalse(database.with_name("messages.sqlite-wal").exists())
        self.assertFalse(database.with_name("messages.sqlite-shm").exists())

    def test_fts_row_must_link_to_the_exact_message_identity(self) -> None:
        database, membership, binding = _make_package(
            self.root,
            rows=[("room-allowed", "message-1", "needle text")],
            membership_rooms=["room-allowed"],
            corrupt_fts_identity=True,
        )
        with self.assertRaisesRegex(
            NasMessagesFtsError, "fts_message_linkage_invalid"
        ):
            NasMessagesFtsAdapter(database, membership, binding)

    def test_attachment_search_is_not_silently_defined(self) -> None:
        database, membership, binding = _make_package(
            self.root,
            rows=[("room-allowed", "message-1", "ordinary message text")],
            membership_rooms=["room-allowed"],
            attachment_file_name="attachmentneedle.bin",
        )
        with NasMessagesFtsAdapter(database, membership, binding) as adapter:
            self.assertEqual(adapter.search_messages("attachmentneedle"), [])
            with self.assertRaisesRegex(
                AttachmentSemanticsUnresolved,
                "attachment_search_semantics_unresolved",
            ):
                adapter.search_attachments("attachmentneedle")


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        print(
            "KWRAG_NAS_MESSAGES_FTS_ADAPTER_SELFTEST=PASS "
            "cases=3 sqlite_created=fixture_only nas_write=0 "
            "membership_row_filter=1 fts_message_linkage=1 "
            "attachment_semantics=blocked"
        )
    raise SystemExit(0 if result.wasSuccessful() else 1)
