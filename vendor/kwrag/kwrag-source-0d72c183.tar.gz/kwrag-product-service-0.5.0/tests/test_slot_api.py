import json
from dataclasses import replace
from pathlib import Path

import pytest

from kwrag.jsonutil import canonical_json_bytes
from kwrag.operation import OperationError, ReceiptWriter
from kwrag.slot_api import SlotSearchApplication
from kwrag.slot_consumer import SlotConsumptionError, verify_slot_search_exchange
from kwrag.slot_mount import SlotMountError, load_slot_index_scope

REQUEST_SCHEMA = "kwrag-slot-search-request-v1"


@pytest.fixture(autouse=True)
def _read_only_mount_fixture(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("kwrag.slot_mount._require_readonly_mount", lambda _path: None)


class Pipeline:
    def __init__(self, returned_room: str = "alpha"):
        self.returned_room = returned_room
        self.calls: list[tuple[str, list[str], int]] = []

    def search(self, query: str, rooms: list[str], k: int):
        self.calls.append((query, rooms, k))
        return {
            "hits": [
                {
                    "room": self.returned_room,
                    "level": "segment",
                    "seg_id": 7,
                    "text": "mounted result",
                    "score": 0.75,
                    "message_ids": ["m1"],
                }
            ],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": "fixture-backend-v1",
                "stages": [
                    {
                        "stage_id": "index_lookup",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": 1,
                        "model": None,
                        "revision": None,
                    }
                ],
                "candidate_count": 1,
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }


def _scope(tmp_path: Path, *, require_readonly: bool = True):
    mount = tmp_path / "nas_docs"
    index = mount / "kw" / "index"
    index.mkdir(parents=True)
    vector = index / "room_123.npy"
    database = index / "room_123.meta.sqlite"
    vector.write_bytes(b"vectors")
    database.write_bytes(b"database")
    import hashlib

    def entry(path: Path):
        data = path.read_bytes()
        return {
            "path": path.name,
            "bytes": len(data),
            "sha256": "sha256:" + hashlib.sha256(data).hexdigest(),
        }

    raw = {
        "version": 1,
        "release_id": "slot-release-1",
        "created_at": "2026-07-27T00:00:00Z",
        "corpus_snapshot": "package-1",
        "embedding_fingerprint": "sha256:" + "1" * 64,
        "rooms": {
            "alpha": {
                "conversation_id": "123",
                "files": [entry(vector), entry(database)],
            }
        },
    }
    manifest = index / "index-manifest.json"
    manifest.write_bytes(canonical_json_bytes(raw))
    return load_slot_index_scope(
        mount.resolve(),
        "kw/index/index-manifest.json",
        require_readonly=require_readonly,
    )


def _application(tmp_path: Path, *, returned_room: str = "alpha"):
    pipeline = Pipeline(returned_room)
    app = SlotSearchApplication(
        pipeline=pipeline,
        scope=_scope(tmp_path),
        pipeline_fingerprint="sha256:" + "2" * 64,
        receipt_writer=ReceiptWriter(tmp_path / "runtime" / "receipts.jsonl"),
    )
    return app, pipeline


def test_slot_search_uses_mounted_manifest_without_token_projection(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    ready = app.ready()
    response = app.search(
        {
            "schema_version": REQUEST_SCHEMA,
            "query": "mounted query",
            "request_id": "req-1",
            "max_results": 2,
        }
    )

    assert ready["authorization_basis"] == "slot_mounted_storage"
    assert "schema_version" not in ready
    assert "projection_digest" not in ready
    assert pipeline.calls == [("mounted query", ["alpha"], 2)]
    assert response["authorization_basis"] == "slot_mounted_storage"
    assert response["schema_version"] == "kwrag-slot-search-response-v1"
    assert response["results"][0]["corpus"] == "alpha"
    assert "token" not in json.dumps(response)

    receipt = json.loads((tmp_path / "runtime" / "receipts.jsonl").read_text())
    assert receipt["schema_version"] == "kwrag-slot-search-operation-receipt-v1"
    assert receipt["authorization_basis"] == "slot_mounted_storage"
    assert receipt["corpora"] == ["alpha"]
    assert "projection_digest" not in receipt
    assert "slot_id" not in receipt
    assert "instance_id" not in receipt
    assert "mounted query" not in (
        tmp_path / "runtime" / "receipts.jsonl"
    ).read_text()


def test_minimal_request_is_retrieval_valid_but_not_consumption_eligible(
    tmp_path: Path,
) -> None:
    app, pipeline = _application(tmp_path)
    request = {"schema_version": REQUEST_SCHEMA, "query": "minimal request"}

    exchange = app.search_exchange(request)

    assert exchange.response["result_status"] == "hits"
    assert pipeline.calls == [("minimal request", ["alpha"], 5)]
    with pytest.raises(SlotConsumptionError, match="request fields are invalid"):
        verify_slot_search_exchange(
            request,
            exchange.response,
            exchange.operation_receipt,
            expected_index_manifest=app.scope.manifest.digest,
            expected_pipeline_fingerprint=app.pipeline_fingerprint,
            max_result_characters=1_000,
        )


@pytest.mark.parametrize("field", ["token", "slot_id", "instance_id", "grant", "corpora"])
def test_slot_search_rejects_fields_that_can_reconstruct_a_grant(
    tmp_path: Path, field: str
):
    app, pipeline = _application(tmp_path)

    with pytest.raises(OperationError, match="outside the slot-local contract"):
        app.search({"schema_version": REQUEST_SCHEMA, "query": "q", field: "injected"})

    assert pipeline.calls == []


def test_slot_search_cannot_request_or_return_an_unmounted_room(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    with pytest.raises(OperationError) as requested:
        app.search({"schema_version": REQUEST_SCHEMA, "query": "q", "corpus": "beta"})
    assert requested.value.code == "outside_mounted_scope"
    assert pipeline.calls == []

    bad_app, bad_pipeline = _application(tmp_path / "second", returned_room="beta")
    with pytest.raises(OperationError) as returned:
        bad_app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})
    assert returned.value.code == "not_ready"
    assert bad_pipeline.calls == [("q", ["alpha"], 5)]


def test_slot_search_rejects_snapshot_identity_drift_before_pipeline(
    tmp_path: Path,
) -> None:
    app, pipeline = _application(tmp_path)
    app.scope.manifest_path.unlink()
    app.scope.manifest_path.write_bytes(b"replaced")

    with pytest.raises(OperationError) as rejected:
        app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})

    assert rejected.value.code == "not_ready"
    assert pipeline.calls == []


def test_slot_search_discards_results_when_snapshot_drifts_during_pipeline(
    tmp_path: Path,
) -> None:
    app, pipeline = _application(tmp_path)
    original = pipeline.search

    def replace_manifest(query: str, rooms: list[str], k: int):
        payload = original(query, rooms, k)
        app.scope.manifest_path.unlink()
        app.scope.manifest_path.write_bytes(b"replaced during search")
        return payload

    pipeline.search = replace_manifest

    with pytest.raises(OperationError) as rejected:
        app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})

    assert rejected.value.code == "not_ready"
    assert rejected.value.retryable is True
    assert pipeline.calls == [("q", ["alpha"], 5)]
    receipt = json.loads((tmp_path / "runtime" / "receipts.jsonl").read_text())
    assert receipt["execution_status"] == "failed"
    assert receipt["result_status"] == "error"
    assert receipt["result_count"] == 0
    assert receipt["result_digest"] is None
    assert receipt["error_code"] == "not_ready"


def test_slot_search_rejects_unknown_fields_even_when_they_look_harmless(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    with pytest.raises(OperationError, match="outside the slot-local contract"):
        app.search(
            {"schema_version": REQUEST_SCHEMA, "query": "q", "future_option": True}
        )

    assert pipeline.calls == []


def test_slot_search_rejects_non_string_corpus_before_pipeline_dispatch(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    with pytest.raises(OperationError, match="corpus must contain"):
        app.search({"schema_version": REQUEST_SCHEMA, "query": "q", "corpus": 123})

    assert pipeline.calls == []


@pytest.mark.parametrize(
    "field,value",
    [
        ("request_id", ""),
        ("request_id", "x" * 129),
        ("request_id", 1),
        ("query", "x" * 4_001),
        ("corpus", ""),
        ("corpus", "x" * 257),
    ],
)
def test_slot_search_rejects_out_of_schema_values_before_dispatch(
    tmp_path: Path, field: str, value: object
):
    app, pipeline = _application(tmp_path)

    with pytest.raises(OperationError) as rejected:
        body = {"schema_version": REQUEST_SCHEMA, "query": "q", field: value}
        app.search(body)

    assert rejected.value.code == "invalid_request"
    assert pipeline.calls == []


def test_slot_search_applies_raw_query_limit_before_stripping(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    response = app.search(
        {"schema_version": REQUEST_SCHEMA, "query": " " + ("q" * 3_998) + " "}
    )
    assert response["result_status"] == "hits"
    assert pipeline.calls == [("q" * 3_998, ["alpha"], 5)]

    with pytest.raises(OperationError) as rejected:
        app.search(
            {"schema_version": REQUEST_SCHEMA, "query": " " + ("q" * 4_000) + " "}
        )

    assert rejected.value.code == "invalid_request"
    assert pipeline.calls == [("q" * 3_998, ["alpha"], 5)]


def test_slot_search_requires_exact_request_schema_before_dispatch(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    for body in (
        {"query": "q"},
        {"schema_version": "kwrag-slot-search-request-v2", "query": "q"},
    ):
        with pytest.raises(OperationError, match="schema_version"):
            app.search(body)

    assert pipeline.calls == []


def test_malformed_pipeline_evidence_is_unavailable_not_zero(tmp_path: Path):
    app, pipeline = _application(tmp_path)

    original = pipeline.search

    def malformed(query: str, rooms: list[str], k: int):
        payload = original(query, rooms, k)
        payload["operation_evidence"]["unexpected"] = "must not leak"
        return payload

    pipeline.search = malformed
    response = app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})
    receipt = json.loads((tmp_path / "runtime" / "receipts.jsonl").read_text())

    assert response["result_status"] == "hits"
    assert receipt["pipeline_evidence"] == {
        "status": "unavailable",
        "schema_version": "kwrag-slot-pipeline-evidence-v1",
        "backend_id": None,
        "stages": [],
        "candidate_count": None,
        "returned_count": 1,
        "corpus_count": 1,
        "data_boundary": {
            "bytes_sent_outside_slot": None,
            "external_persistence": "unavailable",
            "persistence_receipt_digest": None,
        },
    }
    assert receipt["provider_billing"] == {
        "status": "unavailable",
        "amount": None,
        "currency": None,
        "reason": "pipeline_provider_billing_not_attested",
    }
    assert "must not leak" not in (tmp_path / "runtime" / "receipts.jsonl").read_text()


def test_receipt_sink_cannot_be_placed_inside_the_slot_mount(tmp_path: Path):
    scope = _scope(tmp_path)

    with pytest.raises(ValueError, match="outside the read-only slot mount"):
        SlotSearchApplication(
            pipeline=Pipeline(),
            scope=scope,
            pipeline_fingerprint="sha256:" + "2" * 64,
            receipt_writer=ReceiptWriter(scope.mount_root / "receipt.jsonl"),
        )


@pytest.mark.parametrize("readonly_required", [False, 1])
def test_direct_application_rejects_scope_without_exact_readonly_requirement(
    tmp_path: Path, readonly_required: object
) -> None:
    scope = _scope(tmp_path, require_readonly=False)
    scope = replace(scope, readonly_required=readonly_required)
    pipeline = Pipeline()

    with pytest.raises(ValueError, match="must require a read-only mount"):
        SlotSearchApplication(
            pipeline=pipeline,
            scope=scope,
            pipeline_fingerprint="sha256:" + "2" * 64,
            receipt_writer=ReceiptWriter(tmp_path / "runtime" / "receipts.jsonl"),
        )

    assert pipeline.calls == []


def test_direct_application_remeasures_readonly_mount_before_accepting_scope(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    scope = _scope(tmp_path)
    pipeline = Pipeline()

    def rejected(_path: Path) -> None:
        raise SlotMountError("mount is writable")

    monkeypatch.setattr("kwrag.slot_mount._require_readonly_mount", rejected)
    with pytest.raises(ValueError, match="current read-only mount"):
        SlotSearchApplication(
            pipeline=pipeline,
            scope=scope,
            pipeline_fingerprint="sha256:" + "2" * 64,
            receipt_writer=ReceiptWriter(tmp_path / "runtime" / "receipts.jsonl"),
        )

    assert pipeline.calls == []


@pytest.mark.parametrize("max_concurrent", [0, True, 65])
def test_slot_application_rejects_invalid_direct_concurrency_boundary(
    tmp_path: Path, max_concurrent: object
) -> None:
    with pytest.raises(ValueError, match="max_concurrent"):
        SlotSearchApplication(
            pipeline=Pipeline(),
            scope=_scope(tmp_path),
            pipeline_fingerprint="sha256:" + "2" * 64,
            receipt_writer=ReceiptWriter(tmp_path / "runtime" / "receipts.jsonl"),
            max_concurrent=max_concurrent,
        )


def test_shared_stateless_evidence_requires_measured_external_bytes(
    tmp_path: Path,
):
    app, pipeline = _application(tmp_path)
    original = pipeline.search

    def external(query: str, rooms: list[str], k: int):
        payload = original(query, rooms, k)
        evidence = payload["operation_evidence"]
        evidence["stages"][0]["execution_scope"] = "shared_stateless"
        evidence["data_boundary"] = {
            "bytes_sent_outside_slot": 256,
            "external_persistence": "unavailable",
            "persistence_receipt_digest": None,
        }
        return payload

    pipeline.search = external
    app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})
    receipt = json.loads((tmp_path / "runtime" / "receipts.jsonl").read_text())

    assert receipt["pipeline_evidence"]["status"] == "partial"
    assert receipt["pipeline_evidence"]["data_boundary"] == {
        "bytes_sent_outside_slot": 256,
        "external_persistence": "unavailable",
        "persistence_receipt_digest": None,
    }
    assert receipt["provider_billing"]["status"] == "unavailable"


def test_shared_stateless_evidence_requires_exact_persistence_receipt(
    tmp_path: Path,
) -> None:
    app, pipeline = _application(tmp_path)
    original = pipeline.search

    def external(query: str, rooms: list[str], k: int):
        payload = original(query, rooms, k)
        evidence = payload["operation_evidence"]
        evidence["stages"][0]["execution_scope"] = "shared_stateless"
        evidence["data_boundary"] = {
            "bytes_sent_outside_slot": 256,
            "external_persistence": "attested_none",
            "persistence_receipt_digest": "sha256:" + "e" * 64,
        }
        return payload

    pipeline.search = external
    app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})
    receipt = json.loads((tmp_path / "runtime" / "receipts.jsonl").read_text())

    assert receipt["pipeline_evidence"]["status"] == "available"
    assert receipt["pipeline_evidence"]["data_boundary"] == {
        "bytes_sent_outside_slot": 256,
        "external_persistence": "attested_none",
        "persistence_receipt_digest": "sha256:" + "e" * 64,
    }
    assert receipt["provider_billing"]["status"] == "unavailable"


def test_shared_stateless_attestation_without_receipt_digest_is_unavailable(
    tmp_path: Path,
) -> None:
    app, pipeline = _application(tmp_path)
    original = pipeline.search

    def external(query: str, rooms: list[str], k: int):
        payload = original(query, rooms, k)
        evidence = payload["operation_evidence"]
        evidence["stages"][0]["execution_scope"] = "shared_stateless"
        evidence["data_boundary"] = {
            "bytes_sent_outside_slot": 256,
            "external_persistence": "attested_none",
        }
        return payload

    pipeline.search = external
    app.search({"schema_version": REQUEST_SCHEMA, "query": "q"})
    receipt = json.loads((tmp_path / "runtime" / "receipts.jsonl").read_text())

    assert receipt["pipeline_evidence"]["status"] == "unavailable"
    assert receipt["pipeline_evidence"]["data_boundary"] == {
        "bytes_sent_outside_slot": None,
        "external_persistence": "unavailable",
        "persistence_receipt_digest": None,
    }
