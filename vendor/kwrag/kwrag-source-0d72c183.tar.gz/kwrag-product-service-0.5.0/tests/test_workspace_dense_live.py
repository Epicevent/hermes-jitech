"""Live Kakao corpus + disposable Workspace dense-index regression tests."""

from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import tomllib
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

from kwrag.live_kakao import LiveKakaoPackageSource, LiveKakaoSourceError
from kwrag.operation import ReceiptWriteResult, ReceiptWriter
from kwrag.product_runtime import ProductRuntimeError, open_kakao_product_runtime
from kwrag.shared_gpu_core import (
    CallerIdentity,
    SharedGpuCore,
    SharedGpuCoreConfig,
)
from kwrag.shared_gpu_models import NonProductionDeterministicBackend
from kwrag.shared_gpu_transport import (
    ContentFreeGpuJournal,
    InProcessSharedGpuClient,
)
from kwrag.workspace_dense import (
    open_workspace_dense_runtime,
    rebuild_workspace_dense_index,
)


ROOT = Path(__file__).resolve().parents[1]


def _write_package(root: Path, text: str) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "membership.json").write_text(
        json.dumps({"user_id": "7519030", "conversation_ids": ["room-a"]}),
        encoding="utf-8",
    )
    (root / "profile.json").write_text(
        json.dumps({"user_id": "7519030"}), encoding="utf-8"
    )
    database = root / "messages.sqlite"
    if database.exists():
        database.unlink()
    with closing(sqlite3.connect(database)) as connection:
        connection.execute(
            "CREATE TABLE messages("
            "conversation_id TEXT NOT NULL,message_id TEXT NOT NULL,"
            "user_id TEXT,user_name TEXT,sent_time INTEGER,plain_text TEXT)"
        )
        connection.execute(
            "INSERT INTO messages VALUES(?,?,?,?,?,?)",
            ("room-a", "message-1", "user-1", "owner", 1, text),
        )
        connection.commit()


class WorkspaceDenseLiveTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.root = Path(self.temp.name)
        self.package = self.root / "nas_docs" / "kw" / "package"
        self.workspace = self.root / "workspace" / ".kwrag"
        self.workspace.mkdir(parents=True)
        _write_package(self.package, "live kakao dense evidence")
        self.core = SharedGpuCore(
            NonProductionDeterministicBackend(8),
            SharedGpuCoreConfig(allow_nonproduction_backend=True),
        )
        self.core.start()
        caller = CallerIdentity(
            slot="kakao",
            principal=f"uid:{getattr(os, 'geteuid', lambda: 0)()}",
            peer_uid=getattr(os, "geteuid", lambda: 0)(),
            peer_gid=getattr(os, "getegid", lambda: 0)(),
        )
        self.client = InProcessSharedGpuClient(
            core=self.core,
            caller=caller,
            journal=ContentFreeGpuJournal(self.root / "gpu.jsonl"),
        )

    def tearDown(self) -> None:
        self.core.shutdown(grace_seconds=1)
        self.temp.cleanup()

    def _rebuild(self) -> dict:
        with patch("kwrag.live_kakao._require_readonly", lambda _path: None):
            return rebuild_workspace_dense_index(
                package_root=self.package,
                workspace_root=self.workspace / "dense",
                slot_namespace="kakao",
                gpu=self.client,
                allow_nonproduction=True,
            )

    def _open(self):
        with patch("kwrag.live_kakao._require_readonly", lambda _path: None):
            return open_workspace_dense_runtime(
                package_root=self.package,
                slot_root=self.workspace / "dense" / "kakao",
                gpu=self.client,
                receipt_writer=ReceiptWriter(self.root / "search.jsonl"),
                allow_nonproduction_release=True,
            )

    def test_live_package_builds_workspace_index_and_runs_dense_rerank(self) -> None:
        self._rebuild()
        runtime = self._open()
        try:
            with patch("kwrag.live_kakao._require_readonly", lambda _path: None):
                exchange = runtime.search_exchange(
                    {
                        "schema_version": "kwrag-slot-search-request-v1",
                        "query": "live kakao dense evidence",
                        "request_id": "request-1",
                        "operation_id": "operation-1",
                        "run_id": None,
                        "attempt": 1,
                        "max_results": 2,
                        "corpus": None,
                    }
                )
            self.assertEqual(exchange.response["result_status"], "hits")
            stages = exchange.operation_receipt["pipeline_evidence"]["stages"]
            self.assertEqual(
                [stage["stage_id"] for stage in stages],
                ["query_embedding", "dense_index_search", "candidate_rerank"],
            )
            self.assertEqual(stages[2]["call_count"], 1)
            with patch.object(
                self.client.journal.writer,
                "write",
                return_value=ReceiptWriteResult(status="unavailable", digest=None),
            ), patch("kwrag.live_kakao._require_readonly", lambda _path: None):
                unjournaled = runtime.search_exchange(
                    {
                        "schema_version": "kwrag-slot-search-request-v1",
                        "query": "live kakao dense evidence",
                        "max_results": 2,
                    }
                )
            self.assertEqual(unjournaled.response["result_status"], "hits")
            boundary = unjournaled.operation_receipt["pipeline_evidence"][
                "data_boundary"
            ]
            self.assertEqual(boundary["external_persistence"], "unavailable")
            self.assertIsNone(boundary["persistence_receipt_digest"])
        finally:
            runtime.close()

    def test_product_runtime_opens_the_workspace_dense_pipeline(self) -> None:
        self._rebuild()
        with (
            patch("kwrag.live_kakao._require_readonly", lambda _path: None),
            patch("kwrag.product_runtime._gpu_client", return_value=self.client),
        ):
            runtime = open_kakao_product_runtime(
                package_root=self.package,
                workspace_root=self.workspace,
                slot_namespace="kakao",
                socket_path=self.root / "unused.sock",
                receipt_path=self.workspace / "receipts" / "product-search.jsonl",
                gpu_receipt_path=self.workspace / "receipts" / "product-gpu.jsonl",
                _allow_nonproduction_release=True,
            )
            try:
                exchange = runtime.search_exchange(
                    {
                        "schema_version": "kwrag-slot-search-request-v1",
                        "query": "live kakao dense evidence",
                        "max_results": 2,
                    }
                )
            finally:
                runtime.close()
        self.assertEqual(exchange.response["result_status"], "hits")
        self.assertFalse(hasattr(runtime.identity, "source_generation"))
        self.assertEqual(
            [
                stage["stage_id"]
                for stage in exchange.operation_receipt["pipeline_evidence"]["stages"]
            ],
            ["query_embedding", "dense_index_search", "candidate_rerank"],
        )

    def test_product_runtime_rejects_a_workspace_escape_before_gpu_setup(self) -> None:
        with patch("kwrag.product_runtime._gpu_client") as gpu_client:
            with self.assertRaisesRegex(ProductRuntimeError, "slot_namespace_invalid"):
                open_kakao_product_runtime(
                    package_root=self.package,
                    workspace_root=self.workspace,
                    slot_namespace="../oc20",
                    socket_path=self.root / "unused.sock",
                    receipt_path=self.workspace / "receipts" / "product-search.jsonl",
                    gpu_receipt_path=self.workspace / "receipts" / "product-gpu.jsonl",
                )
        gpu_client.assert_not_called()

    def test_normal_source_rewrite_skips_only_stale_candidate(self) -> None:
        self._rebuild()
        _write_package(self.package, "replacement text after crawler refresh")
        runtime = self._open()
        try:
            with patch("kwrag.live_kakao._require_readonly", lambda _path: None):
                exchange = runtime.search_exchange(
                    {
                        "schema_version": "kwrag-slot-search-request-v1",
                        "query": "old indexed evidence",
                        "max_results": 2,
                    }
                )
            self.assertEqual(exchange.response["result_status"], "zero_hits")
            self.assertEqual(exchange.response["results"], [])
        finally:
            runtime.close()

    def test_membership_replacement_is_zero_hits_not_an_outage(self) -> None:
        self._rebuild()
        (self.package / "membership.json").write_text(
            json.dumps({"user_id": "7519030", "conversation_ids": ["room-b"]}),
            encoding="utf-8",
        )
        runtime = self._open()
        try:
            with patch("kwrag.live_kakao._require_readonly", lambda _path: None):
                exchange = runtime.search_exchange(
                    {
                        "schema_version": "kwrag-slot-search-request-v1",
                        "query": "live kakao dense evidence",
                        "max_results": 2,
                    }
                )
            self.assertEqual(exchange.response["result_status"], "zero_hits")
            self.assertEqual(exchange.response["results"], [])
        finally:
            runtime.close()

    def test_product_import_does_not_load_legacy_generation_admission(self) -> None:
        code = (
            "import sys;"
            f"sys.path.insert(0,{str(ROOT / 'src')!r});"
            "import kwrag.product_runtime;"
            "assert 'kwrag.crawler_source' not in sys.modules;"
            "assert 'kwrag.fixed_producer' not in sys.modules;"
            "assert 'kwrag.crawler_fixed_producer' not in sys.modules"
        )
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_product_wheel_exposes_only_the_shared_gpu_service_command(self) -> None:
        project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
        self.assertEqual(
            project["project"]["scripts"],
            {"kwrag-shared-gpu": "kwrag.shared_gpu_service:main"},
        )
        self.assertEqual(
            project["tool"]["setuptools"]["package-data"]["kwrag"],
            ["engine_artifacts/shared-gpu-contract-v1.json"],
        )

    def test_live_snapshot_rejects_unbounded_data_before_materialization(self) -> None:
        limits = {
            "MAX_SOURCE_MESSAGES": 0,
            "MAX_SOURCE_MESSAGE_UTF8_BYTES": 1,
            "MAX_SOURCE_TOTAL_UTF8_BYTES": 1,
        }
        for name, value in limits.items():
            with self.subTest(limit=name), patch(
                "kwrag.live_kakao._require_readonly", lambda _path: None
            ), patch(f"kwrag.live_kakao.{name}", value):
                source = LiveKakaoPackageSource(self.package)
                try:
                    with self.assertRaisesRegex(
                        LiveKakaoSourceError, "source_snapshot_unbounded"
                    ):
                        source.message_snapshot()
                finally:
                    source.close()


if __name__ == "__main__":
    unittest.main()
