"""Harmless standalone probe for the slot receipt publication boundary."""

from __future__ import annotations

import argparse
import hashlib
import os
import stat
import sys
import tempfile
import types
from pathlib import Path

_PACKAGE_ROOT = Path(__file__).resolve().parents[1] / "src" / "kwrag"
_package = types.ModuleType("kwrag")
_package.__path__ = [str(_PACKAGE_ROOT)]
sys.modules["kwrag"] = _package

from kwrag.operation import ReceiptWriter


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _expect_unavailable(path: Path, entry: dict[str, object]) -> None:
    result = ReceiptWriter(path).write(entry)
    if result.status != "unavailable" or result.digest is not None:
        raise AssertionError("negative receipt fixture did not fail closed")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-posix", action="store_true")
    args = parser.parse_args()
    if args.require_posix and os.name != "posix":
        raise SystemExit("POSIX_RECEIPT_PROBE=FAIL reason=POSIX is required")

    negative_controls = 0
    with tempfile.TemporaryDirectory(prefix="kwrag-receipt-probe-") as raw:
        root = Path(raw).resolve()
        sink = root / "private" / "nested" / "receipts.jsonl"
        first = ReceiptWriter(sink).write({"sequence": 1})
        second = ReceiptWriter(sink).write({"sequence": 2})
        expected = b'{"sequence":1}\n{"sequence":2}\n'
        if (
            first.status != "written"
            or second.status != "written"
            or sink.read_bytes() != expected
            or first.digest != _digest(b'{"sequence":1}')
            or second.digest != _digest(b'{"sequence":2}')
            or not stat.S_ISREG(sink.stat().st_mode)
            or sink.stat().st_nlink != 1
        ):
            raise SystemExit("POSIX_RECEIPT_PROBE=FAIL reason=positive fixture drift")

        if os.name == "posix":
            if stat.S_IMODE(sink.stat().st_mode) != 0o600:
                raise SystemExit("POSIX_RECEIPT_PROBE=FAIL reason=leaf mode drift")

            outside_parent = root / "outside-parent"
            outside_parent.mkdir()
            linked_parent = root / "linked-parent"
            linked_parent.symlink_to(outside_parent, target_is_directory=True)
            _expect_unavailable(linked_parent / "receipt.jsonl", {"safe": True})
            if (outside_parent / "receipt.jsonl").exists():
                raise AssertionError("symlinked parent received a receipt")
            negative_controls += 1

            outside_leaf = root / "outside-leaf.jsonl"
            outside_leaf.write_bytes(b"")
            outside_leaf.chmod(0o600)
            leaf_parent = root / "leaf-parent"
            leaf_parent.mkdir()
            (leaf_parent / "receipt.jsonl").symlink_to(outside_leaf)
            _expect_unavailable(leaf_parent / "receipt.jsonl", {"safe": True})
            if outside_leaf.read_bytes() != b"":
                raise AssertionError("symlinked leaf received a receipt")
            negative_controls += 1

            loose = root / "loose.jsonl"
            loose.write_bytes(b"")
            loose.chmod(0o640)
            _expect_unavailable(loose, {"safe": True})
            if loose.read_bytes() != b"":
                raise AssertionError("loose-mode leaf received a receipt")
            negative_controls += 1

            hardlink = root / "hardlink.jsonl"
            hardlink.hardlink_to(loose)
            loose.chmod(0o600)
            _expect_unavailable(loose, {"safe": True})
            if loose.read_bytes() != b"" or hardlink.read_bytes() != b"":
                raise AssertionError("multi-link leaf received a receipt")
            negative_controls += 1

        print(
            "POSIX_RECEIPT_PROBE=PASS "
            f"platform={os.name} positive_controls=1 "
            f"negative_controls={negative_controls} canonical_append=yes "
            "customer_data_read=no network_requests=0 persistent_writes=0"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
