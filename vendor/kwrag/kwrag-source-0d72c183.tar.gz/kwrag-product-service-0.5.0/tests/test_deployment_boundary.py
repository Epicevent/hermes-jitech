from __future__ import annotations

import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
_SELF_GUARD_TEST = "test_local_root_action_dependency_guard_catches_path_expressions"
_PATH_CONSTRUCTORS = {"Path", "PurePath", "PurePosixPath", "PureWindowsPath"}
_PATH_CONSTRUCTOR_MARKER = "<path-constructor>"
_PATH_JOIN_MARKER = "<path-join>"
_PATH_MODULE_MARKER = "<path-module>"


def _join_candidates(parts: list[set[str]]) -> set[str]:
    candidates = {""}
    for values in parts:
        if not values:
            return set()
        candidates = {
            "/".join(part.strip("/\\") for part in (prefix, value) if part)
            for prefix in candidates
            for value in values
        }
    return candidates


def _path_candidates(node: ast.AST, bindings: dict[str, set[str]]) -> set[str]:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return {node.value}
    if isinstance(node, ast.Name):
        return bindings.get(node.id, set())
    if isinstance(node, ast.Attribute):
        if node.attr in {"parent", "parents"}:
            return _path_candidates(node.value, bindings)
        return bindings.get(node.attr, set())
    if isinstance(node, ast.Subscript):
        return _path_candidates(node.value, bindings)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        return _join_candidates(
            [_path_candidates(node.left, bindings), _path_candidates(node.right, bindings)]
        )
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _path_candidates(node.left, bindings)
        right = _path_candidates(node.right, bindings)
        if not left or not right:
            return set()
        return {prefix + suffix for prefix in left for suffix in right}
    if isinstance(node, ast.JoinedStr):
        parts: list[set[str]] = []
        for value in node.values:
            if isinstance(value, ast.FormattedValue):
                parts.append(_path_candidates(value.value, bindings) or {"<dynamic>"})
            elif isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append({value.value})
            else:
                return set()
        candidates = {""}
        for values in parts:
            if not values:
                return set()
            candidates = {
                prefix + value for prefix in candidates for value in values
            }
        return candidates
    if not isinstance(node, ast.Call):
        return set()

    if isinstance(node.func, ast.Name) and (
        node.func.id in _PATH_CONSTRUCTORS
        or _PATH_CONSTRUCTOR_MARKER in bindings.get(node.func.id, set())
    ):
        return _join_candidates(
            [_path_candidates(argument, bindings) for argument in node.args]
        )
    if (
        isinstance(node.func, ast.Attribute)
        and node.func.attr in _PATH_CONSTRUCTORS
    ):
        return _join_candidates(
            [_path_candidates(argument, bindings) for argument in node.args]
        )
    if isinstance(node.func, ast.Attribute) and node.func.attr == "resolve":
        return _path_candidates(node.func.value, bindings)
    if isinstance(node.func, ast.Attribute) and node.func.attr == "joinpath":
        return _join_candidates(
            [_path_candidates(node.func.value, bindings)]
            + [_path_candidates(argument, bindings) for argument in node.args]
        )
    if (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == "join"
        and isinstance(node.func.value, ast.Attribute)
        and node.func.value.attr == "path"
    ):
        return _join_candidates(
            [_path_candidates(argument, bindings) for argument in node.args]
        )
    if (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == "join"
        and isinstance(node.func.value, ast.Name)
        and _PATH_MODULE_MARKER in bindings.get(node.func.value.id, set())
    ):
        return _join_candidates(
            [_path_candidates(argument, bindings) for argument in node.args]
        )
    if (
        isinstance(node.func, ast.Name)
        and _PATH_JOIN_MARKER in bindings.get(node.func.id, set())
    ):
        return _join_candidates(
            [_path_candidates(argument, bindings) for argument in node.args]
        )
    return set()


def _is_local_root_action(candidate: str) -> bool:
    normalized = candidate.replace("\\", "/")
    return "deploy/root/" in normalized and normalized.endswith(".sh")


def _collect_bindings(
    statements: list[ast.stmt], inherited: dict[str, set[str]] | None = None
) -> dict[str, set[str]]:
    bindings = dict(inherited or {})
    for statement in statements:
        if not isinstance(statement, (ast.Assign, ast.AnnAssign)):
            continue
        value = statement.value
        if value is None:
            continue
        candidates = _path_candidates(value, bindings)
        targets = statement.targets if isinstance(statement, ast.Assign) else [statement.target]
        for target in targets:
            if isinstance(target, ast.Name):
                bindings[target.id] = candidates
            elif isinstance(target, ast.Attribute):
                bindings[target.attr] = candidates
    return bindings


def _root_action_dependencies(
    source: str, *, exempt_functions: frozenset[str] = frozenset()
) -> list[str]:
    tree = ast.parse(source)
    import_bindings: dict[str, set[str]] = {}
    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            for imported in node.names:
                local_name = imported.asname or imported.name
                if node.module == "pathlib" and imported.name in _PATH_CONSTRUCTORS:
                    import_bindings[local_name] = {_PATH_CONSTRUCTOR_MARKER}
                elif (
                    node.module in {"os.path", "posixpath", "ntpath"}
                    and imported.name == "join"
                ):
                    import_bindings[local_name] = {_PATH_JOIN_MARKER}
        elif isinstance(node, ast.Import):
            for imported in node.names:
                if imported.name not in {"os.path", "posixpath", "ntpath"}:
                    continue
                local_name = imported.asname or imported.name.split(".", 1)[0]
                import_bindings[local_name] = {_PATH_MODULE_MARKER}
    module_bindings = _collect_bindings(
        tree.body, {"ROOT": {""}, "__file__": {""}, **import_bindings}
    )
    class_bindings = {
        node.name: _collect_bindings(node.body, module_bindings)
        for node in tree.body
        if isinstance(node, ast.ClassDef)
    }

    dependencies: list[str] = []
    module_statements = [
        node
        for node in tree.body
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
    ]
    if any(
        _is_local_root_action(candidate)
        for statement in module_statements
        for expression in ast.walk(statement)
        if isinstance(expression, ast.expr)
        for candidate in _path_candidates(expression, module_bindings)
    ):
        dependencies.append("<module>")
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name in exempt_functions:
            continue
        bindings = dict(module_bindings)
        parent_class = next(
            (
                class_node
                for class_node in tree.body
                if isinstance(class_node, ast.ClassDef) and node in class_node.body
            ),
            None,
        )
        if parent_class is not None:
            bindings.update(class_bindings[parent_class.name])
        bindings = _collect_bindings(node.body, bindings)
        if any(
            _is_local_root_action(candidate)
            for expression in ast.walk(node)
            if isinstance(expression, ast.expr)
            for candidate in _path_candidates(expression, bindings)
        ):
            dependencies.append(node.name)
    return dependencies


def _is_test_python_source(path: Path) -> bool:
    return path.suffix == ".py"


def _tracked_test_paths() -> list[Path]:
    try:
        completed = subprocess.run(
            ["git", "-C", str(ROOT), "ls-files", "--", "tests"],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return sorted(
            path
            for path in (ROOT / "tests").rglob("*.py")
            if _is_test_python_source(path)
        )
    return [
        ROOT / relative
        for relative in completed.stdout.splitlines()
        if relative and _is_test_python_source(Path(relative))
    ]


def test_compose_keeps_the_service_private_and_least_privileged() -> None:
    text = (ROOT / "deploy" / "compose.yaml").read_text(encoding="utf-8")

    assert "ports:" not in text
    assert "read_only: true" in text
    assert "cap_drop:" in text and "- ALL" in text
    assert "no-new-privileges:true" in text
    assert "KWRAG_GPU_UID:?" in text and "KWRAG_GPU_GID:?" in text
    assert "network_mode: none" in text
    assert "kwrag_net" not in text
    assert "KWRAG_INDEX" not in text and "TOKEN_PROJECTION" not in text
    assert text.count("read_only: true") >= 3


def test_deployment_runbook_matches_shared_gpu_and_slot_boundaries() -> None:
    text = (ROOT / "deploy" / "README.md").read_text(encoding="utf-8")

    assert "product slots remain separate, GPU-free, model-free" in text
    assert "receives no NAS mount" in text
    assert "`network_mode: none`" in text
    assert "never stores copied source text" in text
    assert "does not install" in text


def test_publishable_examples_contain_no_live_operational_identifiers() -> None:
    grant = json.loads(
        (ROOT / "deploy" / "grant-export.example.json").read_text(encoding="utf-8")
    )
    rooms = json.loads(
        (ROOT / "deploy" / "rooms.example.json").read_text(encoding="utf-8")
    )
    examples = json.dumps({"grant": grant, "rooms": rooms}, sort_keys=True)

    assert {item["slot_id"] for item in grant["grants"]} == {
        "example-openclaw",
        "example-hermes",
    }
    assert all(item["corpora"] == ["corpus-a"] for item in grant["grants"])
    assert set(rooms) == {"corpus-a", "corpus-b"}
    assert all(value.startswith("<room-id-") for value in rooms.values())
    assert not re.search(r"\b\d{7,}\b", examples)
    assert not re.search(r"/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/", examples)

    source = dict(grant["source"])
    authoritative_digest = source.pop("authoritative_state_digest")
    canonical = json.dumps(
        source, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    assert authoritative_digest == "sha256:" + hashlib.sha256(canonical).hexdigest()
    assert grant["source_ref"].endswith(authoritative_digest)


def test_runtime_ops_contract_fixes_ownership_and_fail_closed_boundaries() -> None:
    text = (ROOT.parents[0] / "contracts" / "kwrag-runtime-ops-v1.md").read_text(
        encoding="utf-8"
    )
    normalized = " ".join(text.split())

    assert "Hermes and OpenClaw product code are outside this contract" in normalized
    assert "previously cached projection is not used as fallback" in normalized
    assert (
        "Imperative `docker network connect` is not an accepted steady state"
        in normalized
    )
    assert "Restoring an older projection is forbidden" in normalized
    assert "external_network_absent" in normalized
    assert "`instance_id` values" in normalized
    assert "validity is 300–3600 seconds" in normalized
    assert "authoritative_state_digest" in normalized
    assert "kwrag-projection-publication-intent/v1" in normalized
    assert "kwrag-client-env-receipt/v1" in normalized
    assert "kwrag-network-plan/v1" in normalized
    assert "kwrag-a1-proof/v1" in normalized
    assert "kwrag-a2-proof/v1" in normalized
    assert "kwrag-promotion-approval/v1" in normalized
    assert "/srv/openclaw-ops/kwrag-attachments.json" in normalized
    assert "same `generated_at` and exact same `projection_digest`" in normalized
    assert "jsonutil.canonical_json_bytes" in normalized
    assert 'grp.getgrnam("kwrag_rt").gr_gid' in normalized
    assert "host root mount, user, and NSS namespaces" in normalized


def test_runtime_ops_contract_fixes_client_env_proof_and_promotion_exactness() -> None:
    text = (ROOT.parents[0] / "contracts" / "kwrag-runtime-ops-v1.md").read_text(
        encoding="utf-8"
    )
    normalized = " ".join(text.split())

    for field in (
        "env_file_dev",
        "env_file_inode",
        "env_file_size",
        "env_file_mtime_ns",
        "projection_publication_receipt_digest",
        "kwrag-compose-action-transcript/v1",
        "daemon_id_before",
        "daemon_id_after",
        "terminal_cursor",
        "kwrag-promotion-post-state/v1",
        "post_state_measurement_digest",
    ):
        assert field in normalized

    assert (
        "`complete`, `incomplete`, `daemon_changed`, `gap`, `timeout`, or `error`"
        in normalized
    )
    assert "`a1_connectivity`, `a2_enable`, `a2_disable`, or `a2_restore`" in normalized
    assert (
        "`passed`, `failed`, `incomplete`, `cancelled`, or `indeterminate`"
        in normalized
    )
    assert "/srv/kwrag-product/runtime/proofs/a1/<action_id>.json" in normalized
    assert "/srv/openclaw-ops/kwrag/proofs/a2/<action_id>.json" in normalized
    assert "idempotent verification, not one-time consumption" in normalized
    assert "`action_transcript_digest=null`" in normalized

    enable_checks = (
        "`compose_apply_succeeded`, `runtime_manifest_match`, "
        "`replacement_container_match`, `client_env_reference_present`, "
        "`network_plan_match`, `network_attachment_match`, "
        "`action_transcript_complete`, `healthz`, `readyz`, `authorized_search`"
    )
    disable_checks = (
        "`compose_apply_succeeded`, `runtime_manifest_attachment_absent`, "
        "`replacement_container_match`, `replacement_container_network_absent`, "
        "`env_reference_absent`, `action_transcript_complete`"
    )
    assert enable_checks in normalized
    assert disable_checks in normalized

    promotion_record_fields = {
        "instance_id",
        "a1_proof_digest",
        "a2_proof_type",
        "a2_proof_digest",
        "post_state_measurement_digest",
    }
    record = {
        "instance_id": "00000000-0000-0000-0000-000000000001",
        "a1_proof_digest": "sha256:" + "1" * 64,
        "a2_proof_type": "a2_enable",
        "a2_proof_digest": "sha256:" + "2" * 64,
        "post_state_measurement_digest": "sha256:" + "3" * 64,
    }
    assert set(record) == promotion_record_fields
    assert record["a2_proof_type"] in {"a2_enable", "a2_restore"}

    required_post_state_checks = (
        "`current_approvals`, `current_images`, `current_runtime_manifest`, "
        "`current_network_attachment`, `current_projection`, `proof_binding_match`"
    )
    assert required_post_state_checks in normalized


def test_search_contract_separates_retrieval_receipts_from_product_consumption() -> (
    None
):
    contract = (ROOT.parents[0] / "contracts" / "conversation-search-v1.md").read_text(
        encoding="utf-8"
    )
    runbook = (ROOT / "deploy" / "README.md").read_text(encoding="utf-8")
    normalized = " ".join(contract.split())

    assert "kwrag-search-operation-receipt/v1" in normalized
    assert "provider_billing.status=not_applicable" in normalized
    assert "It must never be rendered as `$0`" in normalized
    assert "KWRAG preserves repeated `operation_id` values" in normalized
    assert (
        "It does not claim provider retry, fallback, or exactly-once deduplication"
        in normalized
    )
    for status in (
        "not_requested",
        "request_failed",
        "timeout_completion_unknown",
        "completed_zero_hits",
        "completed_hits_not_consumed",
        "completed_hits_consumed",
        "partial_consumption",
        "invalid_result",
    ):
        assert f"`{status}`" in normalized
    assert "KWRAG owns raw result digest and retrieval statistics" in normalized
    assert "the prompt-assembling product owns injected token accounting" in normalized
    assert "KWRAG attests retrieval, not prompt consumption" in runbook
    assert "HTTP success or a non-empty hit list alone cannot be reported" in runbook


def test_publishable_tests_do_not_depend_on_local_root_action_scripts() -> None:
    offenders: list[str] = []

    for path in _tracked_test_paths():
        exemptions = (
            frozenset({_SELF_GUARD_TEST})
            if path.resolve() == Path(__file__).resolve()
            else frozenset()
        )
        offenders.extend(
            f"{path.name}:{name}"
            for name in _root_action_dependencies(
                path.read_text(encoding="utf-8"), exempt_functions=exemptions
            )
        )

    assert offenders == []


def test_local_root_action_dependency_guard_catches_path_expressions() -> None:
    assert _root_action_dependencies(
        'def test_split():\n    ROOT / "deploy" / "root" / "04a-private-action.sh"'
    ) == ["test_split"]
    assert _root_action_dependencies(
        'ACTION = "service/deploy/root/04a-private-action.sh"\n'
        "def test_module_constant():\n    assert ACTION\n"
    ) == ["<module>", "test_module_constant"]
    assert _root_action_dependencies(
        'def test_publishable():\n    ROOT / "deploy" / "compose.yaml"'
    ) == []
    assert _root_action_dependencies(
        'BASE = "deploy/root"\nACTION = "04a-private-action.sh"\n'
        'def test_joined():\n    Path(BASE) / ACTION\n'
    ) == ["test_joined"]
    assert _root_action_dependencies(
        'class TestDeployment:\n'
        '    ACTION = "deploy/root/04a-private-action.sh"\n'
        '    def test_class_binding(self):\n'
        '        assert self.ACTION\n'
    ) == ["test_class_binding"]
    assert _root_action_dependencies(
        'def test_unrelated():\n'
        '    deploy = "deploy"\n'
        '    root = "root"\n'
        '    script = "safe-example.sh"\n'
        '    assert deploy and root and script\n'
    ) == []
    assert _root_action_dependencies(
        'ROOT = Path(__file__).resolve().parents[1]\n'
        'def test_real_project_root():\n'
        '    Path(ROOT, "deploy", "root", "04a-private-action.sh")\n'
    ) == ["test_real_project_root"]
    assert _root_action_dependencies(
        'def test_qualified_path():\n'
        '    pathlib.Path(ROOT, "deploy", "root", "04a-private-action.sh")\n'
    ) == ["test_qualified_path"]
    assert _root_action_dependencies(
        'def test_dynamic_name(name):\n'
        '    ROOT / "deploy" / "root" / f"{name}.sh"\n'
    ) == ["test_dynamic_name"]
    assert _root_action_dependencies(
        'def test_concatenated_name():\n'
        '    ROOT / "deploy" / "root" / ("04a-private-action" + ".sh")\n'
    ) == ["test_concatenated_name"]
    assert _root_action_dependencies(
        'from pathlib import PurePath as P\n'
        'def test_path_alias():\n'
        '    P(ROOT, "deploy", "root", "04a-private-action.sh")\n'
    ) == ["test_path_alias"]
    assert _root_action_dependencies(
        'from os.path import join as path_join\n'
        'def test_join_alias():\n'
        '    path_join(ROOT, "deploy", "root", "04a-private-action.sh")\n'
    ) == ["test_join_alias"]
    assert _root_action_dependencies(
        'import os.path as path_module\n'
        'def test_module_alias():\n'
        '    path_module.join(ROOT, "deploy", "root", "04a-private-action.sh")\n'
    ) == ["test_module_alias"]
    assert _root_action_dependencies(
        'ACTION = (ROOT / "deploy" / "root" / "04a-private-action.sh").read_text()\n'
    ) == ["<module>"]


def test_tracked_test_universe_covers_every_python_helper_and_conftest() -> None:
    assert _is_test_python_source(Path("tests/test_deploy.py"))
    assert _is_test_python_source(Path("tests/sub/deployment_test.py"))
    assert _is_test_python_source(Path("tests/conftest.py"))
    assert _is_test_python_source(Path("tests/helpers/deployment.py"))
    assert not _is_test_python_source(Path("tests/test_deploy.txt"))
