from __future__ import annotations

import hashlib
import json
import stat
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

from kwrag.auth import ProjectionError, ProjectionStore, load_projection
from kwrag.jsonutil import canonical_json_bytes
from kwrag.manifest import ManifestError, load_and_verify_manifest

INSTANCE_ID = "00000000-0000-0000-0000-000000000001"

def _sha256(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _write_canonical(path: Path, value: object) -> None:
    path.write_bytes(canonical_json_bytes(value))


def _manifest(tmp_path: Path) -> tuple[Path, Path]:
    index = tmp_path / "index"
    index.mkdir()
    vector = index / "room_123.npy"
    database = index / "room_123.meta.sqlite"
    vector.write_bytes(b"vectors")
    database.write_bytes(b"database")
    raw = {
        "version": 1,
        "release_id": "release-1",
        "corpus_snapshot": "snapshot-1",
        "embedding_fingerprint": "sha256:" + "a" * 64,
        "rooms": {
            "alpha": {
                "conversation_id": "123",
                "files": [
                    {"path": vector.name, "sha256": _sha256(vector)},
                    {"path": database.name, "sha256": _sha256(database)},
                ],
            }
        },
    }
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(raw), encoding="utf-8")
    return path, index


def test_manifest_verifies_every_file(tmp_path: Path) -> None:
    path, index = _manifest(tmp_path)
    manifest = load_and_verify_manifest(path, index)

    assert manifest.rooms == {"alpha": "123"}
    assert manifest.digest.startswith("sha256:")

    (index / "room_123.npy").write_bytes(b"changed")
    with pytest.raises(ManifestError, match="digest mismatch"):
        load_and_verify_manifest(path, index)


def test_manifest_rejects_path_escape(tmp_path: Path) -> None:
    path, index = _manifest(tmp_path)
    raw = json.loads(path.read_text(encoding="utf-8"))
    outside = tmp_path / "outside"
    outside.write_bytes(b"outside")
    raw["rooms"]["alpha"]["files"] = [
        {"path": "../outside", "sha256": _sha256(outside)}
    ]
    path.write_text(json.dumps(raw), encoding="utf-8")

    with pytest.raises(ManifestError, match="escaping"):
        load_and_verify_manifest(path, index)


def test_projection_is_bound_to_active_manifest(tmp_path: Path) -> None:
    path = tmp_path / "projection.json"
    token = "t" * 32
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    _write_canonical(
        path,
        {
            "version": 1,
            "index_manifest": "sha256:" + "a" * 64,
            "source_digest": "sha256:" + "b" * 64,
            "generated_at": generated.isoformat(),
            "expires_at": (generated + timedelta(minutes=15)).isoformat(),
            "tokens": {
                token: {
                    "instance_id": INSTANCE_ID,
                    "slot_id": "example-slot",
                    "corpora": ["alpha"],
                }
            },
        },
    )

    projection = load_projection(path, "sha256:" + "a" * 64)
    assert projection.authorize(token).slot_id == "example-slot"
    assert projection.projection_digest == _sha256(path)

    with pytest.raises(ProjectionError, match="active index"):
        load_projection(path, "sha256:" + "c" * 64)

    raw = json.loads(path.read_text(encoding="utf-8"))
    raw["generated_at"] = (generated - timedelta(hours=1)).isoformat()
    raw["expires_at"] = (generated - timedelta(minutes=45)).isoformat()
    _write_canonical(path, raw)
    with pytest.raises(ProjectionError, match="expired"):
        load_projection(path, "sha256:" + "a" * 64)


def test_projection_store_reloads_atomic_replacement_and_fails_closed(tmp_path: Path) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0)

    def write(token: str, source: str, offset_seconds: int = 0) -> None:
        published = generated + timedelta(seconds=offset_seconds)
        replacement = path.with_suffix(".tmp")
        _write_canonical(
            replacement,
            {
                "version": 1,
                "index_manifest": manifest,
                "source_digest": source,
                "generated_at": published.isoformat(),
                "expires_at": (published + timedelta(minutes=15)).isoformat(),
                "tokens": {
                    token: {
                        "instance_id": INSTANCE_ID,
                        "slot_id": "slot",
                        "corpora": ["alpha"],
                    }
                },
            },
        )
        replacement.replace(path)

    first_token = "f" * 32
    second_token = "s" * 32
    write(first_token, "sha256:" + "b" * 64)
    store = ProjectionStore(path, manifest)
    assert store.current().authorize(first_token) is not None

    write(second_token, "sha256:" + "c" * 64, 1)
    refreshed = store.current()
    assert refreshed.authorize(first_token) is None
    assert refreshed.authorize(second_token) is not None

    replacement = path.with_suffix(".tmp")
    replacement.write_text("not-json", encoding="utf-8")
    replacement.replace(path)
    with pytest.raises(ProjectionError):
        store.current()

    write(first_token, "sha256:" + "d" * 64, 2)
    recovered = store.current()
    assert recovered.authorize(first_token) is not None
    assert recovered.authorize(second_token) is None


def test_projection_store_rejects_symlink_replacement(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "projection.json"
    path.write_text("{}", encoding="utf-8")
    original_lstat = Path.lstat

    def report_symlink(candidate: Path):
        if candidate == path:
            return SimpleNamespace(st_mode=stat.S_IFLNK)
        return original_lstat(candidate)

    monkeypatch.setattr(Path, "lstat", report_symlink)

    store = ProjectionStore(path, "sha256:" + "a" * 64)
    with pytest.raises(ProjectionError, match="regular file"):
        store.current()


def test_projection_rejects_future_generated_at(tmp_path: Path) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0) + timedelta(minutes=2)
    _write_canonical(
        path,
        {
            "version": 1,
            "index_manifest": manifest,
            "source_digest": "sha256:" + "b" * 64,
            "generated_at": generated.isoformat(),
            "expires_at": (generated + timedelta(minutes=15)).isoformat(),
            "tokens": {
                "a" * 32: {
                    "instance_id": INSTANCE_ID,
                    "slot_id": "slot",
                    "corpora": ["alpha"],
                }
            },
        },
    )

    with pytest.raises(ProjectionError, match="in the future"):
        load_projection(path, manifest)


def test_projection_accepts_revoke_all_and_store_rejects_rollback(tmp_path: Path) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0)

    def publish(at: datetime, token: str | None) -> None:
        replacement = path.with_suffix(".tmp")
        tokens = {}
        if token is not None:
            tokens[token] = {
                "instance_id": INSTANCE_ID,
                "slot_id": "slot",
                "corpora": ["alpha"],
            }
        _write_canonical(
            replacement,
            {
                "version": 1,
                "index_manifest": manifest,
                "source_digest": "sha256:" + "b" * 64,
                "generated_at": at.isoformat(),
                "expires_at": (at + timedelta(minutes=15)).isoformat(),
                "tokens": tokens,
            },
        )
        replacement.replace(path)

    token = "r" * 32
    publish(generated, token)
    store = ProjectionStore(path, manifest)
    assert store.current().authorize(token) is not None

    publish(generated + timedelta(seconds=1), None)
    revoked = store.current()
    assert revoked.grants == {}
    assert revoked.authorize(token) is None

    publish(generated, token)
    with pytest.raises(ProjectionError, match="not monotonic"):
        store.current()


def test_projection_store_allows_idempotent_same_generation_republish(
    tmp_path: Path,
) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    payload = {
        "version": 1,
        "index_manifest": manifest,
        "source_digest": "sha256:" + "b" * 64,
        "generated_at": generated.isoformat(),
        "expires_at": (generated + timedelta(minutes=15)).isoformat(),
        "tokens": {},
    }
    _write_canonical(path, payload)
    store = ProjectionStore(path, manifest)
    first = store.current()

    replacement = path.with_suffix(".tmp")
    _write_canonical(replacement, payload)
    replacement.replace(path)
    second = store.current()

    assert second.generated_at == first.generated_at
    assert second.projection_digest == first.projection_digest


def test_projection_rejects_noncanonical_raw_bytes(tmp_path: Path) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    payload = {
        "version": 1,
        "index_manifest": manifest,
        "source_digest": "sha256:" + "b" * 64,
        "generated_at": generated.isoformat(),
        "expires_at": (generated + timedelta(minutes=15)).isoformat(),
        "tokens": {},
    }
    canonical = canonical_json_bytes(payload)
    variants = (
        b"\xef\xbb\xbf" + canonical,
        canonical + b"\n",
        canonical + b" ",
        json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"),
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
    )
    for variant in variants:
        path.write_bytes(variant)
        with pytest.raises(ProjectionError, match="not canonical"):
            load_projection(path, manifest)

    path.write_bytes(b'{"value":NaN}')
    with pytest.raises(ProjectionError, match="not canonical"):
        load_projection(path, manifest)

    path.write_bytes(b'{"value":"\\ud800"}')
    with pytest.raises(ProjectionError, match="not canonical"):
        load_projection(path, manifest)


def test_projection_store_rejects_same_generation_different_canonical_bytes(
    tmp_path: Path,
) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    payload = {
        "version": 1,
        "index_manifest": manifest,
        "source_digest": "sha256:" + "b" * 64,
        "generated_at": generated.isoformat(),
        "expires_at": (generated + timedelta(minutes=15)).isoformat(),
        "tokens": {},
    }
    _write_canonical(path, payload)
    store = ProjectionStore(path, manifest)
    store.current()

    changed = dict(payload, source_digest="sha256:" + "c" * 64)
    replacement = path.with_suffix(".tmp")
    _write_canonical(replacement, changed)
    replacement.replace(path)
    with pytest.raises(ProjectionError, match="conflicts with the active bytes"):
        store.current()


def test_projection_rejects_unknown_fields_and_duplicate_slots(tmp_path: Path) -> None:
    path = tmp_path / "projection.json"
    manifest = "sha256:" + "a" * 64
    generated = datetime.now(timezone.utc).replace(microsecond=0)
    raw = {
        "version": 1,
        "index_manifest": manifest,
        "source_digest": "sha256:" + "b" * 64,
        "generated_at": generated.isoformat(),
        "expires_at": (generated + timedelta(minutes=15)).isoformat(),
        "tokens": {
            "a" * 32: {
                "instance_id": INSTANCE_ID,
                "slot_id": "same",
                "corpora": ["alpha"],
            },
            "b" * 32: {
                "instance_id": "00000000-0000-0000-0000-000000000002",
                "slot_id": "same",
                "corpora": ["alpha"],
            },
        },
    }
    _write_canonical(path, raw)
    with pytest.raises(ProjectionError, match="duplicate slot"):
        load_projection(path, manifest)

    raw["tokens"] = {
        "a" * 32: {
            "instance_id": INSTANCE_ID,
            "slot_id": "slot-a",
            "corpora": ["alpha"],
        },
        "b" * 32: {
            "instance_id": INSTANCE_ID,
            "slot_id": "slot-b",
            "corpora": ["alpha"],
        },
    }
    _write_canonical(path, raw)
    with pytest.raises(ProjectionError, match="duplicate instance"):
        load_projection(path, manifest)

    raw["unexpected"] = True
    _write_canonical(path, raw)
    with pytest.raises(ProjectionError, match="unknown fields"):
        load_projection(path, manifest)
