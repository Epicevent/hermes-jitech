from __future__ import annotations

import json
from pathlib import Path

import pytest

from kwrag.config import ConfigError, KwRagConfig
from kwrag.shared_gpu_contract import MODEL_MAX_TOKENS


ROOT = Path(__file__).resolve().parents[2]


def test_measured_rerank_default_and_inactive_return_path_are_explicit() -> None:
    config = KwRagConfig()
    shared_gpu = json.loads(
        (ROOT / "service" / "deploy" / "shared-gpu.example.json").read_text(
            encoding="utf-8"
        )
    )

    assert config.rerank.max_length == MODEL_MAX_TOKENS == 512
    assert shared_gpu["embedding_batch_size"] == 32
    assert shared_gpu["rerank_batch_size"] == 16

    config.merge({"rerank": {"max_length": 2_048}})
    config.validate()
    assert config.rerank.max_length == 2_048


def test_fingerprints_are_stable_and_separate() -> None:
    first = KwRagConfig()
    second = KwRagConfig()

    assert first.embedding_fingerprint() == second.embedding_fingerprint()
    assert first.pipeline_fingerprint() == second.pipeline_fingerprint()

    second.rerank.max_length += 1
    assert first.embedding_fingerprint() == second.embedding_fingerprint()
    assert first.pipeline_fingerprint() != second.pipeline_fingerprint()


def test_unknown_configuration_is_rejected() -> None:
    config = KwRagConfig()

    with pytest.raises(ConfigError, match="unknown configuration fields"):
        config.merge({"surprise": True})

    with pytest.raises(ConfigError, match="unknown embedding fields"):
        config.merge({"embedding": {"surprise": True}})


def test_mutable_model_revision_is_rejected() -> None:
    config = KwRagConfig()
    config.embedding.revision = "main"

    with pytest.raises(ConfigError, match="immutable"):
        config.validate()
