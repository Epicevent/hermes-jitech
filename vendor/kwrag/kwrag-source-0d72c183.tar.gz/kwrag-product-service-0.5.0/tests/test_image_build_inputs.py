from __future__ import annotations

import re
import shutil
from pathlib import Path

from tools.build_input_manifest import FIXED_INPUTS, build_manifest


ROOT = Path(__file__).resolve().parents[1]
DOCKERFILE = ROOT / "Dockerfile"
PINS = ROOT / "requirements.arm64-pins.txt"
LOCK = ROOT / "requirements.arm64.lock"
BASE_DIGEST = "sha256:afc139a0a640942491ec481ad8dda10f2c5b753f5c969393b12480155fe15a63"


def _pins(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("--hash="):
            continue
        line = line.removesuffix("\\").rstrip()
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^\s]+)", line)
        assert match is not None, line
        normalized = re.sub(r"[-_.]+", "-", match.group(1)).lower()
        assert normalized not in result
        result[normalized] = match.group(2)
    return result


def test_lock_covers_every_exact_proven_pin_with_hashes() -> None:
    text = LOCK.read_text(encoding="utf-8")

    assert _pins(LOCK) == _pins(PINS)
    assert len(_pins(LOCK)) >= 50
    assert not re.search(r"(x86_64|amd64|win32|win_amd64|macosx)", text, flags=re.IGNORECASE)
    assert re.search(r"^torch==2\.13\.0 \\\n    --hash=sha256:[0-9a-f]{64}$", text, flags=re.MULTILINE)
    for block in re.split(r"(?=^# )", text, flags=re.MULTILINE):
        if not block.strip():
            continue
        assert re.search(r"^# .+\.whl", block)
        assert re.search(r"^[A-Za-z0-9_.-]+==[^\s]+ \\$", block, flags=re.MULTILINE)
        assert re.search(r"^    --hash=sha256:[0-9a-f]{64}(?: \\)?$", block, flags=re.MULTILINE)


def test_dockerfile_has_immutable_arm64_reproducibility_guards() -> None:
    text = DOCKERFILE.read_text(encoding="utf-8")

    assert f"python:3.12.3-slim@{BASE_DIGEST}" in text
    assert f'org.opencontainers.image.base.digest="{BASE_DIGEST}"' in text
    assert "KWRAG_SOURCE_REVISION must be a 40-character lowercase Git commit" in text
    assert "KWRAG_BUILD_INPUT_DIGEST must be an immutable sha256 digest" in text
    assert "--require-hashes" in text
    assert "--no-build-isolation --no-deps" in text
    assert text.count("python -m pip check") == 2
    assert "platform.machine()=='aarch64'" in text
    assert "sys.version_info[:3]==(3,12,3)" in text
    assert "torch.version.cuda=='13.0'" in text
    for forbidden in ("apt ", "apt-get", "curl ", "wget "):
        assert forbidden not in text


def test_build_input_manifest_is_deterministic_and_content_addressed(tmp_path: Path) -> None:
    context = tmp_path / "service"
    context.mkdir()
    for name in FIXED_INPUTS:
        shutil.copy2(ROOT / name, context / name)
    shutil.copytree(ROOT / "src", context / "src")

    first = build_manifest(context)
    second = build_manifest(context)
    assert first == second
    assert re.fullmatch(r"sha256:[0-9a-f]{64}", str(first["build_input_digest"]))
    assert {item["path"] for item in first["files"]} >= {
        ".dockerignore",
        "Dockerfile",
        "pyproject.toml",
        "requirements.arm64.lock",
        "src/kwrag/service.py",
    }

    service_file = context / "src" / "kwrag" / "service.py"
    service_file.write_bytes(service_file.read_bytes() + b"\n")
    assert build_manifest(context)["build_input_digest"] != first["build_input_digest"]


def test_docker_context_excludes_non_image_worktree_content() -> None:
    text = (ROOT / ".dockerignore").read_text(encoding="utf-8")

    assert text.startswith("**\n")
    for included in (
        "!Dockerfile",
        "!.dockerignore",
        "!pyproject.toml",
        "!requirements.arm64.lock",
        "!src/",
        "!src/**",
    ):
        assert included in text
