from __future__ import annotations

import ast
import copy
import hashlib
import json
import os
import socket
import sqlite3
import stat
import sys
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

import kwrag.fixed_producer as fixed
import kwrag.slot_mount as slot_mount
from kwrag.jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from kwrag.operation import OperationError
from kwrag.slot_runtime import SlotRuntimeError


def _digest_bytes(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _digest_file(path: Path) -> str:
    return _digest_bytes(path.read_bytes())


@contextmanager
def _readonly_attestation():
    original = slot_mount._require_readonly_mount
    observed: list[Path] = []

    def attest(path: Path) -> None:
        observed.append(Path(path).resolve(strict=True))

    slot_mount._require_readonly_mount = attest
    try:
        yield observed
    finally:
        slot_mount._require_readonly_mount = original


class FixedProducerFixture:
    def __init__(
        self,
        *,
        enabled: bool = True,
        rows: list[tuple[str, list[str]]] | None = None,
    ):
        self.temporary = tempfile.TemporaryDirectory(
            prefix="kwrag-fixed-producer-test-"
        )
        self.root = Path(self.temporary.name).resolve()
        self.mount = self.root / "slot" / "nas"
        self.index = self.mount / "package"
        self.index.mkdir(parents=True)
        self.database = self.index / "alpha.sqlite3"
        self.source_snapshot = self.index / "alpha-source-snapshot.json"
        self.manifest_path = self.index / "index-manifest.json"
        self.binding_path = self.root / "run" / "fixed-producer-binding.json"
        self.operation_receipt_path = self.root / "runtime" / "operation.jsonl"
        self.producer_receipt_path = self.root / "runtime" / "producer.jsonl"
        self._create_database(
            rows
            if rows is not None
            else [
                ("orion marker exact-slot evidence", ["alpha-source-1"]),
                ("unrelated material", ["alpha-source-2"]),
            ]
        )
        self.source_snapshot.write_bytes(
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-source-snapshot-v1",
                    "snapshot": _digest_bytes(b"alpha-source-snapshot"),
                }
            )
        )
        self.database_digest = _digest_file(self.database)
        self.source_snapshot_digest = _digest_file(self.source_snapshot)
        corpus_snapshot = _digest_bytes(
            canonical_json_bytes({"alpha": self.source_snapshot_digest})
        )
        self.manifest = {
            "version": 1,
            "release_id": "fixed-producer-fixture-v1",
            "corpus_snapshot": corpus_snapshot,
            "embedding_fingerprint": "sha256:" + "e" * 64,
            "rooms": {
                "alpha": {
                    "conversation_id": "fixture-alpha",
                    "files": [
                        {
                            "path": self.database.name,
                            "sha256": self.database_digest,
                        },
                        {
                            "path": self.source_snapshot.name,
                            "sha256": self.source_snapshot_digest,
                        },
                    ],
                }
            },
        }
        self._write_manifest()
        self.binding = {
            "schema_version": "kwrag-fixed-producer-binding-v1",
            "enabled": enabled,
            "mount_root": self.mount.as_posix(),
            "index_manifest_relative": self.manifest_path.relative_to(
                self.mount
            ).as_posix(),
            "index_manifest_digest": _digest_bytes(
                canonical_json_bytes(self.manifest)
            ),
            "operation_receipt_path": self.operation_receipt_path.as_posix(),
            "producer_receipt_path": self.producer_receipt_path.as_posix(),
            "max_concurrent": 1,
            "selected_engine": fixed._packaged_engine_identity(),
            "corpora": {
                "alpha": {
                    "database_relative": self.database.name,
                    "database_sha256": self.database_digest,
                    "source_snapshot_relative": self.source_snapshot.name,
                    "source_snapshot_digest": self.source_snapshot_digest,
                    "authority_receipt_digest": "sha256:" + "a" * 64,
                }
            },
        }
        self._write_binding()

    def _create_database(self, rows: list[tuple[str, list[str]]]) -> None:
        connection = sqlite3.connect(self.database)
        try:
            connection.execute(
                "CREATE TABLE turns(turn_id INTEGER PRIMARY KEY, text TEXT NOT NULL)"
            )
            connection.execute(
                "CREATE TABLE turn_mids(turn_id INTEGER NOT NULL, mid TEXT NOT NULL)"
            )
            connection.execute(
                "CREATE VIRTUAL TABLE turns_fts USING "
                "fts5(turn_id UNINDEXED, text, tokenize='trigram')"
            )
            for turn_id, (text, source_ids) in enumerate(rows, 1):
                connection.execute(
                    "INSERT INTO turns(turn_id,text) VALUES(?,?)",
                    (turn_id, text),
                )
                connection.execute(
                    "INSERT INTO turns_fts(turn_id,text) VALUES(?,?)",
                    (turn_id, text),
                )
                for source_id in source_ids:
                    connection.execute(
                        "INSERT INTO turn_mids(turn_id,mid) VALUES(?,?)",
                        (turn_id, source_id),
                    )
            connection.commit()
        finally:
            connection.close()

    def _write_manifest(self) -> None:
        if self.manifest_path.exists():
            self.manifest_path.chmod(0o600)
        self.manifest_path.write_bytes(canonical_json_bytes(self.manifest))
        self.manifest_path.chmod(0o444)

    def _write_binding(self) -> None:
        self.binding_path.parent.mkdir(parents=True, exist_ok=True)
        if self.binding_path.exists():
            self.binding_path.chmod(0o600)
        self.binding_path.write_bytes(canonical_json_bytes(self.binding))
        self.binding_path.chmod(0o444)

    def request(
        self,
        *,
        query: str = "orion marker",
        corpus: str | None = "alpha",
        max_results: int = 5,
    ) -> dict:
        return {
            "schema_version": "kwrag-slot-search-request-v1",
            "query": query,
            "request_id": "request-fixed-1",
            "operation_id": "operation-fixed-1",
            "run_id": "run-fixed-1",
            "attempt": 1,
            "max_results": max_results,
            "corpus": corpus,
        }

    def request_bytes(self, **kwargs) -> bytes:
        return canonical_json_bytes(self.request(**kwargs))

    def execute(self, **kwargs) -> fixed.FixedProducerExecution:
        return fixed.execute_fixed_producer(
            self.request_bytes(**kwargs),
            binding_path=self.binding_path,
        )

    def receipt_bytes(self) -> bytes:
        output = b""
        for path in (self.operation_receipt_path, self.producer_receipt_path):
            if path.exists():
                output += path.read_bytes()
        return output

    def cleanup(self) -> None:
        self.temporary.cleanup()


@unittest.skipUnless(
    os.name == "posix", "fixed-producer runtime path contract is POSIX-only"
)
class FixedProducerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.fixtures: list[FixedProducerFixture] = []

    def tearDown(self) -> None:
        for fixture in reversed(self.fixtures):
            fixture.cleanup()

    def fixture(self, **kwargs) -> FixedProducerFixture:
        created = FixedProducerFixture(**kwargs)
        self.fixtures.append(created)
        return created

    def test_positive_exact_slot_executes_full_verified_chain(self) -> None:
        fixture = self.fixture()
        before = _digest_file(fixture.database)
        modules_before = set(sys.modules)
        with mock.patch.object(
            socket,
            "socket",
            side_effect=AssertionError("network socket forbidden"),
        ), _readonly_attestation() as observed:
            execution = fixture.execute()
        after = _digest_file(fixture.database)

        output = loads_canonical_json_bytes(execution.output_bytes)
        results = fixed.verify_fixed_producer_output(
            execution.output_bytes,
            execution.producer_receipt,
            request=fixture.request(),
            expected_binding_digest=execution.binding_digest,
        )
        self.assertEqual(before, after)
        self.assertEqual(len(results), 1)
        self.assertIn("orion marker", results[0]["snippet"])
        self.assertEqual(output["consumable"]["results"], results)
        self.assertLessEqual(
            len(execution.output_bytes.decode("utf-8")),
            fixed.MAX_CONSUMABLE_CHARACTERS,
        )
        required_observed = {
            fixture.mount.resolve(),
            fixture.manifest_path.resolve(),
            fixture.database.resolve(),
            fixture.source_snapshot.resolve(),
        }
        self.assertTrue(required_observed.issubset(set(observed)))
        durable = fixture.receipt_bytes()
        self.assertNotIn(b"orion marker", durable)
        self.assertNotIn(b"exact-slot evidence", durable)
        self.assertNotIn(b"alpha-source-1", durable)
        loaded_after = set(sys.modules) - modules_before
        self.assertFalse(
            any(
                name.startswith(("torch", "sentence_transformers", "openai"))
                for name in loaded_after
            )
        )

    def test_zero_hit_is_verified_and_bound(self) -> None:
        fixture = self.fixture()
        with _readonly_attestation():
            execution = fixture.execute(query="nothingmatcheshere")
        output = loads_canonical_json_bytes(execution.output_bytes)
        self.assertEqual(output["consumable"]["result_status"], "zero_hits")
        self.assertEqual(output["consumable"]["results"], [])
        self.assertEqual(execution.producer_receipt["result_count"], 0)

    def test_sibling_corpus_is_rejected_before_pipeline_dispatch(self) -> None:
        fixture = self.fixture()
        with _readonly_attestation(), self.assertRaises(OperationError) as caught:
            fixture.execute(corpus="beta")
        self.assertEqual(caught.exception.code, "outside_mounted_scope")
        self.assertFalse(fixture.operation_receipt_path.exists())
        self.assertFalse(fixture.producer_receipt_path.exists())

    def test_out_of_scope_bound_path_is_rejected(self) -> None:
        fixture = self.fixture()
        fixture.binding["corpora"]["alpha"]["database_relative"] = (
            "../sibling/alpha.sqlite3"
        )
        fixture._write_binding()
        with self.assertRaises(fixed.FixedProducerError) as caught:
            fixed.load_fixed_producer_binding(fixture.binding_path)
        self.assertEqual(caught.exception.code, "relative_path_invalid")

    def test_writable_mount_is_rejected_without_attestation_override(self) -> None:
        fixture = self.fixture()
        with self.assertRaises(SlotRuntimeError):
            fixture.execute()
        self.assertFalse(fixture.operation_receipt_path.exists())
        self.assertFalse(fixture.producer_receipt_path.exists())

    def test_binding_manifest_database_and_source_tamper_are_rejected(self) -> None:
        binding_fixture = self.fixture()
        binding_fixture.binding["selected_engine"]["pipeline_fingerprint"] = (
            "sha256:" + "f" * 64
        )
        binding_fixture._write_binding()
        with self.assertRaises(fixed.FixedProducerError) as binding_caught:
            fixed.load_fixed_producer_binding(binding_fixture.binding_path)
        self.assertEqual(
            binding_caught.exception.code,
            "binding_engine_identity_mismatch",
        )

        manifest_fixture = self.fixture()
        manifest_fixture.manifest["release_id"] = "tampered"
        manifest_fixture._write_manifest()
        with _readonly_attestation(), self.assertRaises(SlotRuntimeError):
            manifest_fixture.execute()

        database_fixture = self.fixture()
        database_fixture.database.chmod(0o600)
        with database_fixture.database.open("ab") as handle:
            handle.write(b"tamper")
        database_fixture.database.chmod(0o444)
        with _readonly_attestation(), self.assertRaises(SlotRuntimeError):
            database_fixture.execute()

        source_fixture = self.fixture()
        source_fixture.source_snapshot.chmod(0o600)
        source_fixture.source_snapshot.write_bytes(b'{"tampered":true}')
        source_fixture.source_snapshot.chmod(0o444)
        with _readonly_attestation(), self.assertRaises(SlotRuntimeError):
            source_fixture.execute()

    def test_result_and_source_exchange_tamper_are_rejected(self) -> None:
        fixture = self.fixture()
        with _readonly_attestation():
            execution = fixture.execute()
        output = loads_canonical_json_bytes(execution.output_bytes)
        original_snippet = output["consumable"]["results"][0]["snippet"]
        output["consumable"]["results"][0]["snippet"] = "x" * len(original_snippet)
        with self.assertRaises(fixed.FixedProducerError) as result_caught:
            fixed.verify_fixed_producer_output(
                canonical_json_bytes(output),
                execution.producer_receipt,
                request=fixture.request(),
                expected_binding_digest=execution.binding_digest,
            )
        self.assertEqual(
            result_caught.exception.code,
            "producer_result_binding_invalid",
        )

        output = loads_canonical_json_bytes(execution.output_bytes)
        output["linkage"]["source_exchange_digest"] = "sha256:" + "f" * 64
        with self.assertRaises(fixed.FixedProducerError) as source_caught:
            fixed.verify_fixed_producer_output(
                canonical_json_bytes(output),
                execution.producer_receipt,
                request=fixture.request(),
                expected_binding_digest=execution.binding_digest,
            )
        self.assertEqual(source_caught.exception.code, "producer_linkage_invalid")

    def test_unknown_and_duplicate_keys_fail_then_valid_request_succeeds(self) -> None:
        fixture = self.fixture()
        unknown = fixture.request()
        unknown["backend"] = "fts5"
        with self.assertRaises(fixed.FixedProducerError) as unknown_caught:
            fixed.execute_fixed_producer(
                canonical_json_bytes(unknown),
                binding_path=fixture.binding_path,
            )
        self.assertEqual(unknown_caught.exception.code, "request_fields_invalid")

        duplicate = (
            b'{"attempt":1,"attempt":1,"corpus":"alpha","max_results":5,'
            b'"operation_id":"operation-fixed-1","query":"orion marker",'
            b'"request_id":"request-fixed-1","run_id":"run-fixed-1",'
            b'"schema_version":"kwrag-slot-search-request-v1"}'
        )
        with self.assertRaises(fixed.FixedProducerError) as duplicate_caught:
            fixed.execute_fixed_producer(
                duplicate,
                binding_path=fixture.binding_path,
            )
        self.assertEqual(duplicate_caught.exception.code, "request_not_canonical")
        self.assertFalse(fixture.operation_receipt_path.exists())

        with _readonly_attestation():
            valid = fixture.execute()
        self.assertTrue(valid.output_bytes)

        binding_fixture = self.fixture()
        binding_fixture.binding["backend"] = "fts5"
        binding_fixture._write_binding()
        with self.assertRaises(fixed.FixedProducerError) as binding_unknown:
            fixed.load_fixed_producer_binding(binding_fixture.binding_path)
        self.assertEqual(
            binding_unknown.exception.code,
            "binding_fields_invalid",
        )

        binding_fixture.binding_path.chmod(0o600)
        binding_fixture.binding_path.write_bytes(
            b'{"schema_version":"kwrag-fixed-producer-binding-v1",'
            b'"schema_version":"kwrag-fixed-producer-binding-v1"}'
        )
        binding_fixture.binding_path.chmod(0o444)
        with self.assertRaises(fixed.FixedProducerError) as binding_duplicate:
            fixed.load_fixed_producer_binding(binding_fixture.binding_path)
        self.assertEqual(
            binding_duplicate.exception.code,
            "binding_not_canonical",
        )

    def test_complete_payload_budget_is_fail_closed_and_content_free(self) -> None:
        rows = []
        for index in range(3):
            prefix = f"budgetmarker {index} "
            rows.append(
                (prefix + chr(ord("a") + index) * (6_500 - len(prefix)), [f"m{index}"])
            )
        fixture = self.fixture(rows=rows)
        with _readonly_attestation(), self.assertRaises(
            fixed.FixedProducerError
        ) as caught:
            fixture.execute(query="budgetmarker", max_results=3)
        self.assertEqual(caught.exception.code, "payload_budget_exceeded")
        self.assertTrue(fixture.operation_receipt_path.exists())
        self.assertTrue(fixture.producer_receipt_path.exists())
        durable = fixture.receipt_bytes()
        self.assertNotIn(b"budgetmarker", durable)
        failure = loads_canonical_json_bytes(
            fixture.producer_receipt_path.read_bytes().rstrip(b"\n")
        )
        self.assertGreater(
            failure["output_characters"],
            fixed.MAX_CONSUMABLE_CHARACTERS,
        )

    def test_disabled_restart_is_nonpersistent_then_enable_is_valid(self) -> None:
        fixture = self.fixture(enabled=False)
        before = _digest_file(fixture.binding_path)
        for _attempt in range(2):
            with self.assertRaises(fixed.FixedProducerError) as caught:
                fixture.execute()
            self.assertEqual(caught.exception.code, "producer_disabled")
        self.assertEqual(before, _digest_file(fixture.binding_path))
        self.assertFalse(fixture.operation_receipt_path.exists())
        self.assertFalse(fixture.producer_receipt_path.exists())

        fixture.binding["enabled"] = True
        fixture._write_binding()
        with _readonly_attestation():
            execution = fixture.execute()
        self.assertTrue(execution.output_bytes)


class FixedProducerPortableBoundaryTests(unittest.TestCase):

    def test_binding_trust_catch_valid_and_fixed_surface_is_local(self) -> None:
        metadata = mock.Mock(st_uid=1200, st_mode=stat.S_IFREG | 0o444)
        with mock.patch.object(fixed.os, "name", "posix"), mock.patch.object(
            fixed.os,
            "geteuid",
            return_value=1200,
            create=True,
        ):
            self.assertTrue(fixed._binding_trust_is_valid(metadata))
            metadata.st_uid = 0
            self.assertTrue(fixed._binding_trust_is_valid(metadata))
            metadata.st_uid = 1201
            self.assertFalse(fixed._binding_trust_is_valid(metadata))
            metadata.st_uid = 1200
            metadata.st_mode = stat.S_IFREG | 0o464
            self.assertFalse(fixed._binding_trust_is_valid(metadata))

        metadata.st_uid = 1200
        metadata.st_mode = stat.S_IFREG | 0o444
        with mock.patch.object(fixed.os, "name", "posix"), mock.patch.object(
            fixed.os,
            "geteuid",
            side_effect=AttributeError("effective uid unavailable"),
            create=True,
        ):
            self.assertFalse(fixed._binding_trust_is_valid(metadata))

        metadata.st_uid = 1201
        metadata.st_mode = stat.S_IFREG | 0o666
        with mock.patch.object(fixed.os, "name", "nt"), mock.patch.object(
            fixed.os,
            "geteuid",
            side_effect=AssertionError("non-POSIX path called os.geteuid"),
            create=True,
        ):
            self.assertTrue(fixed._binding_trust_is_valid(metadata))

        invalid_runtime_paths = (
            "C:/Users/audit/fixed-producer-binding.json",
            "C:relative/fixed-producer-binding.json",
            "C:\\Users\\audit\\fixed-producer-binding.json",
            "/run/kwrag/../fixed-producer-binding.json",
        )
        for value in invalid_runtime_paths:
            with self.subTest(runtime_path=value), self.assertRaises(
                fixed.FixedProducerError
            ) as caught:
                fixed._absolute_posix(value)
            self.assertEqual(caught.exception.code, "absolute_path_invalid")
        fixed_default = "/run/kwrag/fixed-producer-binding.json"
        self.assertEqual(
            fixed._absolute_posix(fixed_default).as_posix(),
            fixed_default,
        )

        root = Path(fixed.__file__).resolve().parent
        imported: set[str] = set()
        for path in (
            Path(fixed.__file__).resolve(),
            root / "engines" / "p1_attachment_fts_v1.py",
        ):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imported.update(alias.name.split(".")[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imported.add(node.module.split(".")[0])
        self.assertTrue(
            {"socket", "subprocess", "requests", "httpx", "openai"}.isdisjoint(
                imported
            )
        )
        self.assertEqual(fixed.DEFAULT_BINDING_PATH.as_posix(), "/run/kwrag/fixed-producer-binding.json")


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if result.wasSuccessful():
        if os.name == "posix":
            print(
                "KWRAG_FIXED_PRODUCER_SELFTEST=PASS "
                f"cases={result.testsRun} actual_sqlite_fts5=1 "
                "search_pipeline=1 slot_application=1 exchange_verifier=1 "
                "model_dispatch=0 provider_dispatch=0 host_ports=0 network=0"
            )
        else:
            passed = result.testsRun - len(result.skipped)
            print(
                "KWRAG_FIXED_PRODUCER_NONPOSIX_BOUNDARY=PASS "
                f"cases={result.testsRun} passed={passed} "
                f"skipped={len(result.skipped)} failed=0 errors=0 "
                "runtime_platform=posix"
            )
    raise SystemExit(0 if result.wasSuccessful() else 1)
