from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from uuid import uuid4

from kwrag.crawler_fixed_producer import execute_crawler_fixed_producer
from kwrag.crawler_source import CanonicalCrawlerSource
from kwrag.dense_pipeline import SharedGpuDensePipeline
from kwrag.dense_release import D_PIPELINE_FINGERPRINT, build_dense_release
from kwrag.jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from kwrag.operation import ReceiptWriter
from kwrag.shared_gpu_core import CallerIdentity, SharedGpuCore, SharedGpuCoreConfig
from kwrag.shared_gpu_models import NonProductionDeterministicBackend
from kwrag.shared_gpu_transport import ContentFreeGpuJournal, InProcessSharedGpuClient
from kwrag.slot_api import SlotSearchApplication
from kwrag.slot_consumer import verify_slot_search_exchange
from kwrag.slot_mount import load_slot_index_scope


_MODULE_PATH = (
    Path(__file__).resolve().parents[1]
    / "crawler-successor"
    / "kw_corpus"
    / "nas"
    / "generation_publish.py"
)
_SPEC = importlib.util.spec_from_file_location(
    "kw_corpus_generation_publish_successor", _MODULE_PATH
)
assert _SPEC is not None and _SPEC.loader is not None
PUBLISHER = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = PUBLISHER
_SPEC.loader.exec_module(PUBLISHER)


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


class _LocalMirrorTransport:
    """Rootless test double for the existing kw_corpus transport methods."""

    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True)
        self.writes: list[str] = []

    def _path(self, remote: str) -> Path:
        if not remote.startswith("/"):
            raise ValueError("remote path must be absolute")
        return self.root / remote.lstrip("/")

    def put_file_atomic(self, local_path: Path, remote_path: str) -> None:
        target = self._path(remote_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(f".{target.name}.upload-{uuid4().hex}")
        shutil.copyfile(local_path, temporary)
        temporary.replace(target)
        self.writes.append(remote_path)

    def write_text_atomic(self, text: str, remote_path: str) -> None:
        target = self._path(remote_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(f".{target.name}.upload-{uuid4().hex}")
        temporary.write_text(text, encoding="utf-8", newline="\n")
        temporary.replace(target)
        self.writes.append(remote_path)

    def read_bytes(self, remote_path: str) -> bytes:
        return self._path(remote_path).read_bytes()

    def list_dir(
        self, remote_dir: str, *, limit: int = 1000, offset: int = 0
    ) -> list[dict]:
        directory = self._path(remote_dir)
        if not directory.is_dir():
            raise FileNotFoundError(directory)
        entries = [
            {"name": child.name, "isdir": child.is_dir()}
            for child in sorted(directory.iterdir())
        ]
        return entries[offset : offset + limit]


def _write_source_package(
    root: Path,
    rows: list[tuple[str, str, str]],
    *,
    membership_rooms: list[str] | None = None,
    tokenizer: str = "unicode61",
    user_id: str = "user-fixture",
) -> None:
    root.mkdir(parents=True, exist_ok=True)
    if tokenizer not in {"unicode61", "porter"}:
        raise ValueError("unsupported fixture tokenizer")
    rooms = membership_rooms or sorted({row[0] for row in rows})
    (root / "membership.json").write_text(
        json.dumps(
            {
                "schema": "kw-corpus-nas-user",
                "user_id": user_id,
                "conversation_ids": rooms,
                "updated_at": "2026-08-05T00:00:00+00:00",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    (root / "profile.json").write_text(
        json.dumps(
            {
                "schema": "kw-corpus-nas-user",
                "user_id": user_id,
                "display_name": "fixture",
                "job_title": None,
                "updated_at": "2026-08-05T00:00:00+00:00",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    database = root / "messages.sqlite"
    if database.exists():
        database.unlink()
    with sqlite3.connect(database) as connection:
        connection.executescript(
            """
            CREATE TABLE messages (
              conversation_id TEXT NOT NULL,
              message_id TEXT NOT NULL,
              room_name TEXT,
              request_id TEXT,
              user_id TEXT,
              user_name TEXT,
              sent_time INTEGER,
              text_kind TEXT NOT NULL,
              plain_text TEXT,
              decrypt_status TEXT,
              PRIMARY KEY (conversation_id, message_id)
            );
            CREATE INDEX idx_user_messages_sent ON messages(sent_time);
            CREATE INDEX idx_user_messages_room ON messages(conversation_id);
            CREATE TABLE attachments (
              conversation_id TEXT NOT NULL,
              message_id TEXT NOT NULL,
              block_index INTEGER NOT NULL,
              block_type TEXT,
              file_name TEXT,
              mime_type TEXT,
              nas_path TEXT,
              PRIMARY KEY (conversation_id, message_id, block_index)
            );
            """
        )
        connection.execute(
            f"CREATE VIRTUAL TABLE messages_fts USING fts5("
            "plain_text,user_name,room_name,file_name,"
            f"conversation_id UNINDEXED,message_id UNINDEXED,tokenize='{tokenizer}')"
        )
        for index, (room, message_id, text) in enumerate(rows, 1):
            connection.execute(
                "INSERT INTO messages VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    room,
                    message_id,
                    f"name-{room}",
                    f"request-{index}",
                    "fixture-user",
                    "fixture-name",
                    index,
                    "text",
                    text,
                    "ok",
                ),
            )
        connection.execute(
            """
            INSERT INTO messages_fts (
              plain_text,user_name,room_name,file_name,conversation_id,message_id
            )
            SELECT plain_text,COALESCE(user_name,''),COALESCE(room_name,''),'',
                   conversation_id,message_id
            FROM messages ORDER BY rowid
            """
        )
    for name in ("membership.json", "messages.sqlite", "profile.json"):
        (root / name).chmod(0o600)


def _make_package_root(transport: _LocalMirrorTransport, remote: str) -> Path:
    path = transport._path(remote)
    path.mkdir(parents=True)
    return path


class _DeterministicProviderSdkStub:
    """Test-only provider boundary; it retains no context or output."""

    def dispatch_current_assistant_turn(
        self, *, kwrag_current_turn_context: bytes
    ) -> str:
        return "assistant-stub:" + hashlib.sha256(kwrag_current_turn_context).hexdigest()[:16]

    def dispatch_current_terminal_turn(
        self, *, kwrag_current_turn_context: bytes
    ) -> str:
        return "terminal-stub:" + hashlib.sha256(kwrag_current_turn_context).hexdigest()[:16]


def _consume_with_literal_interface(
    *,
    interface: str,
    request: dict,
    response: dict,
    operation_receipt: dict,
    index_manifest: str,
    receipt_root: Path,
    model: _DeterministicProviderSdkStub,
) -> tuple[dict, dict]:
    verified = verify_slot_search_exchange(
        request,
        response,
        operation_receipt,
        expected_index_manifest=index_manifest,
        expected_pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
        max_result_characters=20_000,
    )
    context = canonical_json_bytes(
        {
            "schema_version": f"kwrag-{interface}-ephemeral-context-v1",
            "results": verified.results(),
        }
    )
    handoff = {
        "schema_version": f"kwrag-{interface}-provider-sdk-handoff-receipt-v1",
        "status": "accepted",
        "request_id": verified.request_id,
        "operation_id": verified.operation_id,
        "result_digest": verified.result_digest,
        "operation_receipt_digest": verified.operation_receipt_digest,
        "ephemeral_context_sha256": _sha256(context),
        "ephemeral_context_characters": len(context.decode("utf-8")),
        "raw_content_present": False,
    }
    written = ReceiptWriter(receipt_root / f"{interface}-handoff.jsonl").write(handoff)
    assert written.status == "written" and written.digest is not None
    if interface == "openclaw":
        output = model.dispatch_current_assistant_turn(
            kwrag_current_turn_context=context
        )
        terminal_status = "assistant_response"
        terminal_schema = "kwrag-openclaw-assistant-response-receipt-v1"
    elif interface == "hermes":
        output = model.dispatch_current_terminal_turn(
            kwrag_current_turn_context=context
        )
        terminal_status = "terminal_outcome"
        terminal_schema = "kwrag-hermes-terminal-outcome-receipt-v1"
    else:
        raise AssertionError("unknown literal interface")
    terminal = {
        "schema_version": terminal_schema,
        "status": terminal_status,
        "request_id": verified.request_id,
        "provider_handoff_receipt_digest": written.digest,
        "output_sha256": _sha256(output.encode("utf-8")),
        "raw_content_present": False,
    }
    terminal_written = ReceiptWriter(
        receipt_root / f"{interface}-terminal.jsonl"
    ).write(terminal)
    assert terminal_written.status == "written"
    return handoff, terminal


class PublisherBuildTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source-package"
        _write_source_package(
            self.source,
            [
                ("room-a", "m1", "가나다라마 내부 검색 dense evidence"),
                ("room-b", "m2", "separate authorized package content"),
            ],
        )

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_double_build_is_deterministic_and_retains_unicode61(self) -> None:
        first = PUBLISHER.build_generation(self.source, self.root / "build-one")
        second = PUBLISHER.build_generation(self.source, self.root / "build-two")
        self.assertEqual(first.generation_id, second.generation_id)
        self.assertEqual(first.manifest_sha256, second.manifest_sha256)
        for name in PUBLISHER.GENERATION_FILES:
            self.assertEqual(
                (first.generation_dir / name).read_bytes(),
                (second.generation_dir / name).read_bytes(),
            )
        self.assertEqual(
            (first.generation_dir / "membership.json").read_bytes(),
            (self.source / "membership.json").read_bytes(),
        )
        self.assertEqual(
            (first.generation_dir / "profile.json").read_bytes(),
            (self.source / "profile.json").read_bytes(),
        )
        self.assertNotEqual(
            _sha256((first.generation_dir / "messages.sqlite").read_bytes()),
            _sha256((self.source / "messages.sqlite").read_bytes()),
        )
        with sqlite3.connect(first.generation_dir / "messages.sqlite") as connection:
            tokenizers = {
                row[0]: row[1]
                for row in connection.execute(
                    "SELECT name,sql FROM sqlite_master "
                    "WHERE name IN ('messages_fts','messages_fts_trigram')"
                )
            }
            self.assertIn("unicode61", tokenizers["messages_fts"])
            self.assertIn("trigram", tokenizers["messages_fts_trigram"])
            self.assertEqual(
                connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0],
                connection.execute(
                    "SELECT COUNT(*) FROM messages_fts_trigram"
                ).fetchone()[0],
            )
        snapshot = loads_canonical_json_bytes(first.source_snapshot_path.read_bytes())
        self.assertFalse(snapshot["raw_content_present"])
        self.assertFalse(snapshot["source_had_trigram"])

    def test_scope_corruption_tokenizer_sidecar_and_drift_fail_closed(self) -> None:
        _write_source_package(
            self.source,
            [("room-a", "m1", "scope mismatch")],
            membership_rooms=["room-b"],
        )
        with self.assertRaisesRegex(
            PUBLISHER.GenerationPublishError, "membership_database_scope_mismatch"
        ):
            PUBLISHER.build_generation(self.source, self.root / "scope-build")

        _write_source_package(
            self.source, [("room-a", "m1", "wrong tokenizer")], tokenizer="porter"
        )
        with self.assertRaisesRegex(
            PUBLISHER.GenerationPublishError, "compatibility_fts_tokenizer_invalid"
        ):
            PUBLISHER.build_generation(self.source, self.root / "tokenizer-build")

        _write_source_package(self.source, [("room-a", "m1", "sidecar")])
        (self.source / "messages.sqlite-wal").write_bytes(b"unexpected")
        with self.assertRaisesRegex(
            PUBLISHER.GenerationPublishError, "source_database_sidecar_present"
        ):
            PUBLISHER.build_generation(self.source, self.root / "sidecar-build")
        (self.source / "messages.sqlite-wal").unlink()

        (self.source / "messages.sqlite").write_bytes(b"not a sqlite database")
        with self.assertRaisesRegex(
            PUBLISHER.GenerationPublishError, "database_transform_failed"
        ):
            PUBLISHER.build_generation(self.source, self.root / "corrupt-build")

        _write_source_package(self.source, [("room-a", "m1", "drift")])
        original = PUBLISHER._add_trigram

        def mutate_after_copy(database: Path, *, rooms: tuple[str, ...]):
            result = original(database, rooms=rooms)
            membership = self.source / "membership.json"
            membership.write_bytes(membership.read_bytes() + b" ")
            return result

        with patch.object(PUBLISHER, "_add_trigram", side_effect=mutate_after_copy):
            with self.assertRaisesRegex(
                PUBLISHER.GenerationPublishError, "source_changed_after_copy"
            ):
                PUBLISHER.build_generation(self.source, self.root / "drift-build")

    def test_package_selection_is_bounded_before_publication(self) -> None:
        available = ["package-a", "package-b", "package-c"]
        self.assertEqual(
            PUBLISHER.select_package_segments(
                available, ["package-c", "package-a"]
            ),
            ("package-a", "package-c"),
        )
        self.assertEqual(
            PUBLISHER.select_package_segments(available, None), tuple(available)
        )
        for invalid in (
            ["unknown"],
            ["package-a", "package-a"],
            ["../package-a"],
            [],
        ):
            with self.assertRaisesRegex(
                PUBLISHER.GenerationPublishError,
                "requested_package_segments_invalid",
            ):
                PUBLISHER.select_package_segments(available, invalid)

        integration = (
            Path(__file__).resolve().parents[1]
            / "crawler-successor"
            / "kw-corpus-publish-integration.patch"
        ).read_text(encoding="utf-8")
        self.assertIn('user_package_segments=args.package', integration)
        self.assertIn('"--package"', integration)
        self.assertLess(
            integration.index("selected_package_segments = select_package_segments"),
            integration.index("transport = open_transport"),
        )
        self.assertLess(
            integration.index("if folder_seg not in selected_package_set"),
            integration.index('with tempfile.TemporaryDirectory'),
        )
        self.assertNotIn(
            "+                uploaded = upload_tree(transport, local_root, remote_prefix)",
            integration,
        )


class PublisherTransactionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source-package"
        self.transport = _LocalMirrorTransport(self.root / "mirror")
        self.remote = "/kakao-work/users/fixture-package"
        self.package_root = _make_package_root(self.transport, self.remote)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_manifest_last_activation_rollover_retention_and_rollback(self) -> None:
        _write_source_package(
            self.source, [("room-a", "m1", "first 가나다라마 generation")]
        )
        first = PUBLISHER.build_generation(self.source, self.root / "build-one")
        first_receipt = PUBLISHER.publish_generation(
            first, self.transport, self.remote
        )
        self.assertEqual(first_receipt["status"], "ACTIVATED")
        generation_writes = [
            path
            for path in self.transport.writes
            if f"/{first.generation_id}/" in path
        ]
        self.assertEqual(
            [Path(path).name for path in generation_writes],
            [
                "membership.json",
                "messages.sqlite",
                "profile.json",
                "package-manifest.json",
            ],
        )
        self.assertEqual(PUBLISHER.retained_generation_ids(self.transport, self.remote), (first.generation_id,))

        _write_source_package(
            self.source, [("room-a", "m2", "second generation replacement")]
        )
        second = PUBLISHER.build_generation(self.source, self.root / "build-two")
        second_receipt = PUBLISHER.publish_generation(
            second, self.transport, self.remote
        )
        self.assertEqual(second_receipt["previous_generation_id"], first.generation_id)
        self.assertEqual(
            PUBLISHER.retained_generation_ids(self.transport, self.remote),
            (second.generation_id, first.generation_id),
        )
        self.assertTrue(
            (self.package_root / "kwrag" / "source" / "generations" / first.generation_id).is_dir()
        )
        rollback = PUBLISHER.rollback_generation(
            self.transport,
            self.remote,
            expected_current_generation_id=second.generation_id,
        )
        self.assertEqual(rollback["status"], "ROLLED_BACK")
        self.assertEqual(rollback["generation_id"], first.generation_id)
        self.assertEqual(
            PUBLISHER.retained_generation_ids(self.transport, self.remote),
            (first.generation_id, second.generation_id),
        )
        with patch(
            "kwrag.crawler_source.os.statvfs",
            return_value=SimpleNamespace(f_flag=os.ST_RDONLY),
        ):
            with CanonicalCrawlerSource(self.package_root) as source:
                self.assertEqual(source.generation.generation_id, first.generation_id)
                self.assertEqual(source.rooms, ("room-a",))

    def test_remote_generation_corruption_is_never_overwritten(self) -> None:
        _write_source_package(self.source, [("room-a", "m1", "immutable")])
        build = PUBLISHER.build_generation(self.source, self.root / "build")
        PUBLISHER.publish_generation(build, self.transport, self.remote)
        remote_database = (
            self.package_root
            / "kwrag"
            / "source"
            / "generations"
            / build.generation_id
            / "messages.sqlite"
        )
        remote_database.write_bytes(b"corrupt")
        with self.assertRaisesRegex(
            PUBLISHER.GenerationPublishError, "remote_generation_digest_mismatch"
        ):
            PUBLISHER.publish_generation(build, self.transport, self.remote)
        self.assertEqual(remote_database.read_bytes(), b"corrupt")

    def test_distinct_packages_do_not_share_generation_or_scope(self) -> None:
        other_source = self.root / "other-source"
        other_remote = "/kakao-work/users/other-package"
        other_root = _make_package_root(self.transport, other_remote)
        _write_source_package(self.source, [("room-a", "m1", "package a")])
        _write_source_package(
            other_source,
            [("room-b", "m2", "package b")],
            user_id="other-user",
        )
        first = PUBLISHER.build_generation(self.source, self.root / "first-build")
        second = PUBLISHER.build_generation(other_source, self.root / "second-build")
        self.assertNotEqual(first.generation_id, second.generation_id)
        PUBLISHER.publish_generation(first, self.transport, self.remote)
        PUBLISHER.publish_generation(second, self.transport, other_remote)
        with patch(
            "kwrag.crawler_source.os.statvfs",
            return_value=SimpleNamespace(f_flag=os.ST_RDONLY),
        ):
            with CanonicalCrawlerSource(self.package_root) as first_source:
                self.assertEqual(first_source.rooms, ("room-a",))
            with CanonicalCrawlerSource(other_root) as second_source:
                self.assertEqual(second_source.rooms, ("room-b",))


class RootlessProductEndToEndTests(unittest.TestCase):
    def test_generated_package_fts_fixed_producer_dense_and_two_consumers(self) -> None:
        contract_payload = (
            Path(__file__).resolve().parents[2]
            / "contracts"
            / "kwrag-product-consumer-interfaces-v1.json"
        ).read_bytes()
        self.assertTrue(contract_payload.endswith(b"\n"))
        interfaces = loads_canonical_json_bytes(contract_payload[:-1])
        self.assertEqual(
            interfaces["openclaw"]["provider_sdk_method"],
            "dispatch_current_assistant_turn",
        )
        self.assertEqual(
            interfaces["openclaw"]["terminal_status"], "assistant_response"
        )
        self.assertEqual(
            interfaces["hermes"]["provider_sdk_method"],
            "dispatch_current_terminal_turn",
        )
        self.assertEqual(interfaces["hermes"]["terminal_status"], "terminal_outcome")
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source_package = root / "source-package"
            _write_source_package(
                source_package,
                [
                    ("room-a", "m1", "가나다라마 internal trigram result"),
                    ("room-a", "m2", "unique dense evidence for product D"),
                    ("room-b", "m3", "outside selected room evidence"),
                ],
            )
            build = PUBLISHER.build_generation(source_package, root / "generation-build")
            transport = _LocalMirrorTransport(root / "mirror")
            remote = "/kakao-work/users/e2e-package"
            transport._path("/kakao-work").mkdir(parents=True)
            package_root = transport._path(remote)
            self.assertFalse(package_root.exists())
            PUBLISHER.publish_generation(build, transport, remote)
            self.assertTrue(package_root.is_dir())
            receipts = root / "receipts"
            receipts.mkdir()
            binding = root / "fixed-binding.json"
            binding.write_bytes(
                canonical_json_bytes(
                    {
                        "schema_version": "kwrag-crawler-fixed-producer-binding-v1",
                        "enabled": True,
                        "mount_root": str(package_root),
                        "operation_receipt_path": str(receipts / "fixed-operation.jsonl"),
                        "producer_receipt_path": str(receipts / "fixed-producer.jsonl"),
                        "max_concurrent": 1,
                        "expected_uid": os.geteuid(),
                        "expected_gid": os.getegid(),
                        "pipeline_fingerprint": __import__(
                            "kwrag.crawler_fixed_producer", fromlist=["CRAWLER_F_PIPELINE_FINGERPRINT"]
                        ).CRAWLER_F_PIPELINE_FINGERPRINT,
                    }
                )
            )
            binding.chmod(0o600)
            fixed_request = {
                "schema_version": "kwrag-slot-search-request-v1",
                "query": "나다라",
                "request_id": "fixed-e2e-request",
                "operation_id": "fixed-e2e-operation",
                "run_id": "fixed-e2e-run",
                "attempt": 1,
                "max_results": 2,
                "corpus": "room-a",
            }
            with patch(
                "kwrag.crawler_source.os.statvfs",
                return_value=SimpleNamespace(f_flag=os.ST_RDONLY),
            ):
                with CanonicalCrawlerSource(package_root) as lexical_source:
                    self.assertEqual(
                        [hit.message_id for hit in lexical_source.search("나다라", ["room-a"], limit=2)],
                        ["m1"],
                    )
                fixed = execute_crawler_fixed_producer(
                    canonical_json_bytes(fixed_request), binding_path=binding
                )
            fixed_output = loads_canonical_json_bytes(fixed.output_bytes)
            self.assertEqual(
                fixed_output["consumable"]["results"][0]["source_ids"], ["m1"]
            )

            source = CanonicalCrawlerSource(package_root, require_readonly=False)
            core = SharedGpuCore(
                NonProductionDeterministicBackend(8),
                SharedGpuCoreConfig(allow_nonproduction_backend=True),
            )
            core.start()
            journal = ContentFreeGpuJournal(receipts / "gpu.jsonl")
            client = InProcessSharedGpuClient(
                core=core,
                caller=CallerIdentity(
                    slot="slot-fixture",
                    principal=f"uid:{os.geteuid()}",
                    peer_uid=os.geteuid(),
                    peer_gid=os.getegid(),
                ),
                journal=journal,
            )
            try:
                first_dense = build_dense_release(
                    source=source,
                    gpu=client,
                    output_root=package_root,
                    slot_namespace="slot-fixture",
                    allow_nonproduction=True,
                )
                second_dense = build_dense_release(
                    source=source,
                    gpu=client,
                    output_root=package_root,
                    slot_namespace="slot-fixture",
                    allow_nonproduction=True,
                )
                self.assertEqual(first_dense["release_id"], second_dense["release_id"])
                self.assertEqual(
                    first_dense["manifest_sha256"], second_dense["manifest_sha256"]
                )
                manifest_relative = (
                    Path(first_dense["release_relative"]) / "index-manifest.json"
                ).as_posix()
                with patch(
                    "kwrag.slot_mount._require_readonly_mount", lambda _path: None
                ), patch(
                    "kwrag.crawler_source.os.statvfs",
                    return_value=SimpleNamespace(f_flag=os.ST_RDONLY),
                ):
                    scope = load_slot_index_scope(
                        package_root, manifest_relative, require_readonly=True
                    )
                    pipeline = SharedGpuDensePipeline(
                        scope, client, allow_nonproduction_release=True
                    )
                    try:
                        application = SlotSearchApplication(
                            pipeline=pipeline,
                            scope=scope,
                            pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
                            receipt_writer=ReceiptWriter(receipts / "dense-operation.jsonl"),
                        )
                        dense_request = {
                            "schema_version": "kwrag-slot-search-request-v1",
                            "query": "dense evidence product",
                            "request_id": "dense-e2e-request",
                            "operation_id": "dense-e2e-operation",
                            "run_id": "dense-e2e-run",
                            "attempt": 1,
                            "max_results": 2,
                            "corpus": "room-a",
                        }
                        exchange = application.search_exchange(dense_request)
                        self.assertEqual(exchange.response["result_status"], "hits")
                        model = _DeterministicProviderSdkStub()
                        openclaw_handoff, openclaw_terminal = _consume_with_literal_interface(
                            interface="openclaw",
                            request=dense_request,
                            response=exchange.response,
                            operation_receipt=exchange.operation_receipt,
                            index_manifest=scope.manifest.digest,
                            receipt_root=receipts,
                            model=model,
                        )
                        hermes_handoff, hermes_terminal = _consume_with_literal_interface(
                            interface="hermes",
                            request=dense_request,
                            response=exchange.response,
                            operation_receipt=exchange.operation_receipt,
                            index_manifest=scope.manifest.digest,
                            receipt_root=receipts,
                            model=model,
                        )
                        self.assertEqual(openclaw_terminal["status"], "assistant_response")
                        self.assertEqual(hermes_terminal["status"], "terminal_outcome")
                        self.assertEqual(
                            openclaw_handoff["result_digest"], hermes_handoff["result_digest"]
                        )
                    finally:
                        pipeline.close()
            finally:
                source.close()
                core.shutdown(grace_seconds=1)

            durable = b"".join(path.read_bytes() for path in sorted(receipts.iterdir()))
            for forbidden in (
                "나다라",
                "가나다라마",
                "unique dense evidence",
                "assistant-stub",
                "terminal-stub",
            ):
                self.assertNotIn(forbidden.encode("utf-8"), durable)


if __name__ == "__main__":
    unittest.main()
