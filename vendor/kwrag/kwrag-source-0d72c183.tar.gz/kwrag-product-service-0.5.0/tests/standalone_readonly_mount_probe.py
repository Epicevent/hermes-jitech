"""Standard-library proof that a prepared slot mount is read-only to its caller."""

from __future__ import annotations

import argparse
import errno
import hashlib
import os
import sys
import tempfile
import types
from pathlib import Path

_PACKAGE_ROOT = Path(__file__).resolve().parents[1] / "src" / "kwrag"
_package = types.ModuleType("kwrag")
_package.__path__ = [str(_PACKAGE_ROOT)]
sys.modules["kwrag"] = _package

from kwrag.slot_mount import load_slot_index_scope
from kwrag.slot_runtime import SlotRuntimeSpec, build_slot_runtime


class _ProbePipeline:
    def search(self, query: str, rooms: list[str], k: int):
        if query != "synthetic boundary probe" or rooms != ["alpha"] or k != 1:
            raise AssertionError("runtime probe call drifted")
        return {
            "hits": [],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": "readonly-probe-v1",
                "stages": [
                    {
                        "stage_id": "synthetic_lookup",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": 0,
                        "model": None,
                        "revision": None,
                    }
                ],
                "candidate_count": 0,
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }


def _digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _expect_readonly(operation, label: str) -> int:
    try:
        operation()
    except OSError as exc:
        if exc.errno not in {errno.EROFS, errno.EACCES, errno.EPERM}:
            raise AssertionError(f"unexpected errno for {label}: {exc.errno}") from exc
        return int(exc.errno)
    raise AssertionError(f"read-only operation unexpectedly succeeded: {label}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mount-root", required=True, type=Path)
    parser.add_argument("--manifest-relative", required=True)
    args = parser.parse_args()

    mount_root = args.mount_root.resolve(strict=True)
    statvfs = os.statvfs(mount_root)
    if not statvfs.f_flag & os.ST_RDONLY:
        raise SystemExit("READONLY_MOUNT_PROBE=FAIL reason=statvfs_not_readonly")

    scope = load_slot_index_scope(
        mount_root,
        args.manifest_relative,
        require_readonly=True,
    )
    if scope.available_rooms != ("alpha",):
        raise SystemExit("READONLY_MOUNT_PROBE=FAIL reason=fixture_scope_drift")

    with tempfile.TemporaryDirectory(prefix="kwrag-readonly-runtime-") as runtime_raw:
        receipt_path = Path(runtime_raw) / "receipts.jsonl"
        runtime = build_slot_runtime(
            SlotRuntimeSpec(
                mount_root=mount_root,
                index_manifest_relative=args.manifest_relative,
                index_manifest_digest=scope.manifest.digest,
                receipt_path=receipt_path,
                pipeline_fingerprint="sha256:" + "c" * 64,
            ),
            pipeline_factory=lambda _scope: _ProbePipeline(),
        )
        ready = runtime.ready()
        response = runtime.search(
            {
                "schema_version": "kwrag-slot-search-request-v1",
                "query": "synthetic boundary probe",
                "max_results": 1,
            }
        )
        if (
            ready.get("authorization_basis") != "slot_mounted_storage"
            or response.get("result_status") != "zero_hits"
            or response.get("operation_receipt", {}).get("status") != "written"
            or not receipt_path.is_file()
        ):
            raise SystemExit("READONLY_MOUNT_PROBE=FAIL reason=runtime path drift")

    manifest = scope.manifest_path
    vector = scope.index_root / "room_123.npy"
    identities_before = {
        "manifest": (manifest.stat().st_size, _digest(manifest)),
        "vector": (vector.stat().st_size, _digest(vector)),
    }

    created = mount_root / ".kwrag-readonly-negative-control"

    def create_file() -> None:
        descriptor = os.open(created, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(descriptor)

    def append_manifest() -> None:
        descriptor = os.open(manifest, os.O_WRONLY | os.O_APPEND)
        try:
            os.write(descriptor, b"x")
        finally:
            os.close(descriptor)

    errnos = {
        _expect_readonly(create_file, "create"),
        _expect_readonly(append_manifest, "append"),
        _expect_readonly(lambda: vector.unlink(), "unlink"),
    }
    if created.exists() or created.is_symlink():
        raise SystemExit("READONLY_MOUNT_PROBE=FAIL reason=create_left_artifact")

    identities_after = {
        "manifest": (manifest.stat().st_size, _digest(manifest)),
        "vector": (vector.stat().st_size, _digest(vector)),
    }
    if identities_after != identities_before:
        raise SystemExit("READONLY_MOUNT_PROBE=FAIL reason=fixture_identity_changed")

    print(
        "READONLY_MOUNT_PROBE=PASS "
        f"uid={os.geteuid()} statvfs_readonly=yes runtime_readonly_guard=yes "
        "runtime_search_and_receipt=yes "
        "read_scope=alpha "
        f"write_attempts=3 rejected_errnos={','.join(str(value) for value in sorted(errnos))} "
        "fixture_identity_unchanged=yes content_printed=no"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
