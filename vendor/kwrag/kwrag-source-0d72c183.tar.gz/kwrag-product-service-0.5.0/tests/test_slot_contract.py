from __future__ import annotations

import hashlib
from copy import deepcopy
from pathlib import Path

import pytest

from kwrag.jsonutil import canonical_json_bytes, loads_strict_json
from kwrag.manifest import IndexManifest
from kwrag.operation import ReceiptWriter
from kwrag.slot_api import SlotSearchApplication
from kwrag.slot_consumer import SlotConsumptionError, verify_slot_search_exchange
from kwrag.slot_mount import MountedFileIdentity, SlotIndexScope


ROOT = Path(__file__).resolve().parents[2]
CONTRACT_ROOT = ROOT / "contracts"
FIXTURE_ROOT = CONTRACT_ROOT / "fixtures" / "slot-local-retrieval-v1"
SCHEMA_ROOT = CONTRACT_ROOT / "schemas"


@pytest.fixture(autouse=True)
def _read_only_mount_fixture(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("kwrag.slot_mount._require_readonly_mount", lambda _path: None)


def _fixture(name: str) -> dict:
    payload = (FIXTURE_ROOT / name).read_bytes()
    assert payload.endswith(b"\n") and not payload.endswith(b"\n\n")
    canonical = payload[:-1]
    parsed = loads_strict_json(canonical.decode("utf-8"))
    assert canonical == canonical_json_bytes(parsed)
    return parsed


class FixturePipeline:
    def search(self, query: str, rooms: list[str], k: int):
        assert (query, rooms, k) == ("fixture query", ["alpha"], 2)
        return {
            "hits": [
                {
                    "room": "alpha",
                    "level": "segment",
                    "seg_id": 7,
                    "text": "fixture result",
                    "score": 0.75,
                    "message_ids": ["message-1"],
                }
            ],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": "fixture-backend-v1",
                "stages": [
                    {
                        "stage_id": "index_lookup",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": 1,
                        "output_count": 1,
                        "model": None,
                        "revision": None,
                    }
                ],
                "candidate_count": 1,
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }


def _application(tmp_path: Path) -> SlotSearchApplication:
    mount_root = tmp_path / "nas_docs"
    index_root = mount_root / "index"
    index_root.mkdir(parents=True)
    manifest_path = index_root / "index-manifest.json"
    manifest_path.write_bytes(b"fixture identity only")
    mount_metadata = mount_root.lstat()
    manifest_metadata = manifest_path.lstat()
    manifest = IndexManifest(
        digest="sha256:" + "a" * 64,
        release_id="fixture-release",
        corpus_snapshot="fixture-snapshot",
        embedding_fingerprint="sha256:" + "c" * 64,
        rooms={"alpha": "123"},
        raw={},
    )
    scope = SlotIndexScope(
        mount_root=mount_root,
        index_root=index_root,
        manifest_path=manifest_path,
        manifest=manifest,
        mount_device=mount_metadata.st_dev,
        mount_inode=mount_metadata.st_ino,
        file_identities=(
            MountedFileIdentity(
                path=manifest_path,
                device=manifest_metadata.st_dev,
                inode=manifest_metadata.st_ino,
                mode=manifest_metadata.st_mode,
                links=manifest_metadata.st_nlink,
                size=manifest_metadata.st_size,
                mtime_ns=manifest_metadata.st_mtime_ns,
            ),
        ),
        readonly_required=True,
    )
    return SlotSearchApplication(
        pipeline=FixturePipeline(),
        scope=scope,
        pipeline_fingerprint="sha256:" + "b" * 64,
        receipt_writer=ReceiptWriter(tmp_path / "receipts.jsonl"),
    )


def test_runtime_producer_matches_the_exact_consumer_fixture(
    tmp_path: Path, monkeypatch
) -> None:
    ticks = iter((100.0, 100.012))
    monkeypatch.setattr("kwrag.slot_api.time.monotonic", lambda: next(ticks))
    monkeypatch.setattr(
        "kwrag.slot_api.time.strftime", lambda *_args, **_kwargs: "2026-07-27T00:00:00Z"
    )
    request = _fixture("request.json")
    expected_response = _fixture("response.json")
    expected_receipt = _fixture("receipt.json")

    exchange = _application(tmp_path).search_exchange(request)
    response = exchange.response
    receipt_line = (tmp_path / "receipts.jsonl").read_bytes()
    assert receipt_line == canonical_json_bytes(expected_receipt) + b"\n"
    receipt = loads_strict_json(receipt_line[:-1].decode("utf-8"))

    assert response == expected_response
    assert exchange.operation_receipt == expected_receipt
    assert receipt == expected_receipt
    assert response["operation_receipt"]["digest"] == (
        "sha256:" + hashlib.sha256(canonical_json_bytes(receipt)).hexdigest()
    )
    assert response["result_digest"] == (
        "sha256:" + hashlib.sha256(canonical_json_bytes(response["results"])).hexdigest()
    )
    verified = verify_slot_search_exchange(
        request,
        exchange.response,
        exchange.operation_receipt,
        expected_index_manifest="sha256:" + "a" * 64,
        expected_pipeline_fingerprint="sha256:" + "b" * 64,
        max_result_characters=len(
            canonical_json_bytes(expected_response["results"]).decode("utf-8")
        ),
    )
    assert verified.results() == expected_response["results"]


def test_receipt_sink_failure_keeps_retrieval_valid_but_blocks_consumption(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    request = _fixture("request.json")
    application = _application(tmp_path)

    def unavailable(_line: bytes) -> None:
        raise OSError("synthetic receipt sink failure")

    monkeypatch.setattr(application.receipts, "_write_posix", unavailable)
    monkeypatch.setattr(application.receipts, "_write_portable", unavailable)
    exchange = application.search_exchange(request)

    assert exchange.response["result_status"] == "hits"
    assert exchange.response["operation_receipt"] == {
        "status": "unavailable",
        "digest": None,
    }
    with pytest.raises(SlotConsumptionError, match="written operation receipt"):
        verify_slot_search_exchange(
            request,
            exchange.response,
            exchange.operation_receipt,
            expected_index_manifest="sha256:" + "a" * 64,
            expected_pipeline_fingerprint="sha256:" + "b" * 64,
            max_result_characters=1_000,
        )


def test_contract_schemas_and_fixtures_have_exact_stable_identities() -> None:
    identities = {
        "runtime-binding.json": "kwrag-slot-runtime-binding-v1",
        "request.json": "kwrag-slot-search-request-v1",
        "response.json": "kwrag-slot-search-response-v1",
        "receipt.json": "kwrag-slot-search-operation-receipt-v1",
    }
    for fixture_name, schema_id in identities.items():
        fixture = _fixture(fixture_name)
        schema_path = SCHEMA_ROOT / f"{schema_id}.schema.json"
        schema_bytes = schema_path.read_bytes()
        assert schema_bytes.endswith(b"\n") and not schema_bytes.endswith(b"\n\n")
        schema = loads_strict_json(schema_bytes[:-1].decode("utf-8"))
        assert schema_bytes[:-1] == canonical_json_bytes(schema)
        assert schema["$id"] == schema_id
        assert schema["additionalProperties"] is False
        assert fixture["schema_version"] == schema_id
        assert set(fixture) == set(schema["properties"])


def test_research_decision_binding_preserves_identity_without_selecting_backend() -> None:
    binding = _fixture("research-decision-binding.json")
    schema_path = SCHEMA_ROOT / "kwrag-slot-research-decision-binding-v1.schema.json"
    schema = loads_strict_json(schema_path.read_text(encoding="utf-8"))

    assert binding["schema_version"] == schema["$id"]
    assert binding["decision_status"] == "unresolved"
    assert binding["product_schema_transfer"] == "forbidden"
    assert binding["fixture"] == {
        "schema_identity": "kwrag-retrieval-placement-fdr-fixture-v1",
        "bytes": 222147,
        "sha256": "sha256:2f5480758893ca6da85c1597ebe1c8b58280b0ea35d5748bb849b46c88d33b16",
    }
    assert binding["fixture_scope"] == {
        "total_cases": 150,
        "calibration_cases": 30,
        "evaluation_cases": 120,
        "behavior_cases": 12,
        "raw_snippets_present": False,
    }
    assert len(binding["hard_rejection_gates"]) == 8
    assert "central_corpus_index_or_acl_projection_bytes_nonzero" in binding[
        "hard_rejection_gates"
    ]
    assert "behavior_wrong_event_count_nonzero" in binding["hard_rejection_gates"]


def _consume_fixture(
    response: dict, receipt: dict, *, expected_operation_id: str, max_chars: int
) -> list[dict]:
    assert response["schema_version"] == "kwrag-slot-search-response-v1"
    assert receipt["schema_version"] == "kwrag-slot-search-operation-receipt-v1"
    assert response["operation_id"] == receipt["operation_id"] == expected_operation_id
    for field in (
        "request_id",
        "run_id",
        "attempt",
        "authorization_basis",
        "index_manifest",
        "pipeline_fingerprint",
        "result_digest",
        "result_status",
    ):
        assert response[field] == receipt[field]
    assert response["operation_receipt"] == {
        "status": "written",
        "digest": "sha256:"
        + hashlib.sha256(canonical_json_bytes(receipt)).hexdigest(),
    }
    assert response["result_digest"] == (
        "sha256:"
        + hashlib.sha256(canonical_json_bytes(response["results"])).hexdigest()
    )
    assert len(canonical_json_bytes(response["results"]).decode("utf-8")) <= max_chars
    return response["results"]


def test_consumer_fixture_binds_results_and_receipt_and_has_negative_controls() -> None:
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")

    assert len(
        _consume_fixture(
            response,
            receipt,
            expected_operation_id="operation-fixture-1",
            max_chars=len(canonical_json_bytes(response["results"]).decode("utf-8")),
        )
    ) == 1

    changed_result = deepcopy(response)
    changed_result["results"][0]["snippet"] = "different"
    with pytest.raises(AssertionError):
        _consume_fixture(
            changed_result,
            receipt,
            expected_operation_id="operation-fixture-1",
            max_chars=len(canonical_json_bytes(changed_result["results"]).decode("utf-8")),
        )

    changed_receipt = deepcopy(receipt)
    changed_receipt["attempt"] = 2
    with pytest.raises(AssertionError):
        _consume_fixture(
            response,
            changed_receipt,
            expected_operation_id="operation-fixture-1",
            max_chars=len(canonical_json_bytes(response["results"]).decode("utf-8")),
        )


def test_contract_does_not_select_product_policy_or_backend() -> None:
    contract = (CONTRACT_ROOT / "slot-local-retrieval-v1.md").read_text(
        encoding="utf-8"
    )
    legacy = (CONTRACT_ROOT / "conversation-search-v1.md").read_text(encoding="utf-8")

    assert "opens no host port" in contract
    assert "cannot name a mount, slot, grant, token" in contract
    assert "does not select FTS" in contract
    assert "does not authorize an automatic prompt hook" in contract
    assert "research-owned F/D/R alternatives" in contract
    assert "Superseded product boundary" in legacy
