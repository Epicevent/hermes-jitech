from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from kwrag.jsonutil import canonical_json_bytes
from kwrag.operation import OperationError
from kwrag.service import main as legacy_product_main
from kwrag.slot_mount import SlotIndexScope
import kwrag.slot_mount as slot_mount_module
from kwrag.slot_runtime import (
    SlotRuntimeError,
    SlotRuntimeSpec,
    build_slot_runtime,
    load_slot_runtime_spec,
)


REQUEST_SCHEMA = "kwrag-slot-search-request-v1"
ROOT = Path(__file__).resolve().parents[2]


def _sha256(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _fixture_mount(tmp_path: Path) -> tuple[Path, str, str]:
    mount = (tmp_path / "nas_docs").resolve()
    index = mount / "package"
    index.mkdir(parents=True)
    vector = index / "room_123.npy"
    metadata = index / "room_123.meta.sqlite"
    vector.write_bytes(b"vector")
    metadata.write_bytes(b"metadata")
    manifest = {
        "version": 1,
        "release_id": "runtime-fixture",
        "created_at": "2026-07-27T00:00:00Z",
        "corpus_snapshot": "runtime-snapshot",
        "embedding_fingerprint": "sha256:" + "a" * 64,
        "rooms": {
            "alpha": {
                "conversation_id": "123",
                "files": [
                    {"path": vector.name, "sha256": _sha256(vector)},
                    {"path": metadata.name, "sha256": _sha256(metadata)},
                ],
            }
        },
    }
    manifest_path = index / "index-manifest.json"
    manifest_bytes = canonical_json_bytes(manifest)
    manifest_path.write_bytes(manifest_bytes)
    return (
        mount,
        manifest_path.relative_to(mount).as_posix(),
        "sha256:" + hashlib.sha256(manifest_bytes).hexdigest(),
    )


class FixturePipeline:
    def search(self, query: str, rooms: list[str], k: int):
        return {
            "hits": [],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": "injected-fixture-v1",
                "stages": [
                    {
                        "stage_id": "lookup",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": len(rooms),
                        "output_count": 0,
                        "model": None,
                        "revision": None,
                    }
                ],
                "candidate_count": 0,
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }


def test_runtime_binding_fixture_is_backend_and_transport_neutral() -> None:
    fixture = json.loads(
        (
            ROOT
            / "contracts"
            / "fixtures"
            / "slot-local-retrieval-v1"
            / "runtime-binding.json"
        ).read_text(encoding="utf-8")
    )

    spec = SlotRuntimeSpec.from_mapping(fixture)

    assert spec.index_manifest_relative == "package/index-manifest.json"
    forbidden = {"backend", "port", "network", "token", "grant", "slot_id"}
    assert forbidden.isdisjoint(fixture)


def test_runtime_binding_loader_accepts_only_canonical_live_bytes(
    tmp_path: Path,
) -> None:
    fixture = json.loads(
        (
            ROOT
            / "contracts"
            / "fixtures"
            / "slot-local-retrieval-v1"
            / "runtime-binding.json"
        ).read_text(encoding="utf-8")
    )
    live = tmp_path / "runtime-binding.json"
    live.write_bytes(canonical_json_bytes(fixture))

    loaded = load_slot_runtime_spec(live)

    assert loaded.index_manifest_digest == "sha256:" + "c" * 64
    for invalid in (
        canonical_json_bytes(fixture) + b"\n",
        json.dumps(fixture, indent=2).encode("utf-8"),
        b'{"schema_version":"kwrag-slot-runtime-binding-v1",'
        b'"schema_version":"kwrag-slot-runtime-binding-v1"}',
    ):
        live.write_bytes(invalid)
        with pytest.raises(SlotRuntimeError, match="invalid"):
            load_slot_runtime_spec(live)


def test_runtime_binding_loader_rejects_hardlink(tmp_path: Path) -> None:
    fixture = json.loads(
        (
            ROOT
            / "contracts"
            / "fixtures"
            / "slot-local-retrieval-v1"
            / "runtime-binding.json"
        ).read_text(encoding="utf-8")
    )
    live = tmp_path / "runtime-binding.json"
    sibling = tmp_path / "second-link.json"
    live.write_bytes(canonical_json_bytes(fixture))
    sibling.hardlink_to(live)

    with pytest.raises(SlotRuntimeError, match="single-link"):
        load_slot_runtime_spec(live)


@pytest.mark.parametrize(
    "field,value",
    [
        ("port", 8899),
        ("network", "kwrag_net"),
        ("token", "secret"),
        ("backend", "dense"),
    ],
)
def test_runtime_binding_rejects_authority_transport_and_backend_fields(
    field: str, value: object
) -> None:
    raw = {
        "schema_version": "kwrag-slot-runtime-binding-v1",
        "mount_root": "/slot/nas_docs",
        "index_manifest_relative": "package/index-manifest.json",
        "index_manifest_digest": "sha256:" + "c" * 64,
        "receipt_path": "/runtime/kwrag/search-receipts.jsonl",
        "pipeline_fingerprint": "sha256:" + "d" * 64,
        "max_concurrent": 1,
        field: value,
    }

    with pytest.raises(SlotRuntimeError, match="fields are invalid"):
        SlotRuntimeSpec.from_mapping(raw)


def test_runtime_assembles_scope_before_injected_pipeline_and_direct_call(
    tmp_path: Path, monkeypatch,
) -> None:
    mount, relative, manifest_digest = _fixture_mount(tmp_path)
    observed_scopes: list[SlotIndexScope] = []
    monkeypatch.setattr(slot_mount_module, "_require_readonly_mount", lambda _path: None)

    def factory(scope: SlotIndexScope):
        observed_scopes.append(scope)
        return FixturePipeline()

    runtime = build_slot_runtime(
        SlotRuntimeSpec(
            mount_root=mount,
            index_manifest_relative=relative,
            index_manifest_digest=manifest_digest,
            receipt_path=(tmp_path / "runtime" / "receipts.jsonl").resolve(),
            pipeline_fingerprint="sha256:" + "d" * 64,
        ),
        pipeline_factory=factory,
    )

    assert observed_scopes == [runtime.scope]
    assert runtime.ready()["authorization_basis"] == "slot_mounted_storage"
    response = runtime.search(
        {"schema_version": REQUEST_SCHEMA, "query": "direct call"}
    )
    assert response["result_status"] == "zero_hits"
    assert response["results"] == []


def test_runtime_rejects_snapshot_drift_before_pipeline_factory(
    tmp_path: Path, monkeypatch,
) -> None:
    mount, relative, _manifest_digest = _fixture_mount(tmp_path)
    factory_called = False
    monkeypatch.setattr(slot_mount_module, "_require_readonly_mount", lambda _path: None)

    def factory(_scope: SlotIndexScope):
        nonlocal factory_called
        factory_called = True
        return FixturePipeline()

    with pytest.raises(SlotRuntimeError, match="does not match"):
        build_slot_runtime(
            SlotRuntimeSpec(
                mount_root=mount,
                index_manifest_relative=relative,
                index_manifest_digest="sha256:" + "0" * 64,
                receipt_path=(tmp_path / "runtime" / "receipts.jsonl").resolve(),
                pipeline_fingerprint="sha256:" + "d" * 64,
            ),
            pipeline_factory=factory,
        )

    assert factory_called is False


def test_runtime_requires_kernel_attested_readonly_mount(
    tmp_path: Path, monkeypatch,
) -> None:
    mount, relative, manifest_digest = _fixture_mount(tmp_path)
    spec = SlotRuntimeSpec(
        mount_root=mount,
        index_manifest_relative=relative,
        index_manifest_digest=manifest_digest,
        receipt_path=(tmp_path / "runtime" / "receipts.jsonl").resolve(),
        pipeline_fingerprint="sha256:" + "d" * 64,
    )
    factory_called = False

    def factory(_scope: SlotIndexScope):
        nonlocal factory_called
        factory_called = True
        return FixturePipeline()

    monkeypatch.setattr(slot_mount_module.os, "ST_RDONLY", 1, raising=False)
    monkeypatch.setattr(
        slot_mount_module.os,
        "statvfs",
        lambda _path: SimpleNamespace(f_flag=0),
        raising=False,
    )
    with pytest.raises(SlotRuntimeError, match="must be read-only"):
        build_slot_runtime(spec, pipeline_factory=factory)
    assert factory_called is False

    mount_flags = {"value": 1}
    monkeypatch.setattr(
        slot_mount_module.os,
        "statvfs",
        lambda _path: SimpleNamespace(f_flag=mount_flags["value"]),
        raising=False,
    )
    runtime = build_slot_runtime(spec, pipeline_factory=factory)
    assert runtime.scope.mount_root == mount
    assert factory_called is True

    mount_flags["value"] = 0
    with pytest.raises(OperationError) as rejected:
        runtime.search({"schema_version": REQUEST_SCHEMA, "query": "q"})
    assert rejected.value.code == "not_ready"


def test_superseded_shared_product_entrypoint_fails_before_configuration(
    monkeypatch,
) -> None:
    called = False

    def unexpected_load():
        nonlocal called
        called = True
        raise AssertionError("configuration must not be read")

    monkeypatch.setattr("kwrag.service.KwRagConfig.load", unexpected_load)

    with pytest.raises(SystemExit, match="superseded"):
        legacy_product_main()

    assert called is False


def test_legacy_diagnostic_builder_is_not_a_packaged_or_compose_command() -> None:
    project = (ROOT / "service" / "pyproject.toml").read_text(encoding="utf-8")
    compose = (ROOT / "service" / "deploy" / "compose.yaml").read_text(
        encoding="utf-8"
    )
    dockerfile = (ROOT / "service" / "Dockerfile").read_text(encoding="utf-8")

    assert "legacy_diagnostic_main" not in project
    assert "legacy_diagnostic_main" not in compose
    assert "legacy_diagnostic_main" not in dockerfile
