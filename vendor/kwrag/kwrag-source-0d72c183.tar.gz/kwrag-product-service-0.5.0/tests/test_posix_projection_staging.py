from __future__ import annotations

import os
import stat
import uuid
from pathlib import Path

import pytest

from kwrag.release import (
    ReleaseError,
    validate_projection_staging_output,
    write_private_json_exclusive,
)

try:
    import grp
except ImportError:  # pragma: no cover - exercised by Windows collection
    grp = None


def _root_posix_fixture_available() -> bool:
    if grp is None or os.name != "posix" or os.geteuid() != 0:
        return False
    try:
        grp.getgrnam("kwrag_rt")
    except KeyError:
        return False
    return True


pytestmark = pytest.mark.skipif(
    not _root_posix_fixture_available(),
    reason="requires a disposable root POSIX fixture with kwrag_rt pre-created",
)


def _fixture(tmp_path: Path) -> tuple[Path, Path, Path]:
    assert grp is not None
    runtime_gid = grp.getgrnam("kwrag_rt").gr_gid
    auth = tmp_path / "auth"
    auth.mkdir(mode=0o750)
    os.chown(auth, 0, runtime_gid)
    staging = auth / f".staging-projection-{uuid.uuid4()}"
    staging.mkdir(mode=0o700)
    os.chown(staging, 0, 0)
    return auth, staging, staging / "token-projection.json"


def test_real_posix_openat_identity_and_exclusive_creation(tmp_path: Path) -> None:
    auth, staging, target = _fixture(tmp_path)

    validate_projection_staging_output(target, auth)
    write_private_json_exclusive(target, auth, {"version": 1})

    info = os.lstat(target)
    assert stat.S_ISREG(info.st_mode)
    assert not stat.S_ISLNK(info.st_mode)
    assert (info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode), info.st_nlink) == (
        0,
        0,
        0o600,
        1,
    )
    assert info.st_dev == os.lstat(auth).st_dev
    assert target.read_bytes() == b'{"version":1}'

    with pytest.raises(ReleaseError, match="already exists"):
        write_private_json_exclusive(target, auth, {"version": 2})


def test_real_posix_rejects_symlink_and_identity_drift(tmp_path: Path) -> None:
    assert grp is not None
    auth, staging, target = _fixture(tmp_path)
    outsider = tmp_path / "outsider"
    outsider.mkdir(mode=0o700)
    symlink_staging = auth / f".staging-projection-{uuid.uuid4()}"
    symlink_staging.symlink_to(outsider, target_is_directory=True)
    with pytest.raises(ReleaseError, match="identity"):
        validate_projection_staging_output(
            symlink_staging / "token-projection.json", auth
        )

    staging.chmod(0o750)
    with pytest.raises(ReleaseError, match="identity"):
        validate_projection_staging_output(target, auth)

    staging.chmod(0o700)
    os.chown(staging, 0, grp.getgrnam("kwrag_rt").gr_gid)
    with pytest.raises(ReleaseError, match="identity"):
        validate_projection_staging_output(target, auth)
