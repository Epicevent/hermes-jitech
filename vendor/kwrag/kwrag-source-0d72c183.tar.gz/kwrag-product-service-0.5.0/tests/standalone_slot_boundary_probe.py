"""Standard-library Linux probe for the slot-mounted retrieval boundary.

The probe creates only a private temporary fixture, never reads customer data,
and emits no query, message, or source content.  It is intentionally runnable
without pytest so the exact source can be checked on a protected Linux host by
the unprivileged KWRAG account before any root mount test is requested.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import tempfile
import types
from pathlib import Path

# Load the boundary modules through a namespace package so this standard-library
# probe does not import the dense pipeline's optional model dependencies.
_PACKAGE_ROOT = Path(__file__).resolve().parents[1] / "src" / "kwrag"
_package = types.ModuleType("kwrag")
_package.__path__ = [str(_PACKAGE_ROOT)]
sys.modules["kwrag"] = _package

from kwrag.jsonutil import canonical_json_bytes
from kwrag.slot_mount import SlotMountError, load_slot_index_scope


def _digest(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def _expect_slot_error(operation, label: str) -> None:
    try:
        operation()
    except SlotMountError:
        return
    raise AssertionError(f"negative control did not fail: {label}")


def _write_fixture(root: Path) -> tuple[Path, Path, Path]:
    mount = root / "nas_docs"
    index = mount / "kw" / "package" / "index"
    index.mkdir(parents=True)
    vector = index / "room_123.npy"
    database = index / "room_123.meta.sqlite"
    vector.write_bytes(b"vector-fixture")
    database.write_bytes(b"database-fixture")
    manifest = {
        "version": 1,
        "release_id": "slot-boundary-probe",
        "created_at": "2026-07-27T00:00:00Z",
        "corpus_snapshot": "synthetic-fixture",
        "embedding_fingerprint": "sha256:" + "a" * 64,
        "rooms": {
            "alpha": {
                "conversation_id": "123",
                "files": [
                    {"path": vector.name, "sha256": _digest(vector)},
                    {"path": database.name, "sha256": _digest(database)},
                ],
            }
        },
    }
    manifest_path = index / "index-manifest.json"
    manifest_path.write_bytes(canonical_json_bytes(manifest))
    return mount, manifest_path, vector


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--require-linux", action="store_true")
    parser.add_argument("--require-symlink", action="store_true")
    args = parser.parse_args()

    if args.require_linux and platform.system() != "Linux":
        raise SystemExit("PROBE=FAIL reason=Linux is required")

    negative_controls = 0
    symlink_controls = 0
    with tempfile.TemporaryDirectory(prefix="kwrag-slot-boundary-fixture-") as raw:
        fixture_root = Path(raw).resolve()
        mount, manifest, vector = _write_fixture(fixture_root)
        relative_manifest = manifest.relative_to(mount).as_posix()
        before = {
            path.relative_to(fixture_root).as_posix(): (
                path.stat().st_size,
                _digest(path),
            )
            for path in fixture_root.rglob("*")
            if path.is_file()
        }

        scope = load_slot_index_scope(mount, relative_manifest)
        assert scope.available_rooms == ("alpha",)
        assert scope.select_rooms() == ["alpha"]
        assert scope.select_rooms(["alpha"]) == ["alpha"]

        for label, operation in (
            ("parent traversal", lambda: load_slot_index_scope(mount, "../outside")),
            ("absolute path", lambda: load_slot_index_scope(mount, "/outside")),
            ("unknown room", lambda: scope.select_rooms(["beta"])),
            ("duplicate room", lambda: scope.select_rooms(["alpha", "alpha"])),
            ("scalar room", lambda: scope.select_rooms("alpha")),
        ):
            _expect_slot_error(operation, label)
            negative_controls += 1

        symlink_supported = True
        try:
            root_link = fixture_root / "nas_docs-link"
            root_link.symlink_to(mount, target_is_directory=True)
            _expect_slot_error(
                lambda: load_slot_index_scope(root_link, relative_manifest),
                "symlink mount root",
            )
            symlink_controls += 1

            linked_parent = mount / "linked-index"
            linked_parent.symlink_to(manifest.parent, target_is_directory=True)
            _expect_slot_error(
                lambda: load_slot_index_scope(
                    mount, "linked-index/index-manifest.json"
                ),
                "symlink path component",
            )
            symlink_controls += 1

            outside = fixture_root / "outside-vector.npy"
            outside.write_bytes(vector.read_bytes())
            vector.unlink()
            vector.symlink_to(outside)
            _expect_slot_error(
                lambda: load_slot_index_scope(mount, relative_manifest),
                "symlink manifest file",
            )
            symlink_controls += 1
        except OSError:
            symlink_supported = False

        if args.require_symlink and not symlink_supported:
            raise SystemExit("PROBE=FAIL reason=symlink fixtures are unavailable")

        after = {
            path.relative_to(fixture_root).as_posix(): (
                path.stat().st_size,
                _digest(path),
            )
            for path in fixture_root.rglob("*")
            if path.is_file() and not path.is_symlink()
        }
        for name, identity in before.items():
            if name.endswith("room_123.npy"):
                continue
            assert after.get(name) == identity

        print(
            "SLOT_BOUNDARY_PROBE=PASS "
            f"platform={platform.system()} uid={os.geteuid() if hasattr(os, 'geteuid') else 'unavailable'} "
            f"positive_controls=1 negative_controls={negative_controls} "
            f"symlink_supported={'yes' if symlink_supported else 'no'} "
            f"symlink_controls={symlink_controls} customer_data_read=no persistent_writes=0"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
