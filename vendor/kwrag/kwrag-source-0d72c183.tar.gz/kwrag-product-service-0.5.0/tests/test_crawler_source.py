from __future__ import annotations

import hashlib
import os
import sqlite3
from pathlib import Path
from types import SimpleNamespace

import pytest

from kwrag.crawler_source import (
    CanonicalCrawlerSource,
    CrawlerFtsSearchPipeline,
    CrawlerSourceError,
)
from kwrag.jsonutil import canonical_json_bytes


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    path.chmod(0o600)


def _database(path: Path, rows: list[tuple[str, str, str]], *, trigram: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as connection:
        connection.executescript(
            """
            CREATE TABLE messages(
                conversation_id TEXT NOT NULL,
                message_id TEXT NOT NULL UNIQUE,
                user_id TEXT NOT NULL,
                user_name TEXT NOT NULL,
                sent_time INTEGER NOT NULL,
                text_kind TEXT NOT NULL,
                plain_text TEXT NOT NULL
            );
            CREATE TABLE attachments(message_id TEXT, name TEXT);
            CREATE VIRTUAL TABLE messages_fts USING fts5(
                plain_text,
                content='messages',
                content_rowid='rowid',
                tokenize='unicode61'
            );
            """
        )
        if trigram:
            connection.execute(
                "CREATE VIRTUAL TABLE messages_fts_trigram USING fts5("
                "plain_text,content='messages',content_rowid='rowid',tokenize='trigram')"
            )
        for index, (room, message_id, text) in enumerate(rows, 1):
            connection.execute(
                "INSERT INTO messages VALUES(?,?,?,?,?,?,?)",
                (room, message_id, "u", "name", index, "text", text),
            )
        connection.execute("INSERT INTO messages_fts(messages_fts) VALUES('rebuild')")
        if trigram:
            connection.execute(
                "INSERT INTO messages_fts_trigram(messages_fts_trigram) VALUES('rebuild')"
            )
    path.chmod(0o600)


def _generation(
    root: Path,
    *,
    token: str,
    sequence: int,
    rows: list[tuple[str, str, str]],
    membership_rooms: list[str] | None = None,
    trigram: bool = True,
    activation_slot: str = "a",
    previous: str | None = None,
    corrupt_database: bool = False,
) -> str:
    generation_root = root / "kwrag" / "source" / "generations"
    generation = generation_root / f".fixture-staging-{token}"
    rooms = membership_rooms or sorted({row[0] for row in rows})
    membership = canonical_json_bytes(
        {"schema": "kw-corpus-nas-user", "conversation_ids": rooms}
    )
    profile = canonical_json_bytes({"schema": "kw-corpus-profile", "version": 1})
    _write(generation / "membership.json", membership)
    _write(generation / "profile.json", profile)
    if corrupt_database:
        _write(generation / "messages.sqlite", b"not-a-database")
    else:
        _database(generation / "messages.sqlite", rows, trigram=trigram)
    files = []
    for name in ("membership.json", "messages.sqlite", "profile.json"):
        payload = (generation / name).read_bytes()
        files.append({"name": name, "sha256": _digest(payload), "bytes": len(payload)})
    manifest = {
        "schema_version": "kw-corpus-package-manifest-v1",
        "files": files,
        "membership_conversation_set_sha256": _digest(
            canonical_json_bytes(sorted(rooms))
        ),
        "room_count": len(rooms),
        "message_count": len(rows),
        "messages_fts_count": len(rows),
        "fts_tokenizers": {
            "messages_fts": "unicode61",
            "messages_fts_trigram": "trigram" if trigram else None,
        },
    }
    generation_id = "g-" + hashlib.sha256(
        canonical_json_bytes(manifest)
    ).hexdigest()
    destination = generation.parent / generation_id
    generation.replace(destination)
    generation = destination
    manifest["generation_id"] = generation_id
    manifest_payload = canonical_json_bytes(manifest)
    _write(generation / "package-manifest.json", manifest_payload)
    activation = {
        "schema_version": "kw-corpus-package-activation-v1",
        "sequence": sequence,
        "generation_id": generation_id,
        "manifest_relative": (
            f"kwrag/source/generations/{generation_id}/package-manifest.json"
        ),
        "manifest_sha256": _digest(manifest_payload),
        "previous_generation_id": previous,
    }
    _write(
        root / "kwrag" / "source" / f"activation-{activation_slot}.json",
        canonical_json_bytes(activation),
    )
    return generation_id


@pytest.fixture
def readonly_mount(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "kwrag.crawler_source.os.statvfs",
        lambda _path: SimpleNamespace(f_flag=os.ST_RDONLY),
    )


def test_same_generation_acceptance_and_trigram_preference(
    tmp_path: Path, readonly_mount: None
) -> None:
    _generation(
        tmp_path,
        token="1",
        sequence=1,
        rows=[("room-a", "m1", "가나다라마 내부 검색")],
    )
    with CanonicalCrawlerSource(tmp_path) as source:
        assert source.generation.lexical_tokenizer == "trigram"
        hits = source.search("나다라", ["room-a"], limit=5)
        assert [hit.message_id for hit in hits] == ["m1"]
        pipeline = CrawlerFtsSearchPipeline(source)
        response = pipeline.search("나다라", ["room-a"], 1)
        assert response["hits"][0]["message_ids"] == ["m1"]
        assert response["operation_evidence"]["backend_id"].endswith("trigram-v1")


def test_unicode61_is_explicit_compatibility_not_trigram_claim(
    tmp_path: Path, readonly_mount: None
) -> None:
    _generation(
        tmp_path,
        token="2",
        sequence=1,
        rows=[("room-a", "m1", "가나다라마 내부 검색")],
        trigram=False,
    )
    with CanonicalCrawlerSource(tmp_path) as source:
        assert source.generation.lexical_tokenizer == "unicode61"
        assert source.search("나다라", ["room-a"], limit=5) == []
        response = CrawlerFtsSearchPipeline(source).search(
            "가나다라마", ["room-a"], 1
        )
        assert response["hits"]
        assert "unicode61-compat" in response["operation_evidence"]["backend_id"]


def test_mixed_membership_and_database_generation_is_rejected(
    tmp_path: Path, readonly_mount: None
) -> None:
    _generation(
        tmp_path,
        token="3",
        sequence=1,
        rows=[("room-a", "m1", "text")],
        membership_rooms=["room-b"],
    )
    with pytest.raises(CrawlerSourceError, match="membership_database_scope_mismatch"):
        CanonicalCrawlerSource(tmp_path)


def test_corrupt_sqlite_is_rejected(tmp_path: Path, readonly_mount: None) -> None:
    _generation(
        tmp_path,
        token="4",
        sequence=1,
        rows=[("room-a", "m1", "text")],
        corrupt_database=True,
    )
    with pytest.raises(CrawlerSourceError, match="database_query_failed"):
        CanonicalCrawlerSource(tmp_path)


def test_writable_mount_is_rejected(tmp_path: Path) -> None:
    _generation(
        tmp_path,
        token="5",
        sequence=1,
        rows=[("room-a", "m1", "text")],
    )
    with pytest.raises(CrawlerSourceError, match="mount_root_not_readonly"):
        CanonicalCrawlerSource(tmp_path)


def test_generation_rollover_reopens_only_complete_generation(
    tmp_path: Path, readonly_mount: None
) -> None:
    first = _generation(
        tmp_path,
        token="6",
        sequence=1,
        rows=[("room-a", "m1", "first generation")],
    )
    with CanonicalCrawlerSource(tmp_path) as source:
        assert source.search("first", ["room-a"], limit=5)
        second = _generation(
            tmp_path,
            token="7",
            sequence=2,
            rows=[("room-a", "m2", "second generation")],
            activation_slot="b",
            previous=first,
        )
        hits = source.search("second", ["room-a"], limit=5)
        assert source.generation.generation_id == second
        assert [hit.message_id for hit in hits] == ["m2"]


def test_source_mutation_after_open_fails_closed(
    tmp_path: Path, readonly_mount: None
) -> None:
    generation_id = _generation(
        tmp_path,
        token="8",
        sequence=1,
        rows=[("room-a", "m1", "stable source")],
    )
    with CanonicalCrawlerSource(tmp_path) as source:
        database = (
            tmp_path
            / "kwrag"
            / "source"
            / "generations"
            / generation_id
            / "messages.sqlite"
        )
        database.touch()
        with pytest.raises(CrawlerSourceError, match="generation_file_identity_changed"):
            source.search("stable", ["room-a"], limit=5)


def test_stale_or_forked_activation_chain_is_rejected(
    tmp_path: Path, readonly_mount: None
) -> None:
    _generation(
        tmp_path,
        token="9",
        sequence=1,
        rows=[("room-a", "m1", "first")],
    )
    _generation(
        tmp_path,
        token="a",
        sequence=3,
        rows=[("room-a", "m2", "fork")],
        activation_slot="b",
        previous="g-" + "f" * 64,
    )
    with pytest.raises(CrawlerSourceError, match="activation_chain_invalid_or_stale"):
        CanonicalCrawlerSource(tmp_path)
