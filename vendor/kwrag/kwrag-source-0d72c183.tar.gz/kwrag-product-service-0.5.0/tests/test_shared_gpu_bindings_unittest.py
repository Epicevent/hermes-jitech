from __future__ import annotations

import copy
import os
import tempfile
import unittest
from pathlib import Path

from kwrag.dense_adapter import DenseAdapterError, load_dense_adapter_spec
from kwrag.dense_builder import (
    DenseBuilderConfigError,
    _sanitized_error_code,
    load_builder_spec,
)
from kwrag.dense_release import D_PIPELINE_FINGERPRINT
from kwrag.jsonutil import canonical_json_bytes
from kwrag.shared_gpu_contract import (
    KURE_MODEL,
    KURE_REVISION,
    MODEL_MAX_TOKENS,
    RERANK_MODEL,
    RERANK_REVISION,
)
from kwrag.shared_gpu_core import SharedGpuCore, SharedGpuCoreConfig
from kwrag.shared_gpu_models import (
    NonProductionDeterministicBackend,
    PinnedKureBgeBackend,
)
from kwrag.shared_gpu_service import (
    SharedGpuServiceConfigError,
    load_service_spec,
)


ROOT = Path(__file__).resolve().parents[2]


def _write(path: Path, value: dict) -> None:
    path.write_bytes(canonical_json_bytes(value))
    path.chmod(0o600)


class BindingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_shared_service_config_has_no_model_or_policy_override(self) -> None:
        value = {
            "schema_version": "kwrag-shared-gpu-service-config-v1",
            "model_cache_root": self.root.as_posix(),
            "dtype": "float32",
            "embedding_batch_size": 32,
            "rerank_batch_size": 16,
            "max_concurrent": 1,
            "max_queue": 8,
            "endpoints": [
                {
                    "socket_path": (self.root / "slot-a.sock").as_posix(),
                    "socket_mode": "0600",
                    "grants": [
                        {"slot": "slot-a", "uid": os.geteuid(), "gid": os.getegid()}
                    ],
                }
            ],
        }
        path = self.root / "gpu.json"
        _write(path, value)
        spec = load_service_spec(path)
        self.assertEqual(spec.endpoints[0].grants[0].slot, "slot-a")
        self.assertEqual(spec.model_cache_root, self.root)
        multiple_grants = copy.deepcopy(value)
        multiple_grants["endpoints"][0]["grants"].append(
            {"slot": "slot-b", "uid": os.geteuid() + 1, "gid": os.getegid() + 1}
        )
        _write(self.root / "multiple-grants.json", multiple_grants)
        with self.assertRaisesRegex(SharedGpuServiceConfigError, "endpoint grants"):
            load_service_spec(self.root / "multiple-grants.json")
        reused_peer = copy.deepcopy(value)
        reused_peer["endpoints"].append(
            {
                "socket_path": (self.root / "slot-b.sock").as_posix(),
                "socket_mode": "0600",
                "grants": [
                    {
                        "slot": "slot-b",
                        "uid": os.geteuid(),
                        "gid": os.getegid(),
                    }
                ],
            }
        )
        _write(self.root / "reused-peer.json", reused_peer)
        with self.assertRaisesRegex(SharedGpuServiceConfigError, "peer is bound"):
            load_service_spec(self.root / "reused-peer.json")
        value["model"] = "floating/model"
        _write(self.root / "invalid.json", value)
        with self.assertRaisesRegex(SharedGpuServiceConfigError, "fields"):
            load_service_spec(self.root / "invalid.json")

    def test_dense_adapter_binds_exact_principal_and_pipeline(self) -> None:
        value = {
            "schema_version": "kwrag-dense-adapter-binding-v1",
            "enabled": False,
            "slot": "slot-a",
            "expected_uid": os.geteuid(),
            "expected_gid": os.getegid(),
            "socket_path": (self.root / "slot-a.sock").as_posix(),
            "gpu_receipt_path": (self.root / "gpu.jsonl").as_posix(),
            "deadline_ms": 30_000,
            "candidate_pool": 30,
            "pipeline_fingerprint": D_PIPELINE_FINGERPRINT,
        }
        path = self.root / "adapter.json"
        _write(path, value)
        spec = load_dense_adapter_spec(path)
        self.assertFalse(spec.enabled)
        self.assertEqual(spec.expected_uid, os.geteuid())
        value["slot"] = "../other"
        _write(self.root / "escape.json", value)
        with self.assertRaisesRegex(DenseAdapterError, "slot"):
            load_dense_adapter_spec(self.root / "escape.json")

    def test_dense_builder_config_derives_principal_and_rejects_unknown(self) -> None:
        value = {
            "schema_version": "kwrag-dense-builder-config-v1",
            "source_mount_root": self.root.as_posix(),
            "output_root": (self.root / "output").as_posix(),
            "slot_namespace": "slot-a",
            "socket_path": (self.root / "slot-a.sock").as_posix(),
            "gpu_receipt_path": (self.root / "build.jsonl").as_posix(),
            "expected_uid": os.geteuid(),
            "expected_gid": os.getegid(),
            "deadline_ms": 60_000,
        }
        path = self.root / "builder.json"
        _write(path, value)
        spec = load_builder_spec(path)
        self.assertEqual(spec.expected_uid, os.geteuid())
        value["fallback"] = "fts"
        _write(self.root / "fallback.json", value)
        with self.assertRaisesRegex(DenseBuilderConfigError, "fields"):
            load_builder_spec(self.root / "fallback.json")
        self.assertEqual(
            _sanitized_error_code(OSError("/private/customer/path")),
            "builder_io_error",
        )
        self.assertNotIn(
            "private", _sanitized_error_code(OSError("/private/customer/path"))
        )

    def test_fake_backend_cannot_enter_production_core(self) -> None:
        with self.assertRaisesRegex(ValueError, "nonproduction_backend_forbidden"):
            SharedGpuCore(
                NonProductionDeterministicBackend(),
                SharedGpuCoreConfig(allow_nonproduction_backend=False),
            )

    def test_pinned_loader_resolves_only_exact_offline_snapshots(self) -> None:
        embedding = (
            self.root
            / "models--nlpai-lab--KURE-v1"
            / "snapshots"
            / KURE_REVISION
        )
        rerank = (
            self.root
            / "models--BAAI--bge-reranker-v2-m3"
            / "snapshots"
            / RERANK_REVISION
        )
        embedding.mkdir(parents=True)
        rerank.mkdir(parents=True)
        embedding_config = {
            "architectures": ["XLMRobertaModel"],
            "hidden_size": 1024,
            "max_position_embeddings": 8194,
            "model_type": "xlm-roberta",
        }
        rerank_config = {
            "architectures": ["XLMRobertaForSequenceClassification"],
            "hidden_size": 1024,
            "max_position_embeddings": 8194,
            "model_type": "xlm-roberta",
        }
        _write(embedding / "config.json", embedding_config)
        _write(rerank / "config.json", rerank_config)
        _write(embedding / "modules.json", [])
        for snapshot in (embedding, rerank):
            (snapshot / "model.safetensors").write_bytes(b"fixture-model")
            (snapshot / "tokenizer.json").write_bytes(b"fixture-tokenizer")
        backend = PinnedKureBgeBackend(self.root)
        self.assertEqual(backend._snapshot(KURE_MODEL, KURE_REVISION), embedding)
        self.assertEqual(backend._snapshot(RERANK_MODEL, RERANK_REVISION), rerank)
        self.assertEqual(MODEL_MAX_TOKENS, 512)
        invalid_config = dict(embedding_config)
        invalid_config["hidden_size"] = 8
        _write(embedding / "config.json", invalid_config)
        with self.assertRaisesRegex(ValueError, "pinned_model_config_invalid"):
            backend._snapshot(KURE_MODEL, KURE_REVISION)
        with self.assertRaisesRegex(ValueError, "production_device_must_be_cuda"):
            PinnedKureBgeBackend(self.root, device="cpu")

    def test_packaged_and_repository_contracts_are_identical(self) -> None:
        repository = (ROOT / "contracts" / "kwrag-shared-gpu-v1.json").read_bytes()
        packaged = (
            ROOT
            / "service"
            / "src"
            / "kwrag"
            / "engine_artifacts"
            / "shared-gpu-contract-v1.json"
        ).read_bytes()
        self.assertEqual(repository, packaged)


if __name__ == "__main__":
    unittest.main()
