from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from kwrag.jsonutil import canonical_json_bytes, loads_strict_json
from kwrag.slot_consumer import SlotConsumptionError, verify_slot_search_exchange


ROOT = Path(__file__).resolve().parents[2]
FIXTURE_ROOT = ROOT / "contracts" / "fixtures" / "slot-local-retrieval-v1"


def _fixture(name: str) -> dict:
    payload = (FIXTURE_ROOT / name).read_bytes()
    assert payload.endswith(b"\n")
    return loads_strict_json(payload[:-1].decode("utf-8"))


def _verify(request: dict, response: dict, receipt: dict, *, max_chars: int = 1_000):
    return verify_slot_search_exchange(
        request,
        response,
        receipt,
        expected_index_manifest="sha256:" + "a" * 64,
        expected_pipeline_fingerprint="sha256:" + "b" * 64,
        max_result_characters=max_chars,
    )


def _rebind_receipt(response: dict, receipt: dict) -> None:
    response["operation_receipt"] = {
        "status": "written",
        "digest": "sha256:"
        + hashlib.sha256(canonical_json_bytes(receipt)).hexdigest(),
    }


def test_consumer_returns_fresh_results_only_after_full_binding() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")

    verified = _verify(request, response, receipt)

    assert verified.request_id == request["request_id"]
    assert verified.operation_id == request["operation_id"]
    assert verified.result_count == 1
    assert verified.result_characters == len(
        canonical_json_bytes(response["results"]).decode("utf-8")
    )
    first = verified.results()
    second = verified.results()
    assert first == response["results"]
    assert first is not second
    first[0]["snippet"] = "caller mutation"
    assert verified.results() == response["results"]


@pytest.mark.parametrize(
    ("target", "field", "replacement"),
    (
        ("response", "operation_id", "swapped-operation"),
        ("response", "pipeline_fingerprint", "sha256:" + "c" * 64),
        ("receipt", "request_id", "swapped-request"),
        ("receipt", "attempt", 2),
    ),
)
def test_consumer_rejects_swapped_correlation_or_runtime_identity(
    target: str, field: str, replacement: object
) -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    (response if target == "response" else receipt)[field] = replacement
    if target == "receipt":
        _rebind_receipt(response, receipt)

    with pytest.raises(SlotConsumptionError, match="binding is invalid"):
        _verify(request, response, receipt)


def test_consumer_rejects_result_or_receipt_tampering() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")

    response["results"][0]["snippet"] = "different"
    with pytest.raises(SlotConsumptionError, match="result binding is invalid"):
        _verify(request, response, receipt)

    response = _fixture("response.json")
    receipt["recorded_at"] = "2026-07-27T00:00:01Z"
    with pytest.raises(SlotConsumptionError, match="written operation receipt"):
        _verify(request, response, receipt)


def test_consumer_rejects_unwritten_or_unattested_exchange() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")

    response["operation_receipt"] = {"status": "unavailable", "digest": None}
    with pytest.raises(SlotConsumptionError, match="written operation receipt"):
        _verify(request, response, receipt)

    response = _fixture("response.json")
    receipt["pipeline_evidence"]["status"] = "partial"
    receipt["pipeline_evidence"]["data_boundary"] = {
        "bytes_sent_outside_slot": 10,
        "external_persistence": "unavailable",
        "persistence_receipt_digest": None,
    }
    receipt["pipeline_evidence"]["stages"][0][
        "execution_scope"
    ] = "shared_stateless"
    _rebind_receipt(response, receipt)
    with pytest.raises(SlotConsumptionError, match="not fully attested"):
        _verify(request, response, receipt)


def test_consumer_enforces_caller_result_character_budget() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    exact_characters = len(
        canonical_json_bytes(response["results"]).decode("utf-8")
    )

    assert _verify(
        request, response, receipt, max_chars=exact_characters
    ).result_characters == exact_characters
    with pytest.raises(SlotConsumptionError, match="character budget"):
        _verify(request, response, receipt, max_chars=exact_characters - 1)


@pytest.mark.parametrize(
    ("field", "replacement"),
    (
        ("id", "i" * 8_000),
        ("corpus", "c" * 256),
        ("path", "p" * 8_000),
        ("title", "t" * 8_000),
        ("source_ids", ["s" * 256] * 100),
    ),
)
def test_consumer_budgets_every_field_in_the_canonical_result_payload(
    field: str, replacement: object
) -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    original_characters = len(
        canonical_json_bytes(response["results"]).decode("utf-8")
    )
    response["results"][0][field] = replacement

    with pytest.raises(SlotConsumptionError, match="character budget"):
        _verify(request, response, receipt, max_chars=original_characters)


def test_consumer_and_runtime_apply_the_schema_length_before_stripping_query() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    request["query"] = " " + ("q" * 3_998) + " "
    receipt["query_chars"] = 3_998
    _rebind_receipt(response, receipt)

    verified = _verify(request, response, receipt)

    assert verified.operation_id == request["operation_id"]

    request["query"] += " "
    with pytest.raises(SlotConsumptionError, match="text field is invalid"):
        _verify(request, response, receipt)


def test_consumer_accepts_zero_hits_with_bound_empty_result_digest() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    empty_digest = "sha256:" + hashlib.sha256(canonical_json_bytes([])).hexdigest()

    response["results"] = []
    response["result_status"] = "zero_hits"
    response["result_digest"] = empty_digest
    receipt["result_status"] = "zero_hits"
    receipt["result_count"] = 0
    receipt["result_digest"] = empty_digest
    receipt["pipeline_evidence"]["returned_count"] = 0
    _rebind_receipt(response, receipt)

    verified = _verify(request, response, receipt, max_chars=2)
    assert verified.result_status == "zero_hits"
    assert verified.results() == []
    assert verified.result_characters == 2

    with pytest.raises(SlotConsumptionError, match="character budget"):
        _verify(request, response, receipt, max_chars=1)


def test_consumer_requires_explicit_product_correlation_fields() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    del request["operation_id"]

    with pytest.raises(SlotConsumptionError, match="request fields are invalid"):
        _verify(request, response, receipt)


def test_consumer_rejects_unknown_fields_before_digest_checks() -> None:
    request = _fixture("request.json")
    response = _fixture("response.json")
    receipt = _fixture("receipt.json")
    response["backend"] = "dense"

    with pytest.raises(SlotConsumptionError, match="response fields are invalid"):
        _verify(request, response, receipt)
