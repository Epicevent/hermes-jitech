from pathlib import Path
import subprocess
import sys
import tomllib


ROOT = Path(__file__).resolve().parents[2]


def test_shared_service_adr_is_explicitly_superseded() -> None:
    old = (ROOT / "docs" / "adr" / "0001-product-native-conversation-retrieval.md").read_text(
        encoding="utf-8"
    )
    assert "Status: Superseded by ADR 0002" in old
    assert "shared-corpus service and token-projection premise is not the ratified product design" in old
    assert "automatic search" in old
    assert "are not an approved" in old
    assert "They must not be implemented from this ADR" in old


def test_slot_mount_remains_authority_and_adr2_history_is_preserved() -> None:
    current = (ROOT / "docs" / "adr" / "0002-slot-mounted-storage-retrieval-authority.md").read_text(
        encoding="utf-8"
    )
    assert "내가 원하는 구조는 slot에 붙은 나스 (mount)만 검색도구가 보면 좋겠어" in current
    assert "Runtime search does not derive a token-to-corpora projection" in current
    assert "There is no shared KWRAG service that stores all corpus" in current
    assert "indexes or raw corpus" in current
    assert "data. There is no product authorization contract" in current
    assert "dense retrieval with shared stateless embedding/reranking versus a fully" in current
    assert "slot-local FTS path" in current
    assert "does not select FTS or shared stateless inference" in current
    assert "Research task `019f8270-a8f9-7d11-a3d0-a9fd3bb871ac` owns the experiments" in current
    assert "not an unassigned choice waiting" in current
    assert "implementation convenience is not a substitute" in current
    assert "provides only a transport-neutral, callable in-slot retrieval" in current
    assert "must not add an automatic prompt hook, default search, exploration" in current
    assert "research-owned decision" in current


def test_approved_d_product_is_defined_separately_from_later_fdr_tuning() -> None:
    accepted = (
        ROOT / "docs" / "adr" / "0003-shared-stateless-gpu-d-baseline.md"
    ).read_text(encoding="utf-8")

    assert "Status: Accepted for product implementation" in accepted
    assert "first product implementation is D" in accepted
    assert "Product containers have no GPU and no model cache" in accepted
    assert "caller-explicit and default-off" in accepted
    assert "unconditional F+D union is forbidden" in accepted
    assert "existing `messages.sqlite` remains the only semantic source" in accepted


def test_slot_application_has_no_projection_or_network_server_dependency() -> None:
    source = (ROOT / "service" / "src" / "kwrag" / "slot_api.py").read_text(
        encoding="utf-8"
    )

    assert "from .auth" not in source
    assert "TokenProjection" not in source
    assert "ThreadingHTTPServer" not in source
    assert "kwrag_net" not in source
    assert '"authorization_basis": "slot_mounted_storage"' in source


def test_package_metadata_does_not_advertise_the_superseded_shared_service() -> None:
    project = (ROOT / "service" / "pyproject.toml").read_text(encoding="utf-8")

    assert 'description = "Slot-mounted conversation retrieval boundary"' in project
    assert 'description = "Authorized shared conversation retrieval service"' not in project
    assert "kwrag-build-projection" not in project


def test_slot_runtime_core_has_no_mandatory_backend_dependency() -> None:
    project_path = ROOT / "service" / "pyproject.toml"
    project = tomllib.loads(project_path.read_text(encoding="utf-8"))["project"]

    assert project["dependencies"] == []
    assert set(project["optional-dependencies"]) == {
        "dense",
        "slot-dense",
        "shared-gpu",
    }
    assert set(project["optional-dependencies"]["dense"]) == {
        "numpy==2.5.1",
        "sentence-transformers==5.6.0",
        "torch==2.13.0",
    }
    assert project["optional-dependencies"]["slot-dense"] == ["numpy==2.5.1"]
    assert set(project["optional-dependencies"]["shared-gpu"]) == {
        "numpy==2.5.1",
        "sentence-transformers==5.6.0",
        "torch==2.13.0",
    }


def test_slot_runtime_import_does_not_touch_optional_backend_packages() -> None:
    source_root = ROOT / "service" / "src"
    probe = r'''
import importlib.abc
import sys

blocked = {"numpy", "sentence_transformers", "torch", "transformers"}

class RejectOptionalBackend(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".", 1)[0] in blocked:
            raise ImportError("optional backend import attempted: " + fullname)
        return None

sys.meta_path.insert(0, RejectOptionalBackend())
sys.path.insert(0, sys.argv[1])
import kwrag
from kwrag.operation import OperationError
from kwrag.slot_api import SlotSearchExchange
from kwrag.slot_consumer import (
    SlotConsumptionError,
    VerifiedSlotSearchExchange,
    verify_slot_search_exchange,
)
assert kwrag.__all__ == [
    "SlotRuntime",
    "SlotRuntimeSpec",
    "build_slot_runtime",
    "load_slot_runtime_spec",
]
assert OperationError.__module__ == "kwrag.operation"
assert SlotSearchExchange.__module__ == "kwrag.slot_api"
assert SlotConsumptionError.__module__ == "kwrag.slot_consumer"
assert VerifiedSlotSearchExchange.__module__ == "kwrag.slot_consumer"
assert verify_slot_search_exchange.__module__ == "kwrag.slot_consumer"
'''
    completed = subprocess.run(
        [sys.executable, "-I", "-c", probe, str(source_root)],
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode == 0, completed.stderr


def test_package_top_level_exports_only_the_slot_runtime_boundary() -> None:
    import kwrag

    assert kwrag.__all__ == [
        "SlotRuntime",
        "SlotRuntimeSpec",
        "build_slot_runtime",
        "load_slot_runtime_spec",
    ]
    assert not hasattr(kwrag, "KwRagConfig")
    assert not hasattr(kwrag, "Pipeline")
