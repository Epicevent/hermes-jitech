from __future__ import annotations

import sqlite3
from pathlib import Path

import numpy as np

from kwrag.config import KwRagConfig
from kwrag.pipeline import Pipeline


class FakeEmbedder:
    def encode_one(self, text: str) -> np.ndarray:
        return np.array([1.0, 0.0], dtype=np.float32)

    def encode(self, texts: list[str]) -> np.ndarray:
        return np.tile(np.array([[1.0, 0.0]], dtype=np.float32), (len(texts), 1))


def _write_index(root: Path) -> None:
    database = root / "room_123.meta.sqlite"
    with sqlite3.connect(database) as connection:
        connection.executescript(
            """
            CREATE TABLE segments(seg_id INTEGER PRIMARY KEY, text TEXT, t_start INTEGER, t_end INTEGER);
            CREATE TABLE turns(turn_id INTEGER PRIMARY KEY, seg_id INTEGER, text TEXT, t INTEGER);
            CREATE TABLE turn_mids(turn_id INTEGER, mid TEXT);
            INSERT INTO segments VALUES (0, 'best evidence', 10, 20);
            INSERT INTO segments VALUES (1, 'other evidence', 30, 40);
            INSERT INTO turns VALUES (10, 0, 'best turn', 10);
            INSERT INTO turns VALUES (11, 1, 'other turn', 30);
            INSERT INTO turn_mids VALUES (10, 'm-best');
            INSERT INTO turn_mids VALUES (11, 'm-other');
            """
        )
    np.save(
        root / "room_123.npy",
        np.array([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32),
        allow_pickle=False,
    )


def test_dense_pipeline_reads_product_index_without_model_duplication(
    tmp_path: Path,
) -> None:
    _write_index(tmp_path)
    config = KwRagConfig(
        index_dir=tmp_path, cache_dir=tmp_path / "cache", rooms={"alpha": "123"}
    )
    config.rerank.enabled = False
    pipeline = Pipeline(config)
    fake = FakeEmbedder()
    pipeline.embedder = fake
    pipeline.retriever.embedder = fake

    response = pipeline.search("query", ["alpha"], 1)

    assert response["n_candidates"] == 2
    assert response["hits"][0]["seg_id"] == 0
    assert response["hits"][0]["message_ids"] == ["m-best"]
    assert response["hits"][0]["text"] == "best evidence"
    evidence = response["operation_evidence"]
    assert evidence["schema_version"] == "kwrag-slot-pipeline-evidence-v1"
    assert evidence["backend_id"] == "dense-rerank-v1"
    assert [stage["stage_id"] for stage in evidence["stages"]] == [
        "embedding",
        "index_search",
        "rerank",
    ]
    assert all(stage["execution_scope"] == "slot_local" for stage in evidence["stages"])
    assert evidence["stages"][0]["call_count"] == 1
    assert evidence["stages"][1]["output_count"] == 2
    assert evidence["stages"][2]["model"] is None
    assert evidence["candidate_count"] == 2
    assert evidence["data_boundary"] == {
        "bytes_sent_outside_slot": 0,
        "external_persistence": "not_applicable",
        "persistence_receipt_digest": None,
    }


def test_two_stage_pipeline_preserves_turn_score_and_namespaces_cache(
    tmp_path: Path,
) -> None:
    _write_index(tmp_path)
    config = KwRagConfig(
        index_dir=tmp_path, cache_dir=tmp_path / "cache", rooms={"alpha": "123"}
    )
    config.rerank.enabled = False
    config.ret.unit = "two_stage"
    pipeline = Pipeline(config, cache_namespace="sha256:" + "a" * 64)
    fake = FakeEmbedder()
    pipeline.embedder = fake
    pipeline.retriever.embedder = fake
    pipeline.returner.embedder = fake

    response = pipeline.search("query", ["alpha"], 1)

    assert response["hits"][0]["level"] == "turn"
    assert response["hits"][0]["seg_id"] == 10
    assert response["hits"][0]["score"] == 1.0
    assert response["hits"][0]["dense_score"] == 1.0
    cache_files = list((tmp_path / "cache").glob("room_123_turns_*.npy"))
    assert len(cache_files) == 1
    assert "sha256" not in cache_files[0].name
