"""Qualify and publish content-addressed shared-GPU product artifacts."""

from __future__ import annotations

import argparse
import configparser
import io
import os
import re
import stat
import sys
import time
import zipfile
from importlib import metadata
from pathlib import Path
from typing import Any

from build_input_manifest import build_manifest
from fixed_producer_release import (
    ReleaseError,
    _canonical,
    _digest,
    _publish,
    _read_file,
    _run,
    _safe_zip_name,
    _strict_json,
    _verify_clean_source,
)


PRODUCT_VERSION = "0.4.0"
PRODUCT_MODULES = (
    "crawler_fixed_producer.py",
    "crawler_source.py",
    "dense_adapter.py",
    "dense_builder.py",
    "dense_pipeline.py",
    "dense_release.py",
    "shared_gpu_contract.py",
    "shared_gpu_core.py",
    "shared_gpu_models.py",
    "shared_gpu_service.py",
    "shared_gpu_transport.py",
)


def _one_suffix(entries: dict[str, bytes], suffix: str) -> bytes:
    matches = [payload for name, payload in entries.items() if name.endswith(suffix)]
    if len(matches) != 1:
        raise ReleaseError(f"wheel member is missing or duplicated: {suffix}")
    return matches[0]


def _verify_wheel(
    payload: bytes,
    *,
    expected_epoch: int,
    shared_contract: bytes,
) -> dict[str, Any]:
    entries: dict[str, bytes] = {}
    timestamps: set[tuple[int, int, int, int, int, int]] = set()
    with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
        infos = archive.infolist()
        if len({info.filename for info in infos}) != len(infos):
            raise ReleaseError("wheel contains duplicate members")
        for info in infos:
            _safe_zip_name(info.filename)
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise ReleaseError("wheel contains a symlink")
            if info.filename.endswith((".pyc", ".pyo")) or "__pycache__" in info.filename:
                raise ReleaseError("wheel contains bytecode")
            timestamps.add(info.date_time)
            entries[info.filename] = archive.read(info)

    expected_time = list(time.gmtime(expected_epoch)[:6])
    expected_time[5] -= expected_time[5] % 2
    if timestamps != {tuple(expected_time)}:
        raise ReleaseError("wheel timestamp normalization is invalid")

    source_digests = {
        name: _digest(_one_suffix(entries, f"/{name}")) for name in PRODUCT_MODULES
    }
    packaged_contract = _one_suffix(
        entries, "/engine_artifacts/shared-gpu-contract-v1.json"
    )
    if packaged_contract != shared_contract:
        raise ReleaseError("wheel shared GPU contract bytes differ")
    _strict_json(packaged_contract)

    entry_points = _one_suffix(entries, ".dist-info/entry_points.txt")
    parser = configparser.ConfigParser()
    parser.read_string(entry_points.decode("utf-8"))
    console = dict(parser["console_scripts"])
    expected_console = {
        "kwrag-fixed-producer": "kwrag.crawler_fixed_producer:main",
        "kwrag-legacy-fixed-producer": "kwrag.fixed_producer:main",
        "kwrag-shared-gpu": "kwrag.shared_gpu_service:main",
        "kwrag-build-dense-release": "kwrag.dense_builder:main",
    }
    if any(console.get(name) != target for name, target in expected_console.items()):
        raise ReleaseError("shared GPU product entry points are invalid")

    package_metadata = _one_suffix(entries, ".dist-info/METADATA").decode("utf-8")
    if (
        "\nName: kwrag-product-service\n" not in "\n" + package_metadata
        or f"\nVersion: {PRODUCT_VERSION}\n" not in "\n" + package_metadata
    ):
        raise ReleaseError("wheel project identity is invalid")
    return {
        "member_count": len(entries),
        "timestamp_utc": "-".join(
            [
                f"{expected_time[0]:04d}",
                f"{expected_time[1]:02d}",
                f"{expected_time[2]:02d}",
            ]
        )
        + "T"
        + ":".join(f"{value:02d}" for value in expected_time[3:])
        + "Z",
        "source_digests": source_digests,
        "entrypoints": expected_console,
        "bytecode_members": 0,
        "symlink_members": 0,
    }


def _source_loc(repo: Path) -> dict[str, Any]:
    files: dict[str, int] = {}
    total = 0
    for name in PRODUCT_MODULES:
        path = repo / "service" / "src" / "kwrag" / name
        text = _read_file(path, maximum=2 * 1024 * 1024).decode("utf-8")
        count = sum(
            1
            for line in text.splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        )
        files[name] = count
        total += count
    return {
        "method": "nonblank_noncomment_physical_lines",
        "files": files,
        "total": total,
    }


def _normalized_loc(path: Path) -> int:
    text = _read_file(path, maximum=4 * 1024 * 1024).decode("utf-8")
    return sum(
        1
        for line in text.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    )


def _verify_tests(repo: Path, model_cache_root: Path) -> dict[str, Any]:
    service = repo / "service"
    environment = dict(os.environ)
    environment["PYTHONPATH"] = os.pathsep.join(
        [(service / "src").as_posix(), service.as_posix()]
    )
    environment["PYTHONDONTWRITEBYTECODE"] = "1"

    _run(
        [sys.executable, "-m", "compileall", "-q", "src", "crawler-successor", "tests"],
        cwd=service,
        env=environment,
    )
    unittest_output = _run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            "tests",
            "-p",
            "test_*_unittest.py",
            "-v",
        ],
        cwd=service,
        env=environment,
    )
    if "Ran 32 tests" not in unittest_output or "\nOK\n" not in unittest_output:
        raise ReleaseError("shared GPU unittest qualification marker is absent")

    contract_probe = """
from service.tests import test_design_authority as design
from service.tests import test_deployment_boundary as deploy
for name in (
    "test_approved_d_product_is_defined_separately_from_later_fdr_tuning",
    "test_slot_runtime_core_has_no_mandatory_backend_dependency",
    "test_package_metadata_does_not_advertise_the_superseded_shared_service",
):
    getattr(design, name)()
for name in (
    "test_compose_keeps_the_service_private_and_least_privileged",
    "test_deployment_runbook_matches_shared_gpu_and_slot_boundaries",
):
    getattr(deploy, name)()
"""
    _run(
        [sys.executable, "-c", contract_probe],
        cwd=repo,
        env=environment,
    )

    model_probe = """
from pathlib import Path
import sys
from kwrag.shared_gpu_contract import (
    KURE_MODEL, KURE_REVISION, RERANK_MODEL, RERANK_REVISION,
)
from kwrag.shared_gpu_models import PinnedKureBgeBackend
backend = PinnedKureBgeBackend(Path(sys.argv[1]))
assert backend._snapshot(KURE_MODEL, KURE_REVISION).name == KURE_REVISION
assert backend._snapshot(RERANK_MODEL, RERANK_REVISION).name == RERANK_REVISION
"""
    _run(
        [sys.executable, "-c", model_probe, model_cache_root.as_posix()],
        cwd=repo,
        env=environment,
    )
    return {
        "schema_version": "kwrag-shared-gpu-product-test-receipt-v1",
        "status": "passed",
        "unittest_cases": 32,
        "crawler_publisher_successor_cases": 7,
        "modified_existing_contract_cases": 5,
        "compileall": True,
        "actual_sqlite_fts5": True,
        "actual_unix_socket": True,
        "crawler_generation_rollover": True,
        "dense_double_build": True,
        "dense_source_resolution": True,
        "slot_receipt_verification": True,
        "crawler_generation_double_build": True,
        "crawler_manifest_last": True,
        "crawler_activation_rollback": True,
        "crawler_package_isolation": True,
        "openclaw_hermes_stub_handoffs": True,
        "cached_model_metadata": {
            "kure_exact_revision": True,
            "bge_exact_revision": True,
            "gpu_model_load": False,
        },
        "network": False,
        "credentials": False,
        "runtime_mutation": False,
    }


def release(args: argparse.Namespace) -> dict[str, Any]:
    repo = Path(__file__).resolve().parents[2]
    _verify_clean_source(repo, args.source_commit)
    source_epoch = int(args.source_date_epoch)
    if source_epoch < 315532800:
        raise ReleaseError("source date epoch is invalid")

    wheel_a = _read_file(Path(args.wheel), maximum=512 * 1024 * 1024)
    wheel_b = _read_file(
        Path(args.reproduction_wheel), maximum=512 * 1024 * 1024
    )
    if wheel_a != wheel_b:
        raise ReleaseError("wheel reproduction bytes differ")
    bundle_a = _read_file(Path(args.source_bundle), maximum=1024 * 1024 * 1024)
    bundle_b = _read_file(
        Path(args.reproduction_source_bundle), maximum=1024 * 1024 * 1024
    )
    if bundle_a != bundle_b:
        raise ReleaseError("source bundle reproduction bytes differ")
    _run(
        ["git", "bundle", "verify", str(Path(args.source_bundle).resolve())],
        cwd=repo,
    )

    shared_contract = _read_file(
        repo / "contracts" / "kwrag-shared-gpu-v1.json",
        maximum=1024 * 1024,
    )
    publication_contract = _read_file(
        repo / "contracts" / "kw-corpus-sqlite-generation-publication-v1.json",
        maximum=1024 * 1024,
    )
    consumer_contract = _read_file(
        repo / "contracts" / "kwrag-product-consumer-interfaces-v1.json",
        maximum=1024 * 1024,
    )
    crawler_source = _read_file(
        repo / "service" / "crawler-successor" / "kw_corpus" / "nas"
        / "generation_publish.py",
        maximum=4 * 1024 * 1024,
    )
    crawler_baseline = _read_file(
        repo / "service" / "crawler-successor" / "source-baseline.json",
        maximum=1024 * 1024,
    )
    crawler_integration_patch = _read_file(
        repo / "service" / "crawler-successor"
        / "kw-corpus-publish-integration.patch",
        maximum=1024 * 1024,
    )
    packaged_contract = _read_file(
        repo
        / "service"
        / "src"
        / "kwrag"
        / "engine_artifacts"
        / "shared-gpu-contract-v1.json",
        maximum=1024 * 1024,
    )
    for contract in (
        shared_contract,
        publication_contract,
        consumer_contract,
        crawler_baseline,
        packaged_contract,
    ):
        _strict_json(contract)
    if shared_contract != packaged_contract:
        raise ReleaseError("repository and packaged shared GPU contracts differ")

    wheel_detail = _verify_wheel(
        wheel_a,
        expected_epoch=source_epoch,
        shared_contract=shared_contract,
    )
    test_receipt = _verify_tests(repo, Path(args.model_cache_root))
    gpu_smoke = {
        "status": args.gpu_smoke_status,
        "preflight": {
            "device": args.gpu_device,
            "utilization_percent": int(args.gpu_utilization_percent),
            "active_compute_processes": int(args.gpu_active_processes),
            "active_compute_memory_mib": int(args.gpu_active_memory_mib),
        },
        "model_load_performed": False,
        "reason": "existing GPU load made an additional model residency unsafe",
    }
    if gpu_smoke["status"] != "SKIPPED_UNSAFE_PRECONDITION":
        raise ReleaseError("GPU smoke status is invalid for this qualification")

    output_dir = Path(args.output_dir).resolve()
    wheel_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-product-wheel",
        suffix="whl",
        payload=wheel_a,
    )
    bundle_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-product-source",
        suffix="bundle",
        payload=bundle_a,
    )
    shared_contract_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-contract",
        suffix="json",
        payload=shared_contract,
    )
    publication_contract_artifact = _publish(
        output_dir,
        label="kwrag-crawler-generation-publication-contract",
        suffix="json",
        payload=publication_contract,
    )
    consumer_contract_artifact = _publish(
        output_dir,
        label="kwrag-product-consumer-interfaces",
        suffix="json",
        payload=consumer_contract,
    )
    crawler_source_artifact = _publish(
        output_dir,
        label="kw-corpus-generation-publisher-source",
        suffix="py",
        payload=crawler_source,
    )
    crawler_baseline_artifact = _publish(
        output_dir,
        label="kw-corpus-generation-publisher-baseline",
        suffix="json",
        payload=crawler_baseline,
    )
    crawler_patch_artifact = _publish(
        output_dir,
        label="kw-corpus-generation-publisher-integration",
        suffix="patch",
        payload=crawler_integration_patch,
    )
    build_input_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-build-input-manifest",
        suffix="json",
        payload=_canonical(build_manifest(repo / "service")),
    )
    test_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-product-test-receipt",
        suffix="json",
        payload=_canonical(test_receipt),
    )

    branch = _run(["git", "branch", "--show-current"], cwd=repo).strip()
    component_manifest = {
        "schema_version": "kwrag-shared-gpu-product-component-manifest-v1",
        "source": {
            "commit": args.source_commit,
            "branch": branch,
            "bundle": bundle_artifact,
            "loc": _source_loc(repo),
        },
        "wheel": wheel_artifact,
        "shared_gpu_contract": shared_contract_artifact,
        "crawler_publication_contract": publication_contract_artifact,
        "product_consumer_interfaces": consumer_contract_artifact,
        "crawler_publisher_successor": {
            "source": crawler_source_artifact,
            "source_baseline": crawler_baseline_artifact,
            "integration_patch": crawler_patch_artifact,
            "normalized_source_loc": _normalized_loc(
                repo / "service" / "crawler-successor" / "kw_corpus" / "nas"
                / "generation_publish.py"
            ),
            "target": "/kakao-work/users/<package>",
            "runtime_imported": False,
            "nas_publication_performed": False,
        },
        "build_input_manifest": build_input_artifact,
        "test_receipt": test_artifact,
        "gpu_smoke": gpu_smoke,
        "product": {
            "baseline": "D",
            "caller_explicit": True,
            "default_enabled": False,
            "product_slots_have_gpu": False,
            "product_slots_have_model_cache": False,
            "shared_plane": "host_local_stateless_uds",
            "source": "existing_crawler_messages.sqlite_generation",
            "fts_role": "replaceable_direct_source_pipeline_not_product_reduction",
            "fts_preferred": "messages_fts_trigram",
            "fts_compatibility": "messages_fts_unicode61",
            "fallback": None,
            "unconditional_union": False,
        },
        "model_identity": {
            "embedding": {
                "model": "nlpai-lab/KURE-v1",
                "revision": "d14c8a9423946e268a0c9952fecf3a7aabd73bd9",
                "dimension": 1024,
            },
            "rerank": {
                "model": "BAAI/bge-reranker-v2-m3",
                "revision": "953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e",
            },
            "max_tokens": 512,
            "offline": True,
        },
        "claims": {
            "source": "landed_in_clean_successor_commit",
            "build": "two_build_byte_equal",
            "install": False,
            "runtime": False,
            "dev": False,
            "customer": False,
            "canary": False,
        },
        "durable_content": {
            "raw_query": False,
            "raw_result": False,
            "prompt": False,
            "nas_content": False,
            "credential": False,
            "environment": False,
        },
        "wheel_verification": wheel_detail,
    }
    manifest_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-product-component-manifest",
        suffix="json",
        payload=_canonical(component_manifest),
    )
    build_receipt = {
        "schema_version": "kwrag-shared-gpu-product-build-receipt-v1",
        "source_commit": args.source_commit,
        "source_date_epoch": source_epoch,
        "component_manifest": manifest_artifact,
        "wheel": wheel_artifact,
        "source_bundle": bundle_artifact,
        "test_receipt": test_artifact,
        "gpu_smoke": gpu_smoke,
        "reproduction": {
            "wheel_build_count": 2,
            "wheel_byte_equal": True,
            "wheel_a_sha256": _digest(wheel_a),
            "wheel_b_sha256": _digest(wheel_b),
            "source_bundle_build_count": 2,
            "source_bundle_byte_equal": True,
            "source_bundle_a_sha256": _digest(bundle_a),
            "source_bundle_b_sha256": _digest(bundle_b),
            "python": ".".join(str(value) for value in sys.version_info[:3]),
            "setuptools": metadata.version("setuptools"),
            "wheel": metadata.version("wheel"),
        },
        "authority_used": {
            "root": False,
            "install": False,
            "runtime": False,
            "dev": False,
            "customer": False,
            "canary": False,
        },
    }
    receipt_artifact = _publish(
        output_dir,
        label="kwrag-shared-gpu-product-build-receipt",
        suffix="json",
        payload=_canonical(build_receipt),
    )
    return {
        "schema_version": "kwrag-shared-gpu-product-release-result-v1",
        "source_commit": args.source_commit,
        "component_manifest": manifest_artifact,
        "build_receipt": receipt_artifact,
        "wheel": wheel_artifact,
        "source_bundle": bundle_artifact,
        "test_receipt": test_artifact,
        "shared_gpu_contract": shared_contract_artifact,
        "crawler_publication_contract": publication_contract_artifact,
        "product_consumer_interfaces": consumer_contract_artifact,
        "crawler_publisher_source": crawler_source_artifact,
        "crawler_publisher_baseline": crawler_baseline_artifact,
        "crawler_publisher_integration_patch": crawler_patch_artifact,
    }


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wheel", required=True)
    parser.add_argument("--reproduction-wheel", required=True)
    parser.add_argument("--source-bundle", required=True)
    parser.add_argument("--reproduction-source-bundle", required=True)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--source-date-epoch", required=True)
    parser.add_argument("--model-cache-root", required=True)
    parser.add_argument("--gpu-smoke-status", required=True)
    parser.add_argument("--gpu-device", required=True)
    parser.add_argument("--gpu-utilization-percent", required=True)
    parser.add_argument("--gpu-active-processes", required=True)
    parser.add_argument("--gpu-active-memory-mib", required=True)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def main() -> int:
    try:
        result = release(_arguments())
    except (OSError, UnicodeDecodeError, ValueError, zipfile.BadZipFile) as exc:
        code = str(exc) if isinstance(exc, ReleaseError) else "release_input_invalid"
        print(
            _canonical(
                {
                    "schema_version": "kwrag-shared-gpu-product-release-error-v1",
                    "code": code,
                }
            ).decode("utf-8")
        )
        return 1
    print(_canonical(result).decode("utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
