"""Print an exact installed dependency closure without importing ML packages.

Run this with the Python interpreter whose environment is being captured. The
script reads distribution metadata only and makes no network or filesystem
writes.
"""

from __future__ import annotations

import sys
from importlib.metadata import PackageNotFoundError, distribution

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name


def installed_closure(roots: list[str]) -> list[tuple[str, str]]:
    environment = default_environment()
    environment["extra"] = ""
    pending = [canonicalize_name(root) for root in roots]
    seen: dict[str, tuple[str, str]] = {}
    while pending:
        requested = pending.pop()
        if requested in seen:
            continue
        try:
            installed = distribution(requested)
        except PackageNotFoundError as exc:
            raise SystemExit(f"required installed distribution is missing: {requested}") from exc
        canonical = canonicalize_name(installed.metadata["Name"])
        seen[canonical] = (installed.metadata["Name"], installed.version)
        for raw_requirement in installed.requires or []:
            requirement = Requirement(raw_requirement)
            if requirement.marker is not None and not requirement.marker.evaluate(environment):
                continue
            dependency = canonicalize_name(requirement.name)
            if dependency not in seen:
                pending.append(dependency)
    return [seen[name] for name in sorted(seen)]


def main() -> None:
    roots = sys.argv[1:] or ["numpy", "sentence-transformers", "torch"]
    for name, version in installed_closure(roots):
        print(f"{name}=={version}")


if __name__ == "__main__":
    main()
