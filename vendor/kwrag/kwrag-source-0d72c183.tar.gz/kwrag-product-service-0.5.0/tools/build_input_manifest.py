"""Print the canonical product-image build-input manifest and digest.

This command is read-only. It hashes exactly the files that can affect the
Docker image and writes a deterministic JSON receipt only to stdout.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


FIXED_INPUTS = (
    ".dockerignore",
    "Dockerfile",
    "pyproject.toml",
    "requirements.arm64.lock",
)


def build_manifest(context: Path) -> dict[str, object]:
    context = context.resolve(strict=True)
    candidates = [context / name for name in FIXED_INPUTS]
    candidates.extend(sorted((context / "src").rglob("*")))
    files: list[dict[str, object]] = []
    for path in candidates:
        if path.is_symlink():
            raise ValueError(f"build input must not be a symlink: {path}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError(f"required build input is missing: {path}")
        relative = path.relative_to(context).as_posix()
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".pyo"}:
            continue
        content = path.read_bytes()
        files.append(
            {
                "path": relative,
                "bytes": len(content),
                "sha256": hashlib.sha256(content).hexdigest(),
            }
        )
    payload: dict[str, object] = {
        "schema_version": 1,
        "files": sorted(files, key=lambda item: str(item["path"])),
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return {
        "build_input_digest": "sha256:" + hashlib.sha256(canonical).hexdigest(),
        **payload,
    }


def main() -> None:
    if len(sys.argv) > 2:
        raise SystemExit("usage: build_input_manifest.py [service-context]")
    default_context = Path(__file__).resolve().parents[1]
    context = Path(sys.argv[1]) if len(sys.argv) == 2 else default_context
    print(json.dumps(build_manifest(context), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
