"""Create content-addressed fixed-producer release artifacts after a clean build."""

from __future__ import annotations

import argparse
import configparser
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


SETUPTOOLS_WHEEL_SHA256 = (
    "29b23c360f22f414dc7336bb39178cc7bcbf6021ed2733cde173f09dba19abb3"
)
SETUPTOOLS_WHEEL_BYTES = 1_008_090
FACTORY_SHA256 = "104276b46fa427d741fcf63db87b70d9a6d8a2ad32e63c4a43e87692041ed43e"
ENGINE_CONTRACT_SHA256 = (
    "46dbce894e5987fb47598b26d0c29bf3c13c297f705a17c313d550cc6dbc844a"
)
DECISION_SOURCE_SHA256 = (
    "2245278aa9ad4e16ad8502287a0e10340c90a83fa93a2e26210c8f43c6f8f5e1"
)
OWNER_MANIFEST_SHA256 = (
    "60cc8be1962f7c75b1829c7facc3a484d5edb2eee0a120dfaad91b694749bf82"
)
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


class ReleaseError(ValueError):
    pass


def _canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _read_file(path: Path, *, maximum: int = 1024 * 1024 * 1024) -> bytes:
    source = Path(path)
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    descriptor = os.open(source, flags)
    chunks: list[bytes] = []
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size < 0
            or before.st_size > maximum
        ):
            raise ReleaseError("release input identity is invalid")
        total = 0
        while True:
            block = os.read(descriptor, min(1024 * 1024, maximum + 1 - total))
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise ReleaseError("release input is too large")
            chunks.append(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_nlink,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_nlink,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise ReleaseError("release input changed while reading")
    finally:
        os.close(descriptor)
    return b"".join(chunks)


def _strict_json(payload: bytes) -> Any:
    def pairs_hook(pairs):
        output = {}
        for key, value in pairs:
            if key in output:
                raise ReleaseError("duplicate JSON key")
            output[key] = value
        return output

    def reject_constant(value):
        raise ReleaseError(f"non-finite JSON value: {value}")

    return json.loads(
        payload.decode("utf-8"),
        object_pairs_hook=pairs_hook,
        parse_constant=reject_constant,
    )


def _run(argv: list[str], *, cwd: Path, env: dict[str, str] | None = None) -> str:
    completed = subprocess.run(
        argv,
        cwd=cwd,
        env=env,
        check=False,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
    )
    if completed.returncode != 0:
        raise ReleaseError(f"fixed command failed: {argv[0]}")
    return completed.stdout


def _verify_clean_source(repo: Path, source_commit: str) -> None:
    if not re.fullmatch(r"[0-9a-f]{40}", source_commit):
        raise ReleaseError("source commit is invalid")
    head = _run(["git", "rev-parse", "HEAD"], cwd=repo).strip()
    if head != source_commit:
        raise ReleaseError("source commit does not match HEAD")
    status = _run(
        ["git", "status", "--porcelain=v1", "--untracked-files=all"],
        cwd=repo,
    )
    if status:
        raise ReleaseError("source tree is not clean")


def _verify_selftest(repo: Path) -> dict[str, Any]:
    service = repo / "service"
    test_path = service / "tests" / "test_fixed_producer.py"
    environment = dict(os.environ)
    environment["PYTHONPATH"] = (service / "src").as_posix()
    output = _run(
        [sys.executable, "tests/test_fixed_producer.py"],
        cwd=service,
        env=environment,
    )
    marker = (
        "KWRAG_FIXED_PRODUCER_SELFTEST=PASS cases=11 actual_sqlite_fts5=1 "
        "search_pipeline=1 slot_application=1 exchange_verifier=1 "
        "model_dispatch=0 provider_dispatch=0 host_ports=0 network=0"
    )
    if marker not in output:
        raise ReleaseError("fixed producer selftest marker is absent")
    return {
        "schema_version": "kwrag-fixed-producer-test-receipt-v1",
        "status": "passed",
        "source_commit": _run(["git", "rev-parse", "HEAD"], cwd=repo).strip(),
        "test_source_digest": _digest(_read_file(test_path, maximum=1024 * 1024)),
        "command": ["python3", "tests/test_fixed_producer.py"],
        "cases": 11,
        "observed": {
            "actual_sqlite_fts5": 1,
            "search_pipeline": 1,
            "slot_application": 1,
            "exchange_verifier": 1,
            "model_dispatch": 0,
            "provider_dispatch": 0,
            "host_ports": 0,
            "network": 0,
        },
        "authority": {
            "root": False,
            "install": False,
            "dev": False,
            "customer": False,
            "canary": False,
        },
    }


def _verify_index_publication_selftest(repo: Path) -> dict[str, Any]:
    service = repo / "service"
    test_path = service / "tests" / "test_index_release.py"
    environment = dict(os.environ)
    environment["PYTHONPATH"] = (service / "src").as_posix()
    output = _run(
        [sys.executable, "tests/test_index_release.py"],
        cwd=service,
        env=environment,
    )
    marker = (
        "KWRAG_INDEX_PUBLICATION_SELFTEST=PASS cases=12 "
        "network=0 credentials=0 publication=simulated"
    )
    if marker not in output:
        raise ReleaseError("index publication selftest marker is absent")
    return {
        "schema_version": "kwrag-index-publication-test-receipt-v1",
        "status": "passed",
        "source_commit": _run(["git", "rev-parse", "HEAD"], cwd=repo).strip(),
        "test_source_digest": _digest(
            _read_file(test_path, maximum=1024 * 1024)
        ),
        "command": ["python3", "tests/test_index_release.py"],
        "cases": 12,
        "observed": {
            "deterministic_double_build": True,
            "slot_isolation": True,
            "manifest_last": True,
            "idempotent_retry": True,
            "immutable_mismatch_fail_closed": True,
            "network": False,
            "credentials": False,
            "publication": "simulated",
        },
    }


def _safe_zip_name(name: str) -> None:
    path = PurePosixPath(name)
    if (
        not name
        or name.startswith("/")
        or "\\" in name
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise ReleaseError("wheel contains an unsafe path")


def _one_suffix(entries: dict[str, bytes], suffix: str) -> bytes:
    matches = [payload for name, payload in entries.items() if name.endswith(suffix)]
    if len(matches) != 1:
        raise ReleaseError(f"wheel member is missing or duplicated: {suffix}")
    return matches[0]


def _verify_wheel(
    wheel_payload: bytes,
    *,
    expected_epoch: int,
    component_contract: bytes,
) -> dict[str, Any]:
    entries: dict[str, bytes] = {}
    timestamps: set[tuple[int, int, int, int, int, int]] = set()
    with zipfile.ZipFile(io.BytesIO(wheel_payload), "r") as archive:
        infos = archive.infolist()
        if len({info.filename for info in infos}) != len(infos):
            raise ReleaseError("wheel contains duplicate members")
        for info in infos:
            _safe_zip_name(info.filename)
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise ReleaseError("wheel contains a symlink")
            timestamps.add(info.date_time)
            entries[info.filename] = archive.read(info)
    expected_time = list(time.gmtime(expected_epoch)[:6])
    expected_time[5] -= expected_time[5] % 2
    if timestamps != {tuple(expected_time)}:
        raise ReleaseError("wheel timestamp normalization is invalid")

    factory = _one_suffix(entries, "/engines/p1_attachment_fts_v1.py")
    engine_contract = _one_suffix(
        entries,
        "/engine_artifacts/p1-attachment-fts-contract.json",
    )
    decision = _one_suffix(entries, "/engine_artifacts/p1-15b-reassessment.json")
    owner = _one_suffix(
        entries,
        "/engine_artifacts/kwrag-owner-source-transfer-manifest.json",
    )
    packaged_component_contract = _one_suffix(
        entries,
        "/engine_artifacts/fixed-producer-contract-v1.json",
    )
    fixed_source = _one_suffix(entries, "/fixed_producer.py")
    index_release_source = _one_suffix(entries, "/index_release.py")
    index_publisher_source = _one_suffix(entries, "/index_publisher.py")
    if (
        hashlib.sha256(factory).hexdigest() != FACTORY_SHA256
        or hashlib.sha256(engine_contract).hexdigest() != ENGINE_CONTRACT_SHA256
        or hashlib.sha256(decision).hexdigest() != DECISION_SOURCE_SHA256
        or hashlib.sha256(owner).hexdigest() != OWNER_MANIFEST_SHA256
        or packaged_component_contract != component_contract
    ):
        raise ReleaseError("wheel selected-engine or contract bytes are invalid")
    _strict_json(engine_contract)
    _strict_json(decision)
    _strict_json(owner)
    _strict_json(packaged_component_contract)

    entry_points = _one_suffix(entries, ".dist-info/entry_points.txt")
    parser = configparser.ConfigParser()
    parser.read_string(entry_points.decode("utf-8"))
    console = dict(parser["console_scripts"])
    if (
        console.get("kwrag-fixed-producer") != "kwrag.fixed_producer:main"
        or console.get("kwrag-build-index-release")
        != "kwrag.index_release:main"
        or console.get("kwrag-publish-index-release")
        != "kwrag.index_publisher:main"
    ):
        raise ReleaseError("component entry points are invalid")
    metadata = _one_suffix(entries, ".dist-info/METADATA").decode("utf-8")
    if (
        "\nName: kwrag-product-service\n" not in "\n" + metadata
        or "\nVersion: 0.3.0\n" not in "\n" + metadata
    ):
        raise ReleaseError("wheel project identity is invalid")
    return {
        "fixed_source_digest": _digest(fixed_source),
        "index_release_source_digest": _digest(index_release_source),
        "index_publisher_source_digest": _digest(index_publisher_source),
        "member_count": len(entries),
        "timestamp_utc": "-".join(
            [
                f"{expected_time[0]:04d}",
                f"{expected_time[1]:02d}",
                f"{expected_time[2]:02d}",
            ]
        )
        + "T"
        + ":".join(f"{item:02d}" for item in expected_time[3:])
        + "Z",
    }


def _write_exact(path: Path, payload: bytes) -> None:
    target = Path(path)
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        descriptor = os.open(
            target,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
            0o600,
        )
    except FileExistsError:
        existing = _read_file(target, maximum=max(len(payload), 1))
        metadata = target.stat(follow_symlinks=False)
        if (
            existing != payload
            or metadata.st_uid != os.geteuid()
            or stat.S_IMODE(metadata.st_mode) != 0o600
            or metadata.st_nlink != 1
        ):
            raise ReleaseError("existing artifact identity is invalid")
        return
    try:
        view = memoryview(payload)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise ReleaseError("artifact write made no progress")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _publish(
    output_dir: Path,
    *,
    label: str,
    suffix: str,
    payload: bytes,
) -> dict[str, Any]:
    digest = _digest(payload)
    name = f"{label}-sha256-{digest.removeprefix('sha256:')}.{suffix}"
    _write_exact(output_dir / name, payload)
    return {
        "file": name,
        "bytes": len(payload),
        "sha256": digest,
    }


def release(args: argparse.Namespace) -> dict[str, Any]:
    repo = Path(__file__).resolve().parents[2]
    _verify_clean_source(repo, args.source_commit)
    source_epoch = int(args.source_date_epoch)
    if source_epoch < 315532800:
        raise ReleaseError("source date epoch is invalid")

    wheel_a = _read_file(Path(args.wheel), maximum=256 * 1024 * 1024)
    wheel_b = _read_file(Path(args.reproduction_wheel), maximum=256 * 1024 * 1024)
    if wheel_a != wheel_b:
        raise ReleaseError("wheel reproduction bytes differ")
    source_bundle = _read_file(Path(args.source_bundle), maximum=512 * 1024 * 1024)
    build_input = _read_file(
        Path(args.setuptools_wheel),
        maximum=16 * 1024 * 1024,
    )
    if (
        len(build_input) != SETUPTOOLS_WHEEL_BYTES
        or hashlib.sha256(build_input).hexdigest() != SETUPTOOLS_WHEEL_SHA256
    ):
        raise ReleaseError("setuptools build input is invalid")
    _run(
        ["git", "bundle", "verify", str(Path(args.source_bundle).resolve())],
        cwd=repo,
    )

    component_contract = _read_file(
        repo / "contracts" / "kwrag-fixed-producer-v1.json",
        maximum=1024 * 1024,
    )
    _strict_json(component_contract)
    publication_contract = _read_file(
        repo / "contracts" / "kwrag-index-publication-v1.json",
        maximum=1024 * 1024,
    )
    _strict_json(publication_contract)
    wheel_detail = _verify_wheel(
        wheel_a,
        expected_epoch=source_epoch,
        component_contract=component_contract,
    )
    test_receipt = _verify_selftest(repo)
    publication_test_receipt = _verify_index_publication_selftest(repo)
    output_dir = Path(args.output_dir).resolve()
    test_artifact = _publish(
        output_dir,
        label="kwrag-fixed-producer-test-receipt",
        suffix="json",
        payload=_canonical(test_receipt),
    )
    contract_artifact = _publish(
        output_dir,
        label="kwrag-fixed-producer-contract",
        suffix="json",
        payload=component_contract,
    )
    publication_contract_artifact = _publish(
        output_dir,
        label="kwrag-index-publication-contract",
        suffix="json",
        payload=publication_contract,
    )
    publication_test_artifact = _publish(
        output_dir,
        label="kwrag-index-publication-test-receipt",
        suffix="json",
        payload=_canonical(publication_test_receipt),
    )
    wheel_artifact = _publish(
        output_dir,
        label="kwrag-fixed-producer-wheel",
        suffix="whl",
        payload=wheel_a,
    )
    bundle_artifact = _publish(
        output_dir,
        label="kwrag-fixed-producer-source",
        suffix="bundle",
        payload=source_bundle,
    )

    component_manifest = {
        "schema_version": "kwrag-fixed-producer-component-manifest-v1",
        "source": {
            "commit": args.source_commit,
            "ref": "refs/heads/codex/kwrag-fixed-producer",
            "bundle": bundle_artifact,
        },
        "wheel": wheel_artifact,
        "component_contract": contract_artifact,
        "test_receipt": test_artifact,
        "index_publication_contract": publication_contract_artifact,
        "index_publication_test_receipt": publication_test_artifact,
        "surface": {
            "argv": ["kwrag-fixed-producer"],
            "binding_path": "/run/kwrag/fixed-producer-binding.json",
            "runtime_platform": "posix",
            "absolute_path_syntax": "strict_posix",
            "stdin_schema": "kwrag-slot-search-request-v1",
            "stdout_schema": "kwrag-fixed-producer-output-v1",
            "host_ports": 0,
            "network": False,
            "model_dispatch": False,
            "provider_dispatch": False,
        },
        "administrative_surface": {
            "build_argv": ["kwrag-build-index-release"],
            "publish_argv": ["kwrag-publish-index-release"],
            "authoritative_transport": "kw_corpus Synology DSM",
            "server_writer": False,
            "manifest_last": True,
            "default_enabled": False,
            "runtime_mutation": False,
        },
        "limits": {
            "results": 10,
            "complete_output_characters": 20_000,
        },
        "selected_engine": {
            "role": "replaceable_first_actual_engine_not_product_definition",
            "backend_id": "slot-local-fts5-trigram-or-attachment-v1",
            "factory_source_digest": "sha256:" + FACTORY_SHA256,
            "engine_contract_source_digest": "sha256:" + ENGINE_CONTRACT_SHA256,
            "research_decision_source_digest": "sha256:" + DECISION_SOURCE_SHA256,
            "pipeline_factory_digest": (
                "sha256:0dbe54f5a8bc56a6c821e181a0dc6cfda85d25be8cea6a01235cb5e347782f0e"
            ),
            "pipeline_fingerprint": (
                "sha256:53e14752cc9d147dfb4129e00234d1c7fb9f6558df00da7c03189db8da8e4606"
            ),
            "research_decision_digest": (
                "sha256:81e6f4d83e6cde6a9c83a9aa435c65354a1122dded735bf607462c3497e9b25d"
            ),
        },
        "wheel_verification": wheel_detail,
        "claims": {
            "source": "landed_in_successor_commit",
            "build": "deterministic_two_build_byte_equality",
            "install": False,
            "runtime": False,
            "dev": False,
            "customer": False,
            "canary": False,
        },
    }
    manifest_artifact = _publish(
        output_dir,
        label="kwrag-fixed-producer-component-manifest",
        suffix="json",
        payload=_canonical(component_manifest),
    )
    build_receipt = {
        "schema_version": "kwrag-fixed-producer-build-receipt-v1",
        "source_commit": args.source_commit,
        "source_date_epoch": source_epoch,
        "component_manifest": manifest_artifact,
        "component_contract": contract_artifact,
        "index_publication_contract": publication_contract_artifact,
        "wheel": wheel_artifact,
        "source_bundle": bundle_artifact,
        "test_receipt": test_artifact,
        "index_publication_test_receipt": publication_test_artifact,
        "reproduction": {
            "build_count": 2,
            "byte_equal": True,
            "wheel_a_digest": _digest(wheel_a),
            "wheel_b_digest": _digest(wheel_b),
            "setuptools": {
                "version": "83.0.0",
                "wheel_bytes": SETUPTOOLS_WHEEL_BYTES,
                "wheel_sha256": "sha256:" + SETUPTOOLS_WHEEL_SHA256,
                "installed": False,
            },
            "wheel_package_version": args.wheel_package_version,
            "python": ".".join(str(item) for item in sys.version_info[:3]),
        },
        "durable_content": {
            "raw_query": False,
            "raw_result": False,
            "nas_content": False,
            "prompt": False,
            "credential": False,
            "provider_payload": False,
        },
        "authority_used": {
            "root": False,
            "install": False,
            "dev": False,
            "customer": False,
            "canary": False,
        },
    }
    receipt_artifact = _publish(
        output_dir,
        label="kwrag-fixed-producer-build-receipt",
        suffix="json",
        payload=_canonical(build_receipt),
    )
    return {
        "schema_version": "kwrag-fixed-producer-release-result-v1",
        "source_commit": args.source_commit,
        "component_manifest": manifest_artifact,
        "build_receipt": receipt_artifact,
        "wheel": wheel_artifact,
        "source_bundle": bundle_artifact,
        "contract": contract_artifact,
        "index_publication_contract": publication_contract_artifact,
        "test_receipt": test_artifact,
        "index_publication_test_receipt": publication_test_artifact,
    }


def _arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wheel", required=True)
    parser.add_argument("--reproduction-wheel", required=True)
    parser.add_argument("--source-bundle", required=True)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--source-date-epoch", required=True)
    parser.add_argument("--setuptools-wheel", required=True)
    parser.add_argument("--wheel-package-version", required=True)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def main() -> int:
    try:
        result = release(_arguments())
    except (OSError, UnicodeDecodeError, ValueError, zipfile.BadZipFile) as exc:
        code = str(exc) if isinstance(exc, ReleaseError) else "release_input_invalid"
        print(
            _canonical(
                {
                    "schema_version": "kwrag-fixed-producer-release-error-v1",
                    "code": code,
                }
            ).decode("utf-8")
        )
        return 1
    print(_canonical(result).decode("utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
