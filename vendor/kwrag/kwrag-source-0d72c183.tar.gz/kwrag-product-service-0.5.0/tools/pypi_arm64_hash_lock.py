"""Resolve hashes for pinned CPython 3.12/aarch64 wheels from PyPI metadata.

The input must contain exact ``name==version`` pins only. The output is a pip
``--require-hashes`` file. This tool reads public PyPI JSON metadata and writes
only to stdout; it never downloads or installs a distribution.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from urllib.parse import quote
from urllib.request import urlopen

from packaging.utils import parse_wheel_filename

_PIN_RE = re.compile(r"^([A-Za-z0-9_.-]+)==([^\s]+)$")


def _python_compatible(interpreter: str, abi: str) -> bool:
    if interpreter == "py3" and abi == "none":
        return True
    if interpreter == "cp312" and abi in {"cp312", "abi3", "none"}:
        return True
    if interpreter.startswith("cp3") and abi == "abi3":
        try:
            digits = interpreter[2:]
            version = (int(digits[0]), int(digits[1:]))
            return version <= (3, 12)
        except ValueError:
            return False
    return False


def _platform_compatible(platform: str) -> bool:
    if platform == "any":
        return True
    if platform in {"linux_aarch64", "manylinux1_aarch64", "manylinux2010_aarch64", "manylinux2014_aarch64"}:
        return True
    match = re.fullmatch(r"manylinux_(\d+)_(\d+)_aarch64", platform)
    return bool(match and int(match.group(1)) == 2 and int(match.group(2)) <= 36)


def _compatible_wheel(filename: str) -> bool:
    try:
        _name, _version, _build, tags = parse_wheel_filename(filename)
    except ValueError:
        return False
    return any(
        _python_compatible(tag.interpreter, tag.abi)
        and _platform_compatible(tag.platform)
        for tag in tags
    )


def _pins(path: Path) -> list[tuple[str, str]]:
    result: list[tuple[str, str]] = []
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = _PIN_RE.fullmatch(line)
        if not match:
            raise SystemExit(f"non-exact pin at {path}:{line_number}")
        result.append((match.group(1), match.group(2)))
    if not result:
        raise SystemExit("pin file is empty")
    return result


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: pypi_arm64_hash_lock.py requirements.arm64-pins.txt")
    for name, version in _pins(Path(sys.argv[1])):
        endpoint = f"https://pypi.org/pypi/{quote(name)}/{quote(version)}/json"
        with urlopen(endpoint, timeout=30) as response:
            metadata = json.load(response)
        wheels = sorted(
            (
                item["filename"],
                str((item.get("digests") or {}).get("sha256") or ""),
            )
            for item in metadata.get("urls") or []
            if item.get("packagetype") == "bdist_wheel"
            and _compatible_wheel(str(item.get("filename") or ""))
        )
        wheels = [(filename, digest) for filename, digest in wheels if len(digest) == 64]
        if not wheels:
            raise SystemExit(f"no compatible hashed wheel for {name}=={version}")
        print(f"# {', '.join(filename for filename, _digest in wheels)}")
        print(f"{name}=={version} \\")
        for index, (_filename, digest) in enumerate(wheels):
            suffix = " \\" if index + 1 < len(wheels) else ""
            print(f"    --hash=sha256:{digest}{suffix}")


if __name__ == "__main__":
    main()
