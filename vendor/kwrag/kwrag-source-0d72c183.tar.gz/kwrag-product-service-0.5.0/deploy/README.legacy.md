# kwrag service deployment boundary

> **Superseded deployment evidence.** This shared token-projection stack is not
> a runnable product deployment for the slot-mounted design. The packaged
> `kwrag-service` entrypoint fails closed. Do not add the legacy diagnostic
> builder to a product command, Compose file, or runtime approval. The active
> product boundary is `contracts/slot-local-retrieval-v1.md`; its invocation
> transport remains a separate product-family decision.
> The central `kwrag-build-projection` console command is no longer installed;
> its source remains only as superseded verification evidence.

This directory defines the independent shared service stack. It does not alter
or reuse the live experiment process, port, cache, or index paths.

## Active slot-local implementation notes

These are implementation hardening details for the stable
`contracts/slot-local-retrieval-v1.md` interface. They do not add fields to its
public schemas or fixtures.

- The base Python distribution has no mandatory ML/backend dependency. Importing
  `kwrag` exposes only the backend-neutral slot runtime. The historical dense
  implementation is an explicit `dense` extra and its presence does not select
  the product backend. Product-family integration must not install that extra
  until the research-owned backend decision and product image change are
  separately approved.

- The live binding is one canonical JSON object with no BOM or trailing bytes.
  `load_slot_runtime_spec()` reads at most 64 KiB from a single-link regular
  file, does not follow a leaf symlink, rejects duplicate/noncanonical JSON,
  and rejects identity drift during the read. The repository fixture alone has
  its documented single LF and is not itself a live binding file.
- Runtime construction records the filesystem identity of the mount root,
  manifest, and every manifest-declared index file. `ready()` and `search()`
  fail closed before backend dispatch if any recorded object is replaced or
  its identity metadata changes. This detects local snapshot drift; it does
  not claim that a remote NAS server cannot alter bytes while preserving every
  measured identity field.
- The slot loader parses the manifest from a no-follow regular-file descriptor
  and hashes each confined manifest-declared file through the same descriptor
  whose identity it records. It does not hand a checked path back to the
  generic manifest loader for a second path-based open.
- Product runtime assembly also requires the kernel `statvfs` read-only mount
  flag before it loads the index or invokes the injected pipeline factory.
  Search rechecks the pinned snapshot after backend result normalization and
  discards the operation if an identity changed while the backend was running.
- On POSIX, receipt publication walks the absolute parent path with
  directory-fd `O_DIRECTORY|O_NOFOLLOW` opens, creates missing parents
  privately, opens the leaf relative to the pinned parent with
  `O_NOFOLLOW|O_APPEND`, and requires a single-link regular file owned by the
  runtime UID with mode `0600`. Each JSONL record is protected by an advisory
  file lock and file fsync; first creation also fsyncs the parent directory. A
  symlinked parent or leaf fails unavailable.
- File-descriptor reads and portable receipt appends use binary mode where the
  host exposes it, so Windows development fixtures cannot silently translate
  canonical LF-delimited bytes to CRLF or alter bytes before hashing.
- Product-owned optional adapters can call `search_exchange()` to retain the
  exact in-process operation receipt written for one response, then call
  `verify_slot_search_exchange()` to bind the request correlations, mounted
  manifest, pipeline fingerprint, result digest, written receipt digest, fully
  attested data boundary, and caller-selected complete canonical-results JSON
  character budget. Minimal two-field requests are retrieval-valid; product
  consumption uses the exact eight-field request profile with caller-generated
  request and operation IDs. A response whose receipt sink was unavailable is
  retrieval-valid but deliberately fails this consumption verifier. The stable
  adapter imports are `kwrag.operation.OperationError`,
  `kwrag.slot_api.SlotSearchExchange`, and the validation types/functions in
  `kwrag.slot_consumer`; they do not load an optional backend. The verifier
  returns fresh copies of still-untrusted evidence. It neither chooses when
  retrieval runs nor assembles a prompt, and successful validation is not a
  claim that Hermes or OpenClaw actually consumed the results.

## Release invariants

- The Dockerfile defaults to the Docker Official Image `python:3.12.3-slim`
  multi-platform digest `sha256:afc139...15a63` and fails unless its
  `linux/aarch64` image is selected. An override must still be an independently
  approved immutable digest.
- Python/CUDA dependencies are exact pins in `requirements.arm64-pins.txt` and
  every compatible wheel is hash-locked in `requirements.arm64.lock`. Build
  uses `--require-hashes --no-deps`; it does not run `apt`, `curl`, or an
  unconstrained dependency resolver.
- Build requires a lowercase 40-character `KWRAG_SOURCE_REVISION` and a
  `sha256:` `KWRAG_BUILD_INPUT_DIGEST`; both become image labels. A dirty or
  uncommitted worktree is therefore not eligible for a product image build.
- `tools/build_input_manifest.py` prints a canonical, read-only manifest for
  exactly `.dockerignore`, `Dockerfile`, `pyproject.toml`, the wheel lock, and
  `src/`. Its `build_input_digest` is the required build argument and must be
  archived beside the resulting image digest.
- Run only `KWRAG_IMAGE=<repository>@sha256:<digest>`; tags are not release
  identities.
- Use a new product index directory. Do not mount `index_bench` into this stack.
- The index, model cache, release manifest, config, and token projection are
  read-only. Only `/cache` and `/receipts` are writable.
- Each authorized pipeline dispatch attempts one canonical, non-secret
  `kwrag-search-operation-receipt/v1` append. The operation receipt separates
  completed zero-hit retrievals from failures and records local
  embedding/vector/rerank evidence. `provider_billing=not_applicable` means no
  external provider bill exists for that local operation; it is not `$0` and
  full hardware/electricity/operator cost remains unavailable.
- KWRAG attests retrieval, not prompt consumption. Hermes or OpenClaw must bind
  a consumed result to the operation, request, result, index, pipeline, and
  receipt digests and owns `rag_execution_status`, `injected_tokens`, and
  `tokenizer_id`. HTTP success or a non-empty hit list alone cannot be reported
  as evidence consumed by a model.
- The private token projection is generated from an ops-exported grant artifact;
  it is never edited independently.
- Grant exports and projections are valid for 300-3600 seconds. The service fails readiness and
  search closed when the projection expires. The service checks the projection
  file identity on every readiness and search request, reloads an atomically
  replaced valid projection without restart, and does not retain the previous
  projection if a changed file is invalid. Do not deploy until a root-owned
  refresh timer can regenerate, set final ownership and mode, and atomically
  replace it before expiry.
- `kwrag-build-projection` is a staging builder, not a live publisher. It
  runs only from the approved root refresh in the host root mount/user/NSS
  namespaces. The action digest pins the exact `--staging-root`; production
  must not use `/auth` from a container namespace. On POSIX it resolves
  `kwrag_rt` through `grp.getgrnam` and requires the auth fd to be
  `root:kwrag_rt 0750`. It only accepts the direct child
  `.staging-projection-UUID/token-projection.json` after checking root-owned
  directory fds, uid/gid/mode/link count, and same-device identity. It creates
  the output with `O_EXCL|O_NOFOLLOW`, verifies `root:root 0600`, regular,
  single-link and same-device identity, writes compact canonical UTF-8 bytes
  with no BOM or trailing newline, and fsyncs the opened fd. The root refresh owns final
  `root:kwrag_rt 0440` identity checks, monotonic publication receipts, and the
  atomic replacement of the live file.
- A canonical empty grant export is revoke-all, not an error: readiness remains
  healthy while every bearer token is rejected. A non-monotonic projection
  replacement is rejected to prevent a valid-but-older authorization rollback.
  Projection loading rejects duplicate keys and any raw representation other
  than the exact canonical bytes. Re-publishing the same generation and exact
  same raw projection digest is the only idempotent retry.
- The stack publishes no host port. Its only route is the `kwrag_net` bridge.
- The completed initial product index is `root:root` with `0750` directories
  and immutable `0440` published files. Do not work around this by running the
  service as container root. A separately approved host-group/read-only
  permission projection must exist before a container run is eligible.

## Artifact order

1. Produce a separate immutable index release through a host-private runbook.
   Hostnames, user paths, process ids, corpus ids, release digests, and the
   exact root scripts remain outside this publishable product repository. Every
   host action still follows `docs/root-execution-protocol.md` and receives
   per-action operator approval.
2. Compute the embedding fingerprint from the exact config (`kwrag.config`).
3. Run `kwrag-build-manifest` against the release and verify it again at startup.
4. Export the normalized grant artifact from the authoritative ops/mount state
   according to `contracts/kwrag-runtime-ops-v1.md`.
5. Load per-slot tokens into process environment without printing them, then run
   `kwrag-build-projection` into same-filesystem staging. Before the atomic
   replacement, set the staged file to `root:kwrag_rt` and `0440`; the service
   must never receive write access to the auth directory.
6. Start this stack and require `/readyz` to report the expected manifest and
   pipeline fingerprints.
7. Only after A1 (dev slot reachability) and A2 (reachability after `opsctl
   apply`) pass may a slot compose attach to `kwrag_net`.

The caller must preserve separate request attempts under a stable logical
`operation_id`. KWRAG records the supplied correlation but does not claim
cross-request deduplication, retry/fallback ownership, or exactly-once model
consumption.

The current implementation deliberately does not include the slot-network
attachment. That deployment mutation remains blocked on the root-only A1/A2
measurement, so an ops update cannot accidentally make existing slots depend on
an unproven or absent network.
