# Product RAG runtime boundary

This directory describes the source-side runtime shape. It is not an image,
installation, activation, or customer-turn receipt.

## Physical ownership

- The product container already sees its Kakao package read-only. The package
  contains `membership.json`, `profile.json`, and `messages.sqlite`; that live
  view is the corpus available to the slot.
- The slot's existing writable Workspace owns its disposable dense index. No
  additional corpus mount, service account, or product host port is introduced.
- One host-local `kwrag-shared-gpu` process owns the pinned KURE embedding and
  BGE reranker models. It accepts bounded calls through an authenticated Unix
  socket, stores no corpus or index, and persists no query or result content.
- Hermes or OpenClaw owns the explicit product call and the model handoff. KWRAG
  does not decide whether to search, generate a query, or choose a provider.

The exact KURE snapshot is
`d14c8a9423946e268a0c9952fecf3a7aabd73bd9`; the exact BGE reranker snapshot is
`953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e`.

## Workspace index lifecycle

Indexing is an explicit product operation. The indexer reads one consistent
SQLite snapshot from the currently mounted package, sends bounded corpus
batches to KURE, and writes normalized vectors plus source references into an
inactive release under the slot Workspace. It then atomically advances the
Workspace-local current pointer.

Routine crawler publication is not a query admission event. Search resolves
dense candidates against the live package and current membership; a stale
message reference is skipped instead of taking the whole product offline. A
later explicit rebuild refreshes the disposable index. Missing source files,
an unsafe writable corpus mount, a corrupt index, or unavailable shared GPU
still fails the retrieval call.

No publisher epoch, frozen source generation, copied source capsule, generated
ops binding, or research decision is required by this product path.

## Product call

The caller decides whether to retrieve and supplies the literal query. The
default path performs no retrieval. An explicit call follows:

`caller -> live mounted Kakao source + current Workspace index -> UDS KURE query
embedding -> dense vector search -> live source resolution -> UDS bounded BGE
rerank -> verified KWRAG response/operation receipt -> product-owned bounded
current-turn context -> existing provider handoff`

KWRAG does not trim or expand the query, retry autonomously, union an FTS
fallback, choose an answer, or inject a prompt. The shared worker receives no
NAS mount, Workspace index, membership file, receipt directory, or product
network endpoint.

KWRAG attests retrieval, not prompt consumption.
HTTP success or a non-empty hit list alone cannot be reported as product consumption; the product-owned
handoff and its content-free receipts remain a separate boundary.

## Not completed by source tests

Building and testing this repository does not install a wheel or image, create
the Unix socket or its peer grant, rebuild a customer index, attach a slot,
invoke a provider, run oc20, or prove a customer-visible RAG turn. Those are
separate runtime observations after the exact product image is available.
