# Crawler generation publisher successor

This directory is a source-only successor for the PC-owned `kw publish nas`
publisher. It is not installed into the KWRAG server runtime and performs no
credential discovery or network action by itself.

`kw_corpus/nas/generation_publish.py` is shaped to the existing
`PublishTransport` methods. The PC owner integrates it only at the existing
user-package branch of `publish_corpus_to_nas`. The accompanying integration
patch also adds a repeatable exact-package allowlist. A bounded two-package
publication is:

```text
kw publish nas --skip-media --skip-internal \
  --package <OC14_EXACT_PACKAGE_SEGMENT> \
  --package <OC20_EXACT_PACKAGE_SEGMENT>
```

The CLI resolves every requested segment against the locally derived package
set before opening a transport or performing any publication write. Unknown,
duplicate, empty, traversal-like, or `--skip-users` combinations fail closed.
Omitting `--package` deliberately retains the crawler's existing all-user
behavior; it must not be used for a bounded canary publication.

The generation flow is:

1. `export_user_package(...)` continues to construct the authorized
   `membership.json`, `profile.json`, and `messages.sqlite` with the existing
   `messages_fts` (`unicode61`).
2. `build_generation(local_root, private_work_root)` reads those exact files,
   rejects sidecars and drift, and adds `messages_fts_trigram` only to its
   private SQLite copy.
3. `publish_generation(build, transport, remote_prefix)` uploads the three
   files and `package-manifest.json` under
   `kwrag/source/generations/g-<sha256>`, reads every byte back, then overwrites
   only the inactive activation record.
4. The legacy root-level three-file upload must be removed from the user branch;
   otherwise it would remain a mixed-generation product entry point.
5. `rollback_generation(...)` advances the same journal to the retained
   previous generation. It never deletes a generation; crawler/Common OPS owns
   any later bounded GC policy.

The `remote_prefix` remains the existing dedicated publisher's fixed
`/kakao-work/users/<package>` target. It is not accepted from a KWRAG request.
This server task has no DSM credential and does not run any function against
NAS. `source-baseline.json` pins the exact read-only PC source used for this
successor.
