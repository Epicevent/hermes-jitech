"""Immutable user-package publication successor for ``kw publish nas``.

This file is deliberately kept outside the KWRAG runtime package.  It is a
minimal crawler-owner source artifact shaped to the existing
``kw_corpus.nas.transport.PublishTransport`` surface.  It reads the three
authoritative files from one already-built user package, transforms only a
private copy of ``messages.sqlite``, and commits one content-addressed
generation with a two-record activation journal.

No function in this module discovers a package, credential, user, or NAS root.
Those remain fixed inputs of the existing crawler publisher.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Protocol
from uuid import uuid4


SOURCE_FILES = ("membership.json", "messages.sqlite", "profile.json")
GENERATION_FILES = (*SOURCE_FILES, "package-manifest.json")
ACTIVATION_FILES = ("activation-a.json", "activation-b.json")
MAX_JSON_BYTES = 16 * 1024 * 1024
MAX_DATABASE_BYTES = 4 * 1024 * 1024 * 1024
MAX_REMOTE_ENTRIES = 128

_GENERATION_RE = re.compile(r"g-[0-9a-f]{64}\Z")
_SHA256_RE = re.compile(r"sha256:[0-9a-f]{64}\Z")
_FTS5_RE = re.compile(r"\busing\s+fts5\s*\(", re.IGNORECASE)
_TOKENIZE_RE = re.compile(
    r"\btokenize\s*=\s*(?:'([^']*)'|\"([^\"]*)\"|([^\s,)]+))",
    re.IGNORECASE,
)


class GenerationPublishError(ValueError):
    """A source package or publication step failed closed."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class PublishTransport(Protocol):
    """The exact subset already provided by kw_corpus.nas.transport."""

    def put_file_atomic(self, local_path: Path, remote_path: str) -> None: ...

    def write_text_atomic(self, text: str, remote_path: str) -> None: ...

    def read_bytes(self, remote_path: str) -> bytes: ...

    def list_dir(
        self, remote_dir: str, *, limit: int = 1000, offset: int = 0
    ) -> list[dict]: ...


@dataclass(frozen=True)
class FileIdentity:
    device: int
    inode: int
    mode: int
    links: int
    size: int
    mtime_ns: int


@dataclass(frozen=True)
class CopiedFile:
    source: Path
    destination: Path
    source_identity: FileIdentity
    source_sha256: str
    source_bytes: int


@dataclass(frozen=True)
class BuiltGeneration:
    generation_id: str
    generation_dir: Path
    manifest_sha256: str
    manifest_bytes: int
    source_snapshot_path: Path
    source_snapshot_sha256: str
    source_snapshot_bytes: int
    source_had_trigram: bool
    message_count: int
    room_count: int


@dataclass(frozen=True)
class Activation:
    slot: str
    sequence: int
    generation_id: str
    manifest_sha256: str
    previous_generation_id: str | None
    payload_sha256: str


def _digest(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _canonical_json(value: Any) -> bytes:
    try:
        return json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise GenerationPublishError("json_not_canonicalizable") from exc


def _reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for key, value in pairs:
        if key in output:
            raise GenerationPublishError("json_duplicate_key")
        output[key] = value
    return output


def _strict_json(payload: bytes, *, canonical: bool = False) -> Mapping[str, Any]:
    try:
        value = json.loads(
            payload.decode("utf-8"), object_pairs_hook=_reject_duplicates
        )
    except GenerationPublishError:
        raise
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise GenerationPublishError("json_invalid") from exc
    if not isinstance(value, Mapping):
        raise GenerationPublishError("json_object_required")
    if canonical and payload != _canonical_json(value):
        raise GenerationPublishError("json_not_canonical")
    return value


def _identity(metadata: os.stat_result) -> FileIdentity:
    return FileIdentity(
        device=metadata.st_dev,
        inode=metadata.st_ino,
        mode=metadata.st_mode,
        links=metadata.st_nlink,
        size=metadata.st_size,
        mtime_ns=metadata.st_mtime_ns,
    )


def _canonical_directory(path: Path, *, create: bool, code: str) -> Path:
    candidate = Path(path)
    if not candidate.is_absolute():
        raise GenerationPublishError(code)
    if create:
        candidate.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        metadata = candidate.lstat()
        resolved = candidate.resolve(strict=True)
    except OSError as exc:
        raise GenerationPublishError(code) from exc
    if (
        candidate.is_symlink()
        or not stat.S_ISDIR(metadata.st_mode)
        or candidate.absolute() != resolved
    ):
        raise GenerationPublishError(code)
    return resolved


def _write_new(path: Path, payload: bytes) -> tuple[str, int]:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
    )
    try:
        descriptor = os.open(path, flags, 0o600)
    except OSError as exc:
        raise GenerationPublishError("build_output_collision") from exc
    try:
        view = memoryview(payload)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:
                raise GenerationPublishError("build_write_failed")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    return _digest(payload), len(payload)


def _copy_stable_source(source: Path, destination: Path, *, maximum: int) -> CopiedFile:
    read_flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    write_flags = (
        os.O_WRONLY
        | os.O_CREAT
        | os.O_EXCL
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        source_fd = os.open(source, read_flags)
    except OSError as exc:
        raise GenerationPublishError("source_file_unavailable") from exc
    destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        destination_fd = os.open(destination, write_flags, 0o600)
    except OSError as exc:
        os.close(source_fd)
        raise GenerationPublishError("build_output_collision") from exc
    digest = hashlib.sha256()
    total = 0
    try:
        before = _identity(os.fstat(source_fd))
        if (
            not stat.S_ISREG(before.mode)
            or before.links != 1
            or not 1 <= before.size <= maximum
        ):
            raise GenerationPublishError("source_file_identity_invalid")
        while True:
            block = os.read(source_fd, 1024 * 1024)
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise GenerationPublishError("source_file_size_invalid")
            digest.update(block)
            view = memoryview(block)
            while view:
                written = os.write(destination_fd, view)
                if written <= 0:
                    raise GenerationPublishError("build_write_failed")
                view = view[written:]
        os.fsync(destination_fd)
        after = _identity(os.fstat(source_fd))
        if before != after or total != before.size:
            raise GenerationPublishError("source_changed_during_copy")
    finally:
        os.close(destination_fd)
        os.close(source_fd)
    return CopiedFile(
        source=source,
        destination=destination,
        source_identity=before,
        source_sha256="sha256:" + digest.hexdigest(),
        source_bytes=total,
    )


def _file_digest(path: Path, *, maximum: int) -> tuple[str, int]:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise GenerationPublishError("build_file_unavailable") from exc
    digest = hashlib.sha256()
    total = 0
    try:
        before = _identity(os.fstat(descriptor))
        if (
            not stat.S_ISREG(before.mode)
            or before.links != 1
            or not 1 <= before.size <= maximum
        ):
            raise GenerationPublishError("build_file_identity_invalid")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise GenerationPublishError("build_file_size_invalid")
            digest.update(block)
        after = _identity(os.fstat(descriptor))
        if before != after or total != before.size:
            raise GenerationPublishError("build_file_changed")
    finally:
        os.close(descriptor)
    return "sha256:" + digest.hexdigest(), total


def _tokenizer(sql: Any) -> str:
    if not isinstance(sql, str) or _FTS5_RE.search(sql) is None:
        raise GenerationPublishError("fts_schema_invalid")
    matches = list(_TOKENIZE_RE.finditer(sql))
    if len(matches) > 1:
        raise GenerationPublishError("fts_schema_invalid")
    if not matches:
        return "unicode61"
    specification = next(
        (value for value in matches[0].groups() if value is not None), ""
    ).strip()
    return specification.split(maxsplit=1)[0].lower()


def _membership(payload: bytes) -> tuple[Mapping[str, Any], tuple[str, ...]]:
    value = _strict_json(payload)
    if value.get("schema") != "kw-corpus-nas-user":
        raise GenerationPublishError("membership_schema_invalid")
    raw_rooms = value.get("conversation_ids")
    if (
        not isinstance(raw_rooms, list)
        or not 1 <= len(raw_rooms) <= 4096
        or any(
            not isinstance(room, str)
            or not room
            or room != room.strip()
            or len(room) > 256
            for room in raw_rooms
        )
        or len(raw_rooms) != len(set(raw_rooms))
    ):
        raise GenerationPublishError("membership_rooms_invalid")
    return value, tuple(sorted(raw_rooms))


def _profile(payload: bytes, membership: Mapping[str, Any]) -> Mapping[str, Any]:
    value = _strict_json(payload)
    if value.get("schema") != "kw-corpus-nas-user":
        raise GenerationPublishError("profile_schema_invalid")
    membership_user = membership.get("user_id")
    profile_user = value.get("user_id")
    if (
        not isinstance(membership_user, str)
        or not membership_user
        or profile_user != membership_user
    ):
        raise GenerationPublishError("profile_membership_user_mismatch")
    return value


def _table_sql(connection: sqlite3.Connection, table: str) -> str:
    row = connection.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone()
    if row is None:
        raise GenerationPublishError("database_tables_invalid")
    return str(row[0] or "")


def _validate_fts_rows(connection: sqlite3.Connection, table: str) -> int:
    count = int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
    mismatch = int(
        connection.execute(
            f"""
            SELECT COUNT(*) FROM messages AS m
            LEFT JOIN {table} AS f ON f.rowid=m.rowid
            WHERE f.rowid IS NULL
               OR f.conversation_id != m.conversation_id
               OR f.message_id != m.message_id
            """
        ).fetchone()[0]
    )
    reverse = int(
        connection.execute(
            f"""
            SELECT COUNT(*) FROM {table} AS f
            LEFT JOIN messages AS m ON m.rowid=f.rowid
            WHERE m.rowid IS NULL
            """
        ).fetchone()[0]
    )
    if mismatch or reverse:
        raise GenerationPublishError("fts_source_binding_mismatch")
    return count


def _validate_database(
    connection: sqlite3.Connection,
    *,
    rooms: tuple[str, ...],
    require_trigram: bool,
) -> tuple[int, int, bool]:
    if connection.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
        raise GenerationPublishError("database_integrity_invalid")
    tables = {
        str(row[0])
        for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
        )
    }
    if not {"messages", "attachments", "messages_fts"}.issubset(tables):
        raise GenerationPublishError("database_tables_invalid")
    required_columns = {
        "conversation_id",
        "message_id",
        "user_id",
        "user_name",
        "sent_time",
        "plain_text",
    }
    columns = {
        str(row[1]) for row in connection.execute("PRAGMA table_info(messages)")
    }
    if not required_columns.issubset(columns):
        raise GenerationPublishError("database_columns_invalid")
    database_rooms = tuple(
        sorted(
            str(row[0])
            for row in connection.execute(
                "SELECT DISTINCT conversation_id FROM messages ORDER BY conversation_id"
            )
        )
    )
    if database_rooms != rooms:
        raise GenerationPublishError("membership_database_scope_mismatch")
    message_count = int(
        connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
    )
    if message_count < 1:
        raise GenerationPublishError("database_has_no_messages")
    invalid_text = int(
        connection.execute(
            "SELECT COUNT(*) FROM messages "
            "WHERE plain_text IS NULL OR TRIM(plain_text)=''"
        ).fetchone()[0]
    )
    distinct_messages = int(
        connection.execute("SELECT COUNT(DISTINCT message_id) FROM messages").fetchone()[0]
    )
    if invalid_text or distinct_messages != message_count:
        raise GenerationPublishError("message_identity_or_text_invalid")
    if _tokenizer(_table_sql(connection, "messages_fts")) != "unicode61":
        raise GenerationPublishError("compatibility_fts_tokenizer_invalid")
    compatibility_count = _validate_fts_rows(connection, "messages_fts")
    if compatibility_count != message_count:
        raise GenerationPublishError("compatibility_fts_coverage_mismatch")
    has_trigram = "messages_fts_trigram" in tables
    if has_trigram:
        if _tokenizer(_table_sql(connection, "messages_fts_trigram")) != "trigram":
            raise GenerationPublishError("trigram_fts_tokenizer_invalid")
        if _validate_fts_rows(connection, "messages_fts_trigram") != message_count:
            raise GenerationPublishError("trigram_fts_coverage_mismatch")
    elif require_trigram:
        raise GenerationPublishError("trigram_fts_missing")
    return message_count, compatibility_count, has_trigram


def _add_trigram(database: Path, *, rooms: tuple[str, ...]) -> tuple[int, int, bool]:
    try:
        connection = sqlite3.connect(database)
        connection.execute("PRAGMA journal_mode=DELETE")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA temp_store=MEMORY")
        message_count, compatibility_count, had_trigram = _validate_database(
            connection, rooms=rooms, require_trigram=False
        )
        if not had_trigram:
            try:
                connection.execute(
                    """
                    CREATE VIRTUAL TABLE messages_fts_trigram USING fts5(
                      plain_text,
                      user_name,
                      room_name,
                      file_name,
                      conversation_id UNINDEXED,
                      message_id UNINDEXED,
                      tokenize='trigram'
                    )
                    """
                )
            except sqlite3.Error as exc:
                raise GenerationPublishError("trigram_fts_unsupported") from exc
            connection.execute(
                """
                INSERT INTO messages_fts_trigram (
                  rowid, plain_text, user_name, room_name, file_name,
                  conversation_id, message_id
                )
                SELECT
                  m.rowid,
                  m.plain_text,
                  COALESCE(m.user_name, ''),
                  COALESCE(m.room_name, ''),
                  COALESCE(
                    (SELECT GROUP_CONCAT(ordered.file_name, ' ')
                     FROM (
                       SELECT a.file_name AS file_name
                       FROM attachments AS a
                       WHERE a.conversation_id=m.conversation_id
                         AND a.message_id=m.message_id
                       ORDER BY a.block_index
                     ) AS ordered),
                    ''
                  ),
                  m.conversation_id,
                  m.message_id
                FROM messages AS m
                ORDER BY m.rowid
                """
            )
            connection.commit()
            connection.execute("VACUUM")
        message_count, compatibility_count, _ = _validate_database(
            connection, rooms=rooms, require_trigram=True
        )
        connection.commit()
        return message_count, compatibility_count, had_trigram
    except GenerationPublishError:
        raise
    except sqlite3.Error as exc:
        raise GenerationPublishError("database_transform_failed") from exc
    finally:
        try:
            connection.close()
        except (NameError, sqlite3.Error):
            pass


def _assert_sources_unchanged(copied: Mapping[str, CopiedFile]) -> None:
    for entry in copied.values():
        try:
            current = _identity(entry.source.lstat())
        except OSError as exc:
            raise GenerationPublishError("source_changed_after_copy") from exc
        if current != entry.source_identity:
            raise GenerationPublishError("source_changed_after_copy")


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def build_generation(source_package: Path, work_root: Path) -> BuiltGeneration:
    """Build one deterministic private generation without touching the source."""

    source = _canonical_directory(
        Path(source_package), create=False, code="source_package_invalid"
    )
    work = _canonical_directory(Path(work_root), create=True, code="work_root_invalid")
    try:
        work.relative_to(source)
    except ValueError:
        pass
    else:
        raise GenerationPublishError("work_root_inside_source_forbidden")
    for suffix in ("-journal", "-wal", "-shm"):
        sidecar = source / f"messages.sqlite{suffix}"
        if sidecar.exists() or sidecar.is_symlink():
            raise GenerationPublishError("source_database_sidecar_present")
    staging = work / f".generation-build-{uuid4().hex}"
    generation = staging / "generation"
    generation.mkdir(parents=True, mode=0o700)
    try:
        copied = {
            name: _copy_stable_source(
                source / name,
                generation / name,
                maximum=(MAX_DATABASE_BYTES if name == "messages.sqlite" else MAX_JSON_BYTES),
            )
            for name in SOURCE_FILES
        }
        membership_payload = (generation / "membership.json").read_bytes()
        profile_payload = (generation / "profile.json").read_bytes()
        membership, rooms = _membership(membership_payload)
        _profile(profile_payload, membership)
        message_count, fts_count, source_had_trigram = _add_trigram(
            generation / "messages.sqlite", rooms=rooms
        )
        _assert_sources_unchanged(copied)
        for suffix in ("-journal", "-wal", "-shm"):
            sidecar = source / f"messages.sqlite{suffix}"
            if sidecar.exists() or sidecar.is_symlink():
                raise GenerationPublishError("source_database_sidecar_present")

        files: list[dict[str, Any]] = []
        generated: dict[str, dict[str, Any]] = {}
        for name in SOURCE_FILES:
            digest, size = _file_digest(
                generation / name,
                maximum=(MAX_DATABASE_BYTES if name == "messages.sqlite" else MAX_JSON_BYTES),
            )
            files.append({"name": name, "sha256": digest, "bytes": size})
            generated[name] = {"sha256": digest, "bytes": size}
        manifest_identity = {
            "schema_version": "kw-corpus-package-manifest-v1",
            "files": files,
            "membership_conversation_set_sha256": _digest(
                _canonical_json(list(rooms))
            ),
            "room_count": len(rooms),
            "message_count": message_count,
            "messages_fts_count": fts_count,
            "fts_tokenizers": {
                "messages_fts": "unicode61",
                "messages_fts_trigram": "trigram",
            },
        }
        generation_id = "g-" + hashlib.sha256(
            _canonical_json(manifest_identity)
        ).hexdigest()
        manifest = dict(manifest_identity)
        manifest["generation_id"] = generation_id
        manifest_payload = _canonical_json(manifest)
        manifest_digest, manifest_bytes = _write_new(
            generation / "package-manifest.json", manifest_payload
        )
        destination = staging / generation_id
        generation.replace(destination)
        generation = destination
        source_snapshot = {
            "schema_version": "kw-corpus-generation-source-snapshot-v1",
            "generation_id": generation_id,
            "source_files": {
                name: {
                    "sha256": copied[name].source_sha256,
                    "bytes": copied[name].source_bytes,
                }
                for name in SOURCE_FILES
            },
            "generated_files": generated,
            "source_had_trigram": source_had_trigram,
            "authorized_room_count": len(rooms),
            "authorized_room_set_sha256": _digest(_canonical_json(list(rooms))),
            "source_message_count": message_count,
            "raw_content_present": False,
        }
        snapshot_payload = _canonical_json(source_snapshot)
        snapshot_digest, snapshot_bytes = _write_new(
            staging / "source-snapshot.json", snapshot_payload
        )
        _fsync_directory(generation)
        _fsync_directory(staging)
        return BuiltGeneration(
            generation_id=generation_id,
            generation_dir=generation,
            manifest_sha256=manifest_digest,
            manifest_bytes=manifest_bytes,
            source_snapshot_path=staging / "source-snapshot.json",
            source_snapshot_sha256=snapshot_digest,
            source_snapshot_bytes=snapshot_bytes,
            source_had_trigram=source_had_trigram,
            message_count=message_count,
            room_count=len(rooms),
        )
    except Exception:
        if staging.exists() and staging.is_dir() and not staging.is_symlink():
            shutil.rmtree(staging)
        raise


def select_package_segments(
    available: list[str], requested: list[str] | None
) -> tuple[str, ...]:
    """Resolve a bounded package allowlist before any publication write."""

    def valid(value: Any) -> bool:
        return (
            isinstance(value, str)
            and 1 <= len(value) <= 255
            and value == value.strip()
            and value not in {".", ".."}
            and "/" not in value
            and "\\" not in value
            and "\x00" not in value
        )

    if (
        not isinstance(available, list)
        or not available
        or any(not valid(value) for value in available)
        or len(available) != len(set(available))
    ):
        raise GenerationPublishError("available_package_segments_invalid")
    if requested is None:
        return tuple(available)
    if (
        not isinstance(requested, list)
        or not requested
        or any(not valid(value) for value in requested)
        or len(requested) != len(set(requested))
        or set(requested) - set(available)
    ):
        raise GenerationPublishError("requested_package_segments_invalid")
    selected = set(requested)
    return tuple(value for value in available if value in selected)


def _remote_root(value: str) -> str:
    if not isinstance(value, str) or not value.startswith("/") or "\\" in value:
        raise GenerationPublishError("remote_package_root_invalid")
    path = PurePosixPath(value)
    parts = path.parts[1:]
    if (
        len(parts) != 3
        or parts[:2] != ("kakao-work", "users")
        or any(part in {"", ".", ".."} for part in parts)
    ):
        raise GenerationPublishError("remote_package_root_invalid")
    normalized = "/" + "/".join(parts)
    if normalized != value.rstrip("/"):
        raise GenerationPublishError("remote_package_root_invalid")
    return normalized


def _remote_join(root: str, relative: str) -> str:
    rel = PurePosixPath(relative)
    if rel.is_absolute() or any(part in {"", ".", ".."} for part in rel.parts):
        raise GenerationPublishError("remote_relative_invalid")
    return root.rstrip("/") + "/" + rel.as_posix()


def _entries(transport: PublishTransport, directory: str) -> dict[str, bool]:
    try:
        raw = transport.list_dir(directory, limit=MAX_REMOTE_ENTRIES + 1, offset=0)
    except Exception as exc:
        raise GenerationPublishError("remote_directory_unavailable") from exc
    if not isinstance(raw, list) or len(raw) > MAX_REMOTE_ENTRIES:
        raise GenerationPublishError("remote_directory_entries_invalid")
    output: dict[str, bool] = {}
    for item in raw:
        if not isinstance(item, Mapping):
            raise GenerationPublishError("remote_directory_entries_invalid")
        name = item.get("name")
        isdir = item.get("isdir")
        if (
            not isinstance(name, str)
            or not name
            or name in {".", ".."}
            or "/" in name
            or "\\" in name
            or not isinstance(isdir, bool)
            or name in output
        ):
            raise GenerationPublishError("remote_directory_entries_invalid")
        output[name] = isdir
    return output


def _package_root_exists(transport: PublishTransport, root: str) -> bool:
    package = PurePosixPath(root).name
    base_entries = _entries(transport, "/kakao-work")
    users_state = base_entries.get("users")
    if users_state is None:
        return False
    if users_state is not True:
        raise GenerationPublishError("remote_package_root_type_mismatch")
    user_entries = _entries(transport, "/kakao-work/users")
    package_state = user_entries.get(package)
    if package_state is None:
        return False
    if package_state is not True:
        raise GenerationPublishError("remote_package_root_type_mismatch")
    _entries(transport, root)
    return True


def _remote_state(
    transport: PublishTransport, root: str, relative: str
) -> tuple[str, bool] | None:
    parts = PurePosixPath(relative).parts
    current = root
    for index, part in enumerate(parts):
        entries = _entries(transport, current)
        state = entries.get(part)
        if state is None:
            return None
        path = current.rstrip("/") + "/" + part
        final = index == len(parts) - 1
        if not final and state is not True:
            raise GenerationPublishError("remote_path_type_mismatch")
        if final:
            return path, state
        current = path
    raise GenerationPublishError("remote_relative_invalid")


def _remote_payload(
    transport: PublishTransport,
    root: str,
    relative: str,
    *,
    maximum: int,
) -> bytes | None:
    state = _remote_state(transport, root, relative)
    if state is None:
        return None
    path, isdir = state
    if isdir:
        raise GenerationPublishError("remote_path_type_mismatch")
    try:
        payload = transport.read_bytes(path)
    except Exception as exc:
        raise GenerationPublishError("remote_file_unavailable") from exc
    if not isinstance(payload, bytes) or not 1 <= len(payload) <= maximum:
        raise GenerationPublishError("remote_file_size_invalid")
    return payload


def _activation_from_payload(slot: str, payload: bytes) -> Activation:
    value = _strict_json(payload, canonical=True)
    fields = {
        "schema_version",
        "sequence",
        "generation_id",
        "manifest_relative",
        "manifest_sha256",
        "previous_generation_id",
    }
    if set(value) != fields or value.get("schema_version") != "kw-corpus-package-activation-v1":
        raise GenerationPublishError("activation_fields_invalid")
    sequence = value.get("sequence")
    generation_id = value.get("generation_id")
    previous = value.get("previous_generation_id")
    manifest_digest = value.get("manifest_sha256")
    if (
        isinstance(sequence, bool)
        or not isinstance(sequence, int)
        or not 1 <= sequence <= 2**63 - 1
        or not isinstance(generation_id, str)
        or _GENERATION_RE.fullmatch(generation_id) is None
        or not isinstance(manifest_digest, str)
        or _SHA256_RE.fullmatch(manifest_digest) is None
        or (
            previous is not None
            and (not isinstance(previous, str) or _GENERATION_RE.fullmatch(previous) is None)
        )
        or value.get("manifest_relative")
        != f"kwrag/source/generations/{generation_id}/package-manifest.json"
    ):
        raise GenerationPublishError("activation_identity_invalid")
    return Activation(
        slot=slot,
        sequence=sequence,
        generation_id=generation_id,
        manifest_sha256=manifest_digest,
        previous_generation_id=previous,
        payload_sha256=_digest(payload),
    )


def _activations(transport: PublishTransport, root: str) -> list[Activation]:
    source_state = _remote_state(transport, root, "kwrag/source")
    if source_state is None:
        return []
    if source_state[1] is not True:
        raise GenerationPublishError("remote_path_type_mismatch")
    entries = _entries(transport, source_state[0])
    allowed = {"generations", *ACTIVATION_FILES}
    if set(entries) - allowed or entries.get("generations") is not True:
        raise GenerationPublishError("remote_source_entries_invalid")
    records: list[Activation] = []
    for slot, name in zip(("a", "b"), ACTIVATION_FILES):
        if name not in entries:
            continue
        if entries[name] is not False:
            raise GenerationPublishError("remote_path_type_mismatch")
        payload = _remote_payload(
            transport, root, f"kwrag/source/{name}", maximum=16 * 1024
        )
        assert payload is not None
        records.append(_activation_from_payload(slot, payload))
    records.sort(key=lambda record: record.sequence)
    if len(records) == 2:
        older, current = records
        if (
            current.sequence != older.sequence + 1
            or current.previous_generation_id != older.generation_id
            or current.generation_id == older.generation_id
        ):
            raise GenerationPublishError("activation_chain_invalid_or_stale")
    return records


def _activation_fingerprint(records: list[Activation]) -> tuple[tuple[str, str], ...]:
    return tuple(sorted((record.slot, record.payload_sha256) for record in records))


def _verify_remote_generation(
    transport: PublishTransport,
    root: str,
    *,
    generation_id: str,
    expected: Mapping[str, bytes] | None = None,
) -> tuple[str, int]:
    base = f"kwrag/source/generations/{generation_id}"
    state = _remote_state(transport, root, base)
    if state is None or state[1] is not True:
        raise GenerationPublishError("remote_generation_incomplete")
    entries = _entries(transport, state[0])
    if entries != {name: False for name in GENERATION_FILES}:
        raise GenerationPublishError("remote_generation_entries_invalid")
    payloads: dict[str, bytes] = {}
    for name in GENERATION_FILES:
        payload = _remote_payload(
            transport,
            root,
            f"{base}/{name}",
            maximum=(MAX_DATABASE_BYTES if name == "messages.sqlite" else MAX_JSON_BYTES),
        )
        if payload is None:
            raise GenerationPublishError("remote_generation_incomplete")
        if expected is not None and payload != expected[name]:
            raise GenerationPublishError("remote_generation_digest_mismatch")
        payloads[name] = payload
    manifest = _strict_json(payloads["package-manifest.json"], canonical=True)
    if manifest.get("generation_id") != generation_id:
        raise GenerationPublishError("remote_manifest_generation_mismatch")
    identity = dict(manifest)
    identity.pop("generation_id", None)
    if generation_id != "g-" + hashlib.sha256(_canonical_json(identity)).hexdigest():
        raise GenerationPublishError("remote_generation_content_address_mismatch")
    declared = manifest.get("files")
    if not isinstance(declared, list) or len(declared) != 3:
        raise GenerationPublishError("remote_manifest_files_invalid")
    by_name = {item.get("name"): item for item in declared if isinstance(item, Mapping)}
    if set(by_name) != set(SOURCE_FILES):
        raise GenerationPublishError("remote_manifest_files_invalid")
    for name in SOURCE_FILES:
        if by_name[name].get("sha256") != _digest(payloads[name]) or by_name[name].get(
            "bytes"
        ) != len(payloads[name]):
            raise GenerationPublishError("remote_manifest_file_mismatch")
    manifest_payload = payloads["package-manifest.json"]
    return _digest(manifest_payload), len(manifest_payload)


def _advance_activation(
    transport: PublishTransport,
    root: str,
    *,
    generation_id: str,
    manifest_sha256: str,
    expected_records: list[Activation],
) -> dict[str, Any]:
    observed = _activations(transport, root)
    if _activation_fingerprint(observed) != _activation_fingerprint(expected_records):
        raise GenerationPublishError("activation_changed_before_commit")
    current = observed[-1] if observed else None
    if current is not None and current.generation_id == generation_id:
        return {
            "schema_version": "kw-corpus-generation-publication-receipt-v1",
            "status": "ALREADY_ACTIVE",
            "generation_id": generation_id,
            "manifest_sha256": manifest_sha256,
            "sequence": current.sequence,
            "previous_generation_id": current.previous_generation_id,
            "activation_slot": current.slot,
            "previous_generation_retained": current.previous_generation_id is not None,
            "raw_content_present": False,
        }
    target_slot = "a" if current is None else ("b" if current.slot == "a" else "a")
    sequence = 1 if current is None else current.sequence + 1
    previous = None if current is None else current.generation_id
    value = {
        "schema_version": "kw-corpus-package-activation-v1",
        "sequence": sequence,
        "generation_id": generation_id,
        "manifest_relative": (
            f"kwrag/source/generations/{generation_id}/package-manifest.json"
        ),
        "manifest_sha256": manifest_sha256,
        "previous_generation_id": previous,
    }
    payload = _canonical_json(value)
    relative = f"kwrag/source/activation-{target_slot}.json"
    try:
        transport.write_text_atomic(payload.decode("utf-8"), _remote_join(root, relative))
    except Exception as exc:
        raise GenerationPublishError("activation_write_failed") from exc
    readback = _remote_payload(transport, root, relative, maximum=16 * 1024)
    if readback != payload:
        raise GenerationPublishError("activation_readback_mismatch")
    selected = _activations(transport, root)
    if not selected or selected[-1] != _activation_from_payload(target_slot, payload):
        raise GenerationPublishError("activation_postcheck_failed")
    return {
        "schema_version": "kw-corpus-generation-publication-receipt-v1",
        "status": "ACTIVATED",
        "generation_id": generation_id,
        "manifest_sha256": manifest_sha256,
        "sequence": sequence,
        "previous_generation_id": previous,
        "activation_slot": target_slot,
        "activation_sha256": _digest(payload),
        "previous_generation_retained": previous is not None,
        "raw_content_present": False,
    }


def publish_generation(
    build: BuiltGeneration,
    transport: PublishTransport,
    remote_package_root: str,
) -> dict[str, Any]:
    """Upload one immutable generation and commit only its inactive activation."""

    root = _remote_root(remote_package_root)
    package_exists = _package_root_exists(transport, root)
    if _GENERATION_RE.fullmatch(build.generation_id) is None:
        raise GenerationPublishError("build_generation_id_invalid")
    local_payloads: dict[str, bytes] = {}
    for name in GENERATION_FILES:
        path = build.generation_dir / name
        maximum = MAX_DATABASE_BYTES if name == "messages.sqlite" else MAX_JSON_BYTES
        _file_digest(path, maximum=maximum)
        local_payloads[name] = path.read_bytes()
    if _digest(local_payloads["package-manifest.json"]) != build.manifest_sha256:
        raise GenerationPublishError("build_manifest_identity_changed")
    generation_relative = f"kwrag/source/generations/{build.generation_id}"
    existing_state = (
        _remote_state(transport, root, generation_relative) if package_exists else None
    )
    if existing_state is not None:
        if existing_state[1] is not True:
            raise GenerationPublishError("remote_path_type_mismatch")
        existing_entries = _entries(transport, existing_state[0])
        if set(existing_entries) - set(GENERATION_FILES) or any(
            existing_entries[name] is not False for name in existing_entries
        ):
            raise GenerationPublishError("remote_generation_entries_invalid")
    uploaded_count = 0
    for name in GENERATION_FILES:
        relative = f"{generation_relative}/{name}"
        maximum = MAX_DATABASE_BYTES if name == "messages.sqlite" else MAX_JSON_BYTES
        remote = (
            _remote_payload(transport, root, relative, maximum=maximum)
            if package_exists else None
        )
        if remote is not None:
            if remote != local_payloads[name]:
                raise GenerationPublishError("remote_generation_digest_mismatch")
            continue
        try:
            transport.put_file_atomic(
                build.generation_dir / name, _remote_join(root, relative)
            )
        except Exception as exc:
            raise GenerationPublishError("generation_upload_failed") from exc
        uploaded_count += 1
        package_exists = True
        readback = _remote_payload(transport, root, relative, maximum=maximum)
        if readback != local_payloads[name]:
            raise GenerationPublishError("generation_readback_mismatch")
    manifest_sha256, _ = _verify_remote_generation(
        transport,
        root,
        generation_id=build.generation_id,
        expected=local_payloads,
    )
    if manifest_sha256 != build.manifest_sha256:
        raise GenerationPublishError("remote_manifest_digest_mismatch")
    records = _activations(transport, root)
    receipt = _advance_activation(
        transport,
        root,
        generation_id=build.generation_id,
        manifest_sha256=build.manifest_sha256,
        expected_records=records,
    )
    receipt["generation_readback_verified"] = True
    receipt["source_snapshot_sha256"] = build.source_snapshot_sha256
    receipt["generation_files_uploaded"] = uploaded_count
    receipt["activation_written"] = receipt["status"] == "ACTIVATED"
    receipt["credential_recorded"] = False
    return receipt


def rollback_generation(
    transport: PublishTransport,
    remote_package_root: str,
    *,
    expected_current_generation_id: str,
) -> dict[str, Any]:
    """Commit a new activation pointing to the retained previous generation."""

    root = _remote_root(remote_package_root)
    records = _activations(transport, root)
    if not records or records[-1].generation_id != expected_current_generation_id:
        raise GenerationPublishError("rollback_current_generation_mismatch")
    current = records[-1]
    previous = current.previous_generation_id
    if previous is None:
        raise GenerationPublishError("rollback_previous_generation_unavailable")
    manifest_sha256, _ = _verify_remote_generation(
        transport, root, generation_id=previous
    )
    receipt = _advance_activation(
        transport,
        root,
        generation_id=previous,
        manifest_sha256=manifest_sha256,
        expected_records=records,
    )
    receipt["status"] = "ROLLED_BACK"
    receipt["rollback_from_generation_id"] = current.generation_id
    receipt["generation_readback_verified"] = True
    receipt["credential_recorded"] = False
    return receipt


def retained_generation_ids(
    transport: PublishTransport, remote_package_root: str
) -> tuple[str, ...]:
    """Return the active journal's bounded retention set; delete nothing."""

    records = _activations(transport, _remote_root(remote_package_root))
    if not records:
        return ()
    current = records[-1]
    retained = [current.generation_id]
    if current.previous_generation_id is not None:
        retained.append(current.previous_generation_id)
    return tuple(retained)


__all__ = [
    "BuiltGeneration",
    "GenerationPublishError",
    "build_generation",
    "publish_generation",
    "retained_generation_ids",
    "rollback_generation",
    "select_package_segments",
]
