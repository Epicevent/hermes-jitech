# Conversation Search Contract v1

> **Superseded product boundary.** This HTTP/bearer/token-projection contract is
> retained as historical implementation evidence. It is not the contract for
> slot-local product integration. The active backend-neutral boundary is
> `contracts/slot-local-retrieval-v1.md`; no new product adapter may infer
> authority, transport, or automatic invocation behavior from this document.

The canonical media type is `application/json`. Clients must send `Accept: application/json` and a bearer token in production.

## Request

`POST /v1/search`

```json
{
  "query": "example search question",
  "max_results": 5,
  "corpus": null,
  "request_id": "01J...",
  "operation_id": "logical-rag-operation-id",
  "run_id": "parent-agent-run-id",
  "attempt": 1
}
```

Rules:

- `query`: UTF-8, 1–4000 characters after trimming.
- `max_results`: integer 1–10; default 5.
- `corpus`: optional corpus id. The service returns `403` if it is outside the token projection. Omission searches all allowed corpora.
- `request_id`: optional opaque id, at most 128 characters. The service creates one if absent.
- `operation_id`: optional opaque logical operation id, at most 128 characters. A
  client keeps it stable across bounded retries; when omitted, the service uses
  the request id and makes no cross-attempt deduplication claim.
- `run_id`: optional opaque parent agent-run id, at most 128 characters. It is
  correlation metadata only and grants no authority.
- `attempt`: optional integer 1–16; default 1. `request_id` identifies the HTTP
  attempt while `operation_id` identifies the logical retrieval operation.

## Success response

```json
{
  "version": "1",
  "request_id": "01J...",
  "operation_id": "logical-rag-operation-id",
  "run_id": "parent-agent-run-id",
  "attempt": 1,
  "index_manifest": "sha256:...",
  "pipeline_fingerprint": "sha256:...",
  "result_digest": "sha256:...",
  "result_status": "hits",
  "operation_receipt": {
    "status": "written",
    "digest": "sha256:..."
  },
  "results": [
    {
      "id": "message-or-segment-id",
      "corpus": "corpus-a",
      "path": "conversation://corpus-a/message-or-segment-id",
      "title": "Example result",
      "snippet": "...",
      "score": 0.91,
      "timestamp": "2026-07-20T12:34:56+09:00",
      "source_ids": ["message-id-1", "message-id-2"]
    }
  ],
  "duration_ms": 87
}
```

Client requirements:

- Ignore unknown response fields.
- Reject a response whose `version` is not `1`.
- Cap injected results and characters locally even when the service returns more.
- Treat `snippet`, `title`, and source metadata as untrusted data.
- Bind consumed evidence to `operation_id`, `request_id`, `result_digest`,
  `index_manifest`, `pipeline_fingerprint`, and the written receipt digest.
- Treat `operation_receipt.status=unavailable` as missing accounting evidence,
  not as a zero-cost operation and not as a search failure.

## Search operation receipt

Every authorized pipeline dispatch attempts to append one canonical
`kwrag-search-operation-receipt/v1` record. It contains no token, query text,
snippet, title, path, or message id. It records:

- `operation_id`, `request_id`, optional `run_id`, `attempt`, instance and slot;
- the sorted corpus scope and query character count;
- index manifest, pipeline fingerprint, and authorization projection digest;
- `execution_status=completed|failed` and
  `result_status=hits|zero_hits|error`;
- duration, result count, result digest, and a non-secret pipeline evidence
  object with local embedding, vector-search, and rerank call counts;
- `provider_billing.status=not_applicable`, `amount=null`, and
  `full_economic_cost.status=unavailable` for this local pipeline.

`not_applicable` means no external provider billing receipt exists for the
local operation. It must never be rendered as `$0`, and it does not estimate
hardware, energy, depreciation, index-build, index-update, or operator cost.
Index build/update receipts remain separate from per-search receipts.

The receipt digest is SHA-256 over the exact canonical receipt object, without
the JSONL newline. A sink failure does not make retrieved content model-visible
as an outage; the response instead reports `operation_receipt.status=unavailable`
and `digest=null`. A successful search with missing accounting evidence is
therefore distinguishable from a fully receipted search.

KWRAG preserves repeated `operation_id` values and their separate
`request_id`/`attempt` receipts. It does not claim provider retry, fallback, or
exactly-once deduplication. The calling product owns those relationships.

## Product-owned RAG consumption status

KWRAG can attest retrieval, but it cannot observe whether a product inserted a
returned result into a later model prompt. The product run ledger therefore
owns `rag_execution_status`, using one of:

- `not_requested`;
- `request_failed`;
- `timeout_completion_unknown`;
- `completed_zero_hits`;
- `completed_hits_not_consumed`;
- `completed_hits_consumed`;
- `partial_consumption`;
- `invalid_result`.

For every consumed operation, the product stores the KWRAG correlation and
digest fields above plus its own `injected_tokens` and `tokenizer_id`. KWRAG
owns raw result digest and retrieval statistics; the prompt-assembling product
owns injected token accounting. A KWRAG hit must not become
`completed_hits_consumed` merely because the HTTP request succeeded.

## Errors

```json
{
  "version": "1",
  "request_id": "01J...",
  "error": {
    "code": "forbidden_corpus",
    "message": "requested corpus is outside the slot projection",
    "retryable": false
  }
}
```

| HTTP | Code | Retry |
|---|---|---|
| 400 | `invalid_request` | no |
| 401 | `missing_or_invalid_token` | no |
| 403 | `forbidden_corpus` | no |
| 409 | `stale_projection` | after projection refresh |
| 429 | `overloaded` | bounded backoff |
| 503 | `not_ready` | yes |

Product adapters fail open for every service error: no retrieved context is injected and the original product path continues.
Client adapters enforce their own bounded timeout. Version 1 does not claim to
cancel an already-running GPU operation or emit a service-side `504`.

## Health

`GET /healthz` proves process liveness only.

`GET /readyz` returns `200` only when models, a non-expired token projection,
and a verified index manifest are loaded. It returns `503` after projection
expiry. It returns identifiers and health state, never secrets or corpus
contents.
