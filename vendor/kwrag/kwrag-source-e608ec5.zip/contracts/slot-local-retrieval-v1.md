# Slot-local Retrieval Contract v1

This is the active backend-neutral product boundary for KWRAG. It defines a
callable retrieval component inside one product slot. It does not select FTS,
dense retrieval, a fallback policy, a product tool shape, or when a product
should call retrieval.

## Authority and placement

- The only corpus authority is the NAS tree already mounted read-only inside
  the calling slot. A request cannot name a mount, slot, grant, token,
  projection, or arbitrary list of corpora.
- The component is constructed with one absolute, real mount root and one safe
  mount-relative index manifest path. Every manifest and index path is resolved
  below that root without following symlinks. Each declared index path is
  confined before its content is opened for hashing; reject-after-read is not
  an accepted boundary.
- The v1 call is an in-process `SlotSearchApplication.search()` call inside the
  slot boundary. It opens no host port and needs no product network.
- The product owns whether and when to call this component. A successful
  implementation of this contract does not authorize an automatic prompt hook,
  default search, exploration loop, or retry policy.

## Canonical schemas and fixtures

The machine-readable schemas are:

- `schemas/kwrag-slot-runtime-binding-v1.schema.json`
- `schemas/kwrag-slot-search-request-v1.schema.json`
- `schemas/kwrag-slot-search-response-v1.schema.json`
- `schemas/kwrag-slot-search-operation-receipt-v1.schema.json`

The canonical producer/consumer fixture set is under
`fixtures/slot-local-retrieval-v1/`. JSON fixtures are one UTF-8 canonical JSON
object followed by exactly one LF for repository text portability: sorted
keys, compact separators, no BOM, no other trailing bytes, and no duplicate
keys. Digests bind the canonical object bytes without that fixture LF.

The request has the exact schema identity
`kwrag-slot-search-request-v1`. Unknown fields fail before pipeline dispatch.
`corpus` may narrow the call to one corpus already present in the mounted
manifest; omission searches the manifest's complete mounted scope. It cannot
expand the scope.

The response has the exact schema identity
`kwrag-slot-search-response-v1`. Results are untrusted content. A consumer must
bind them to `request_id`, `operation_id`, `attempt`, `index_manifest`,
`pipeline_fingerprint`, `result_digest`, and the written operation-receipt
digest before recording consumption. The consumer applies its own result and
character limit. Retrieval success alone never proves prompt consumption.

## Backend-neutral pipeline evidence

The receipt stores a strict `kwrag-slot-pipeline-evidence-v1` envelope. It
contains an opaque bounded `backend_id`, one to sixteen ordered stages, actual
candidate/result/corpus counts, and a data-boundary measurement. A stage can
execute only as `slot_local` or `shared_stateless`. The envelope does not assign
either placement to a backend.

`bytes_sent_outside_slot` measures payload bytes sent outside the slot during
this operation. `external_persistence` is one of:

- `not_applicable`: no stage sent data outside the slot;
- `attested_none`: an external stateless stage was used and its accepted
  execution receipt attests no persistence and
  `persistence_receipt_digest` binds that immutable receipt;
- `unavailable`: persistence evidence is missing.

An external stage requires a positive measured byte count and either
`attested_none` plus a SHA-256 receipt digest, or `unavailable` plus a null
digest; a fully slot-local operation requires zero, `not_applicable`, and a
null digest. A structurally valid external operation with unavailable
persistence evidence has `status=partial`. Missing, malformed, inconsistent,
or extra evidence fields produce `status=unavailable`, null transfer bytes,
`external_persistence=unavailable`, and a null receipt digest. They never
produce an inferred zero.

## Runtime assembly

`kwrag-slot-runtime-binding-v1` is host-owned configuration for one in-slot
runtime. It contains only the absolute mounted root, a safe mount-relative
manifest path, the expected manifest digest, a writable receipt path outside
that mount, the injected pipeline fingerprint, and a concurrency bound.
Network, port, token, grant, slot id, backend selection, and product invocation
policy are not fields.

`build_slot_runtime()` resolves the mounted scope, requires its manifest digest
to equal the binding, and only then passes that exact scope to a caller-supplied
pipeline factory. The returned `SlotRuntime` exposes only direct `ready()` and
`search()` calls. The factory injection is the point where the later
research-owned backend is supplied; assembly itself does not choose it.

## Operation receipt

Every dispatched pipeline operation attempts one canonical
`kwrag-slot-search-operation-receipt-v1` JSONL append. It records correlation,
mounted corpus scope, query length, manifest and pipeline identities, result
digest/count/status, generic pipeline evidence, and receipt cost semantics. It
contains no query, result text, message id, token, slot id, instance id, mount
path, or customer path.

`provider_billing.status=not_applicable` is emitted only when complete evidence
shows every stage executed inside the slot. Shared-stateless or unavailable
pipeline evidence produces `provider_billing.status=unavailable`; the runtime
does not infer a free call. Neither status may be rendered as zero cost.
`full_economic_cost.status=unavailable` keeps hardware, energy, depreciation,
index lifecycle, and operator cost separate from per-search evidence.

A receipt-sink failure leaves a valid retrieval response available but sets
`operation_receipt.status=unavailable` and `digest=null`. A pipeline failure is
separate and returns no results.

## Explicitly outside v1

- backend choice among the research-owned F/D/R alternatives;
- product invocation, prompt injection, stopping, fallback, and retry policy;
- model-facing search or context tool schema;
- index publication transaction and Linux mount creation;
- Hermes or OpenClaw adapter implementation;
- customer-slot rollout, canary, or promotion.

The existing dense pipeline remains reusable implementation material and may
emit this generic evidence envelope in tests. Its presence does not make dense
retrieval the product default or satisfy the research-owned backend gate.

## Research decision binding

`fixtures/slot-local-retrieval-v1/research-decision-binding.json` binds this
contract to the research-owned F/D/R evidence universe without importing its
query, routing, stopping, or evaluation policy into the product call. Its exact
schema is `schemas/kwrag-slot-research-decision-binding-v1.schema.json`.

The binding identifies:

- fixture schema `kwrag://research/retrieval-placement-fdr-fixture-v1`;
- observation schema
  `kwrag://research/retrieval-placement-fdr-observation-v1`;
- decision packet
  `kwrag-retrieval-placement-fdr-decision-evidence-packet-v1`;
- the private 150-case fixture only by receipt identity, byte count, and
  SHA-256. No query, gold, or raw snippet enters this repository contract.

Any F/D/R promotion is rejected when central corpus/index/ACL-projection bytes
are nonzero; shared inference retains raw query or corpus text; egress or
persistence evidence is unknown; paired slot/snapshot/query/gold/deadline/
result/character controls differ; gold or researcher labels are visible before
result freeze; the per-case corpus-text budget exceeds 20,000 characters; the
12-case behavior subset has any wrong-event answer; or fallback is unbounded or
an unconditional dense-plus-FTS union. These are research-gate inputs, not a
choice of F, D, or R and not new fields in the product request.
