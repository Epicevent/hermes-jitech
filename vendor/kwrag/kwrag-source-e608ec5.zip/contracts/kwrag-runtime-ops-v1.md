# KWRAG runtime / OPS boundary contract v1

- KWRAG-side status: revision under joint OPS review
- OPS-side status: implementation and approval pending
- External effect: none
- Explicit non-authorization: this document does not authorize root execution,
  image publication, network creation or attachment, canary, or deployment

This contract defines the boundary between the KWRAG product/deployment owner
and shared `agent-runtime-ops`. KWRAG owns service behavior, the private
`kwrag_net` lifecycle, bearer generation, authorization projection, and KWRAG
execution approvals. OPS owns authoritative runtime bindings, Kakao NAS view
configuration, membership export, and declarative attachment of specifically
approved dev containers. Hermes and OpenClaw product code are outside this
contract.

## 1. Canonical authoritative input

OPS derives one immutable snapshot from these exact classes of source:

| Source | Current authoritative location | Required snapshot rule |
|---|---|---|
| Runtime bindings | `/srv/openclaw-ops/runtime-bindings.json` | strict parsed object; select only exact approved `instance_id` values |
| Kakao view configuration | `/srv/openclaw-ops/nas-views.yaml` | strict parsed object; select the primary Kakao view for each target |
| Kakao membership | read-only CIFS tree `/mnt/nas/kakao-work`, matched package `users/*_<user_id>/membership.json` | regular file only; bind its SHA-256 and sorted `conversation_ids` |
| KWRAG index | approved `release/index-manifest.json` | verified manifest digest and exact conversation-id-to-corpus mapping |

The export targets exact immutable UUID `instance_id` values. Logical names
such as `dev-oc`, `dev-hermess`, `dev-oc-img`, or `dev-hermes-img` are never
substitutes for an instance id. Before A1, a read-only inventory freezes the
two intended source-preview dev targets (currently intended logical accounts:
`dev-oc` and `dev-hermess`) and their exact instance ids. Choosing image-preview
slots later is a separate plan and approval.

All canonical JSON uses UTF-8 without BOM, `ensure_ascii=false`,
lexicographically sorted object keys, compact comma/colon separators,
`allow_nan=false`, no insignificant or trailing bytes, and the array ordering
specified below. The shared primitive is `jsonutil.canonical_json_bytes`.
Security-sensitive loaders first reject duplicate keys, then require the exact
raw bytes to equal `canonical_json_bytes(parsed)`. Non-finite numbers, unpaired
Unicode surrogates, alternate key order, pretty JSON, BOM, and a trailing
newline or space fail closed.
Component payloads are:

1. selected runtime bindings, sorted by `instance_id`, with exactly
   `instance_id`, `linux_account`, `public_host`, `family`, `runtime_class`,
   `gateway_port`, `bridge_port`, and `enabled`;
2. selected primary Kakao view records, sorted by `instance_id`, each containing
   exactly `instance_id`, `slot`, `user_id`, `share`, `corpus`, `package`,
   `paths`, `rooms_bound`, `rooms_missing_media`, and `assigned_at`; `corpus`
   must be `kakao` and `slot` must equal the selected binding's
   `linux_account`;
3. membership records containing `instance_id`, membership-file SHA-256, and
   unique sorted `conversation_ids`, sorted by `instance_id`;
4. the verified KWRAG index-manifest digest.

Each component is independently SHA-256 digested. The combined payload is
exactly:

```json
{
  "schema": "kwrag-grant-source/v1",
  "ops_commit": "<40-lowercase-hex>",
  "runtime_bindings_digest": "sha256:<64-lowercase-hex>",
  "nas_views_digest": "sha256:<64-lowercase-hex>",
  "membership_set_digest": "sha256:<64-lowercase-hex>",
  "index_manifest_digest": "sha256:<64-lowercase-hex>"
}
```

Its canonical digest is `authoritative_state_digest`. Missing/unreadable
sources, writable NAS mounts, ambiguous package matches, duplicate
conversation ownership, an unapproved instance id, an index conversation
without a unique corpus alias, or source drift during the snapshot fails the
whole export closed.
Every selected binding must have `runtime_class == "dev"` and
`enabled == true`; a requested disabled or non-dev target fails the whole
export closed.

For one attachment entry, `runtime_binding_digest` is the canonical JSON
SHA-256 digest of exactly that instance's eight-field runtime-binding record
from item 1 above. It is not the digest of the full binding file or selected
binding array.

## 2. Grant export

OPS publishes a canonical object with exactly these top-level fields:

```json
{
  "version": 1,
  "source_ref": "ops-grant-export:<ops_commit>:<authoritative_state_digest>",
  "source": {
    "schema": "kwrag-grant-source/v1",
    "ops_commit": "<40-lowercase-hex>",
    "runtime_bindings_digest": "sha256:...",
    "nas_views_digest": "sha256:...",
    "membership_set_digest": "sha256:...",
    "index_manifest_digest": "sha256:...",
    "authoritative_state_digest": "sha256:..."
  },
  "generated_at": "2026-07-24T00:00:00Z",
  "expires_at": "2026-07-24T00:15:00Z",
  "grants": [
    {
      "instance_id": "00000000-0000-0000-0000-000000000001",
      "slot_id": "example-openclaw",
      "corpora": ["corpus-a"]
    }
  ]
}
```

Rules:

- validity is 300–3600 seconds;
- `generated_at` may be at most 30 seconds ahead of verifier UTC time;
- `source` contains exactly the fields in section 1 and its combined digest
  must recompute exactly;
- `source_ref` must equal the exact value derived from `source`;
- `instance_id` is a canonical lowercase UUID and unique;
- `slot_id` and corpus aliases match `[A-Za-z0-9._-]+`; slot ids are unique;
- grants sort by `instance_id`, corpora are unique and sorted;
- `grants: []` is the canonical revoke-all state and produces a valid empty
  token projection; readiness stays healthy while every bearer is rejected;
- unknown fields at every level are rejected;
- no token, message text, command line, customer log, or model output appears.

### Publication transaction

OPS owns:

- parent: `/srv/openclaw-ops/kwrag/grants`, `root:root`, `0750`;
- staging: `.staging-grant-<uuid>.json` in the same directory;
- live: `/srv/openclaw-ops/kwrag/grants/current.json`, `root:root`, `0440`.

Parent and files must be non-symlinks; files must be regular with link count
one. OPS writes a complete staging file with exclusive creation, fsyncs it,
reopens and validates bytes/owner/mode/link count, atomically replaces the live
file, and fsyncs the parent. Failure before replacement publishes nothing;
failure after replacement is reported as indeterminate and audited before any
retry. An old export is never given a later expiry.

## 3. Bearer ownership and projection refresh

KWRAG deployment generates high-entropy tokens and owns root-only per-instance
client env files:

`/srv/kwrag-product/runtime/client-env/<instance_id>.env`

The directory is `root:root 0700`; each regular, single-link file is
`root:root 0400` and contains exactly:

```text
KWRAG_SERVICE_URL=http://kwrag:8899
KWRAG_BEARER_TOKEN=<secret>
```

OPS may reference the exact env-file path in an approved attachment plan but
must not read, copy, hash, log, render, or receipt the secret value. Hermes and
OpenClaw adapters consume only these two stable client variables; implementing
those adapters remains with their product owners.

Root creates each bearer with the pinned generator identified by
`generator_source_sha256`, using the kernel CSPRNG for at least 256 generated
bits and an unambiguous base64url encoding. The validator does not estimate
entropy from visible character variety. Root opens the env file with
`O_NOFOLLOW`, strictly proves two unique keys, the exact URL, a final newline,
and a bearer matching the generated in-memory value; it never prints or hashes
the bearer.

For each env file, root publishes a non-secret receipt at
`/srv/kwrag-product/runtime/client-env-receipts/<instance_id>.json`,
`root:kwrag_rt 0440`, regular, single-link, canonical JSON. Schema
`kwrag-client-env-receipt/v1` contains exactly `schema`, `instance_id`,
`action_script_sha256`, `generator_source_sha256`, `entropy_source`,
`generated_bits`, `encoding`, `env_file`, `env_file_uid`, `env_file_gid`,
`env_file_mode`, `env_file_nlink`, `env_file_dev`, `env_file_inode`,
`env_file_size`, `env_file_mtime_ns`, `keys`, `service_url_verified`,
`token_matches_projection`, `projection_digest`,
`projection_publication_receipt_digest`, `created_at`, and `valid_until`.
`keys` is exactly
`["KWRAG_BEARER_TOKEN","KWRAG_SERVICE_URL"]`, sorted. `entropy_source` is
`kernel_csprng`, `generated_bits >= 256`, and `token_matches_projection` is
proven only by an in-memory comparison during refresh. Receipt identity is its
canonical digest; no token-derived bytes occur in it.

The same approved root action first publishes the projection and its
publication receipt, then re-`lstat`s the live env file, verifies that the
in-memory token maps to that exact published projection, and only then creates
the client-env receipt. `projection_publication_receipt_digest` binds the
publication transaction id and sequence; the client-env receipt does not copy
those lineage fields. `valid_until <= projection.expires_at`. A changed env
device/inode/size/mtime, non-current publication receipt, or recombination with
an older projection fails closed. Metadata detects drift; it does not replace
root generator provenance or the in-memory secret comparison.

The KWRAG root refresh derives each projection variable name, rather than
accepting it from OPS:

`KWRAG_TOKEN_<INSTANCE_UUID_WITHOUT_HYPHENS_IN_UPPERCASE>`

It loads token values only into the short-lived projection-builder environment.
The live projection is:

`/srv/kwrag-product/runtime/auth/token-projection.json`

The auth directory is a real directory `root:kwrag_rt 0750`. The root refresh
creates exactly one direct child
`.staging-projection-<canonical-lowercase-uuid>` as `root:root 0700` on the same
device. Production `kwrag-build-projection` runs only inside the approved root
refresh in the host root mount, user, and NSS namespaces. The approved
launcher/action digest pins the exact `--staging-root`; a container namespace,
numeric group fallback, failed `grp.getgrnam("kwrag_rt")`, or skipped identity
check fails closed.

On POSIX the builder opens the auth root with `O_DIRECTORY|O_NOFOLLOW`, resolves
the expected gid with `grp.getgrnam("kwrag_rt").gr_gid`, and verifies the fd is
a real directory `uid=0,gid=<resolved>,mode=0750` with a valid directory link
count. It opens the direct child relative to that fd and verifies
`uid=0,gid=0,mode=0700`, real directory, direct-child UUID name, and the same
`st_dev`. It creates the target relative to the pinned staging fd with
`O_CREAT|O_EXCL|O_NOFOLLOW`, then verifies the opened fd is `root:root 0600`,
regular, single-link, and on the same device. It writes exactly
`canonical_json_bytes(projection)` and fsyncs the fd. It does not use a
path-based temporary rename.

It is staged on the same filesystem, fully verified, published as
`root:kwrag_rt 0440` with file and parent fsync, and never writable by
`kwrag_rt`. Projection validity is also 300–3600 seconds.
Projection `generated_at` has the same 30-second maximum future skew.

`kwrag-build-projection` is a staging-artifact builder only. Its output must be
exactly `<root-created-.staging-projection-UUID>/token-projection.json`; every
other parent or filename is rejected. It does not implement the publication
transaction. The separately approved root refresh owns exclusive staging,
owner/mode/link verification, fsync, atomic live replacement, parent fsync,
and the publication receipt. Calling the builder directly on the live path is
forbidden.

For TTL `T`, the refresh margin is:

`max(60, min(900, floor(T / 3))) seconds`

and the deadline is `expires_at - margin`. This is defined for the entire
allowed range; for a 900-second grant the margin is 300 seconds.

KWRAG checks projection file identity on every readiness and search request.
An atomic replacement is loaded without restart. A changed missing, symlinked,
non-regular, malformed, expired, or manifest-mismatched file immediately makes
readiness/search fail closed; the previously cached projection is not used as
fallback.
Recovery uses current authoritative state. Restoring an older projection is
forbidden.
Within one process, an older `generated_at`, or the same generation with
different bytes, is rejected. Across restart, root compares the last live
publication receipt and rejects non-monotonic generation/source/projection
lineage before replacement.
An atomic re-publication with the same `generated_at` and exact same
`projection_digest` is an idempotent recovery and is accepted; same generation
with different bytes is always rejected.
The loader rejects duplicate keys and then requires raw bytes to equal the
canonical encoding. `projection_digest` is SHA-256 of those exact on-disk bytes
and equals the publication receipt's `live_file_sha256`.

### Projection publication journal and receipt

The authoritative receipt is
`/srv/kwrag-product/runtime/auth/projection-publication-receipt.json`; the
crash journal is `projection-publication-intent.json` in the same directory.
Both are canonical JSON, non-symlink regular single-link files. The receipt is
`root:kwrag_rt 0440`; the intent is `root:root 0400`.

The intent schema is `kwrag-projection-publication-intent/v1` with exactly
`schema`, `transaction_id`, `sequence`, `action_script_sha256`,
`grant_export_digest`, `source_digest`, `projection_digest`, `generated_at`,
`expires_at`, `staged_file_sha256`, `previous_receipt_digest`, and
`prepared_at`. The receipt schema is `kwrag-projection-publication-receipt/v1`
with exactly the same lineage fields except `staged_file_sha256` is named
`live_file_sha256` and `prepared_at` is named `published_at`. Its identity is
the canonical digest of the complete receipt object. `sequence` starts at one
and increases by exactly one; `previous_receipt_digest` is null only at one.

The transaction order is: publish+fsync intent; revalidate staging and current
receipt; replace+fsync live projection; publish+fsync receipt; unlink+fsync
intent. On restart, no intent requires live bytes and receipt to match. With an
intent, an unchanged old live file aborts the prepared transaction; a live file
matching the intent finalizes only the receipt without replacing live bytes;
any third state is `projection_publication_indeterminate` and blocks refresh,
service start, and restore until a read-only audit resolves it. The root
refresh never reconstructs lineage from timestamps alone.

Initial token installation may precede attachment. Rotation v1 is explicitly a
fail-closed bounded-outage operation: atomically replace the root env file with
the new token, publish a projection containing only that token, and recreate
the single approved client so it reads the new env file. A temporary `401`
between projection publication and client recreation is acceptable; widening
authorization or restoring an old projection is not.

## 4. Declarative dev attachment

Runtime bindings remain binding truth and are not extended ad hoc. OPS owns a
separate strict ledger proposed at:

`/srv/openclaw-ops/kwrag-attachments.json`

The ledger top level contains exactly `schema`, `ops_commit`, `generated_at`,
and `entries`; schema is `kwrag-attachments/v1`. Entries sort by
`instance_id`. Each entry contains exactly:

- canonical `instance_id`;
- `enabled` boolean;
- external network name `kwrag_net`;
- service alias `kwrag`;
- service port `8899`;
- exact `client_env_file`;
- exact approved client `wrapper_image_digest` and `product_image_digest`;
- selected `runtime_binding_digest`;
- immutable attachment `plan_digest`.

For each entry, the plan payload excludes `plan_digest` and is exactly:

```json
{
  "schema": "kwrag-attachment-plan/v1",
  "ops_commit": "<40-lowercase-hex>",
  "instance_id": "<canonical-uuid>",
  "enabled": true,
  "network": "kwrag_net",
  "alias": "kwrag",
  "port": 8899,
  "client_env_file": "/srv/kwrag-product/runtime/client-env/<instance_id>.env",
  "wrapper_image_digest": "sha256:...",
  "product_image_digest": "sha256:...",
  "runtime_binding_digest": "sha256:..."
}
```

`plan_digest` is the canonical JSON digest of that payload. The live wrapper
label must attest the exact embedded product digest. `ledger_digest` is the
canonical JSON digest of the complete ledger including plan digests.
The authoritative ledger is strict UTF-8 JSON parsed with duplicate-key
rejection; YAML, aliases, tags, implicit typing, comments, and parser-dependent
normalization are not accepted.

`network_plan_digest` in the KWRAG execution approval is the canonical digest
of exactly this KWRAG-owned payload:

```json
{
  "schema": "kwrag-network-plan/v1",
  "name": "kwrag_net",
  "driver": "bridge",
  "internal": true,
  "attachable": false,
  "ipv6": false,
  "labels": {"co.ji-tech.owner": "kwrag-product"}
}
```

Unknown network fields or a live network whose driver/internal/attachable/IPv6
or label state differs from this object fail closed.

Unknown fields, customer instances, unfrozen dev instances, duplicate
instances, or unapproved plan digests fail closed. `enabled=false` means the
network and env-file references are absent from the rendered service.
Canonical Kakao view `paths` and `rooms_missing_media` arrays are unique and
lexicographically sorted.

The rendered Compose model is declarative:

```yaml
networks:
  kwrag_net:
    external: true
    name: kwrag_net
```

The selected service joins that network with alias `kwrag`. Imperative
`docker network connect` is not an accepted steady state. OPS never creates,
deletes, or imperatively connects `kwrag_net`; KWRAG deployment owns its
lifecycle. Plan reports an absent network as `external_network_absent`. Apply
checks it before Compose mutation and refuses with the same code. Runtime
manifests must preserve the attachment-plan digest, instance id, external
network, alias, env-file path, and enabled state, but never the env contents.

This schema/renderer is a required future OPS extension, not current OPS
functionality and not authorized by this document.

Before rendering or apply, OPS performs metadata-only client-env preflight. The
path must exactly equal
`/srv/kwrag-product/runtime/client-env/<instance_id>.env`; every parent and the
file are checked with `lstat`; the file is non-symlink regular, link count one,
`root:root 0400`. OPS does not open the file. Failure is
`client_env_identity_invalid`. A KWRAG root receipt separately proves the exact
two-key content without printing or hashing secret bytes.

## 5. A1 and A2 proof schema

Each proof is a non-secret JSON receipt bound to:

- KWRAG image id and immutable runtime-input digests;
- exact client `instance_id`, container id, separate wrapper and embedded
  product image digests, live wrapper-label attestation, and runtime-binding
  digest;
- attachment-plan digest and external-network id;
- index manifest, pipeline, projection, and source digests.

### A1 request contract

From each exact approved dev container:

1. `GET http://kwrag:8899/healthz` must return HTTP 200 with JSON pointer
   `/version == "1"` and `/ok == true`.
2. `GET http://kwrag:8899/readyz` must return HTTP 200 with
   `/version == "1"`, `/ready == true`, `/projection_status == "current"`,
   and approved values at `/index_manifest`, `/pipeline_fingerprint`, and
   `/projection_digest`.
3. `POST http://kwrag:8899/v1/search` uses JSON content type, bearer auth, and
   body `{"query":"<non-customer synthetic canary>","max_results":1,
   "corpus":"<authorized-alias>","request_id":"<unique-id>"}`.
   It passes only with HTTP 200, `/version == "1"`, `/results` length at most
   one, and every result `/corpus` equal to the requested alias.
4. Under `boundary_profile == "partial-grant"`, the same token requesting one
   known unauthorized alias must return HTTP 403 with
   `/error/code == "forbidden_corpus"` and no results. Under
   `boundary_profile == "full-manifest-grant"`, the grant corpora must equal the
   exact active manifest alias set; no corpus-denial claim is made, and a
   separately generated invalid bearer must return HTTP 401 with
   `/error/code == "missing_or_invalid_token"` and no results.

The unauthorized alias is selected from the active verified index manifest,
must not be present in that instance grant, and is frozen in the non-secret A1
plan. A nonexistent or arbitrary alias is not accepted as a boundary proof.
The full-manifest profile is permitted only with exact set equality and is
reported as token-boundary-only; it must never be presented as a successful
corpus-boundary negative test.

Receipts record method, status, result count, booleans, digests, duration, and
error code only. They redact bearer values, query text, result text, result
ids/source ids, customer identifiers, and response bodies.

### A2

After normal OPS apply/recreate, A2-enable repeats A1 and proves that the
replacement container obtained the attachment from the exact approved ledger
and runtime-manifest digest. It does not claim the historical origin of Docker
API calls or that an imperative connection never occurred outside the bounded
window. The accepted claim is only the continuously observed approved action,
labels, expected attachment, and final state described below.

The immutable action transcript uses schema
`kwrag-compose-action-transcript/v1` and contains exactly `schema`, `action_id`,
`proof_type`, `instance_id`, `daemon_id_before`, `daemon_id_after`,
`window_started_at`, `window_completed_at`, `compose_project`,
`compose_service`, `compose_plan_digest`, `runtime_manifest_digest`,
`previous_container_id`, `target_container_id`, `target_network_id`,
`collector_status`, `events`, and `terminal_cursor`. `previous_container_id` is
a string or null; null is allowed only when the approved pre-state proves that
no previous container existed.

Each event preserves exact `sequence`, `timeNano`, `type`, `action`, `actor_id`,
canonical sorted whitelisted `attributes`, and `event_digest`. The event digest
excludes itself; transcript identity is the digest of the complete canonical
transcript. `collector_status` is one of `complete`, `incomplete`,
`daemon_changed`, `gap`, `timeout`, or `error`; only `complete` can pass. The
stream is connected before the action starts. Daemon drift, disconnect/parse
gap, duplicate event digest, decreasing `timeNano`, or terminal-drain failure
fails closed. `terminal_cursor` contains exactly `daemon_id`, `last_sequence`,
`last_timeNano`, and `last_event_digest`.

For `a2_enable` and `a2_restore`, exactly one matching connect exists for the
target container and target network and unmatched target attachments are zero.
For `a2_disable`, replacement-container connects to the target network are zero;
previous-container/network events are limited to the approved action's
correlated disconnect/destroy, and final live inspection proves the replacement
has no target network. Caller origin is not attested. Enable, disable, and
restore are separate immutable actions and approvals. Ports 8899 and 18991
remain unchanged and no customer slot attaches.

### Exact proof receipts

A1 uses schema `kwrag-a1-proof/v1`; A2 uses `kwrag-a2-proof/v1`.
`proof_type` is exactly one of `a1_connectivity`, `a2_enable`, `a2_disable`, or
`a2_restore`. `terminal_status` is one of `passed`, `failed`, `incomplete`,
`cancelled`, or `indeterminate`. Every proof object contains exactly `schema`,
`proof_type`, `action_id`, `instance_id`, `container_id`,
`wrapper_image_digest`, `product_image_digest`, `runtime_binding_digest`,
`runtime_manifest_digest`, `attachment_plan_digest`, `network_plan_digest`,
`network_id`, `kwrag_execution_approval_digest`,
`ops_attachment_approval_digest`, `index_manifest_digest`,
`pipeline_fingerprint`, `projection_digest`, `grant_source_digest`,
`boundary_profile`, `started_at`, `completed_at`, `terminal_status`, `checks`,
`action_transcript_digest`, and `all_checks_passed`.

`action_id` is a globally unique canonical UUID and the deduplication key is
`(proof_type,action_id,instance_id)`. Each check contains exactly `sequence`,
`name`, `passed`, `evidence`, and `evidence_digest`. `evidence_digest` is the
canonical digest of the complete redacted `evidence` object. The validator owns
a name-specific exact evidence field allowlist; missing or unknown keys fail
closed. HTTP evidence contains only allowed method/path/request-id/status/error/
result-count/JSON-pointer assertion/duration and response-digest fields, never
bearer, query, raw body, result text, or source id. Runtime, manifest, image,
env-reference, network, and transcript checks likewise contain only exact
expected/observed digests, ids, counts, booleans, cursor, and status fields.

The exact ordered required check names are:

- A1: `healthz`, `readyz`, `authorized_search`, then `unauthorized_corpus` for
  partial grant or `invalid_token` for full-manifest grant;
- A2 enable/restore: `compose_apply_succeeded`, `runtime_manifest_match`,
  `replacement_container_match`, `client_env_reference_present`,
  `network_plan_match`, `network_attachment_match`,
  `action_transcript_complete`, `healthz`, `readyz`, `authorized_search`, then
  profile-specific `unauthorized_corpus` or `invalid_token`;
- A2 disable: `compose_apply_succeeded`, `runtime_manifest_attachment_absent`,
  `replacement_container_match`, `replacement_container_network_absent`,
  `env_reference_absent`, `action_transcript_complete`.

`all_checks_passed` is recomputed by the validator and must match the stored
value; every required check occurs exactly once in sequence. A1 requires
`action_transcript_digest=null`; every A2 requires a SHA-256 transcript digest.

A1 proofs live at
`/srv/kwrag-product/runtime/proofs/a1/<action_id>.json`; A2 proofs live at
`/srv/openclaw-ops/kwrag/proofs/a2/<action_id>.json`. Parents are `root:root
0750`; proof files are immutable canonical JSON, `root:root 0440`, regular,
single-link, created with `O_EXCL`, followed by file and parent fsync. There is
no mutable proof index. The verifier strictly scans both exact directories and
rejects a symlink, non-regular entry, wrong owner/mode/name, noncanonical bytes,
duplicate action/dedup key, or same key with a different digest.

Revalidating the same immutable proof/digest against the same live binding is
idempotent verification, not one-time consumption. Referencing it from another
action, instance, container, image, plan, approval set, or incompatible
promotion state is cross-binding reuse and fails closed. V1 does not claim
one-time proof consumption.

## 6. Separate approval objects and eligibility

Existing OPS product-image approval does not approve KWRAG inputs or
attachments.

1. **KWRAG execution approval** is canonical JSON schema
   `kwrag-execution-approval/v1`, owned by KWRAG deployment, with exactly
   `schema`, `candidate_image_digest`, `build_input_digest`,
   `model_release_digest`, `index_manifest_digest`, `config_digest`,
   `grant_source_digest`, `projection_digest`, `client_env_receipts`,
   `network_plan_digest`, `action_script_sha256`, `approved_at`, and
   `expires_at`. `client_env_receipts` is the unique array of exact
   `{instance_id,receipt_digest}` records sorted by `instance_id`. Its object
   identity is the canonical JSON digest.
2. **OPS attachment approval** is canonical JSON schema
   `kwrag-attachment-approval/v1`, owned by shared OPS, with exactly `schema`,
   `ops_commit`, `runtime_bindings_digest`, `ledger_digest`,
   `grant_export_digest`, `approved_plan_digests`, `instance_ids`,
   `approved_at`, and `expires_at`.
   Arrays are sorted and unique; its object identity is the canonical JSON
   digest.
3. A root action approval references exactly one immutable action and the
   required approval-object digests; it does not substitute for either object.
4. **KWRAG promotion approval** is canonical JSON schema
   `kwrag-promotion-approval/v1` with exactly `schema`,
   `promotion_action_id`, `kwrag_execution_approval_digest`,
   `ops_attachment_approval_digest`, `records`, `approved_at`, and `expires_at`.
   `records` contains exact `{instance_id,a1_proof_digest,a2_proof_type,
   a2_proof_digest,post_state_measurement_digest}` objects sorted uniquely by
   `instance_id`; `a2_proof_type` is `a2_enable` or `a2_restore`. Records have
   exact set equality with enabled attachment instances. It can be created only
   after every bound proof and post-state object is complete and passing.

Before any KWRAG execution, the root verifier must cross-check the grant
`source.ops_commit` and `source.runtime_bindings_digest` against the exact OPS
attachment approval and must cross-check the attachment `ledger_digest` and
every plan digest plus the canonical grant-export digest. Exact set equality
is required between enabled ledger entries, approved plan digests, and
approved instance ids. The product validator checks syntax and canonical
consistency; approval authenticity is deliberately a root execution gate, not
inferred from a 40-hex string.

Enabled attachment instances, projection token instances, client-env receipt
instances, and KWRAG execution approval receipt records must be exact-equal
sets. Every receipt digest must match current receipt bytes and current
projection publication lineage. The execution approval expiry is no later than
the projection expiry or any bound client-env receipt `valid_until`.

KWRAG approval lives at
`/srv/kwrag-product/runtime/approvals/current.json`; OPS approval lives at
`/srv/openclaw-ops/kwrag/approvals/current.json`. Parents are `root:root 0750`;
files are non-symlink regular, link count one, `root:root 0440`, and use
same-directory fsync+atomic replace+parent fsync. Timestamps are UTC RFC3339,
validity is 300–3600 seconds, future skew is at most 30 seconds, and expiry
fails closed.
Promotion approval lives at
`/srv/kwrag-product/runtime/approvals/promotion-current.json` with the same
identity, publication, timestamp, and expiry rules.

For every promotion approval, including idempotent reuse of an older valid
proof, the root promotion verifier publishes one immutable canonical
`kwrag-promotion-post-state/v1` object for each promotion action and instance at
`/srv/kwrag-product/runtime/proofs/promotion/<promotion_action_id>/<instance_id>.json`.
It contains exactly `schema`, `promotion_action_id`, `measured_at`,
`instance_id`, `container_id`, `wrapper_image_digest`, `product_image_digest`,
`runtime_binding_digest`, `runtime_manifest_digest`,
`attachment_plan_digest`, `network_plan_digest`, `network_id`,
`kwrag_execution_approval_digest`, `ops_attachment_approval_digest`,
`index_manifest_digest`, `pipeline_fingerprint`, `projection_digest`,
`grant_source_digest`, `a1_proof_digest`, `a2_proof_type`, `a2_proof_digest`,
`checks`, and `passed`.

`checks` is the exact ordered set `current_approvals`, `current_images`,
`current_runtime_manifest`, `current_network_attachment`, `current_projection`,
`proof_binding_match`. `passed` is validator-derived and true only when each
check occurs exactly once and passes. The file follows the same canonical-byte,
`O_EXCL`, root owner/mode/link-count, file fsync, parent fsync, and immutability
rules as other proofs. Its exact-byte SHA-256 is
`post_state_measurement_digest`. A transient measurement not bound into the
promotion record cannot authorize promotion. The record, immutable post-state
object, current live state, current approvals, and bound A1/A2 proofs must all
match exactly.

A candidate may execute only after:

1. its image contains the tested live-projection reload behavior;
2. runtime-foundation verification passes;
3. the grant export validates against sections 1–2;
4. root projection refresh and non-secret receipt are installed and verified;
5. the external network exists under KWRAG ownership;
6. Hermes and OpenClaw owners have each supplied a separately tested and
   approved exact image digest containing an adapter for
   `KWRAG_SERVICE_URL`/`KWRAG_BEARER_TOKEN`;
7. A1/A2 exact dev plans and both pre-execution approval objects exist;
8. candidate and every runtime input digest are separately approved.

These eight items authorize only the bounded dev canary execution needed to
produce A1/A2 proofs. Promotion, persistent enabled attachment, or any claim of
integration success additionally requires a current KWRAG promotion approval
whose per-instance proof and post-state digests exactly match the successful
immutable objects and whose instance/image/plan/approval sets match the live
state. Reusing an immutable proof in a new promotion approval still requires a
new bound post-state measurement and exact current-live-state revalidation.
Missing, failed, unbound, cross-bound, or mismatched objects fail promotion
closed.

The existing candidate
`sha256:36d97eb7152d5454e7efcaa51ea4f4d74ca4d95713a85aac87f01dee9b9fa017`
does not contain live projection reload and is not eligible. Runtime-foundation
PASS alone is insufficient.
