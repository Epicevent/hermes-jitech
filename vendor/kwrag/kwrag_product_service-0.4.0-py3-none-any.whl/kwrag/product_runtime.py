"""Product-native KWRAG runtime over the slot's mounted Kakao package.

The product supplies only the source mount, a receipt destination, and one
caller-explicit query.  KWRAG observes its current source identity itself.
No ops tool, approval record, capsule, fixed-generation request, or generated
binding participates in this API.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Sequence

from .engines.nas_messages_fts_v1 import (
    BACKEND_ID,
    NasMessagesFtsAdapter,
    NasMessagesFtsError,
)
from .jsonutil import canonical_json_bytes
from .operation import ReceiptWriter
from .slot_api import SlotSearchApplication, SlotSearchExchange
from .slot_mount import SlotMountError


PRODUCT_PIPELINE_FINGERPRINT = "sha256:" + hashlib.sha256(
    canonical_json_bytes(
        {
            "schema_version": "kwrag-kakao-product-pipeline-v1",
            "backend_id": BACKEND_ID,
            "source": "slot-mounted-kakao-user-package",
            "invocation": "caller-explicit",
            "automatic_query": False,
            "provider_policy": None,
        }
    )
).hexdigest()


class ProductRuntimeError(ValueError):
    """The mounted source cannot serve the product retrieval call."""


@dataclass(frozen=True)
class ProductRuntimeIdentity:
    source_generation: str
    index_manifest: str
    pipeline_fingerprint: str
    digest: str


class _MountedPackageScope:
    def __init__(self, adapter: NasMessagesFtsAdapter):
        self._adapter = adapter
        self.mount_root = adapter.package_root
        self.index_root = adapter.package_root
        self.readonly_required = True
        self.available_rooms = adapter.allowed_conversation_ids
        self.manifest = SimpleNamespace(
            digest=adapter.source_generation,
            corpus_snapshot=adapter.source_generation,
            rooms={room: {} for room in adapter.allowed_conversation_ids},
        )

    def assert_current(self) -> None:
        try:
            self._adapter.assert_current()
        except NasMessagesFtsError as exc:
            raise SlotMountError("mounted Kakao package changed") from exc

    def select_rooms(self, requested: Sequence[str] | None = None) -> list[str]:
        available = set(self.available_rooms)
        if requested is None:
            return sorted(available)
        if (
            isinstance(requested, (str, bytes))
            or not requested
            or len(requested) != len(set(requested))
            or set(requested) - available
        ):
            raise SlotMountError("requested corpus is outside the mounted package")
        return list(requested)


class _MountedPackagePipeline:
    def __init__(self, adapter: NasMessagesFtsAdapter):
        self._adapter = adapter

    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]:
        hits = self._adapter.search_messages(
            query,
            conversation_ids=rooms,
            limit=k,
        )
        return {
            "hits": [
                {
                    "room": hit.conversation_id,
                    "level": "message",
                    "seg_id": hit.message_id,
                    "message_ids": [hit.message_id],
                    "text": hit.text,
                    "score": hit.score,
                }
                for hit in hits
            ],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": BACKEND_ID,
                "stages": [
                    {
                        "stage_id": "messages_fts5_search",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": len(rooms),
                        "output_count": len(hits),
                        "model": None,
                        "revision": self._adapter.source_generation,
                    }
                ],
                "candidate_count": len(hits),
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }


class KakaoProductRuntime:
    """One product-owned handle to the currently mounted Kakao source."""

    def __init__(
        self,
        *,
        package_root: Path,
        receipt_path: Path,
        max_concurrent: int = 1,
    ):
        root = Path(package_root)
        self._adapter = NasMessagesFtsAdapter(
            root / "messages.sqlite",
            root / "membership.json",
        )
        scope = _MountedPackageScope(self._adapter)
        identity_body = {
            "schema_version": "kwrag-product-runtime-identity-v1",
            "source_generation": self._adapter.source_generation,
            "index_manifest": scope.manifest.digest,
            "pipeline_fingerprint": PRODUCT_PIPELINE_FINGERPRINT,
        }
        self.identity = ProductRuntimeIdentity(
            source_generation=self._adapter.source_generation,
            index_manifest=scope.manifest.digest,
            pipeline_fingerprint=PRODUCT_PIPELINE_FINGERPRINT,
            digest="sha256:"
            + hashlib.sha256(canonical_json_bytes(identity_body)).hexdigest(),
        )
        try:
            self.application = SlotSearchApplication(
                pipeline=_MountedPackagePipeline(self._adapter),
                scope=scope,
                pipeline_fingerprint=PRODUCT_PIPELINE_FINGERPRINT,
                receipt_writer=ReceiptWriter(Path(receipt_path)),
                max_concurrent=max_concurrent,
            )
        except Exception:
            self._adapter.close()
            raise

    def search_exchange(self, request: dict[str, Any]) -> SlotSearchExchange:
        return self.application.search_exchange(request)

    def close(self) -> None:
        self._adapter.close()

    def __enter__(self) -> "KakaoProductRuntime":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


def open_kakao_product_runtime(
    *,
    package_root: Path,
    receipt_path: Path,
    max_concurrent: int = 1,
) -> KakaoProductRuntime:
    """Open the actual mounted source without an ops-generated binding."""

    try:
        return KakaoProductRuntime(
            package_root=package_root,
            receipt_path=receipt_path,
            max_concurrent=max_concurrent,
        )
    except (NasMessagesFtsError, OSError, ValueError) as exc:
        raise ProductRuntimeError("mounted Kakao product source is unavailable") from exc


__all__ = [
    "KakaoProductRuntime",
    "PRODUCT_PIPELINE_FINGERPRINT",
    "ProductRuntimeError",
    "ProductRuntimeIdentity",
    "open_kakao_product_runtime",
]
